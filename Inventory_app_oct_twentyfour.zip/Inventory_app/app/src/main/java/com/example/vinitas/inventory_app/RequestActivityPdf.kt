package com.example.vinitas.inventory_app


import android.app.Notification
import android.app.Notification.*
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent

import android.app.ProgressDialog
import android.content.*
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.print.PdfView
import android.print.PrintAttributes
import android.print.PrintManager
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.app.NotificationCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil

import dmax.dialog.SpotsDialog
import kotlinx.android.synthetic.main.activity_request_pdf.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

import java.util.*

@RequiresApi(Build.VERSION_CODES.LOLLIPOP)

class RequestActivityPdf : AppCompatActivity(){

    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""






    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""


    var befnm=String()
    var request_datedup=String()
    var reqest_datedup=String()
    var supp_namedup=String()
    var supp_gstdup=String()
    var supp_addredup=String()

    var htmlDocument= String()


    var supplieridfr= String()

    var sendrequest=String()
    var edclick= String()

    var ids = arrayOf<String>()

    val progressBar=null
    private val progressBarStatus = 0;
    private val progressBarHandler =  Handler();
     // --- Add these variables
    private val  mNotifyManager: NotificationManager? = null
    private val mBuilder= NotificationCompat.Builder(this)

    private var fileSize = 0;



    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var grosstotArray = arrayListOf<String>()

    var cessArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var igstArray = arrayListOf<String>()
    var cgstArray = arrayListOf<String>()
    var sgstArray = arrayListOf<String>()
    var igsttotArray = arrayListOf<String>()
    var cesstotalArray = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var imageArray = arrayListOf<String>()
    var singrosstot= arrayListOf<String>()
    var  idproArray = arrayListOf<String>()


    var reqid = String()
    var reprnms = String()
    var reqdt = String()
    var reqliid = String()
    var restimt = String()
    var reqnm = String()
    var reqmail = String()
    var reqph = String()
    var downstatus= String()
    var tt= arrayListOf<String>()

   var updatestatus= String()

    var supnm = String()
    var supadd1 = String()
    var supadd2 = String()
    var supadd3 = String()
    var supgst = String()
    var supphone = String()
    var supcity = String()
    var supstate = String()
    var idli= String()
    var brky= String()
    var tallyar= String()
    var receivear= String()
    var status= String()
    var igsttt= String()
    var cgsttt= String()
    var sgsttt= String()
    var cestt= String()
    var grosstt= String()
    var igstt= String()
    var cgstt= String()
    var sgstt= String()
    var cesttt= String()
    var grosst= String()
    var oriky= String()
    var imglinks= String()
    var grossto = String()
    var igstto = String()
    var cgstto = String()
    var sgstto = String()
    var cessto = String()

    var nmscomtt= String()
    var addre= String()


    var names= String()

var YES_ACTION= String()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private var myWebView: WebView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_pdf)


        val webView = findViewById<WebView>(R.id.webviews) as WebView

        myWebView = webView


        net_status()        //Check net status

        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@RequestActivityPdf) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }


         //Define No connection view when inetrnet connection is off.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.container)

        val bundle = intent.extras
        var a = bundle.get("pnm") as ArrayList<String>

        val dsy = bundle.get("phsn") as ArrayList<String>
        val ly = bundle.get("pmanu") as ArrayList<String>
        val fy = bundle.get("barcode") as ArrayList<String>
        val gy = bundle.get("quan") as ArrayList<String>
        val hy = bundle.get("price") as ArrayList<String>
        val ky = bundle.get("tot") as ArrayList<String>
        val kygro = bundle.get("grosstotarr") as ArrayList<String>

        val my = bundle.get("cessup") as ArrayList<String>
        val ny = bundle.get("igst") as ArrayList<String>
        val cy = bundle.get("cgst") as ArrayList<String>
        val sy = bundle.get("sgst") as ArrayList<String>
        val oy = bundle.get("igsttotal") as ArrayList<String>
        val py = bundle.get("cesstotarray") as ArrayList<String>
        val iddd = bundle.get("idsofli") as ArrayList<String>
        val idtally = bundle.get("tallyarray") as ArrayList<String>
        val idrec = bundle.get("receivedarray") as ArrayList<String>

        val idsar = bundle.get("ids") as Array<String>


        try {
            nmscomtt = intent.getStringExtra("nm")
            addre = intent.getStringExtra("addre")
        }
        catch (e:Exception){

        }


        try{
            supplieridfr=intent.getStringExtra("supplieridfr")
        }
        catch (e:Exception){

        }


        ids=idsar.clone()

        try {
            val immy = bundle.get("image") as ArrayList<String>
           tt=immy
        }
        catch(e:Exception){

        }


        try{
            edclick=intent.getStringExtra("edclick")

        }
        catch (e:Exception)
        {

        }



        val idpros = bundle.get("idpro") as ArrayList<String>
        idproArray = idpros











        //Purchase request

        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr


            println("PURCHASE REQUEST TRANSFER NEXT"+transferpurreq)


        }
        if (expr != null) {
            exportpurreq = expr
        }


        //Purchase order

        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")
        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }


        //Supplier Invoice

        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }


        pronameArray = a
        hsnArray = dsy
        manufacturerArray = ly
        barcodeArray = fy
        quantityArray = gy
        priceArray = hy
        totArray = ky
        grosstotArray = kygro

        cessArray = my
        igstArray = ny
        cgstArray = cy
        sgstArray = sy
        igsttotArray = oy
        cesstotalArray = py
        keyArray = iddd
        tallyArray = idtally
        receivedArray = idrec
        try {
            imageArray = tt
        } catch (e: Exception) {

        }



        try {
            val a = intent.getStringExtra("reqid")
            reqid = a

            val c = intent.getStringExtra("reqdate")
            reqdt = c

            val k=intent.getStringExtra("imlinks")
            imglinks=k


    } catch (e: Exception) {

    }

        try{
            sendrequest=intent.getStringExtra("sendrequest")
        }
        catch (e:Exception){

        }


        try{

            var fcc=intent.getStringExtra("updatestatus")
            updatestatus=fcc
        }
        catch (e:Exception){

        }

        try {
            val b = intent.getStringExtra("reqname")
            reqnm = b

            val s = intent.getStringExtra("status")
            status = s
            val o = intent.getStringExtra("reqest")
            restimt = o
            val d = intent.getStringExtra("reqmail")
            reqmail = d

        }
        catch (e:Exception){
            val o = intent.getStringExtra("reqest")
            restimt = o
            val d = intent.getStringExtra("reqmail")
            reqmail = d
        }


            val ig = intent.getStringExtra("igsttot")
            igsttt = ig


            val cg = intent.getStringExtra("cgsttot")
            cgsttt = cg


            val sg = intent.getStringExtra("sgsttot")
            sgsttt = sg


            val cessg = intent.getStringExtra("cesstot")
            cestt = cessg


            val gt = intent.getStringExtra("grosstot")
            grosstt = gt


        var nm=intent.getStringExtra("names")
      names=nm

        try{
            befnm=intent.getStringExtra("befnm")
            request_datedup=intent.getStringExtra("request_datedup")
            reqest_datedup=intent.getStringExtra("reqest_datedup")
            supp_namedup=intent.getStringExtra("supp_namedup")
            supp_gstdup=intent.getStringExtra("supp_gstdup")
            supp_addredup=intent.getStringExtra("supp_addredup")
        }
        catch (e:Exception){

        }


        try {

            val nm = intent.getStringExtra("reprnms")
            reprnms = nm

            val lii = intent.getStringExtra("reqliid")
            reqliid = lii
        }
        catch (e:Exception){
            val lii = intent.getStringExtra("reqliid")
            reqliid = lii
        }

       try {
           val f = intent.getStringExtra("supnm")
           supnm = f
           println("SUPPPP NNNNNAAAMMME" + supnm)
           val g = intent.getStringExtra("supadd1")
           supadd1 = g
           val m = intent.getStringExtra("supgst")
           supgst = m
           val j = intent.getStringExtra("supcity")
           supcity = j
           val k = intent.getStringExtra("supstate")
           supstate = k
           val l = intent.getStringExtra("supph")
           supphone = l

           val h = intent.getStringExtra("supadd2")
           supadd2 = h
           val i = intent.getStringExtra("supadd3")
           supadd3 = i
       }
       catch (e:Exception){
           val m = intent.getStringExtra("supgst")
           supgst = m

           val l = intent.getStringExtra("supph")
           supphone = l

           val g = intent.getStringExtra("supadd1")
           supadd1 = g
           val h = intent.getStringExtra("supadd2")
           supadd2 = h
           val i = intent.getStringExtra("supadd3")
           supadd3 = i
       }

        val sky=intent.getStringExtra("brky")
        oriky=sky



           /* if (supnm.isNotEmpty()) {
                suppliernm.setText(supnm)
            } else {
                suppliernm.setText("-")
            }


            //Supphone

            if (supphone.isNotEmpty()) {
                supplierph.setText(supphone)
            } else {
                supplierph.setText("-")
            }


            //Gross tot
            if (grosstt.isNotEmpty()) {
                gross.setText(grosstt)
            } else {
                gross.setText("-")
            }

            //IGST TOT
            if (igsttt.isNotEmpty()) {
                igsttotal.setText(igsttt)
            } else {
                igsttotal.setText("-")
            }

            //CGST TOT
            if (cgsttt.isNotEmpty()) {
                cgsttotal.setText(cgsttt)
            } else {
                cgsttotal.setText("-")
            }

            //SGST TOT
            if (sgsttt.isNotEmpty()) {
                sgsttotal.setText(sgsttt)
            } else {
                sgsttotal.setText("-")
            }

            //CESS TOT
            if (cestt.isNotEmpty()) {
                cesstotal.setText(cestt)
            } else {
                cesstotal.setText("-")
            }

            //Req id
            if (reqid.isNotEmpty()) {
                ansreid.setText(reqid)
            } else {
                ansreid.setText("-")
            }
            //Req Date
            if (reqdt.isNotEmpty()) {
                ansredt.setText(reqdt)
            } else {
                ansredt.setText("-")
            }

            //Req Name
            if (reqnm.isNotEmpty()) {
                ansresnm.setText(reqnm)
            } else {
                ansresnm.setText("-")
            }
            //Req Phone
            if (reqph.isNotEmpty()) {
                ansresph.setText(reqph)
            } else {
                ansresph.setText("-")
            }
            //Req mail
            if (reqmail.isNotEmpty()) {
                ansresmail.setText(reqmail)
            } else {
                ansresmail.setText("-")
            }

            //Req esti
            if (restimt.isNotEmpty()) {
                ansrestidt.setText(restimt)
            } else {
                ansrestidt.setText("-")
            }
            //Supp Address1
            if (supadd1.isNotEmpty()) {
                supplieraddre.setText(supadd1 + supadd2 + supadd3)
            } else {
                supplieraddre.setText("-")
            }
            //Supp GST
            if (supgst.isNotEmpty()) {
                ansgst.setText(supgst)
            } else {
                ansgst.setText("-")
            }

            //Supp City
            if (supcity.isNotEmpty()) {
                anscity.setText(supcity)
            } else {
                anscity.setText("-")
            }

            //Supp State
            if (supstate.isNotEmpty()) {
                ansstate.setText(supstate)
            } else {
                ansstate.setText("-")
            }*/












        addData();


        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView,
                                                  url: String): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                if(sendrequest=="send"){
                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase request"
                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    var f = reqid + "_request"

                    var y = f + ".pdf"




                    val file = File(dir, y)
                    val progressDialog = ProgressDialog(this@RequestActivityPdf)
                    progressDialog.setMessage("Please wait")
                    progressDialog.show()
                    try {
                        PdfView.createWebPrintJob(this@RequestActivityPdf, webView, file, y, object : PdfView.Callback {

                            override fun success(path: String) {
                                progressDialog.dismiss()
                                val builder = android.app.AlertDialog.Builder(this@RequestActivityPdf)
                                with(builder) {
                                    setTitle("Are you sure?")
                                    setMessage("Are you sure want to send?")
                                    setPositiveButton("Send") { dialog, whichButton ->
                                      sendMail(path)
                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            }

                            override fun failure() {
                                progressDialog.dismiss()

                            }
                        })
                    }
                    catch (e:Exception){
                        Toast.makeText(applicationContext,"Already exist",Toast.LENGTH_SHORT).show()
                    }
                }
                myWebView = null
            }
        }







        pdf.setOnClickListener {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase request"
            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            var f = reqid + "_request"

            var y = f + ".pdf"




                    val file = File(dir, y)
                    val progressDialog = ProgressDialog(this@RequestActivityPdf)
                    progressDialog.setMessage("Please wait")
                    progressDialog.show()
                    try {
                        PdfView.createWebPrintJob(this@RequestActivityPdf, webView, file, y, object : PdfView.Callback {

                            override fun success(path: String) {
                                progressDialog.dismiss()
                                val builder = android.app.AlertDialog.Builder(this@RequestActivityPdf)
                                with(builder) {
                                    setTitle("File downloaded")
                                    setMessage("Do you want to open a file?")
                                    setPositiveButton("Open") { dialog, whichButton ->
                                        PdfView.openPdfFile(this@RequestActivityPdf, path)
                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            }

                            override fun failure() {
                                progressDialog.dismiss()

                            }
                        })
                    }
                    catch (e:Exception){
                        Toast.makeText(applicationContext,"Already exist",Toast.LENGTH_SHORT).show()
                    }






             /*   val file = File(dir, y)
                val progressDialog = ProgressDialog(this@RequestActivityPdf)
                progressDialog.setMessage("Please wait")
                progressDialog.show()
                PdfView.createWebPrintJob(this@RequestActivityPdf, webView, file, y, object : PdfView.Callback {

                    override fun success(path: String) {
                        progressDialog.dismiss()
                        val builder = android.app.AlertDialog.Builder(this@RequestActivityPdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->
                                PdfView.openPdfFile(this@RequestActivityPdf, path)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }

                    override fun failure() {
                        progressDialog.dismiss()

                    }
                })*/
            /*} else {

                val file = File(dir, y)
                val progressDialog = ProgressDialog(this@RequestActivityPdf)
                progressDialog.setMessage("Please wait")
                progressDialog.show()
                PdfView.createWebPrintJob(this@RequestActivityPdf, webView, file, y, object : PdfView.Callback {

                    override fun success(path: String) {
                        progressDialog.dismiss()
                        val builder = android.app.AlertDialog.Builder(this@RequestActivityPdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->
                                PdfView.openPdfFile(this@RequestActivityPdf, path)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }

                    }

                    override fun failure() {
                        progressDialog.dismiss()

                    }
                })
            }*/
        }

       /* pdf.setOnClickListener {            //Create local path storage for this pdf




            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            var f = reqid + "_request"

            var y = f + ".pdf"

            val file = File(dir, y)

            if (file.exists()) {                    //If file already exist alert


                val builder = AlertDialog.Builder(this@RequestActivityPdf)
                with(builder) {
                    setTitle("File Already Exist")
                    setMessage("Do you want to overwrite the existing file?")





                    setPositiveButton("Yes") { dialog, whichButton ->  //Overwrite the exist pdf
                        // continue with delete



                        val dialo = SpotsDialog(this@RequestActivityPdf, "Downloading pdf...")

                        dialo.show();

                        createandDisplayPdf(reqid, reqdt, reqnm, reqmail, restimt, supnm, supadd1, supadd2, supadd3, supcity,
                                supstate, supphone, supgst, igsttt, cgsttt, sgsttt, cestt, grosstt)   //Pdf write fiunction


                        val timer2 = Timer()
                        timer2.schedule(object : TimerTask() {
                            override fun run() {


                                if(downstatus=="success"){
                                    val mBuilder = NotificationCompat.Builder(this@RequestActivityPdf)
                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                    val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order")
                                    intent.setDataAndType(uri, "application/pdf")   //Open pdf with pdf reader

                                    val pendingIntent = PendingIntent.getActivity(this@RequestActivityPdf, 0, intent, 0)
                                    mBuilder.setContentIntent(pendingIntent)


                                    val mNotifyManager = this@RequestActivityPdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;


                                    //Notification alert

                                    mBuilder.setContentTitle(reqid + "_request.pdf")
                                    mBuilder.setContentText("Downloaded")
                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                    mBuilder.setDefaults(DEFAULT_SOUND or DEFAULT_VIBRATE or DEFAULT_LIGHTS)
                                    mBuilder.setProgress(100, 100, false)
                                    mNotifyManager.notify(0, mBuilder.build());
                                }

                                dialo.dismiss()

                                timer2.cancel() //this will cancel the timer of the system
                            }


                        }, 3000)

                        val handler = Handler()
                        handler.postDelayed({
                            println("INSIDE IF" + a)
                            if (file.exists()) {
                                val builder = AlertDialog.Builder(this@RequestActivityPdf)
                                with(builder) {
                                    setTitle("File downloaded")
                                    setMessage("Do you want to open a file?")
                                    setPositiveButton("Open") { dialog, whichButton ->
                                        var f = reqid + "_request"


                                        var y = f + ".pdf"
                                        viewPdf("Purchase Order", y)
                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            }
                            else {

                            }
                        }, 4000)

                    }

                    setNegativeButton("NO") { dialog, whichButton ->
                        //showMessage("Close the game or anything!")
                        dialog.dismiss()
                    }

                    // Dialog
                    val dialog = builder.create()

                    dialog.show()
                }


                *//* val u = findViewById<ScrollView>(R.id.ss) as ScrollView
            val zx=findViewById<HorizontalScrollView>(R.id.hh) as HorizontalScrollView
            val yx=findViewById<RelativeLayout>(R.id.relative) as RelativeLayout
            val cx=findViewById<TableLayout>(R.id.table) as TableLayout

            val totalHeight = cx.height+u.height
            val totalWidth = cx.width+u.width

            val b = getBitmapFromView(yx, totalHeight, totalWidth)
            *//**//*  val share = Intent(Intent.ACTION_SEND)
              share.type = "image/jpeg"*//**//*
            val bytes = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 100, bytes)

            val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
            try {
                f.createNewFile()
                val fo = FileOutputStream(f)
                fo.write(bytes.toByteArray())
                imageToPDF()

            } catch (e: IOException) {
                e.printStackTrace()
            }*//*


            } else {

                val dialo = SpotsDialog(this@RequestActivityPdf, "Downloading pdf...")

                dialo.show()


                val timer2 = Timer()
                timer2.schedule(object : TimerTask() {
                    override fun run() {


                        //Pdf write fiunction

                        createandDisplayPdf(reqid, reqdt, reqnm,  reqmail, restimt, supnm, supadd1, supadd2, supadd3, supcity, supstate, supphone, supgst, igsttt, cgsttt, sgsttt, cestt, grosstt)
                        if(downstatus=="success"){
                            val mBuilder = NotificationCompat.Builder(this@RequestActivityPdf)
                            val intent = Intent(Intent.ACTION_GET_CONTENT)
                            val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order")
                            intent.setDataAndType(uri, "application/pdf") //Open pdf with pdf reader

                            val pendingIntent = PendingIntent.getActivity(this@RequestActivityPdf, 0, intent, 0)
                            mBuilder.setContentIntent(pendingIntent)


                            val mNotifyManager = this@RequestActivityPdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;



                            mBuilder.setContentTitle(reqid + "_request.pdf")
                            mBuilder.setContentText("Downloaded")
                            mBuilder.setSmallIcon(R.drawable.ic_logo)
                            mBuilder.setDefaults(DEFAULT_SOUND or DEFAULT_VIBRATE or DEFAULT_LIGHTS)
                            mBuilder.setProgress(100, 100, false)
                            mNotifyManager.notify(0, mBuilder.build());
                        }

                        dialo.dismiss()
                        var b = "null"

                        timer2.cancel() //this will cancel the timer of the system
                    }


                }, 3000)

                val handler = Handler()
                handler.postDelayed({
                    println("INSIDE IF" + a)
                    if (file.exists()) {
                        val builder = AlertDialog.Builder(this@RequestActivityPdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->

                                var f = reqid + "_request"


                                var y = f + ".pdf"
                                viewPdf("Purchase Order", y)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    } else {

                    }

                }, 4000)
            }
        }*/

        back.setOnClickListener {
            val o = Intent(this@RequestActivityPdf, RequestAddActivity::class.java)
            o.putExtra("renm", a)
            o.putExtra("from_req", "from_pdf")
            o.putExtra("remanu", ly)
            o.putExtra("rekey", iddd)
            o.putExtra("rehsn", dsy)
            o.putExtra("reprice", hy)
            o.putExtra("requan", gy)
            o.putExtra("rebc", fy)
            o.putExtra("retotal", ky)
            o.putExtra("regrosstotal", kygro)
            o.putExtra("supplieridfr",supplieridfr)


            o.putExtra("recess", my)
            o.putExtra("reigst", ny)
            o.putExtra("recgst", cy)
            o.putExtra("resgst", sy)
            o.putExtra("retally", idtally)
            o.putExtra("rereceived", idrec)
            o.putExtra("reigst_total", oy)
            o.putExtra("recesstotal", py)
            o.putExtra("reimmg", tt)
            o.putExtra("req_id", reqid)
            o.putExtra("req_liids", reqliid)
            o.putExtra("req_prnms", reprnms)
            o.putExtra("req_date", reqdt)
            o.putExtra("req_name", reqnm)
            o.putExtra("req_mail", reqmail)
            o.putExtra("req_esti", restimt)
o.putExtra("updatestatus",updatestatus)
            o.putExtra("req_supnm", supnm)
            o.putExtra("req_supadd1", supadd1)
            o.putExtra("req_supadd2", supadd2)
            o.putExtra("req_supadd3", supadd3)
            o.putExtra("req_supgst", supgst)
            o.putExtra("req_supcity", supcity)
            o.putExtra("req_supstate", supstate)
            o.putExtra("req_supph", supphone)
            o.putExtra("status", status)
            o.putExtra("orikys", oriky)
            o.putExtra("images", imglinks)
            o.putExtra("viewsuppin", viewsuppin)
            o.putExtra("addsuppin", addsuppin)
            o.putExtra("deletesuppin", deletesuppin)
            o.putExtra("editsuppin", editesuppin)
            o.putExtra("transfersuppin", transfersuppin)
            o.putExtra("exportsuppin", exportsuppin)
            o.putExtra("names", names)

           o.putExtra("request_datedup",request_datedup)
           o.putExtra("reqest_datedup",reqest_datedup)
           o.putExtra("supp_namedup",supp_namedup)
           o.putExtra("supp_gstdup",supp_gstdup)
           o.putExtra("supp_addredup",supp_addredup)
           o.putExtra("befnm",befnm)

            o.putExtra("idpro", idproArray)

            o.putExtra("igsttot",igsttt)
            o.putExtra("cgsttot",cgsttt )
            o.putExtra("sgsttot",sgsttt )
            o.putExtra("cesstot",cestt )
            o.putExtra("grosstot",grosstt )

            o.putExtra("nm",nmscomtt)
            o.putExtra("addre",addre)


            o.putExtra("viewpurord", viewpurord)
            o.putExtra("addpurord", addpurord)
            o.putExtra("deletepurord", deletepurord)
            o.putExtra("editpurord", editepurord)
            o.putExtra("transferpurord", transferpurord)
            o.putExtra("exportpurord", exportpurord)
            o.putExtra("sendpurord", sendpurpo)




            o.putExtra("viewpurreq", viewpurreq)
            o.putExtra("addpurreq", addpurreq)
            o.putExtra("deletepurreq", deletepurreq)
            o.putExtra("editpurreq", editepurreq)
            o.putExtra("transferpurreq", transferpurreq)
            o.putExtra("exportpurreq", exportpurreq)



            o.putExtra("edclick",edclick)



            o.putExtra("ids",ids)


            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }





    }




    override fun onBackPressed() {
        val bundle = intent.extras
        var a = bundle.get("pnm") as ArrayList<String>

        val dsy = bundle.get("phsn") as ArrayList<String>
        val ly = bundle.get("pmanu") as ArrayList<String>
        val fy = bundle.get("barcode") as ArrayList<String>
        val gy = bundle.get("quan") as ArrayList<String>
        val hy = bundle.get("price") as ArrayList<String>
        val ky = bundle.get("tot") as ArrayList<String>
        val kygro = bundle.get("grosstotarr") as ArrayList<String>

        val my = bundle.get("cessup") as ArrayList<String>
        val ny = bundle.get("igst") as ArrayList<String>
        val cy = bundle.get("cgst") as ArrayList<String>
        val sy = bundle.get("sgst") as ArrayList<String>
        val oy = bundle.get("igsttotal") as ArrayList<String>
        val py = bundle.get("cesstotarray") as ArrayList<String>
        val iddd = bundle.get("idsofli") as ArrayList<String>
        val idtally = bundle.get("tallyarray") as ArrayList<String>
        val idrec = bundle.get("receivedarray") as ArrayList<String>


        val idsar = bundle.get("ids") as Array<String>

        ids=idsar.clone()


        try {
            nmscomtt = intent.getStringExtra("nm")
            addre = intent.getStringExtra("addre")
        }
        catch (e:Exception){

        }

        val idpros=bundle.get("idpro") as ArrayList<String>
        idproArray=idpros


        try {
            val immy = bundle.get("image") as ArrayList<String>
            tt=immy
        }
        catch(e:Exception){

        }
        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr
        }
        if (expr != null) {
            exportpurreq = expr
        }

        pronameArray = a
        hsnArray = dsy
        manufacturerArray = ly
        barcodeArray = fy
        quantityArray = gy
        priceArray = hy
        totArray = ky
        grosstotArray = kygro

        cessArray = my
        igstArray = ny
        cgstArray = cy
        sgstArray = sy
        igsttotArray = oy
        cesstotalArray = py
        keyArray = iddd
        tallyArray = idtally
        receivedArray = idrec
        try {
            imageArray = tt
        } catch (e: Exception) {

        }

        try{
            supplieridfr=intent.getStringExtra("supplieridfr")
        }
        catch (e:Exception){

        }
        try{
            sendrequest=intent.getStringExtra("sendrequest")
        }
        catch (e:Exception){

        }

        try {
            val a = intent.getStringExtra("reqid")
            reqid = a

            val c = intent.getStringExtra("reqdate")
            reqdt = c

            val k=intent.getStringExtra("imlinks")
            imglinks=k


        } catch (e: Exception) {

        }

        try{
            edclick=intent.getStringExtra("edclick")

        }
        catch (e:Exception)
        {

        }
        try {
            val b = intent.getStringExtra("reqname")
            reqnm = b

            val s = intent.getStringExtra("status")
            status = s
            val o = intent.getStringExtra("reqest")
            restimt = o
            val d = intent.getStringExtra("reqmail")
            reqmail = d

        }
        catch (e:Exception){
            val o = intent.getStringExtra("reqest")
            restimt = o
            val d = intent.getStringExtra("reqmail")
            reqmail = d
        }
        try{
            befnm=intent.getStringExtra("befnm")
            request_datedup=intent.getStringExtra("request_datedup")
            reqest_datedup=intent.getStringExtra("reqest_datedup")
            supp_namedup=intent.getStringExtra("supp_namedup")
            supp_gstdup=intent.getStringExtra("supp_gstdup")
            supp_addredup=intent.getStringExtra("supp_addredup")
        }
        catch (e:Exception){

        }

        try{

            var fcc=intent.getStringExtra("updatestatus")
            updatestatus=fcc
        }
        catch (e:Exception){

        }

        val ig = intent.getStringExtra("igsttot")
        igsttt = ig


        val cg = intent.getStringExtra("cgsttot")
        cgsttt = cg


        val sg = intent.getStringExtra("sgsttot")
        sgsttt = sg


        val cessg = intent.getStringExtra("cesstot")
        cestt = cessg


        val gt = intent.getStringExtra("grosstot")
        grosstt = gt


        val lii = intent.getStringExtra("reqliid")
        reqliid = lii

        var nm=intent.getStringExtra("names")
        names=nm

        try {

            val nm = intent.getStringExtra("reprnms")
            reprnms = nm
        }
        catch (e:Exception){

        }

        try {
            val f = intent.getStringExtra("supnm")
            supnm = f
            println("SUPPPP NNNNNAAAMMME" + supnm)
            val g = intent.getStringExtra("supadd1")
            supadd1 = g

            val j = intent.getStringExtra("supcity")
            supcity = j
            val k = intent.getStringExtra("supstate")
            supstate = k
            val l = intent.getStringExtra("supph")
            supphone = l
            val m = intent.getStringExtra("supgst")
            supgst = m
            val h = intent.getStringExtra("supadd2")
            supadd2 = h
            val i = intent.getStringExtra("supadd3")
            supadd3 = i
        }
        catch (e:Exception){
            val m = intent.getStringExtra("supgst")
            supgst = m
        }

        val sky=intent.getStringExtra("brky")
        oriky=sky



            /*if (supnm.isNotEmpty()) {
                suppliernm.setText(supnm)
            } else {
                suppliernm.setText("NONE")
            }


            //Supphone

            if (supphone.isNotEmpty()) {
                supplierph.setText(supphone)
            } else {
                supplierph.setText("NONE")
            }


            //Gross tot
            if (grosstt.isNotEmpty()) {
                gross.setText(grosstt)
            } else {
                gross.setText("NONE")
            }

            //IGST TOT
            if (igsttt.isNotEmpty()) {
                igsttotal.setText(igsttt)
            } else {
                igsttotal.setText("NONE")
            }

            //CGST TOT
            if (cgsttt.isNotEmpty()) {
                cgsttotal.setText(cgsttt)
            } else {
                cgsttotal.setText("NONE")
            }

            //SGST TOT
            if (sgsttt.isNotEmpty()) {
                sgsttotal.setText(sgsttt)
            } else {
                sgsttotal.setText("NONE")
            }

            //CESS TOT
            if (cestt.isNotEmpty()) {
                cesstotal.setText(cestt)
            } else {
                cesstotal.setText("NONE")
            }

            //Req id
            if (reqid.isNotEmpty()) {
                ansreid.setText(reqid)
            } else {
                ansreid.setText("NONE")
            }
            //Req Date
            if (reqdt.isNotEmpty()) {
                ansredt.setText(reqdt)
            } else {
                ansredt.setText("NONE")
            }

            //Req Name
            if (reqnm.isNotEmpty())
            {
                ansresnm.setText(reqnm)
            } else
            {
                ansresnm.setText("NONE")
            }


            //Req mail
            if (reqmail.isNotEmpty()) {
                ansresmail.setText(reqmail)
            } else {
                ansresmail.setText("NONE")
            }

            //Req esti
            if (restimt.isNotEmpty()) {
                estidt.setText(restimt)
            } else {
                estidt.setText("NONE")
            }
            //Supp Address1
            if (supadd1.isNotEmpty()) {
                supplieraddress.setText(supadd1 + supadd2 + supadd3)
            } else {
                supplieraddress.setText("NONE")
            }
            //Supp GST
            if (supgst.isNotEmpty()) {
                ansgst.setText(supgst)
            } else {
                ansgst.setText("NONE")
            }

            //Supp City
            if (supcity.isNotEmpty()) {
                anscity.setText(supcity)
            } else {
                anscity.setText("NONE")
            }

            //Supp State
            if (supstate.isNotEmpty()) {
                ansstate.setText(supstate)
            } else {
                ansstate.setText("NONE")
            }*/



        val o = Intent(this@RequestActivityPdf, RequestAddActivity::class.java)
        o.putExtra("renm", a)
        o.putExtra("from_req", "from_pdf")
        o.putExtra("remanu", ly)
        o.putExtra("rekey", iddd)
        o.putExtra("rehsn", dsy)
        o.putExtra("reprice", hy)
        o.putExtra("requan", gy)
        o.putExtra("rebc", fy)
        o.putExtra("retotal", ky)
        o.putExtra("regrosstotal", kygro)

        o.putExtra("recess", my)
        o.putExtra("reigst", ny)
        o.putExtra("recgst", cy)
        o.putExtra("resgst", sy)
        o.putExtra("retally", idtally)
        o.putExtra("rereceived", idrec)
        o.putExtra("reigst_total", oy)
        o.putExtra("recesstotal", py)
        o.putExtra("reimmg", tt)
        o.putExtra("req_id", reqid)
        o.putExtra("req_liids", reqliid)
        o.putExtra("req_prnms", reprnms)
        o.putExtra("req_date", reqdt)
        o.putExtra("req_name", reqnm)
        o.putExtra("req_mail", reqmail)
        o.putExtra("req_esti", restimt)
        o.putExtra("updatestatus",updatestatus)
        o.putExtra("req_supnm", supnm)
        o.putExtra("req_supadd1", supadd1)
        o.putExtra("req_supadd2", supadd2)
        o.putExtra("req_supadd3", supadd3)
        o.putExtra("req_supgst", supgst)
        o.putExtra("req_supcity", supcity)
        o.putExtra("req_supstate", supstate)
        o.putExtra("req_supph", supphone)
        o.putExtra("status", status)
        o.putExtra("orikys", oriky)
        o.putExtra("images", imglinks)
        o.putExtra("viewsuppin", viewsuppin)
        o.putExtra("addsuppin", addsuppin)
        o.putExtra("deletesuppin", deletesuppin)
        o.putExtra("editsuppin", editesuppin)
        o.putExtra("transfersuppin", transfersuppin)
        o.putExtra("exportsuppin", exportsuppin)
        o.putExtra("request_datedup",request_datedup)
        o.putExtra("reqest_datedup",reqest_datedup)
        o.putExtra("supp_namedup",supp_namedup)
        o.putExtra("supp_gstdup",supp_gstdup)
        o.putExtra("supp_addredup",supp_addredup)
        o.putExtra("befnm",befnm)
        o.putExtra("edclick",edclick)

        o.putExtra("supplieridfr",supplieridfr)

        o.putExtra("names", names)
        o.putExtra("igsttot",igsttt)
        o.putExtra("cgsttot",cgsttt )
        o.putExtra("sgsttot",sgsttt )
        o.putExtra("cesstot",cestt )
        o.putExtra("grosstot",grosstt )
        o.putExtra("viewpurord", viewpurord)
        o.putExtra("addpurord", addpurord)
        o.putExtra("deletepurord", deletepurord)
        o.putExtra("editpurord", editepurord)
        o.putExtra("transferpurord", transferpurord)
        o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)

        o.putExtra("nm",nmscomtt)
        o.putExtra("addre",addre)

        o.putExtra("idpro", idproArray)


        o.putExtra("viewpurreq", viewpurreq)
        o.putExtra("addpurreq", addpurreq)
        o.putExtra("deletepurreq", deletepurreq)
        o.putExtra("editpurreq", editepurreq)
        o.putExtra("transferpurreq", transferpurreq)
        o.putExtra("exportpurreq", exportpurreq)


        o.putExtra("ids",ids)


        startActivity(o)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()
    }








    /*@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun createWebPrintJob(webView: WebView) {

        val printManager = this
                .getSystemService(Context.PRINT_SERVICE) as PrintManager

        val printAdapter = webView.createPrintDocumentAdapter("MyDocument")

        val jobName = getString(R.string.app_name) + " Print Test"

        printManager.print(jobName, printAdapter,
                PrintAttributes.Builder().build())
    }*/


    private fun getTextView(id: Int, title: String, color: Int, typeface: Int, bgColor: Int): TextView {        //Document's fonts and design

        val tv = TextView(this)
        tv.id = id
        tv.text = title.toUpperCase()
        tv.setTextColor(color)
        tv.setPadding(20, 20, 20, 20)
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.DEFAULT, typeface)
        tv.setBackgroundColor(bgColor)
        tv.layoutParams = getLayoutParams()

        return tv
    }

    private fun getLayoutParams(): TableRow.LayoutParams {          //Table row layout design

        val params = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT)
        params.setMargins(2, 0, 0, 2)
        return params
    }

    private fun getTblLayoutParams(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT)
    }

    fun addHeaders() {          //TAble headers

        val tl = findViewById<TableLayout>(R.id.table)
        val tr = TableRow(this)
        tr.layoutParams = getLayoutParams()
        tr.addView(getTextView(0, "S.No", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))

        tr.addView(getTextView(0, "Product name", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "HSN/SAC", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))

        tr.addView(getTextView(0, "Price", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Quantity", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "          Tax         ", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))

        tr.addView(getTextView(0, "Total", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tl.addView(tr, getTblLayoutParams())
    }
    var ee=0.0F
    var cc=0.0F
    var gros=0.0F
    var ig=0.0F
    var cg=0.0F
    var sg=0.0F
    var ces=0.0F


    fun addData() {         //Fill datas on table

        htmlDocument = "<html><body><h3>Vinitas Enterprises Pvt Ltd</h3><h4>" + "Purchase request</h4>" +
                "<table class=Border>"+

                "<tr>"+
                "<td class=Border>Request Id:   </td>"+
                "<td class=Border>$reqid</td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Request Date: </td>"+
                "<td class=Border>$reqdt  </td>"+
                "</tr>"+



                "<tr>"+
                "<td class=Border><b>Purchase Details</b></td>"+
                "<td class=Border></td>"+"</tr>"+
                "<tr>"+


                "<tr>"+
                "<td class=Border>Requestor name:   </td>"+
                "<td class=Border>$reqnm </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Requestor phone:</td>"+
                "<td class=Border>$reqph </td>"+
                "</tr>"+

                "<tr>"+
                "<td class=Border>Requestor Email: </td>"+
                "<td class=Border>$reqmail  </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border> Estimated date: </td>"+
                "<td class=Border>$restimt  </td>"+
                "</tr>"+


                "<tr>"+
                "<td class=Border><b>Supplier Details</b></td>"+
                "<td class=Border></td>"+"</tr>"+
                "<tr>"+




                "<tr>"+
                "<td class=Border>Supplier Name: </td>"+
                "<td class=Border>$supnm  </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Supplier Phone: </td>"+
                "<td class=Border>$supphone</td>"+
                "</tr>"+


                "<tr>"+
                "<td class=Border> Supplier Address:  </td>"+
                "<td class=Border>${supadd1+"\n"+supadd2+"\n"+supadd3} </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>GST:</td>"+
                "<td class=Border> $supgst  </td>"+
                "</tr>"+

                "<style>"+
                "table, th, td {"+
                "border: 1px solid black;"+
                "border-collapse: collapse;"+
                "}"+
                "th, td {"+
                "padding: 15px;"+
                "}"+
                "th {"+
                "text-align: left;"+
                "}"+
                "td.Hidden {"+
                "visibility: hidden;"+
                "}"+
                "td.Border {"+
                "border:none;"+
                "width:60%;"+
                "padding:8px;"+
                "}"+


                "table.Border {"+
                "border:none;"+

                "}"+
                "</style>"+

                "<table style=\"width:100%\">"+
                "<tr>"+







                "<th>S.No</th>"+
                "<th>Product name</th>"+
                "<th>HSN/SAC Code</th>"+

                "<th>Price</th>"+
                "<th>Quantity</th>"+
                "<th>Tax</th>"+
                "<th>Total</th>"+
                "</tr>"
        val tl = findViewById<TableLayout>(R.id.table)
        for (i in 0 until priceArray.size) {
            val tr = TableRow(this)
            tr.layoutParams = getLayoutParams()
            var pri=priceArray[i].toFloat()
            var quan=quantityArray[i].toFloat()
            var e=igsttotArray[i].toFloat()
            var f=cesstotalArray[i].toFloat()

           var jj=e+f

            var grtt=jj
            var grflo=grtt
            var gttt=grflo+(pri*quan)

            var grossrealtot=gttt+gros


            singrosstot.add(grossrealtot.toString())




















            htmlDocument=htmlDocument+
                    "<tr>"+
                    "<td>${i+1}</td>"+
                    "<td>${pronameArray[i]}</td>"+
                    "<td>${hsnArray[i]}</td>"+
                    "<td>${priceArray[i]}</td>"+
                    "<td>${quantityArray[i]}</td>"+
                    "<td>$grtt</td>"+
                    "<td>$gttt</td>"+
                    "</tr>"

            if(priceArray.size==i){

            }























            /*  tr.addView(getTextView(i + 1, (i + 1).toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
              tr.addView(getTextView(i + 1, pronameArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
              tr.addView(getTextView(i + 1, hsnArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
              tr.addView(getTextView(i + 1, priceArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
              tr.addView(getTextView(i + 1, quantityArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
              tr.addView(getTextView(i + 1, grtt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
              tr.addView(getTextView(i + 1, gttt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
              tl.addView(tr, getTblLayoutParams())*/
        }
        htmlDocument=htmlDocument+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>IGST TOTAL:</td>"+
                "<td>$igsttt</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>CGST TOTAL:</td>"+
                "<td>$cgsttt</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>SGST TOTAL:</td>"+
                "<td>$sgsttt</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>Cess TOTAL:</td>"+
                "<td>$cestt</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td> Gross TOTAL:</td>"+
                "<td>$grosstt</td>"+

                "</tr>"+"</body></html>"


        myWebView!!.loadDataWithBaseURL(null, htmlDocument, "text/HTML", "UTF-8", null)


            /*tr.addView(getTextView(i + 1, (i+1).toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))

            tr.addView(getTextView(i + 1, pronameArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, hsnArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))

            tr.addView(getTextView(i +1, priceArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, quantityArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, grtt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))

            tr.addView(getTextView(i +1, gttt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tl.addView(tr,getTblLayoutParams())*/
        }

       /* val t2 = findViewById<TableLayout>(R.id.table1)
        val t3 = findViewById<TableLayout>(R.id.table2)
        val tr2 = TableRow(this)
        val tr3 = TableRow(this)
        val tr4 = TableRow(this)
        val tr6 = TableRow(this)
        val tr5 = TableRow(this)

        val trval2= TableRow(this)
        val trval3= TableRow(this)
        val trval4= TableRow(this)
        val trval5= TableRow(this)
        val trval6= TableRow(this)

      *//*  var ttgross=0.0F
            for(l in 0 until singrosstot.size)

            {

                var arrgrosstt=singrosstot[l].toFloat()
                ttgross=ttgross+arrgrosstt
                grosst=ttgross.toString()
                println("TOTAL"+ttgross+l)
                println("GROSS TOTAL"+grosst+l)



            }*//*

        tr2.layoutParams = getLayoutParams()

        trval2.addView(getTextView( 0,igsttt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval3.addView(getTextView( 0,cgsttt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval4.addView(getTextView( 0,sgsttt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval5.addView(getTextView( 0,cestt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval6.addView(getTextView( 0,grosstt,ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        tr2.addView(getTextView( 1,"IGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr3.addView(getTextView( 1,"CGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr4.addView(getTextView( 1,"SGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr5.addView(getTextView( 1,"Cess TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr6.addView(getTextView( 1,"Gross TOTAL:",ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        t2.addView(tr2, getTblLayoutParams())
        t2.addView(tr3, getTblLayoutParams())
        t2.addView(tr4, getTblLayoutParams())
        t2.addView(tr5, getTblLayoutParams())
        t2.addView(tr6, getTblLayoutParams())


        t3.addView(trval2, getTblLayoutParams())
        t3.addView(trval3, getTblLayoutParams())
        t3.addView(trval4, getTblLayoutParams())
        t3.addView(trval5, getTblLayoutParams())
        t3.addView(trval6, getTblLayoutParams())*/






    companion object {


        //Listens internet status whether net is on/off.

        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {


            if(log=="NOT_CONNECT"){
                /// if connection is off then all views becomes disable

                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {

                /// if connection is off then all views becomes enabled


                constraintLayout3dis!!.visibility=View.GONE

                relativeslayoutdis!!.visibility=View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }
    fun sendMail(path: String) {  //Send this purchase request to desired path.
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "Purchase Request Pdf")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Inventory")
        val file = File(path)
        val uri = FileProvider.getUriForFile(this@RequestActivityPdf, "com.package.name.fileprovider", file)
        emailIntent.type ="application/pdf"


        emailIntent.putExtra(Intent.EXTRA_STREAM, uri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))

    }

    fun openFolder() {
        val intent = Intent(Intent.ACTION_GET_CONTENT)
        val uri = Uri.parse(Environment.getExternalStorageDirectory().path
                + File.separator + "myFolder" + File.separator)
        intent.setDataAndType(uri, "text/csv")
        startActivity(Intent.createChooser(intent, "Open folder"))
    }

    fun net_status():Boolean{//Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}



                //Create,write,export pdf

   /* fun createandDisplayPdf(id:String, requestdt:String, reqname:String, reqemail:String, reqestidate:String, supplnm:String, suppladdress1:String,
                           suppladdress2:String, suppladdress3:String, supplcity:String, supplstate:String,supplph:String,supplgst:String, igsttotal:String, cgsttotal:String, sgsttotal:String, cesstotal:String, grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Purchase Order"

            val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs()
            var f=reqid+"_request"

            var y=f+".pdf"

            val file = File(dir,y)
            val fOut =  FileOutputStream(file)





  PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();

            val fntSize = 9.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize);
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Purchase Request",fontsubheading)

            val a1=  Paragraph("Request Id:"+'\t'+'\t'+"         "+id,font)


            val b1=  Paragraph("Request Date:"+'\t'+'\t'+"      "+requestdt,font)
            val b122=  Paragraph("Requestor Details:",fontsubheading)

            val c1=  Paragraph("Requestor Name:"+'\t'+'\t'+"     "+reqname,font)


            val f1=  Paragraph("Requestor Email:"+'\t'+'\t'+"          "+reqemail,font)
            val g1=  Paragraph("Estimated Date:"+'\t'+'\t'+"       "+reqestidate,font)
            val hg1dd =  Paragraph("Supplier Details:",fontsubheading)

            val hg1 =  Paragraph("Supplier Name:"+'\t'+'\t'+"        "+supplnm,font)
            val i2 =  Paragraph("Supplier Phone:"+'\t'+'\t'+"        "+supplph,font)
            val j3 =  Paragraph("Supplier Address:"+'\t'+'\t'+"        "+suppladdress1+suppladdress2+suppladdress3,font)

            val k4 =  Paragraph("GST:"+'\t'+'\t'+'\t'+'\t'+'\t'+"                         "+supplgst,font)

     *//*       val p12 =  Paragraph("IGST Total:                  "+igsttotal,font)
            val p13 =  Paragraph("CGST Total:                  "+cgsttotal,font)
            val p14 =  Paragraph("SGST Total:                  "+sgsttotal,font)
            val p15 =  Paragraph("CESS Total:                  "+cesstotal,font)
            val p7 =  Paragraph("Gross Total:                 "+grosstot,font)*//*
            val p8=   Paragraph("Product Details",fontsubheading)

            val pnm= Paragraph("Product Name")
            val pri= Paragraph("Price")

            val table =  PdfPTable( floatArrayOf(2F,6F,5F,5F,4F,6F,4F));

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell("S.No");
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");
            table.addCell("Quantity");
            table.addCell("Taxes");
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for(j in 0 until cells.size)
            {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var gros=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var ces=0.0F
            for (i in 0 until priceArray.count())
            {

                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)

                var grossrealtot=gttt+gros

                *//*var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var div=2
                var e=igsttotArray[i]
                var eflo=e.toFloat()
                ee=ee+eflo
                ig= ee
                var csgsts=ig
                var csgttotalss=csgsts/div
                cg=csgttotalss
                sg=csgttotalss



                var f=cesstotalArray[i]
                var fflo=f.toFloat()
                cc=fflo+cc
                ces=cc
                var gg=ig.toFloat()
                var jj=ces.toFloat()
                var grtt=gg+jj
                var grflo=grtt.toFloat()
                var gttt=grflo+(pri*quan)



                var grossrealtot=gttt+gros

                singrosstot=singrosstot.plusElement(grossrealtot.toString())*//*

                table.addCell((i+1).toString())
                table.addCell(pronameArray[i])
                table.addCell( hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell( quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell( gttt.toString())
            }
              var ttgross=0.0F

        *//*     for(l in 0 until singrosstot.size)

            {

                var arrgrosstt=singrosstot[l].toFloat()
                ttgross=ttgross+arrgrosstt
                grosst=ttgross.toString()
                println("TOTAL"+ttgross+l)
                println("GROSS TOTAL"+grosstt+l)



            }*//*
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            table.addCell("")

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("IGST Total")
            table.addCell(igsttt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgsttt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgsttt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cestt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstt)
            *//*val table =  PdfPTable(10);
            val  cell = PdfPCell(pnm);
           cell.colspan=1
           cell.setBorder(PdfPCell.NO_BORDER);
           cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);
            val cellCaveat =  PdfPCell(pri);
            cellCaveat.setColspan(1);
            cellCaveat.setBorder(PdfPCell.NO_BORDER);
            table.addCell(cellCaveat);
           table.addCell(cellCaveat);
           doc.add(table)*//*





            //add paragraph to document
            doc.add(h1)
            doc.add( Chunk.NEWLINE );
            doc.add(hs1)

            doc.add( Chunk.NEWLINE );
            doc.add(a1)
            doc.add( Chunk.NEWLINE );
            doc.add(b1)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(b122)
            doc.add( Chunk.NEWLINE );
            doc.add(c1)

            doc.add( Chunk.NEWLINE );
            doc.add(f1)
            doc.add( Chunk.NEWLINE );
            doc.add(g1)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(hg1dd)
            doc.add( Chunk.NEWLINE );
            doc.add(hg1)
            doc.add( Chunk.NEWLINE );
            doc.add(i2)
            doc.add( Chunk.NEWLINE );
            doc.add(j3)
            doc.add( Chunk.NEWLINE );
            doc.add(k4)
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(table)

            downstatus="success"


        } catch ( de: DocumentException) {
            downstatus="not"
        } catch ( e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        }
        finally {
            doc.close()
        }


    }*/

    // Method for opening a pdf file
    /*fun viewPdf(folder:String,file:String) {                 //Open created pdf document from local storage using pdf reader.


        *//*  val pdfIntent = Intent(Intent.ACTION_VIEW)


            val newFilePath = folder.replace("%20", " ")
            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + newFilePath, file).toString()
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
                pdfIntent.setDataAndType(Uri.parse(pdfFile), "application/pdf");

            } else {
                val uri = Uri.parse(pdfFile);
                val file = File(uri.path);
                if (file.exists()) {
                    val uri = FileProvider.getUriForFile(this@PurchasePdfActivity, this.packageName + "com.example.vinitas.purchase_third.provider", file);
                    pdfIntent.setDataAndType(uri, "application/pdf");
                    pdfIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
            }
            pdfIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);*//*


        *//*  println("SD CARD URL"+pdfFile)
        val path = Uri.fromFile(pdfFile)

        // Setting the intent for pdf reader

        pdfIntent.setDataAndType(path,"application/pdf")
        pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)*//*
        try {




            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + folder,file)
            println("SD CARD URL" + pdfFile)
            val path = Uri.fromFile(pdfFile)

            // Setting the intent for pdf reader
            val pdfIntent = Intent(Intent.ACTION_VIEW)
            pdfIntent.setDataAndType(path,"application/pdf")
            pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

            try {
                startActivity(pdfIntent);
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }


        }

        catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW)
            val k = folder.replace("%20", "")
            val path = Environment.getExternalStorageDirectory().absolutePath + "/" + folder + "/" + file
            println("PATH"+path)
            val targetFile = File(path)
            println("TARGET PATH"+targetFile)
            val targetUri = Uri.fromFile(targetFile)


            try {
                val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider",targetFile)
                println("URI"+photoURI)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.setDataAndType(photoURI, "application/pdf")
                startActivity(intent);
                Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }

        }
    }*/



