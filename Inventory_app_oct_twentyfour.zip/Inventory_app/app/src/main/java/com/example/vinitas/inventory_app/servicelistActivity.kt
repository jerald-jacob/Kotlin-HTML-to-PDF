package com.example.vinitas.inventory_app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.*
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.StrictMode
import android.support.constraint.ConstraintLayout
import android.support.v4.content.FileProvider
import android.widget.AbsListView

import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.View
import android.widget.*

import kotlinx.android.synthetic.main.activity_servicelist.*
import java.io.*
import android.text.Editable
import android.text.TextWatcher
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.animation.AnimationUtils
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.*
import com.opencsv.CSVWriter

import java.util.ArrayList


class servicelistActivity : AppCompatActivity() {


    private var firstTimeserv: Boolean? = null

    private var view=String()
    private var add=String()
    private var delete=String()
    private var edit=String()
    private var import=String()
    private var export =String()
    val REQUESTCODE_PICK_VIDEO:Int = 0
    var brkey = String()


    var curencyck=String()
    var percentageck=String()
    var emp_comck=String()
    var cn_soldck=String()
    var taxck=String()

    var brnm=String()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }



    /**
     * Checks if the user is opening the app for the first time.
     * Note that this method should be placed inside an activity and it can be called multiple times.
     * @return boolean
     */
    private fun isFirstTimeserv(): Boolean {
        if (firstTimeserv == null) {
            val mPreferences = this.getSharedPreferences("first_times_serv", Context.MODE_PRIVATE)
            firstTimeserv = mPreferences.getBoolean("firstTimesser", true)
            if (firstTimeserv!!) {
                val editor = mPreferences.edit()
                editor.putBoolean("firstTimesser", false)
                editor.commit()

            }
        }
        return firstTimeserv!!
    }

    internal lateinit var myDb: Databasehelper_service
    internal lateinit var session: SessionManagement_service
    internal lateinit var sessions: SessionManagement
    val db = FirebaseFirestore.getInstance()
    val TAG = "some"
    var a=arrayOf<String>()
    var ids= String()
    //@RequiresApi(Build.VERSION_CODES.LOLLIPOP)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_servicelist)






    net_status()  // Checks the net status.


                //Listens internet changing movements


        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@servicelistActivity) > 0)
        {

        }
        else{

        }

 //Define No connection view when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.containers)

        addLogText(NetworkUtil.getConnectivityStatusString(this@servicelistActivity))



        //Service access

        myDb = Databasehelper_service(this)
        val service_access = SessionManagement(this)
        view = service_access.userDetails[SessionManagement.sview].toString()
        add = service_access.userDetails[SessionManagement.sadd].toString()
        delete = service_access.userDetails[SessionManagement.sdelete].toString()
        edit = service_access.userDetails[SessionManagement.sedit].toString()
        import = service_access.userDetails[SessionManagement.simport].toString()
        export = service_access.userDetails[SessionManagement.s_export].toString()

        val user = service_access.userDetails

        // name
        val name = user[SessionManagement.KEY_NAME]
        val namebr = user[SessionManagement.KEY_brnm]
        brkey = name.toString()
        brnm=namebr.toString()
        /*view=intent.getStringExtra("view")
        add=intent.getStringExtra("add")
        delete=intent.getStringExtra("delete")
        edit=intent.getStringExtra("edit")
        import=intent.getStringExtra("import")
        export=intent.getStringExtra("export")*/

        slsearch.setOnClickListener {//Image button search  action
            println("clicked")
            card.visibility = View.VISIBLE
            card.startAnimation(AnimationUtils.loadAnimation(this@servicelistActivity, R.anim.slide_to_right))
            editText.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)
        }
        searchback.setOnClickListener {//Image button search back action
            card.visibility = View.GONE
            editText.text.clear()
            card.startAnimation(AnimationUtils.loadAnimation(this@servicelistActivity, R.anim.slide_to_left))
            //get()
        }
        //get()

        myDb = Databasehelper_service(this)

        myDb.givedata(brkey)

        session = SessionManagement_service(applicationContext)
        sessions = SessionManagement(applicationContext)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        val i = intent.extras

        //var frm = i!!.get("frm_main")
        StrictMode.setThreadPolicy(policy)

        slback.setOnClickListener {
            onBackPressed()
        }
        sadd.setOnClickListener {        //Add button click (Fab)
            card.visibility = View.GONE
            sadd.isEnabled = false
            if (add == "true") {        //Navigate to service insert activity (ScrollActivity) for adding new service
                val b = Intent(applicationContext, ScrollActivity::class.java)
                b.putExtra("newid", db.collection("${brkey}_service").document().id)
                b.putExtra("add",add)
                b.putExtra("edit",edit)
                b.putExtra("delete",delete)
                b.putExtra("keybr", brkey)
                startActivity(b)
                finish()
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                sadd.isEnabled = true
            } else {
                popup("add")
                sadd.isEnabled = true
            }

        }



        /*swipeContainer.setOnRefreshListener {
            //get()

        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/



        //Vert menu contains 'Logout','Export products','Import products' options.

        sldot.setOnClickListener {
            val popup = PopupMenu(this@servicelistActivity, sldot)

            popup.menuInflater.inflate(R.menu.vert, popup.menu)

            popup.setOnMenuItemClickListener { item ->

                var ky = arrayOf<String>()
                var snm = arrayOf<String>()

                var sid = arrayOf<String>()
                var dur = arrayOf<String>()
                var sac = arrayOf<String>()
                var sacdesc = arrayOf<String>()
                var pr = arrayOf<String>()
                var tx = arrayOf<String>()
                var igst = arrayOf<String>()
                var cess = arrayOf<String>()
                var cgst = arrayOf<String>()
                var sgst = arrayOf<String>()
                var ttot = arrayOf<String>()
                var ctot = arrayOf<String>()
                var gtot = arrayOf<String>()
                var ecomm = arrayOf<String>()
                var ebns = arrayOf<String>()
                var cry = arrayOf<String>()
                var ptg = arrayOf<String>()
                var bval = arrayOf<String>()
                var gdr = arrayOf<String>()
                var mctg = arrayOf<String>()
                var sctg = arrayOf<String>()
                var desc = arrayOf<String>()
                var fp = arrayOf<String>()
                var fpr = arrayOf<String>()
                var tpr = arrayOf<String>()
                var status = arrayOf<String>()
                val pDialog1 = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)


                //Navigate to pinActivity


                if (item.title == "logout") {
                    Toast.makeText(this@servicelistActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                    val f = Intent(this@servicelistActivity, PinActivity::class.java)
                    startActivity(f)
                    finish()
                }
                if (item.itemId == R.id.export) {  //If the user can select the 'Export services' option below code to be executed.


                    if ((export == "true")&&(net_status()==true)){
                        db.collection("${brkey}_service")
                                .get()
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        if (task.result != null) {
                                            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                                            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                            pDialog.setTitleText("Exporting...")
                                            pDialog.setCancelable(false)
                                            pDialog.show();
                                            for (doc in task.result) {
                                                val dd = doc.data
                                                ky = ky.plusElement(doc.id)
                                                snm = snm.plusElement(dd["snm"].toString())
                                                sid = sid.plusElement(dd["sid"].toString())
                                                pr = pr.plusElement(dd["pr"].toString())
                                                dur = dur.plusElement(dd["dur"].toString())
                                                sac = sac.plusElement(dd["sac"].toString())
                                                sacdesc = sacdesc.plusElement(dd["sacdesc"].toString())
                                                tx = tx.plusElement(dd["tx"].toString())
                                                igst = igst.plusElement(dd["igst"].toString())
                                                cess = cess.plusElement(dd["cess"].toString())
                                                cgst = cgst.plusElement(dd["cgst"].toString())
                                                sgst = sgst.plusElement(dd["sgst"].toString())
                                                ttot = ttot.plusElement(dd["ttot"].toString())
                                                ctot = ctot.plusElement(dd["ctot"].toString())
                                                gtot = gtot.plusElement(dd["gtot"].toString())
                                                ecomm = ecomm.plusElement(dd["ecomm"].toString())
                                                ebns = ebns.plusElement(dd["ebns"].toString())
                                                cry = cry.plusElement(dd["cry"].toString())
                                                ptg = ptg.plusElement(dd["ptg"].toString())
                                                bval = bval.plusElement(dd["bval"].toString())
                                                gdr = gdr.plusElement(dd["gdr"].toString())
                                                mctg = mctg.plusElement(dd["mctg"].toString())
                                                sctg = sctg.plusElement(dd["sctg"].toString())
                                                desc = desc.plusElement(dd["desc"].toString())
                                                fp = fp.plusElement(dd["fp"].toString())
                                                fpr = fpr.plusElement(dd["fpr"].toString())
                                                tpr = tpr.plusElement(dd["tpr"].toString())
                                                status = status.plusElement(dd["status"].toString())
                                            }
                                            pDialog.dismiss()
                                        }
                                        else{

                                        }
                                    }
                                }
                                .addOnSuccessListener {
                                    val baseDir = android.os.Environment.getExternalStorageDirectory().getAbsolutePath();
                                    println(baseDir)
                                    val tsLong = System.currentTimeMillis() / 1000
                                    val ts = tsLong.toString()
                                    val fileName = "servicelist$ts.xlsx";
                                    val filePath = baseDir + File.separator + fileName;
                                    println(filePath)
                                    val f = File(filePath);
                                    val writer: CSVWriter
                                    if (f.exists() && !f.isDirectory()) {
                                        val mFileWriter = FileWriter(filePath, true);
                                        writer = CSVWriter(mFileWriter, ',', CSVWriter.NO_QUOTE_CHARACTER);
                                    } else {
                                        writer = CSVWriter(FileWriter(filePath), ',', CSVWriter.NO_QUOTE_CHARACTER)
                                    }
                                    val otherStrings = arrayOf("service name", "service id", "Price", "duration", "SAC code", "SAC description", "taxable", "IGST",
                                            "CGST", "SGST", "Taxtotal", "Cesstotal", "Grosstotal", "Employee commission", "Employee bonus", "currency", "percentage",
                                            "percentage value", "Gender", "Main category", "Subcategory", "service description", "Fixed price", "From", "To", "status")
                                    writer.writeNext(otherStrings)
                                    for (i in 0 until ky.size) {
                                        val next = arrayOf(snm[i], sid[i], pr[i], dur[i], sac[i], sacdesc[i], tx[i], igst[i], cess[i], cgst[i], sgst[i], ttot[i],
                                                ctot[i], gtot[i], ecomm[i], ebns[i], cry[i], ptg[i], bval[i], gdr[i], mctg[i], sctg[i], desc[i], fp[i], fpr[i],
                                                tpr[i], status[i])
                                        writer.writeNext(next)
                                    }
                                    writer.close();

                                    pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)
                                    Toast.makeText(this, "Exported:" + filePath + " - " + fileName, Toast.LENGTH_LONG).show()
                                    pDialog1.titleText = "Exported!"
                                    pDialog1.contentText = filePath
                                    pDialog1.setConfirmText("Open")
                                    pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                                    pDialog1.setConfirmClickListener {
                                        try {


                                            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + filePath, fileName)
                                            println("SD CARD URL" + pdfFile)
                                            val path = Uri.fromFile(pdfFile)

                                            // Setting the intent for pdf reader
                                            val pdfIntent = Intent(Intent.ACTION_VIEW)
                                            pdfIntent.setDataAndType(path, "application/vnd.ms-excel")  //Read csv file by reader

                                            pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

                                            try {
                                                startActivity(pdfIntent);
                                            } catch (e: ActivityNotFoundException) {
                                                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                            }


                                        } catch (e: Exception) {
                                            val intent = Intent(Intent.ACTION_VIEW)
                                            val k = filePath.replace("%20", "")
                                            val path = Environment.getExternalStorageDirectory().absolutePath + "/" + filePath + "/" + fileName
                                            println("PATH" + path)
                                            val targetFile = File(path)
                                            println("TARGET PATH" + targetFile)
                                            val targetUri = Uri.fromFile(targetFile)


                                            try {
                                                val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider", targetFile)
                                                println("URI" + photoURI)
                                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                intent.setDataAndType(photoURI, "application/vnd.ms-excel")
                                                startActivity(intent);
                                                Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

                                            } catch (e: Exception) {
                                                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
                                            }

                                        }
                                    }


                                }

                        pDialog1.show()
                    } else {
                        if(net_status()==false){
                            Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
                        }
                        popup("export")
                    }
                }
                true
                if (item.itemId == R.id.importservice) {   //Import products
                    if (import == "true") {
                        val file = File(Environment.getExternalStorageDirectory().absolutePath + File.separator)
                        val mediaIntent = Intent(Intent.ACTION_GET_CONTENT)
                        mediaIntent.setDataAndType(Uri.fromFile(file), "*/*"); //set mime type as per requirement
                        startActivityForResult(mediaIntent, REQUESTCODE_PICK_VIDEO)   //Select csv file using this 'REQUESTCODE_PICK_VIDEO' code
                    } else {
                        popup("import")
                    }
                }
                true
            }
            popup.show()
        }


        isFirstTimeserv()

        try {
            val p = intent.getStringExtra("skey")
            ids = p
        } catch (e: Exception) {

        }


        //Toast.makeText(applicationContext, "User Login Status: " + session.isLoggedIn, Toast.LENGTH_SHORT).show()


        //if local sql db's document count is 0 nothing to be executed.

        if (myDb.notesCount == 0) {

            println("INSIDE SESSION")

            imageView10.visibility=View.VISIBLE


        }
        else    //ELSE PRODUCT DETAILS WILL BE SHOWN AS LIST.
        {
            imageView10.visibility=View.GONE
            var usArray = arrayOf<String>()//("HD Makeup")
            var tyArray = arrayOf<String>()//("Skin Services, 120min")
            var brArray = arrayOf<String>()//("12,000.00")
            var id = arrayOf<String>()
            var status = arrayOf<String>()
            var icoArray = arrayOf<String>()
            var icohighArray = arrayOf<String>()
            var icohighnmArray = arrayOf<String>()

            var idd = arrayOf<String>()
            var cate = arrayOf<String>()
            val dd = myDb.getAllData()

            while (dd.moveToNext()) {

                idd = idd.plusElement(dd.getString(0))
                val sname = dd.getString(1)
                val maincat = dd.getString(21)
                val subcat = dd.getString(22)
                val sdur = dd.getString(3)
                val price = dd.getString(14)
                val state = dd.getString(27)
                val high = dd.getString(43)
                val highnm = dd.getString(38)
                icohighnmArray=icohighnmArray.plusElement(highnm)
                cate = cate.plusElement(maincat)
                usArray = usArray.plusElement(sname)
                icohighArray=icohighArray.plusElement(high)

                if((maincat.isNotEmpty())&&(subcat.isNotEmpty())&&(sdur.isNotEmpty())){
                    tyArray=tyArray.plusElement(maincat+", "+subcat+", "+ sdur)
                }
                else if((maincat.isNotEmpty())&&(subcat.isNotEmpty())&&(sdur.isEmpty())){
                    tyArray=tyArray.plusElement(maincat+", "+subcat)
                }
                else if((maincat.isNotEmpty())&&(subcat.isEmpty())&&(sdur.isEmpty())){
                    tyArray=tyArray.plusElement(maincat)
                }
                else if((maincat.isNotEmpty())&&(subcat.isEmpty())&&(sdur.isNotEmpty())){
                    tyArray=tyArray.plusElement(maincat+", "+ sdur)
                }
                else if((maincat.isEmpty())&&(subcat.isEmpty())&&(sdur.isNotEmpty())){
                    tyArray=tyArray.plusElement(sdur)
                }


                else if((maincat.isEmpty())&&(subcat.isEmpty())&&(sdur.isEmpty())){
                    tyArray=tyArray.plusElement("")
                }

                brArray = brArray.plusElement(price)
                id = id.plusElement(dd.getString(0))
                status = status.plusElement(state)
                val ur = dd.getString(33)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                val ur1 = dd.getString(34)
                val ur2 = dd.getString(35)
                val ur3 = dd.getString(36)
                val ur4 = dd.getString(37)
                if (ur.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur)
                } else if(ur1.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur1)
                }
                else if(ur2.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur2)
                }
                else if(ur3.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur3)
                }
                else if(ur4.isNotEmpty()) {
                    icoArray = icoArray.plusElement(ur4)
                }
                else{
                    icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                }
            }


            slopt.setText("${dd.count} Services")
            val whatever = SlistAdapter(this, usArray, tyArray, brArray, id, status, icoArray,icohighnmArray,icohighArray)
            val slist = findViewById<View>(R.id.Slist) as ListView
            slist.adapter = whatever


            //Navigate to product details insert activity (MainActivityScroll) for updating the product.

            slist.setOnItemClickListener { parent, view, position, d ->
                card.visibility=View.GONE
                println("dfhidd  " + idd)
                val b = Intent(applicationContext, ScrollActivity::class.java)
                b.putExtra("id", id[position])
                b.putExtra("add",add)
                b.putExtra("edit",edit)
                b.putExtra("delete",delete)
                b.putExtra("keybr",brkey)
                startActivity(b)
                finish()
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

            }


            /* println("OUTSIDE SESSION")
            session.createLoginSession(ids)
             sessions.createLoginSession(ids)*/


        }


        /* var category = arrayListOf<String>()
                var d = arrayListOf<String>()
                var dlt = arrayListOf<String>()
                val list_item = ArrayList<String>()

                Slist.choiceMode = ListView.CHOICE_MODE_MULTIPLE_MODAL;
                Slist.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
                    override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                        //capture total checked items
                        var checkedCount = Slist.checkedItemCount
                        val l = a[position]
                        Log.i(TAG," "+l)
                        //setting CAB title
                        mode.setTitle(""+checkedCount + " Selected")
                        Log.d(TAG," "+id)
                        //list_item.add(id);
                        if (checked) {
                            list_item.add(id.toString()) // Add to list when checked ==  true
                            dlt.add(l)
                            Log.i(TAG,"itm "+dlt.size)
                            //Log.i(TAG,"itm "+dlt.get(position))
                        } else {
                            list_item.remove(id.toString())
                            dlt.remove(l)
                            Log.i(TAG,"itm "+dlt.size)
                            Log.d(TAG,"id  "+id)
                        }

                    }

                    override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                        //Inflate the CAB
                        sltoolbar.visibility = View.GONE
                        mode.getMenuInflater().inflate(R.menu.list, menu);
                        return true;
                    }

                    override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                        return false
                    }

                    override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                        progresslist.visibility=View.VISIBLE
                        val deleteSize = dlt.size
                        Log.i("tsdfs","  "+dlt.size)
                        val cate = null

                        val i = 0
                        Log.d("dlt"," "+dlt.get(i))
                        val itemId = item.getItemId()
                        if (itemId == R.id.delete) {
                            for (i in dlt) {


                                db.collection("services").document(i)
                                        .delete()
                                        .addOnSuccessListener {
                                            myDb.deleteData(i)
                                            dlt.clear()
                                            Toast.makeText(applicationContext, "" + deleteSize + " Items deleted", Toast.LENGTH_SHORT).show()
                                            get()
                                            progresslist.visibility=View.GONE



                                            // save_progress.visibility = android.view.View.GONE

                                        }
                                        .addOnFailureListener {
                                            Toast.makeText(applicationContext, "not updated", Toast.LENGTH_LONG).show()
                                            //save_progress.visibility = android.view.View.GONE
                                        }
                            }
                        }else if (itemId == R.id.selectAll){

                        }

                        list_item.clear()
                        mode.finish()
                        return true
                    }

                    override fun onDestroyActionMode(mode: ActionMode) {
                        // refresh list after deletion
                        sltoolbar.visibility =View.VISIBLE
                    }
                })
*/




        //Check if sql db services not exists, below code is going to insert a service to local sql table


        myDb = Databasehelper_service(this)
        println("myDb.getNotesCount() : "+myDb.getNotesCount())
        slopt.setText(myDb.notesCount.toString() + " options")
        db.collection("${brkey}_service")
                .addSnapshotListener(EventListener<QuerySnapshot>{task,e->
                    println("e : "+e)
                    if (e==null) {
                        println("task.docchange : "+task.documentChanges)
                        for (change in task.getDocumentChanges()) {
                            when (change.getType()) {
                                DocumentChange.Type.ADDED -> {
                                    val groupId = change.getDocument().getId()
                                    println("type added " + groupId)
                                    println("myDb.isin(groupId).moveToNext() " + myDb.checkIfRecordExist(groupId))
                                    val d=myDb.checkIfRecordExist(groupId)
                                    if (d==false) {

                                        imageView10.visibility=View.GONE
                                                        val dd = change.document
                                                        val id = dd.id;//0
                                                        val snm = dd["snm"].toString();//1
                                                        val sid = dd["sid"].toString();//2
                                                        val dur = dd["dur"].toString();//3
                                                        val sac = dd["sac"].toString();//4
                                                        val sacdesc = dd["sacdesc"].toString();//5
                                                        val pr = dd["pr"].toString();//6
                                                        val tx = dd["tx"].toString();//7
                                                        val igst = dd["igst"].toString();//8
                                                        val cess = dd["cess"].toString();//9
                                                        val cgst = dd["cgst"].toString();//10
                                                        val sgst = dd["sgst"].toString();//11
                                                        val ttot = dd["ttot"].toString();//12
                                                        val ctot = dd["ctot"].toString();//13
                                                        val gtot = dd["gtot"].toString();//14
                                                        val ecomm = dd["ecomm"].toString();//15
                                                        val ebns = dd["ebns"].toString();//16
                                                        val cry = dd["cry"].toString();//17
                                                        val ptg = dd["ptg"].toString();//18
                                                        val bval = dd["bval"].toString();//19
                                                        val gdr = dd["gdr"].toString();//20
                                                        val mctg = dd["mctg"].toString();//21
                                                        val sctg = dd["sctg"].toString();//22
                                                        val mctgky = dd["mctgkey"].toString();//21
                                                        val sctgky = dd["sctgkey"].toString();//22
                                                        val desc = dd["desc"].toString();//23
                                                        val fp = dd["fp"].toString();//24
                                                        val fpr = dd["fpr"].toString();//25
                                                        val tpr = dd["tpr"].toString();//26
                                                        val status = dd["status"].toString();//27
                                                        val img1n = dd["img1n"].toString();//28
                                                        val img2n = dd["img2n"].toString();//29
                                                        val img3n = dd["img3n"].toString();//30
                                                        val img4n = dd["img4n"].toString();//31
                                                        val img5n = dd["img5n"].toString();//32
                                                        val img1url = dd["img1url"].toString();//33
                                                        val img2url = dd["img2url"].toString();//34
                                                        val img3url = dd["img3url"].toString();//35
                                                        val img4url = dd["img4url"].toString();//36
                                                        val img5url = dd["img5url"].toString();//37
                                                        val img1nhigh = dd["img1nhigh"].toString();//28
                                                        val img2nhigh = dd["img2nhigh"].toString();//29
                                                        val img3nhigh = dd["img3nhigh"].toString();//30
                                                        val img4nhigh = dd["img4nhigh"].toString();//31
                                                        val img5nhigh = dd["img5nhigh"].toString();//32
                                                        val img1urlhigh = dd["img1urlhigh"].toString();//33
                                                        val img2urlhigh = dd["img2urlhigh"].toString();//34
                                                        val img3urlhigh = dd["img3urlhigh"].toString();//35
                                                        val img4urlhigh = dd["img4urlhigh"].toString();//36
                                                        val img5urlhigh = dd["img5urlhigh"].toString();//37
                                        val retadates = dd["retdate"].toString();//37

                                        val makeupitems=dd["makeupitem"].toString()

                                        val isUpdated = myDb.insertData(id, snm, sid, dur, sac, sacdesc, pr, tx, igst, cess, cgst, sgst, ttot,
                                                                ctot, gtot, ecomm, ebns, cry, ptg, bval, gdr, mctg, sctg, desc, fp, fpr, tpr, status, img1n,
                                                                img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh,
                                                                img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh,
                                                                img4urlhigh, img5urlhigh,mctgky,sctgky,retadates,makeupitems)
                                                        slopt.setText(myDb.notesCount.toString() + " Services")
                                                        if (isUpdated==true) {
                                                          get()
                                                        }


                                    }
                                }

                            //when modified the existing data below code will be executed.


                                DocumentChange.Type.MODIFIED -> {
                                    val groupId = change.getDocument().getId()
                                    println("type modified " + groupId)
                                    imageView10.visibility=View.GONE
                                                    val dd = change.document
                                                    val id = dd.id;//0
                                                    val snm = dd["snm"].toString();//1
                                                    val sid = dd["sid"].toString();//2
                                                    val dur = dd["dur"].toString();//3
                                                    val sac = dd["sac"].toString();//4
                                                    val sacdesc = dd["sacdesc"].toString();//5
                                                    val pr = dd["pr"].toString();//6
                                                    val tx = dd["tx"].toString();//7
                                                    val igst = dd["igst"].toString();//8
                                                    val cess = dd["cess"].toString();//9
                                                    val cgst = dd["cgst"].toString();//10
                                                    val sgst = dd["sgst"].toString();//11
                                                    val ttot = dd["ttot"].toString();//12
                                                    val ctot = dd["ctot"].toString();//13
                                                    val gtot = dd["gtot"].toString();//14
                                                    val ecomm = dd["ecomm"].toString();//15
                                                    val ebns = dd["ebns"].toString();//16
                                                    val cry = dd["cry"].toString();//17
                                                    val ptg = dd["ptg"].toString();//18
                                                    val bval = dd["bval"].toString();//19
                                                    val gdr = dd["gdr"].toString();//20
                                                    val mctg = dd["mctg"].toString();//21
                                                    val sctg = dd["sctg"].toString();//22
                                                    val mctgky=dd["mctgkey"].toString();//21
                                                    val sctgky=dd["sctgkey"].toString();//22
                                                    val desc = dd["desc"].toString();//23
                                                    val fp = dd["fp"].toString();//24
                                                    val fpr = dd["fpr"].toString();//25
                                                    val tpr = dd["tpr"].toString();//26
                                                    val status = dd["status"].toString();//27
                                                    val img1n = dd["img1n"].toString();//28
                                                    val img2n = dd["img2n"].toString();//29
                                                    val img3n = dd["img3n"].toString();//30
                                                    val img4n = dd["img4n"].toString();//31
                                                    val img5n = dd["img5n"].toString();//32
                                                    val img1url = dd["img1url"].toString();//33
                                                    val img2url = dd["img2url"].toString();//34
                                                    val img3url = dd["img3url"].toString();//35
                                                    val img4url = dd["img4url"].toString();//36
                                                    val img5url = dd["img5url"].toString();//37

                                                    val img1nhigh = dd["img1nhigh"].toString();//28
                                                    val img2nhigh = dd["img2nhigh"].toString();//29
                                                    val img3nhigh = dd["img3nhigh"].toString();//30
                                                    val img4nhigh = dd["img4nhigh"].toString();//31
                                                    val img5nhigh = dd["img5nhigh"].toString();//32
                                                    val img1urlhigh = dd["img1urlhigh"].toString();//33
                                                    val img2urlhigh = dd["img2urlhigh"].toString();//34
                                                    val img3urlhigh = dd["img3urlhigh"].toString();//35
                                                    val img4urlhigh = dd["img4urlhigh"].toString();//36
                                                    val img5urlhigh = dd["img5urlhigh"].toString();//37
                                    val retadates = dd["retdate"].toString();//37
                                    val makeupitems=dd["makeupitem"].toString()


                                    val isUpdated = myDb.updateData(id, snm, sid, dur, sac, sacdesc, pr, tx, igst, cess,
                                                            cgst, sgst, ttot, ctot, gtot, ecomm, ebns, cry, ptg, bval, gdr, mctg, sctg, desc, fp,
                                                            fpr, tpr, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,img1nhigh,
                                                            img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh,
                                                            img3urlhigh, img4urlhigh, img5urlhigh,mctgky,sctgky,retadates,makeupitems)

                                                    if(isUpdated==true){
                                                        get()
                                                    }


                                }

                            //Check if remove the data.


                                DocumentChange.Type.REMOVED ->{
                                    val groupId = change.getDocument().getId()
                                    println("type removed " + groupId)
                                    myDb.deleteData(groupId)
                                    slopt.setText(myDb.notesCount.toString() + " options")
                                }
                            }
                        }
                    }

                })


        Slist.setOnScrollListener(object : AbsListView.OnScrollListener {       ///When scroll listview fab button hide and show.
            override fun onScrollStateChanged(view: AbsListView, scrollState: Int) {

             val btn_initPosY=sadd.getScrollY();
            if (scrollState == SCROLL_STATE_TOUCH_SCROLL) {
                sadd.animate().cancel();
                sadd.animate().translationYBy(150F);
            } else {
                sadd.animate().cancel();
                sadd.animate().translationY(btn_initPosY.toFloat());
            }

            }

            override fun onScroll(view: AbsListView, firstVisibleItem: Int, visibleItemCount: Int, totalItemCount: Int) {

            }
        })



        //SEARCH ACTION


        editText.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {
                progresslist.visibility = View.VISIBLE
                Slist.visibility = View.GONE
                noresfo.visibility = View.GONE
                println("des : "+des)
                //progresslist.visibility=View.VISIBLE
                //Slist.visibility=View.GONE
                var usArray = arrayOf<String>()//("HD Makeup")
                var tyArray = arrayOf<String>()//("Skin Services, 120min")
                var brArray = arrayOf<String>()//("12,000.00")
                var id = arrayOf<String>()
                var status = arrayOf<String>()
                var icoArray = arrayOf<String>()
                var icohighArray = arrayOf<String>()
                var icohighnmArray = arrayOf<String>()

                var idd = arrayOf<String>()
                var cate = arrayOf<String>()
                val dd =  myDb.retrieve(des.toString())
                while (dd.moveToNext()) {
                    noresfo.visibility = View.GONE
                println("dd : "+dd.getString(0))
                    idd=idd.plusElement(dd.getString(0))
                    val sname = dd.getString(1)
                    val maincat = dd.getString(21)
                    val subcat= dd.getString(22)
                    val sdur = dd.getString(3)
                    val price = dd.getString(14)
                    val state = dd.getString(27)
                    val highnm = dd.getString(38)

                    val high=dd.getString(43)
                    cate=cate.plusElement(maincat)
                    usArray=usArray.plusElement(sname)
                    icohighnmArray=icohighnmArray.plusElement(highnm)


                    if((maincat.isNotEmpty())&&(subcat.isNotEmpty())&&(sdur.isNotEmpty())){
                        tyArray=tyArray.plusElement(maincat+", "+subcat+", "+ sdur)
                    }
                    else if((maincat.isNotEmpty())&&(subcat.isNotEmpty())&&(sdur.isEmpty())){
                        tyArray=tyArray.plusElement(maincat+", "+subcat)
                    }
                    else if((maincat.isNotEmpty())&&(subcat.isEmpty())&&(sdur.isEmpty())){
                        tyArray=tyArray.plusElement(maincat)
                    }
                    else if((maincat.isNotEmpty())&&(subcat.isEmpty())&&(sdur.isNotEmpty())){
                        tyArray=tyArray.plusElement(maincat+", "+ sdur)
                    }
                    else if((maincat.isEmpty())&&(subcat.isEmpty())&&(sdur.isNotEmpty())){
                        tyArray=tyArray.plusElement(sdur)
                    }


                    else if((maincat.isEmpty())&&(subcat.isEmpty())&&(sdur.isEmpty())){
                        tyArray=tyArray.plusElement("")
                    }

                    brArray=brArray.plusElement(price)
                    id=id.plusElement(dd.getString(0))
                    icohighArray=icohighArray.plusElement(high)
                    status=status.plusElement(state)
                    val ur = dd.getString(33)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                    val ur1 = dd.getString(34)
                    val ur2 = dd.getString(35)
                    val ur3 = dd.getString(36)
                    val ur4 = dd.getString(37)
                    if (ur.isNotEmpty()) {
                        icoArray = icoArray.plusElement(ur)
                    } else if(ur1.isNotEmpty()) {
                        icoArray = icoArray.plusElement(ur1)
                    }
                    else if(ur2.isNotEmpty()) {
                        icoArray = icoArray.plusElement(ur2)
                    }
                    else if(ur3.isNotEmpty()) {
                        icoArray = icoArray.plusElement(ur3)
                    }
                    else if(ur4.isNotEmpty()) {
                        icoArray = icoArray.plusElement(ur4)
                    }
                    else{
                        icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                    }


                //Slist.visibility=View.VISIBLE
                }

                Slist.visibility = View.VISIBLE
                progresslist.visibility = View.GONE
                noresfo.visibility=View.GONE

                if(usArray.isEmpty())
                {
                    noresfo.visibility=View.VISIBLE
                }

                val whatever = SlistAdapter(this@servicelistActivity,usArray,tyArray,brArray,id,status,icoArray,icohighnmArray,icohighArray)
                val slist = findViewById<View>(R.id.Slist) as ListView
                slist.adapter = whatever
                whatever.notifyDataSetChanged()
                slist.getItemIdAtPosition(0)
                slist.setOnItemClickListener { parent, view, position, d ->
                    println("dfhidd  "+idd)
                    val b = Intent(applicationContext, ScrollActivity::class.java)
                    b.putExtra("id", id[position])
                    b.putExtra("add",add)
                    b.putExtra("edit",edit)
                    b.putExtra("delete",delete)
                    b.putExtra("keybr",brkey)
                    startActivity(b)

                    finish()
                    overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                }
                //progresslist.visibility=View.GONE

            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
                if(editText.text.toString().isEmpty()){

                    noresfo.visibility=View.GONE
                    //get()
                }
            }
        })






    }


    override fun onBackPressed() {
        if(containersd.visibility==View.VISIBLE){       //if larged imageview from dp image container is visible
            containersd.visibility=View.INVISIBLE       //Invisible the container
            relative.visibility=View.GONE
            containers.setBackgroundColor(Color.parseColor("#32ffffff"))
            Slist.isClickable=true
            Slist.isEnabled=true
            sadd.isEnabled=true
            sadd.isClickable=true
        }
        else if(card.visibility==View.VISIBLE){
            card.visibility=View.GONE
            get()
        }
        else{
            finish()
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        }
    }




    fun AddData() {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();
        db.collection("${brkey}_service")
                .get()
                .addOnCompleteListener { task ->
                    myDb.deleteall()
                    if (task.isSuccessful) {
                        Log.d(TAG, "cleared")
                        if (task.result.isEmpty==false) {
                            slopt.visibility=View.VISIBLE

                            imageView10.visibility=View.GONE
                            for (document in task.result) {
                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data
                                val id = document.id;//0
                                val snm = dd["snm"].toString();//1
                                val sid = dd["sid"].toString();//2
                                val dur = dd["dur"].toString();//3
                                val sac = dd["sac"].toString();//4
                                val sacdesc = dd["sacdesc"].toString();//5
                                val pr = dd["pr"].toString();//6
                                val tx = dd["tx"].toString();//7
                                val igst = dd["igst"].toString();//8
                                val cess = dd["cess"].toString();//9
                                val cgst = dd["cgst"].toString();//10
                                val sgst = dd["sgst"].toString();//11
                                val ttot = dd["ttot"].toString();//12
                                val ctot = dd["ctot"].toString();//13
                                val gtot = dd["gtot"].toString();//14
                                val ecomm = dd["ecomm"].toString();//15
                                val ebns = dd["ebns"].toString();//16
                                val cry = dd["cry"].toString();//17
                                val ptg = dd["ptg"].toString();//18
                                val bval = dd["bval"].toString();//19
                                val gdr = dd["gdr"].toString();//20
                                val mctg = dd["mctg"].toString();//21
                                val sctg = dd["sctg"].toString();//22
                                val mctgky=dd["mctgkey"].toString();//21
                                val sctgky=dd["sctgkey"].toString();//22
                                val desc = dd["desc"].toString();//23
                                val fp = dd["fp"].toString();//24
                                val fpr = dd["fpr"].toString();//25
                                val tpr = dd["tpr"].toString();//26
                                val status = dd["status"].toString();//27
                                val img1n = dd["img1n"].toString();//28
                                val img2n = dd["img2n"].toString();//29
                                val img3n = dd["img3n"].toString();//30
                                val img4n = dd["img4n"].toString();//31
                                val img5n = dd["img5n"].toString();//32
                                val img1url = dd["img1url"].toString();//33
                                val img2url = dd["img2url"].toString();//34
                                val img3url = dd["img3url"].toString();//35
                                val img4url = dd["img4url"].toString();//36
                                val img5url = dd["img5url"].toString();//37
                                val img1nhigh = dd["img1nhigh"].toString();//28
                                val img2nhigh = dd["img2nhigh"].toString();//29
                                val img3nhigh = dd["img3nhigh"].toString();//30
                                val img4nhigh = dd["img4nhigh"].toString();//31
                                val img5nhigh = dd["img5nhigh"].toString();//32
                                val img1urlhigh = dd["img1urlhigh"].toString();//33
                                val img2urlhigh = dd["img2urlhigh"].toString();//34
                                val img3urlhigh = dd["img3urlhigh"].toString();//35
                                val img4urlhigh = dd["img4urlhigh"].toString();//36
                                val img5urlhigh = dd["img5urlhigh"].toString();//37
                                val retadates=dd["retdate"].toString()
                                val makeupitems=dd["makeupitem"].toString()

                                val isInserted = myDb.insertData(id, snm, sid, dur, sac, sacdesc, pr, tx, igst, cess, cgst, sgst,
                                        ttot, ctot, gtot, ecomm, ebns, cry, ptg, bval, gdr, mctg, sctg, desc, fp, fpr, tpr, status, img1n,
                                        img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,img1nhigh,
                                        img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,mctgky,sctgky,retadates,makeupitems)
                                if (isInserted == true)
                                {

                                }
                                else
                                {

                                }
                            }
                            return@addOnCompleteListener
                        }else{
                            imageView10.visibility=View.VISIBLE
                            slopt.visibility=View.GONE
                            return@addOnCompleteListener
                        }
                    } else {
                        imageView10.visibility=View.VISIBLE
                        slopt.visibility=View.GONE
                        Log.w(TAG, "Error getting documents.", task.exception)
                        return@addOnCompleteListener
                    }
                }
                .addOnSuccessListener {
                    var usArray = arrayOf<String>()//("HD Makeup")
                    var tyArray = arrayOf<String>()//("Skin Services, 120min")
                    var brArray = arrayOf<String>()//("12,000.00")
                    var id = arrayOf<String>()
                    var status = arrayOf<String>()
                    var icoArray = arrayOf<String>()
                    var idd = arrayOf<String>()
                    var cate = arrayOf<String>()
                    val dd = myDb.getAllData()

                    while (dd.moveToNext()) {
                        idd=idd.plusElement(dd.getString(0))
                        val sname = dd.getString(1)
                        val maincat = dd.getString(21)
                        val subcat= dd.getString(22)
                        val sdur = dd.getString(3)
                        val price = dd.getString(14)
                        val state = dd.getString(27)
                        cate=cate.plusElement(maincat)
                        usArray=usArray.plusElement(sname)
                        tyArray=tyArray.plusElement(maincat+""+subcat+" , "+ sdur)
                        brArray=brArray.plusElement(price)
                        id=id.plusElement(dd.getString(0))
                        status=status.plusElement(state)
                        val ur = dd.getString(33)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                        val ur1 = dd.getString(34)
                        val ur2 = dd.getString(35)
                        val ur3 = dd.getString(36)
                        val ur4 = dd.getString(37)
                        if (ur.isNotEmpty()) {
                            icoArray = icoArray.plusElement(ur)
                        } else if(ur1.isNotEmpty()) {
                            icoArray = icoArray.plusElement(ur1)
                        }
                        else if(ur2.isNotEmpty()) {
                            icoArray = icoArray.plusElement(ur2)
                        }
                        else if(ur3.isNotEmpty()) {
                            icoArray = icoArray.plusElement(ur3)
                        }
                        else if(ur4.isNotEmpty()) {
                            icoArray = icoArray.plusElement(ur4)
                        }
                        else{
                            icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                        }
                    }


                    pDialog.dismiss()


                    for(i in 0 until brArray.count()){

                        slopt.setText((i+1).toString()+" options")

                    }


                }
    }


    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        try{
        if (requestCode == REQUESTCODE_PICK_VIDEO && resultCode == Activity.RESULT_OK) {   ///get the csv file from storage to import products.
            /*   val bid = ArrayList<String>()
            val snm = ArrayList<String>()
            val pr = ArrayList<String>()
            val sac = ArrayList<String>()
            val st = ArrayList<String>()
            val dat = ArrayList<String>()*/


            val snm = ArrayList<String>()
            val sid = ArrayList<String>()
            val dur = ArrayList<String>()
            val sac = ArrayList<String>()
            val sacdesc = ArrayList<String>()
            val pr = ArrayList<String>()
            val tx = ArrayList<String>()
            val igst = ArrayList<String>()
            val cess = ArrayList<String>()
            val cgst = ArrayList<String>()
            val sgst = ArrayList<String>()
            val ttot = ArrayList<String>()
            val ctot = ArrayList<String>()
            val gtot = ArrayList<String>()
            val ecomm = ArrayList<String>()
            val ebns = ArrayList<String>()
            val cry = ArrayList<String>()
            val ptg = ArrayList<String>()
            val bval = ArrayList<String>()
            val gdr = ArrayList<String>()
            val mctg = ArrayList<String>()
            val sctg = ArrayList<String>()
            val mctgkey=ArrayList<String>()
            val retdate=ArrayList<String>()
            val sctgkey=ArrayList<String>()
            val desc = ArrayList<String>()
            val makeupitem=ArrayList<String>()
            val fp = ArrayList<String>()
            val fpr = ArrayList<String>()
            val tpr = ArrayList<String>()
            val status = ArrayList<String>()
            val img1n=ArrayList<String>()
            val img2n=ArrayList<String>()
            val img3n=ArrayList<String>()
            val img4n=ArrayList<String>()
            val img5n=ArrayList<String>()
            val img1url=ArrayList<String>()
            val img2url=ArrayList<String>()
            val img3url=ArrayList<String>()
            val img4url=ArrayList<String>()
            val img5url=ArrayList<String>()
            val img1nhigh=ArrayList<String>()
            val img2nhigh=ArrayList<String>()
            val img3nhigh=ArrayList<String>()
            val img4nhigh=ArrayList<String>()
            val img5nhigh=ArrayList<String>()
            val img1urlhigh=ArrayList<String>()
            val img2urlhigh=ArrayList<String>()
            val img3urlhigh=ArrayList<String>()
            val img4urlhigh=ArrayList<String>()
            val img5urlhigh=ArrayList<String>()
            /*        val img1n=ArrayList<String>()
            val img2n=ArrayList<String>()
            val img3n=ArrayList<String>()
            val img4n=ArrayList<String>()
            val img5n=ArrayList<String>()
            val img1url=ArrayList<String>()
            val img2url=ArrayList<String>()
            val img3url=ArrayList<String>()
            val img4url=ArrayList<String>()
            val img5url=ArrayList<String>()*/

            data class s(var snm: String, var sid: String, var dur: String, var sac: String, var sacdesc: String,
                         var pr: String, var tx: String, var igst: String, var cess: String, var cgst: String, var sgst: String, var ttot: String,
                         var ctot: String, var gtot: String, var ecomm: String, var ebns: String, var cry: String, var ptg: String, var bval: String,
                         var gdr: String, var mctg: String, var sctg: String, var mctgkey:String, var retdate:String,var sctgkey:String, var desc: String,
                         var makeupitem:String,var fp: String, var fpr: String, var tpr: String,var status: String,var img1n:String, var img2n:String,
                         var img3n:String, var img4n:String, var img5n:String, var img1url:String, var img2url:String, var img3url:String, var img4url:String,
                         var img5url:String, var img1nhigh:String, var img2nhigh:String, var img3nhigh:String, var img4nhigh:String, var img5nhigh:String,
                         var img1urlhigh:String, var img2urlhigh:String, var img3urlhigh:String, var img4urlhigh:String, var img5urlhigh:String)

            if (data!!.data != null) {

                val pDialog = SweetAlertDialog(this,SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Importing...")
                pDialog.setCancelable(false);
                pDialog.show();
                val fileUri = data.data
                Log.d("", "file URI= " + fileUri!! + "  " + fileUri.encodedPath + " " + data.data.lastPathSegment)
                val last = data.data.lastPathSegment
                val ed = last.replace("primary:", File.separator)
                val p = File(Environment.getExternalStorageDirectory()
                        .getAbsolutePath() + File.separator + ed.toString());
                val csvFile = p//Environment.getExternalStorageDirectory().absolutePath+File.separator+"servicelist.xlsx"
                println("csvFile  " + csvFile)
                var br: BufferedReader? = null
                val cvsSplitBy = ","
                try {
                    br = BufferedReader(FileReader(csvFile))
                    val li = br!!.readLine()
                    println("line 0  " + li.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                    while (br!!.readLine() != null) {
                        val line = br.readLine()
                        /*println("line 1  " + line.split(cvsSplitBy.toRegex()))//line 1  ["key", "service name", "category", "price"]
                        println("line 2  " + line.split(cvsSplitBy.toRegex()).drop(2))//line 2  ["price"]*/
                        //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })//line 3  ["key", "service name", "category", "price"]
                        //println("line 4  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray())//line 4  [Ljava.lang.String;@b731c54

                        try {
                            val pos = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                            //println("line 4  " + pos)
                            snm.add(pos[0])
                            sid.add(pos[1])
                            dur.add(pos[2])
                            sac.add(pos[3])
                            sacdesc.add(pos[4])
                            pr.add(pos[5])
                            tx.add(pos[6])
                            igst.add(pos[7])
                            cess.add(pos[8])
                            cgst.add(pos[9])
                            sgst.add(pos[10])
                            ttot.add(pos[11])
                            ctot.add(pos[12])
                            gtot.add(pos[13])
                            ecomm.add(pos[14])
                            ebns.add(pos[15])
                            cry.add(pos[16])
                            ptg.add(pos[17])
                            bval.add(pos[18])
                            gdr.add(pos[19])
                            mctg.add(pos[20])
                            sctg.add(pos[21])
                            mctgkey.add(pos[22])
                            retdate.add(pos[23])
                            sctgkey.add(pos[24])
                            desc.add(pos[25])
                            makeupitem.add(pos[26])
                            fp.add(pos[27])
                            fpr.add(pos[28])
                            tpr.add(pos[29])
                            status.add(pos[30])
                            img1n.add(pos[31])
                            img2n.add(pos[32])
                            img3n.add(pos[33])
                            img4n.add(pos[34])
                            img5n.add(pos[35])
                            img1url.add(pos[36])
                            img2url.add(pos[37])
                            img3url.add(pos[38])
                            img4url.add(pos[39])
                            img5url.add(pos[40])
                            img1nhigh.add(pos[41])
                            img2nhigh.add(pos[42])
                            img3nhigh.add(pos[43])
                            img4nhigh.add(pos[44])
                            img5nhigh.add(pos[45])
                            img1urlhigh.add(pos[46])
                            img2urlhigh.add(pos[47])
                            img3urlhigh.add(pos[48])
                            img4urlhigh.add(pos[49])
                            img5urlhigh.add(pos[50])
                            /*   img1n.add(pos[27])
                        img2n.add(pos[28])
                        img3n.add(pos[29])
                        img4n.add(pos[30])
                        img5n.add(pos[31])
                        img1url.add(pos[32])
                        img2url.add(pos[33])
                        img3url.add(pos[34])
                        img4url.add(pos[35])
                        img5url.add(pos[36])*/


                            /*   bid.add(pos[0])
                        snm.add(pos[1])
                        pr.add(pos[2])
                        sac.add(pos[3])
                        st.add(pos[4])
                        dat.add(pos[5])*/
                            val database = FirebaseDatabase.getInstance()
                            val myRef = database.getReference("service_counter")
                            myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                                override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                                    var p = mutableData.value


                                    if (p == null) {
                                        p = 1
                                    }

                                    if (p == 0) {
                                        // Unstar the post and remove self from stars
                                        p = 1

                                    } else {
                                        // Star the post and add self to stars
                                        p = Integer.parseInt(p.toString()) + 1
                                    }

                                    // Set value and report transaction success
                                    mutableData.value = p
                                    //mutableData.setValue(p.number)
                                    return com.google.firebase.database.Transaction.success(mutableData)
                                }

                                override fun onComplete(
                                        databaseError: DatabaseError?,
                                        b: Boolean,
                                        dataSnapshot: DataSnapshot
                                ) {

                                    println(dataSnapshot)
                                    println(dataSnapshot.value)
                                    val id = dataSnapshot.value

                                    var k=pos[0].toString()
                                    var kcaps=k
                                    val upperString = kcaps.substring(0, 1).toUpperCase() + kcaps.substring(1)

                                    var gchk=pos[6]
                                    if(gchk.isNotEmpty()){
                                        taxck=gchk.toLowerCase()
                                    }
                                    else{
                                        taxck=pos[6]
                                    }

                                    var curr=pos[16]
                                    if(curr.isNotEmpty()){
                                        curencyck=curr.toLowerCase()
                                    }
                                    else{
                                        curencyck=pos[16]
                                    }

                                    var perc=pos[17]

                                    if(perc.isNotEmpty()){
                                        percentageck=perc.toLowerCase()
                                    }
                                    else{
                                        percentageck=pos[17]
                                    }
                                    var empc=pos[14]
                                    if(empc.isNotEmpty()){
                                        emp_comck=empc.toLowerCase()
                                    }
                                    else{
                                        emp_comck=pos[14]
                                    }
                                    var cn_sol=pos[15]
                                    if(cn_sol.isNotEmpty()){
                                        cn_soldck=cn_sol.toLowerCase()
                                    }
                                    else{
                                        cn_soldck=pos[15]
                                    }

                                    val datum = s(snm = upperString, sid =id.toString(), dur = pos[2], sac = pos[3], sacdesc = pos[4], pr = pos[5],
                                            tx = taxck, igst = pos[7], cess = pos[8], cgst = pos[9], sgst = pos[10], ttot = pos[11],ctot = pos[12],
                                            gtot = pos[13], ecomm = curencyck, ebns = percentageck, cry = emp_comck, ptg = cn_soldck, bval = pos[18], gdr = pos[19],
                                            mctg = pos[20], sctg = pos[21],mctgkey=pos[22],retdate=pos[23],sctgkey=pos[24], desc = pos[25],makeupitem=pos[26],
                                            fp = pos[27], fpr = pos[28], tpr = pos[29], status = pos[30],img1n= pos[31], img2n= pos[32], img3n= pos[33],
                                            img4n= pos[34], img5n= pos[35], img1url= pos[36], img2url= pos[37], img3url= pos[38], img4url= pos[39],
                                            img5url= pos[40],img1nhigh= pos[41], img2nhigh= pos[42], img3nhigh= pos[43], img4nhigh= pos[44], img5nhigh= pos[45],
                                            img1urlhigh= pos[46], img2urlhigh= pos[47], img3urlhigh= pos[48], img4urlhigh= pos[49], img5urlhigh= pos[50])
                                    println(datum)
                                    db.collection("${brkey}_service")
                                            .add(datum)
                                            .addOnSuccessListener {
                                                println("data saved")
                                                Toast.makeText(applicationContext, "Imported Successfully", Toast.LENGTH_SHORT).show()
                                                get()
                                            }

                                    // Transaction completed
                                    // Log.d("", "postTransaction:onComplete:" + databaseError)
                                }
                            })


                        } catch (e: Exception) {

                        }

                    }
                } catch (e: FileNotFoundException) {
                    e.printStackTrace()
                } catch (e: IOException) {
                    e.printStackTrace()
                } finally {
                    if (br != null) {
                        try {
                            br!!.close()
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }

                    }
                }
                val reader = BufferedReader(FileReader(csvFile))
                reader.readLine()
                val lin = reader.readLine()
                while (reader!!.readLine() != null) {
                    val line = reader.readLine()
                    if (line != null) {
                        val po = line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                        //println("line 3  " + line.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() })
                        snm.add(po[0])
                        sid.add(po[1])
                        dur.add(po[2])
                        sac.add(po[3])
                        sacdesc.add(po[4])
                        pr.add(po[5])
                        tx.add(po[6])
                        igst.add(po[7])
                        cess.add(po[8])
                        cgst.add(po[9])
                        sgst.add(po[10])
                        ttot.add(po[11])
                        ctot.add(po[12])
                        gtot.add(po[13])
                        ecomm.add(po[14])
                        ebns.add(po[15])
                        cry.add(po[16])
                        ptg.add(po[17])
                        bval.add(po[18])
                        gdr.add(po[19])
                        mctg.add(po[20])
                        sctg.add(po[21])
                        mctgkey.add(po[22])
                        retdate.add(po[23])
                        sctgkey.add(po[24])
                        desc.add(po[25])
                        makeupitem.add(po[26])
                        fp.add(po[27])
                        fpr.add(po[28])
                        tpr.add(po[29])
                        status.add(po[30])


                        img1n.add(po[31])
                        img2n.add(po[32])
                        img3n.add(po[33])
                        img4n.add(po[34])
                        img5n.add(po[35])
                        img1url.add(po[36])
                        img2url.add(po[37])
                        img3url.add(po[38])
                        img4url.add(po[39])
                        img5url.add(po[40])
                        img1nhigh.add(po[41])
                        img2nhigh.add(po[42])
                        img3nhigh.add(po[43])
                        img4nhigh.add(po[44])
                        img5nhigh.add(po[45])
                        img1urlhigh.add(po[46])
                        img2urlhigh.add(po[47])
                        img3urlhigh.add(po[48])
                        img4urlhigh.add(po[49])
                        img5urlhigh.add(po[50])
                        /*   img1n.add(po[27])
                           img2n.add(po[28])
                           img3n.add(po[29])
                           img4n.add(po[30])
                           img5n.add(po[31])
                           img1url.add(po[32])
                           img2url.add(po[33])
                           img3url.add(po[34])
                           img4url.add(po[35])
                           img5url.add(po[36])*/
                        //println("reader   " + line)
                        //println("snm   " + snm)
                        val database = FirebaseDatabase.getInstance()
                        val myRef = database.getReference("service_id")
                        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                                var p = mutableData.value


                                if (p == null) {
                                    p = 1
                                }

                                if (p == 0) {
                                    // Unstar the post and remove self from stars
                                    p = 1

                                } else {
                                    // Star the post and add self to stars
                                    p = Integer.parseInt(p.toString()) + 1
                                }

                                // Set value and report transaction success
                                mutableData.value = p
                                //mutableData.setValue(p.number)
                                return com.google.firebase.database.Transaction.success(mutableData)
                            }

                            override fun onComplete(
                                    databaseError: DatabaseError?,
                                    b: Boolean,
                                    dataSnapshot: DataSnapshot
                            ) {

                                println(dataSnapshot)
                                println(dataSnapshot.value)
                                val id = dataSnapshot.value

                                var k=po[0].toString()
                                var kcaps=k
                                val upperString = kcaps.substring(0, 1).toUpperCase() + kcaps.substring(1)


                                var gchk=po[6]
                                if(gchk.isNotEmpty()){
                                    taxck=gchk.toLowerCase()
                                }
                                else{
                                    taxck=po[6]
                                }

                                var curr=po[16]
                                if(curr.isNotEmpty()){
                                    curencyck=curr.toLowerCase()
                                }
                                else{
                                    curencyck=po[16]
                                }

                                var perc=po[17]

                                if(perc.isNotEmpty()){
                                    percentageck=perc.toLowerCase()
                                }
                                else{
                                    percentageck=po[17]
                                }
                                var empc=po[14]
                                if(empc.isNotEmpty()){
                                    emp_comck=empc.toLowerCase()
                                }
                                else{
                                    emp_comck=po[14]
                                }
                                var cn_sol=po[15]
                                if(cn_sol.isNotEmpty()){
                                    cn_soldck=cn_sol.toLowerCase()
                                }
                                else{
                                    cn_soldck=po[15]
                                }

                                val datum = s(snm = upperString, sid =id.toString(), dur = po[2], sac = po[3], sacdesc = po[4], pr = po[5],
                                        tx = taxck, igst = po[7], cess = po[8], cgst = po[9], sgst = po[10], ttot = po[11],ctot = po[12],
                                        gtot = po[13], ecomm = curencyck, ebns = percentageck, cry = emp_comck, ptg = cn_soldck, bval = po[18], gdr = po[19],
                                        mctg = po[20], sctg = po[21],mctgkey=po[22],retdate=po[23],sctgkey=po[24], desc = po[25],makeupitem=po[26],
                                        fp = po[27], fpr = po[28], tpr = po[29], status = po[30],img1n= po[31], img2n= po[32], img3n= po[33],
                                        img4n= po[34], img5n= po[35], img1url= po[36], img2url= po[37], img3url= po[38], img4url= po[39],
                                        img5url= po[40],img1nhigh= po[41], img2nhigh= po[42], img3nhigh= po[43], img4nhigh= po[44], img5nhigh= po[45],
                                        img1urlhigh= po[46], img2urlhigh= po[47], img3urlhigh= po[48], img4urlhigh= po[49], img5urlhigh= po[50])
                                println(datum)
                                db.collection("${brkey}_service")
                                        .add(datum)
                                        .addOnSuccessListener {
                                            println("data saved")
                                            Toast.makeText(applicationContext, "Imported Successfully", Toast.LENGTH_SHORT).show()
                                            get()
                                        }


                                // Transaction completed
                                // Log.d("", "postTransaction:onComplete:" + databaseError)
                            }
                        })


                        val pDialog1 = SweetAlertDialog(this, SweetAlertDialog.SUCCESS_TYPE)
                        pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)
                        Toast.makeText(this, "Imported successfully", Toast.LENGTH_LONG).show()
                        pDialog1.titleText = "Imported!"

                        pDialog1.setConfirmText("OK")
                        pDialog1.show()
                        pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                        pDialog1.setConfirmClickListener {
                            pDialog1.hide()
                            pDialog.dismiss()

                        }
                    }
                }
                println("vaeliye" + lin)
                val po = lin.split(cvsSplitBy.toRegex()).dropLastWhile { it.isEmpty() }
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("service_id")
                myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {

                    override fun doTransaction(mutableData: MutableData):com.google.firebase.database.Transaction.Result? {
                        var p = mutableData.value


                        if (p == null) {
                            p = 1
                        }

                        if (p == 0) {
                            // Unstar the post and remove self from stars
                            p = 1

                        } else {
                            // Star the post and add self to stars
                            p = Integer.parseInt(p.toString()) + 1
                        }

                        // Set value and report transaction success
                        mutableData.value = p
                        //mutableData.setValue(p.number)
                        return com.google.firebase.database.Transaction.success(mutableData)
                    }

                    override fun onComplete(
                            databaseError: DatabaseError?,
                            b: Boolean,
                            dataSnapshot: DataSnapshot
                    ) {

                        println(dataSnapshot)
                        println(dataSnapshot.value)
                        val id = dataSnapshot.value
                        var k=po[0].toString()
                        var kcaps=k
                        val upperString = kcaps.substring(0, 1).toUpperCase() + kcaps.substring(1)


                        var gchk=po[6]
                        if(gchk.isNotEmpty()){
                            taxck=gchk.toLowerCase()
                        }
                        else{
                            taxck=po[6]
                        }

                        var curr=po[16]
                        if(curr.isNotEmpty()){
                            curencyck=curr.toLowerCase()
                        }
                        else{
                            curencyck=po[16]
                        }

                        var perc=po[17]

                        if(perc.isNotEmpty()){
                            percentageck=perc.toLowerCase()
                        }
                        else{
                            percentageck=po[17]
                        }
                        var empc=po[14]
                        if(empc.isNotEmpty()){
                            emp_comck=empc.toLowerCase()
                        }
                        else{
                            emp_comck=po[14]
                        }
                        var cn_sol=po[15]
                        if(cn_sol.isNotEmpty()){
                            cn_soldck=cn_sol.toLowerCase()
                        }
                        else{
                            cn_soldck=po[15]
                        }

                        val datum = s(snm = upperString, sid =id.toString(), dur = po[2], sac = po[3], sacdesc = po[4], pr = po[5],
                                tx = taxck, igst = po[7], cess = po[8], cgst = po[9], sgst = po[10], ttot = po[11],ctot = po[12],
                                gtot = po[13], ecomm = curencyck, ebns = percentageck, cry = emp_comck, ptg = cn_soldck, bval = po[18], gdr = po[19],
                                mctg = po[20], sctg = po[21],mctgkey=po[22],retdate=po[23],sctgkey=po[24], desc = po[25],makeupitem=po[26],
                                fp = po[27], fpr = po[28], tpr = po[29], status = po[30],img1n= po[31], img2n= po[32], img3n= po[33],
                                img4n= po[34], img5n= po[35], img1url= po[36], img2url= po[37], img3url= po[38], img4url= po[39],
                                img5url= po[40],img1nhigh= po[41], img2nhigh= po[42], img3nhigh= po[43], img4nhigh= po[44], img5nhigh= po[45],
                                img1urlhigh= po[46], img2urlhigh= po[47], img3urlhigh= po[48], img4urlhigh= po[49], img5urlhigh= po[50])
                        println(datum)
                        db.collection("${brkey}_service")
                                .add(datum)
                                .addOnSuccessListener {
                                    println("data saved")
                                    Toast.makeText(applicationContext,"Imported Successfully",Toast.LENGTH_SHORT).show()
                                    get()
                                }


                        // Transaction completed
                        // Log.d("", "postTransaction:onComplete:" + databaseError)
                    }
                })

            }

        }
    }
    catch (e:Exception){
        Toast.makeText(applicationContext,"Invalid file",Toast.LENGTH_LONG).show()
    }
    }


    companion object {

  //Listens inetrnet status whether net is on/off. .

        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively:RelativeLayout?=null
        private var cont:ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                                  /// if connection is off then all views becomes disable


                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


for (i  in 0 until cont!!.getChildCount()) {
    val child = cont!!.getChildAt(i);
    child.setEnabled(false);
}

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                                  /// if connection is off then all views becomes enabled


                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }


    fun get() {  ///Get service details from local sql storage and list out.

                              var usArray = arrayOf<String>()//("HD Makeup")
                              var tyArray = arrayOf<String>()//("Skin Services, 120min")
                              var brArray = arrayOf<String>()//("12,000.00")
                              var id = arrayOf<String>()
                              var status = arrayOf<String>()
                              var icoArray = arrayOf<String>()
                              var idd = arrayOf<String>()
                              var cate = arrayOf<String>()
                              var icohighArray = arrayOf<String>()
                              var icohighnmArray= arrayOf<String>()

                              val dd = myDb.getAllData()

                              while (dd.moveToNext()) {

                                  imageView10.visibility=View.GONE

                                  idd = idd.plusElement(dd.getString(0))
                                  val sname = dd.getString(1)
                                  val maincat = dd.getString(21)
                                  val subcat = dd.getString(22)
                                  val sdur = dd.getString(3)
                                  val price = dd.getString(14)
                                  val high = dd.getString(43)
                                  val highnm = dd.getString(38)
                                  val state = dd.getString(27)
                                  cate = cate.plusElement(maincat)
                                  icohighArray = icohighArray.plusElement(high)
                                  icohighnmArray = icohighnmArray.plusElement(highnm)
                                  usArray = usArray.plusElement(sname)

                                  if((maincat.isNotEmpty())&&(subcat.isNotEmpty())&&(sdur.isNotEmpty())){
                                      tyArray=tyArray.plusElement(maincat+", "+subcat+", "+ sdur)
                                  }
                                  else if((maincat.isNotEmpty())&&(subcat.isNotEmpty())&&(sdur.isEmpty())){
                                      tyArray=tyArray.plusElement(maincat+", "+subcat)
                                  }
                                  else if((maincat.isNotEmpty())&&(subcat.isEmpty())&&(sdur.isEmpty())){
                                      tyArray=tyArray.plusElement(maincat)
                                  }
                                  else if((maincat.isNotEmpty())&&(subcat.isEmpty())&&(sdur.isNotEmpty())){
                                      tyArray=tyArray.plusElement(maincat+", "+ sdur)
                                  }
                                  else if((maincat.isEmpty())&&(subcat.isEmpty())&&(sdur.isNotEmpty())){
                                      tyArray=tyArray.plusElement(sdur)
                                  }


                                  else if((maincat.isEmpty())&&(subcat.isEmpty())&&(sdur.isEmpty())){
                                      tyArray=tyArray.plusElement("")
                                  }
                                  brArray = brArray.plusElement(price)
                                  id = id.plusElement(dd.getString(0))
                                  a = id
                                  status = status.plusElement(state)
                                  val ur = dd.getString(33)//"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                  val ur1 = dd.getString(34)
                                  val ur2 = dd.getString(35)
                                  val ur3 = dd.getString(36)
                                  val ur4 = dd.getString(37)
                                  if (ur.isNotEmpty()) {
                                      icoArray = icoArray.plusElement(ur)
                                  } else if(ur1.isNotEmpty()) {
                                      icoArray = icoArray.plusElement(ur1)
                                  }
                                  else if(ur2.isNotEmpty()) {
                                      icoArray = icoArray.plusElement(ur2)
                                  }
                                  else if(ur3.isNotEmpty()) {
                                      icoArray = icoArray.plusElement(ur3)
                                  }
                                  else if(ur4.isNotEmpty()) {
                                      icoArray = icoArray.plusElement(ur4)
                                  }
                                  else{
                                      icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")

                                  }
                                  //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"


                                  val whatever = SlistAdapter(this, usArray, tyArray, brArray, id, status, icoArray, icohighnmArray, icohighArray)
                                  val slist = findViewById<View>(R.id.Slist) as ListView
                                  slist.adapter = whatever
                                  for(i in 0 until brArray.count()){

                                      slopt.setText((i+1).toString()+" options")

                                  }

                              }



        /*for(i in 0 until brArray.count()){

            slopt.setText((i).toString()+" options")

        }*/


        Slist.getItemIdAtPosition(0)
        Slist.setOnItemClickListener { parent, view, position, d ->
            card.visibility=View.GONE
            println("dfhidd  " + idd)
            val b = Intent(applicationContext, ScrollActivity::class.java)
            b.putExtra("id", a[position])
            b.putExtra("add",add)
            b.putExtra("edit",edit)
            b.putExtra("delete",delete)
            b.putExtra("keybr",brkey)
            startActivity(b)
            finish()
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

        }
    }

    fun popup(st:String){
        SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                .setTitleText("Access Denied!")
                .setContentText("You dont have Access to $st")
                .setConfirmText("ok")
                .setConfirmClickListener(null)
                .show()
        /*val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()*/
    }



    fun net_status():Boolean{       // Checks the net status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
