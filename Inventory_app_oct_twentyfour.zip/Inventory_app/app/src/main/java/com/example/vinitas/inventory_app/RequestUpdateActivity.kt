package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_request_update.*
import java.text.DecimalFormat


class RequestUpdateActivity : AppCompatActivity() {

     private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    var befnm= String()
    var request_datedup= String()
    var reqest_datedup= String()
    var supp_namedup= String()
    var supp_gstdup= String()
    var supp_addredup= String()

    var deletelistener=String()


    var cesscalc:Float = 0.0f
    var igstcalc:Float = 0.0f

    var ids=arrayOf<String>()

    var supplieridfr=String()


    var regx="[/,:<>!~@#$%^&()+=?()\"|!\\[#$-]"



    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""




    var editchange= String()

    var incompstr= String()
    var groschk= String()

    var groschkyes= String()

    var pzsave:Int = 0
    var asave=arrayListOf<String>()
    var dsysave=arrayListOf<String>()
    var fysave=arrayListOf<String>()
    var gysave=arrayListOf<String>()
    var hysave=arrayListOf<String>()
    var kysave=arrayListOf<String>()
    var kygrosave=arrayListOf<String>()
    var cysave=arrayListOf<String>()
    var sysave=arrayListOf<String>()
    var idprokysave= arrayListOf<String>()
    var mysave=arrayListOf<String>()
    var nysave=arrayListOf<String>()
    var oysave=arrayListOf<String>()
    var pysave=arrayListOf<String>()
    var tallysave=arrayListOf<String>()
    var receivedsave=arrayListOf<String>()
    var idddsave= arrayListOf<String>()
    var lysave= arrayListOf<String>()
    var immysave= arrayListOf<String>()


    var reqidsave = String()
    var reprnmssave = String()
    var reqdtsave = String()
    var reqliidsave = String()
    var restimtsave = String()
    var reqnmsave = String()
    var reqmailsave = String()
    var reqphsave= String()
    var imagelinksave = String()

    var supnmsave = String()
    var supadd1save = String()
    var supadd2save = String()
    var supadd3save = String()
    var supgstsave = String()
    var supphsave = String()
    var supcitysave = String()
    var supstatesave = String()
    var idlisave= String()
    var brkysave= String()
    var tallyarsave= String()
    var receivearsave= String()
    var statussave= String()
    var orikysave= String()


    var reprnms = String()
    var reqdt = String()
    var reqliid = String()
    var restimt = String()
    var reqnm = String()
    var reqmail = String()
    var reqph = String()
    var imagelink = String()

    var supnm = String()
    var supadd1 = String()
    var supadd2 = String()
    var supadd3 = String()
    var supgst = String()
    var supph = String()
    var supcity = String()
    var supstate = String()
    var idli= String()
    var brky= String()
    var tallyar= String()
    var receivear= String()

    var oriky= String()



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_update)

        net_status()
        val bundle = intent.extras
        var frm = bundle!!.get("from_req").toString()







        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@RequestUpdateActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
        }



        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        req_updatedis=findViewById(R.id.req_update)
        userbackdis=findViewById(R.id.userback)
        scrollView2dis=findViewById(R.id.scrollView2)
        editdis=findViewById(R.id.edit)

        cess_edtdis=findViewById(R.id.cess_edt)
        igst_edtdis=findViewById(R.id.igst_edt)
        quan_req_firstdis=findViewById(R.id.quan_req_first)
        reqpridis=findViewById(R.id.reqpri)





        //Purchase request

        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr


            println("PURCHASE REQUEST TRANSFER NEXT"+transferpurreq)


        }
        if (expr != null) {
            exportpurreq = expr
        }


        //Purchase order

        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")

        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }


        //Supplier Invoice

        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }

        try{
            befnm=intent.getStringExtra("befnm")
            request_datedup=intent.getStringExtra("request_datedup")
            reqest_datedup=intent.getStringExtra("reqest_datedup")
            supp_namedup=intent.getStringExtra("supp_namedup")
            supp_gstdup=intent.getStringExtra("supp_gstdup")
            supp_addredup=intent.getStringExtra("supp_addredup")
        }
        catch (e:Exception){

        }


try{
    deletelistener=intent.getStringExtra("deletelistener")

}
catch(e:Exception){

}


        edit.setOnClickListener{
            println("EDT PERMISSION"+editepurreq)
            if(editepurreq=="true"){


                edclick="clicked"
                edit.visibility=View.GONE
                req_update.visibility=View.VISIBLE
                req_update.isEnabled=true




                reqpri.isEnabled=true
                quan_req_first.isEnabled=true
                cess_edt.isEnabled=true
                igst_edt.isEnabled=true


            }
            else if(editepurreq=="false"){
                popup("Update")
            }
        }


        var a= bundle.get("pnm") as ArrayList<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy=bundle.get("phsn")        as ArrayList<String>
        val ly=bundle.get("pmanu")        as ArrayList<String>
        val fy=bundle.get("barcode")      as ArrayList<String>
        val gy=bundle.get("quan")         as ArrayList<String>
        val hy=bundle.get("price")        as ArrayList<String>
        val ky=bundle.get("tot")          as ArrayList<String>
        val kygro=bundle.get("grosstot")          as ArrayList<String>
        val my=bundle.get("cessup")       as ArrayList<String>
        val ny=bundle.get("igst")         as ArrayList<String>
        val cy=bundle.get("cgst")         as ArrayList<String>
        val sy=bundle.get("sgst")         as ArrayList<String>
        val oy=bundle.get("igsttotal")    as ArrayList<String>
        val py=bundle.get("cesstotarray") as ArrayList<String>
        val iddd=bundle.get("idsofli")    as ArrayList<String>
        val idtally=bundle.get("tallyarray") as ArrayList<String>
        val idrec=bundle.get("receivedarray") as ArrayList<String>
        val immy=bundle.get("image") as ArrayList<String>
        val idpros=bundle.get("idpro") as ArrayList<String>

        ids=bundle.get("ids") as Array<String>


        asave=a
        dsysave=dsy
        cysave=cy
        sysave=sy
        fysave=fy
        gysave=gy
        hysave=hy
        kysave=ky
        kygrosave=kygro
        mysave=my
        nysave=ny
        oysave=oy
        pysave=py
        tallysave=idtally
        receivedsave=idrec
        idddsave=iddd
        immysave=immy
        lysave=ly
        idprokysave=idpros



        try {
            val a = intent.getStringExtra("reqid")
            reqid = a

            val b = intent.getStringExtra("reqname")
            reqnm = b


            val skyimg=intent.getStringExtra("imlinks")
            imagelink=skyimg
            try {

                Picasso.with(this)
                        .load(skyimg)
                        .into(comp_toolimg);
            }
            catch (e:Exception){

            }

        }
        catch (e:Exception){

        }

        try {
            supplieridfr=intent.getStringExtra("supplieridfr")


        }
        catch (e:Exception){

        }

        val s=intent.getStringExtra("status")
        status=s
        val sky=intent.getStringExtra("brky")
        oriky=sky

      /*  if(status==""){


        }*/

        val lii=intent.getStringExtra("reqliid")
        reqliid=lii
        val c=intent.getStringExtra("reqdate")
        reqdt=c
        val nm=intent.getStringExtra("reprnms")
        reprnms=nm
        val o=intent.getStringExtra("reqest")
        restimt=o
        val d=intent.getStringExtra("reqmail")
        reqmail=d

        val f=intent.getStringExtra("supnm")
        supnm=f

        comttname.setText(f)


        println("SUPPPP NNNNNAAAMMME"+supnm)
        val g=intent.getStringExtra("supadd1")
        supadd1=g
        val h=intent.getStringExtra("supadd2")
        supadd2=h
        val i=intent.getStringExtra("supadd3")
        supadd3=i
        val j=intent.getStringExtra("supcity")
        supcity=j
        val k=intent.getStringExtra("supstate")
        supstate=k
        val l=intent.getStringExtra("supph")
        supph=l
        val m=intent.getStringExtra("supgst")
        supgst=m
        comphone.setText(l)

        val grochk=intent.getStringExtra("groschk")
        groschk=grochk


        try{
            edclick=intent.getStringExtra("edclick")
        }
        catch (e:Exception){

        }





        try{
            incompstr=intent.getStringExtra("incompstr")
        }
        catch (e:Exception){

        }


        updatestatus=intent.getStringExtra("updstatus")


        println("STATUS OF APPROVE PRND"+status)

        println("STATUS UPDATE STATUS"+updatestatus)


        if(status=="Pending") {


            if ((updatestatus == "update_req_list")&&(edclick.isEmpty()==true)&&(reqid!="Auto-generated")) {
                req_update.visibility = View.GONE
                edit.visibility = View.VISIBLE

            } else if ((updatestatus == "update_req_upd")&&(edclick.isEmpty()==true)&&(reqid!="Auto-generated")) {
                req_update.visibility = View.GONE
                edit.visibility = View.VISIBLE

            } else if ((updatestatus == "start_update_req")&&(edclick.isEmpty()==true)&&(reqid!="Auto-generated")) {

                    req_update.visibility = View.GONE
                    edit.visibility = View.VISIBLE

            }
            else if((updatestatus == "update_req_list")||(updatestatus == "update_req_upd")||(updatestatus == "start_update_req")&&(edclick=="clicked"))
            {

                reqpri.isEnabled=true
                quan_req_first.isEnabled=true
                cess_edt.isEnabled=true
                igst_edt.isEnabled=true
            }

        }
        else if(status=="Approved"){
            req_update.visibility = View.GONE
            reqpri.isEnabled=false
            quan_req_first.isEnabled=false
            cess_edt.isEnabled=false
            igst_edt.isEnabled=false

        }




        val pz=bundle.get("pos") as Int
        pzsave=pz
        var prname=a[pz]
        reqprd_nm.setText(prname)


        //quantity
        var quant=gy[pz]
        var qu:Int

        qu=quant.toInt()

        quan_req_first.setText(quant)

        //hsn code
        var prord=dsy[pz]
        reqhsn.setText(prord)


        //total
        var totalof=ky[pz]
        var prtot:Float
        prtot=totalof.toFloat()
        req_total.setText(totalof)


        //GrossTot
        var totalofgro=kygro[pz]
        var prtotgro:Float
        prtot=totalofgro.toFloat()

        gross_tot.setText((String.format("%.2f",totalofgro.toFloat())))



        //price
        var price=hy[pz]
        var pr:Float
        pr=price.toFloat()

        var prsuf=pr.toString()
        var praddzr=String()

        println("PRICE ORI"+prsuf)

        if((pr.toString().endsWith(".1"))||(pr.toString().endsWith(".2"))||(pr.toString().endsWith(".3"))||(pr.toString().endsWith(".4"))
                ||(pr.toString().endsWith(".5"))||(pr.toString().endsWith(".6"))||(pr.toString().endsWith(".7"))||
                (pr.toString().endsWith(".8")) ||(pr.toString().endsWith(".9"))){
            var przr=pr.toString()
            praddzr=przr+"0"
        }
        else{
            praddzr=pr.toString()

        }

        if((prsuf.toString().endsWith(".0")&&(hy[pz].endsWith(".00")))){
            var ff=prsuf.removeSuffix(".0")
            var kl=ff+".00"
            println("PRI REMOVE"+ff)


            reqpri.setText(kl.toString())
        }
        else if(((prsuf.toString().endsWith(".0")&&(!hy[pz].endsWith(".00"))))){
            var ff=prsuf.removeSuffix(".0")
            var kl=ff+".00"
            println("PRI REMOVE"+ff)


            reqpri.setText(ff.toString())
        }
        else{


            reqpri.setText(praddzr.toString())
        }


        //barcode
        var bar=fy[pz]
        req_bc.setText(bar)



        //cess
        var cssof=my[pz]
        cess_edt.setText(cssof)

        ///IGST
        var igstof=ny[pz]
        igst_edt.setText(igstof)

        //CGST
        var cgstof=cy[pz]
        cgst_edt.setText(cgstof)

        //SGST
        var sgstof=sy[pz]
        scgst_edt.setText(sgstof)


        var igsttotof=oy[pz]
        tax_tot.setText((String.format("%.2f",igsttotof.toFloat())))
        var hs=tax_tot.text.toString()


        var cesstotof=py[pz]
        cess_amt1.setText((String.format("%.2f",cesstotof.toFloat())))
        var gd=cess_amt1.text.toString()


        var idof=iddd[pz]
        newid.setText(idof)
        idli=newid.text.toString()

        var tally=idtally[pz]
        tallyarr.setText(tally)
        tallyar=tallyarr.text.toString()

        var receive=idrec[pz]
        receivearr.setText(receive)
        receivear=receivearr.text.toString()



igst_radio.setOnClickListener {
    if(igst_radio.isChecked==true) {
        igst_edt.isEnabled = true
        csgst_radio.isChecked = false

        cgst_edt.isEnabled = false
        scgst_edt.isEnabled = false

    }

}

        csgst_radio.setOnClickListener {
            if (csgst_radio.isChecked == true){
                igst_radio.isChecked = false
            cgst_edt.isEnabled = true
            scgst_edt.isEnabled = true

            igst_edt.isEnabled = false
        }

        }
        reqprd_nm.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                errnm.visibility=View.INVISIBLE


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {


            }

            override fun afterTextChanged(s: Editable) {
            }
        })


        quan_req_first.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                errqnt.visibility=View.INVISIBLE
                var prq : Float; var igst : Float; var ces : Float;
                var pri : Float;
                if (pr.isEmpty()){
                    pri = 1F
                }else{
                    pri=pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()){
                    igst = 0.0F

                }else{
                    igst=igst_edt.text.toString().toFloat()
                }
                if (reqpri.text.isEmpty()){
                    prq = 0.0F
                }else{
                    prq=reqpri.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess_edt.text.toString().replace("%","").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq*pri)*(igst/100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (prq*pri)*(ces/100)
             cess_amt1.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot +(prq*pri)
                gross_tot.setText((String.format("%.2f",fitot)))


                var k = reqpri.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                req_total.setText((String.format("%.2f",f)))




            }
            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {

                var prq : Float; var igst : Float; var ces : Float;
                var pri : Float;
                if (pr.isEmpty()){
                    pri = 1F
                }else{
                    pri=pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()){
                    igst = 0.0F

                }else{
                    igst=igst_edt.text.toString().toFloat()
                }
                if (reqpri.text.isEmpty()){
                    prq = 0.0F
                }else{
                    prq=reqpri.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess_edt.text.toString().replace("%","").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq*pri)*(igst/100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (prq*pri)*(ces/100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot +(prq*pri)
                gross_tot.setText((String.format("%.2f",fitot)))


                var k = reqpri.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                req_total.setText((String.format("%.2f",f)))
            }
            override fun afterTextChanged(s: Editable) {
            }
        })

        reqpri.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                errpri.visibility=View.INVISIBLE
                var prq : Float; var igst : Float; var ces : Float;var qty:Float;
                req_total.setText("")
                gross_tot.setText("")
                var pri : Float;
                if (pr.isEmpty()){
                    pri = 0F

                }else{
                    pri=pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()){
                    igst = 0.0F

                }else{
                    igst=igst_edt.text.toString().toFloat()
                }

                if (quan_req_first.text.isEmpty()){
                    qty = 1.0F
                }else{
                    qty=quan_req_first.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess_edt.text.toString().replace("%","").toFloat()
                }


                var k =   quan_req_first.text.toString()
                var l = pri.toBigDecimal()
                val oi = k.toBigDecimal()
                val f = l.times(oi)
               req_total.setText(f.toString())
                tax_tot.setText((String.format("%.2f",f)))

                //IGST TOTAL
                val ttot = (pri*qty)*(igst/100)
                tax_tot.setText((String.format("%.2f",ttot)))


                //CESS TOTAL
                val cesstot = (pri*qty)*(ces/100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot +(pri*qty)
                gross_tot.setText((String.format("%.2f",fitot)))





            }
            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
                var prq : Float; var igst : Float; var ces : Float;var qty:Float;
                req_total.setText("")
                gross_tot.setText("")
                var pri : Float;
                if (pr.isEmpty()){
                    pri = 0F

                }else{
                    pri=pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()){
                    igst = 0.0F

                }else{
                    igst=igst_edt.text.toString().toFloat()
                }

                if (quan_req_first.text.isEmpty()){
                    qty = 1.0F
                }else{
                    qty=quan_req_first.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()){
                    ces = 0.0F
                }else{
                    ces= cess_edt.text.toString().replace("%","").toFloat()
                }


                var k =   quan_req_first.text.toString()
                var l = pri.toBigDecimal()
                val oi = k.toBigDecimal()
                val f = l.times(oi)
                req_total.setText(f.toString())
                tax_tot.setText((String.format("%.2f",f)))

                //IGST TOTAL
                val ttot = (pri*qty)*(igst/100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (pri*qty)*(ces/100)
                cess_amt1.setText((String.format("%.2f",cesstot)))


                val fitot = ttot + cesstot +(pri*qty)
                gross_tot.setText((String.format("%.2f",fitot)))

            }
            override fun afterTextChanged(s: Editable) {
            }
        })


        cess_edt.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {
                var pri : Float; var igst : Float; var ces : Float;var qty:Float;
                if (reqpri.text.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=reqpri.text.toString().toFloat()
                }
                if ((quan_req_first.text.isEmpty())){
                    qty = 1.0F
                }else{
                    qty=quan_req_first.text.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()){
                    igst=0.0F
                }else{
                    try{
                        igst= igst_edt.text.toString().replace("%","").toFloat()

                    }
                    catch (e:Exception)
                    {
                        igst=igstcalc
                    }
                }
                if ((cess.isEmpty())){
                    ces = 0.0F
                }else{

                    try{
                        ces= cess.toString().replace("%","").toFloat()

                    }
                    catch (e:Exception)
                    {
                        ces=cesscalc
                    }
                }

                //cgst & sgst
                val ans =igst/2
                cgst_edt.setText("$ans"+"%")
                scgst_edt.setText("$ans"+"%")

                //tax total
                val ttot = (pri*qty)*(igst/100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //cess total
                val cesstot = (pri*qty)*(ces/100)
                cess_amt1.setText((String.format("%.2f",cesstot)))


                //gross total
                val fitot = ttot  + cesstot + (pri*qty)
                gross_tot.setText((String.format("%.2f",fitot)))



            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })
        igst_edt.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                var pri : Float; var igst : Float; var ces : Float;var qty:Float;
                if (reqpri.text.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=reqpri.text.toString().toFloat()
                }
                if (quan_req_first.text.isEmpty()){
                    qty = 1.0F
                }else{
                    qty=quan_req_first.text.toString().toFloat()
                }
                if (ig.isEmpty()){
                    igst=0.0F
                }else{
                    try{
                        igst= ig.toString().replace("%","").toFloat()

                    }
                    catch (e:Exception)
                    {
                        igst=igstcalc
                    }
                }
                if (cess_edt.text.isEmpty()){
                    ces = 0.0F
                }else{
                    try{
                        ces= cess_edt.text.toString().replace("%","").toFloat()

                    }
                    catch (e:Exception)
                    {
                        ces=cesscalc
                    }
                }

                //cgst & sgst
                val ans =igst/2
                cgst_edt.setText("$ans"+"%")
                scgst_edt.setText("$ans"+"%")

                //tax total
                val ttot = (pri*qty)*(igst/100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //cess total
                val cesstot = (pri*qty)*(ces/100)
                cess_amt1.setText((String.format("%.2f",cesstot)))


                //gross total
                val fitot = ttot  + cesstot + (pri*qty)
                gross_tot.setText((String.format("%.2f",fitot)))



            }
            override fun beforeTextChanged(ig: CharSequence, start: Int, count: Int, after: Int) {
                var pri : Float; var igst : Float; var ces : Float;var qty:Float;
                if (reqpri.text.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=reqpri.text.toString().toFloat()
                }
                if (quan_req_first.text.isEmpty()){
                    qty = 1.0F
                }else{
                    qty=quan_req_first.text.toString().toFloat()
                }
                if (ig.isEmpty()){
                    igst=0.0F
                }else{
                    try{
                        igst= ig.toString().replace("%","").toFloat()

                    }
                    catch (e:Exception)
                    {
                        igst=igstcalc
                    }
                }
                if (cess_edt.text.isEmpty()){
                    ces = 0.0F
                }else{
                    try{
                        ces= cess_edt.text.toString().replace("%","").toFloat()

                    }
                    catch (e:Exception)
                    {
                        ces=cesscalc
                    }
                }

                //cgst & sgst
                val ans =igst/2
                cgst_edt.setText("$ans"+"%")
                scgst_edt.setText("$ans"+"%")

                //tax total
                val ttot = (pri*qty)*(igst/100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //cess total
                val cesstot = (pri*qty)*(ces/100)
                cess_amt1.setText((String.format("%.2f",cesstot)))


                //gross total
                val fitot = ttot  + cesstot + (pri*qty)
                gross_tot.setText((String.format("%.2f",fitot)))



            }
            override fun afterTextChanged(s: Editable) {
            }
        })

        req_total.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {


            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })


        req_bc.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {


            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })


        reqhsn.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {


            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
            }
        })


       // -------------------------------------------------------BACK ACTION-------------------------------------------//

        userback.setOnClickListener {
            onBackPressed()
        }


        //------------------------------------------------------UPDATE------------------------------------------------//

        req_update.setOnClickListener {

            if (reqprd_nm.length() == 0) {
                errnm.visibility = View.VISIBLE

                errnm.setText("Required field*")
            }
            if (reqpri.length() == 0) {
                errpri.visibility = View.VISIBLE

                errpri.setText("Required field*")
            }
            if (quan_req_first.length() == 0) {
                errqnt.visibility = View.VISIBLE

                errqnt.setText("Required field*")
            }

            if ((errnm.visibility == View.INVISIBLE) && (errpri.visibility == View.INVISIBLE) && (errqnt.visibility == View.INVISIBLE)) {
                if((hysave[pzsave]!=reqpri.text.toString())||(gysave[pzsave]!=quan_req_first.text.toString())||
                        (nysave[pzsave]!=igst_edt.text.toString())||(mysave[pzsave]!=cess_edt.text.toString())){
                    groschk="edited"
                    editchange="changed"
                }
                val o = Intent(this@RequestUpdateActivity, RequestBottproActivity::class.java)
                o.putExtra("from_req", "update_request")
                var dx = reqprd_nm.text
                var ex = reqhsn.text
                var fx = reqpri.text
                var gx = quan_req_first.text
                var hx = req_bc.text
                var ix = req_total.text
                var ixgro = gross_tot.text
                var jx = cess_edt.text
                var kx = igst_edt.text.toString()
                var px = cgst_edt.text.toString()
                var qx = scgst_edt.text.toString()
                var lx = tax_tot.text
                var mx = cess_amt1.text
                var tallx = tallyarr.text
                var receivex = receivearr.text


                a[pz] = dx.toString()
                dsy[pz] = ex.toString()
                fy[pz] = hx.toString()
                gy[pz] = gx.toString()
                hy[pz] = fx.toString()
                ky[pz] = ix.toString()
                kygro[pz] = ixgro.toString()
                my[pz] = jx.toString()
                ny[pz] = kx.toString()
                cy[pz] = px.toString()
                sy[pz] = qx.toString()
                oy[pz] = lx.toString()
                py[pz] = mx.toString()
                idtally[pz] = tallx.toString()
                idrec[pz] = receivex.toString()

                o.putExtra("renm", a)
                o.putExtra("from_req", "update_request")
                o.putExtra("remanu", ly)
                o.putExtra("rekey", iddd)
                o.putExtra("rehsn", dsy)
                o.putExtra("reprice", hy)
                o.putExtra("requan", gy)
                o.putExtra("rebc", fy)
                o.putExtra("retotal", ky)
                o.putExtra("regrosstotal", kygro)
                o.putExtra("recess", my)
                o.putExtra("reigst", ny)
                o.putExtra("recgst", cy)
                o.putExtra("resgst", sy)
                o.putExtra("retally", idtally)
                o.putExtra("rereceived", idrec)
                o.putExtra("reigst_total", oy)
                o.putExtra("recesstotal", py)
                o.putExtra("reimmg", immy)
                o.putExtra("req_id", reqid)
                o.putExtra("req_liids", reqliid)
                o.putExtra("req_prnms", reprnms)
                o.putExtra("req_date", reqdt)
                o.putExtra("req_name", reqnm)
                o.putExtra("req_mail", reqmail)
                o.putExtra("req_esti", restimt)

                o.putExtra("supplieridfr",supplieridfr)
                o.putExtra("edclick",edclick)
                o.putExtra("req_supnm", supnm)
                o.putExtra("req_supadd1", supadd1)
                o.putExtra("groschk",groschk)
                o.putExtra("idpro", idpros)
                o.putExtra("incompstr",incompstr)

                o.putExtra("request_datedup",request_datedup)
                o.putExtra("reqest_datedup",reqest_datedup)
                o.putExtra("supp_namedup",supp_namedup)
                o.putExtra("supp_gstdup",supp_gstdup)
                o.putExtra("supp_addredup",supp_addredup)
                o.putExtra("befnm",befnm)

                o.putExtra("req_supadd2", supadd2)
                o.putExtra("req_supadd3", supadd3)
                o.putExtra("req_supgst", supgst)
                o.putExtra("req_supcity", supcity)
                o.putExtra("req_supstate", supstate)
                o.putExtra("req_supph", supph)
                o.putExtra("status", status)
                o.putExtra("orikys", oriky)
                o.putExtra("images", imagelink)
                o.putExtra("viewsuppin", viewsuppin)
                o.putExtra("addsuppin", addsuppin)
                o.putExtra("deletesuppin", deletesuppin)
                o.putExtra("editsuppin", editesuppin)
                o.putExtra("transfersuppin", transfersuppin)
                o.putExtra("exportsuppin", exportsuppin)


                o.putExtra("viewpurord", viewpurord)
                o.putExtra("addpurord", addpurord)
                o.putExtra("deletepurord", deletepurord)
                o.putExtra("editpurord", editepurord)
                o.putExtra("transferpurord", transferpurord)
                o.putExtra("exportpurord", exportpurord)
                o.putExtra("sendpurord", sendpurpo)


                o.putExtra("deletelistener",deletelistener)

                o.putExtra("viewpurreq", viewpurreq)
                o.putExtra("addpurreq", addpurreq)
                o.putExtra("deletepurreq", deletepurreq)
                o.putExtra("editpurreq", editepurreq)
                o.putExtra("transferpurreq", transferpurreq)
                o.putExtra("exportpurreq", exportpurreq)


                o.putExtra("ids",ids)





                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }
            else{
                Toast.makeText(applicationContext,"Please fill required fields", Toast.LENGTH_SHORT).show()
            }
        }

    }
    override fun onBackPressed() {
        println("PRICE  "+hysave[pzsave])
        println("RECEIVED PRICE  "+gysave[pzsave])

        if(groschk!="list") {
            editchange = ""
            groschk = ""
        }
        if((hysave[pzsave]!=reqpri.text.toString())||(gysave[pzsave]!=quan_req_first.text.toString())||
                (nysave[pzsave]!=igst_edt.text.toString())||(mysave[pzsave]!=cess_edt.text.toString())){
            groschk="edited"
            editchange="changed"
        }

        if (editchange.isEmpty()) {
            val o = Intent(this@RequestUpdateActivity, RequestBottproActivity::class.java)
            o.putExtra("from_req", "update_request")
            o.putExtra("renm", asave)

            o.putExtra("remanu", lysave)
            o.putExtra("rekey", idddsave)
            o.putExtra("rehsn", dsysave)
            o.putExtra("reprice", hysave)
            o.putExtra("requan", gysave)
            o.putExtra("rebc", fysave)
            o.putExtra("retotal", kysave)
            o.putExtra("regrosstotal", kygrosave)
            o.putExtra("recess", mysave)
            o.putExtra("reigst", nysave)
            o.putExtra("recgst", cysave)
            o.putExtra("resgst", sysave)
            o.putExtra("retally", tallysave)
            o.putExtra("rereceived", receivedsave)
            o.putExtra("reigst_total", oysave)
            o.putExtra("recesstotal", pysave)
            o.putExtra("reimmg", immysave)
            o.putExtra("req_id", reqid)
            o.putExtra("req_liids", reqliid)
            o.putExtra("req_prnms", reprnms)
            o.putExtra("req_date", reqdt)
            o.putExtra("groschk",groschk)
            o.putExtra("idpro", idprokysave)
            o.putExtra("edclick",edclick)
            o.putExtra("incompstr",incompstr)
            o.putExtra("deletelistener",deletelistener)
            o.putExtra("request_datedup",request_datedup)
            o.putExtra("reqest_datedup",reqest_datedup)
            o.putExtra("supp_namedup",supp_namedup)
            o.putExtra("supp_gstdup",supp_gstdup)
            o.putExtra("supp_addredup",supp_addredup)
            o.putExtra("befnm",befnm)
            o.putExtra("supplieridfr",supplieridfr)


            o.putExtra("req_name", reqnm)
            o.putExtra("req_mail", reqmail)
            o.putExtra("req_esti", restimt)

            o.putExtra("req_supnm", supnm)
            o.putExtra("req_supadd1", supadd1)
            o.putExtra("req_supadd2", supadd2)
            o.putExtra("req_supadd3", supadd3)
            o.putExtra("req_supgst", supgst)
            o.putExtra("req_supcity", supcity)
            o.putExtra("req_supstate", supstate)
            o.putExtra("req_supph", supph)
            o.putExtra("status", status)
            o.putExtra("orikys", oriky)
            o.putExtra("images", imagelink)
            o.putExtra("viewsuppin", viewsuppin)
            o.putExtra("addsuppin", addsuppin)
            o.putExtra("deletesuppin", deletesuppin)
            o.putExtra("editsuppin", editesuppin)
            o.putExtra("transfersuppin", transfersuppin)
            o.putExtra("exportsuppin", exportsuppin)


            o.putExtra("viewpurord", viewpurord)
            o.putExtra("addpurord", addpurord)
            o.putExtra("deletepurord", deletepurord)
            o.putExtra("editpurord", editepurord)
            o.putExtra("transferpurord", transferpurord)
            o.putExtra("exportpurord", exportpurord)
            o.putExtra("sendpurord", sendpurpo)




            o.putExtra("viewpurreq", viewpurreq)
            o.putExtra("addpurreq", addpurreq)
            o.putExtra("deletepurreq", deletepurreq)
            o.putExtra("editpurreq", editepurreq)
            o.putExtra("transferpurreq", transferpurreq)
            o.putExtra("exportpurreq", exportpurreq)



            o.putExtra("ids",ids)





            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
        else if (editchange == "changed") {
            savepopup()

        }
    }

    fun savepopup() {
        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr
        }
        if (expr != null) {
            exportpurreq = expr
        }
        val builder = AlertDialog.Builder(this@RequestUpdateActivity)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")

            setPositiveButton("Yes") { dialog, whichButton ->
                println("YES")
                if (reqprd_nm.length() == 0) {
                    errnm.visibility = View.VISIBLE

                    errnm.setText("Required field*")
                }
                if (reqpri.length() == 0) {
                    errpri.visibility = View.VISIBLE

                    errpri.setText("Required field*")
                }
                if (quan_req_first.length() == 0) {
                    errqnt.visibility = View.VISIBLE

                    errqnt.setText("Required field*")
                }

                if ((errnm.visibility == View.INVISIBLE) && (errpri.visibility == View.INVISIBLE) && (errqnt.visibility == View.INVISIBLE)&&(net_status()==true)) {
                    val o = Intent(this@RequestUpdateActivity, RequestBottproActivity::class.java)
                    o.putExtra("from_req", "update_request")
                    var dx = reqprd_nm.text
                    var ex = reqhsn.text
                    var fx = reqpri.text
                    var gx = quan_req_first.text
                    var hx = req_bc.text
                    var ix = req_total.text
                    var ixgro = gross_tot.text
                    var jx = cess_edt.text
                    var kx = igst_edt.text.toString()
                    var px = cgst_edt.text.toString()
                    var qx = scgst_edt.text.toString()
                    var lx = tax_tot.text
                    var mx = cess_amt1.text
                    var tallx = tallyarr.text
                    var receivex = receivearr.text

                    asave[pzsave] = dx.toString()
                    dsysave[pzsave] = ex.toString()
                    fysave[pzsave] = hx.toString()
                    gysave[pzsave] = gx.toString()
                    hysave[pzsave] = fx.toString()
                    kysave[pzsave] = ix.toString()
                    kygrosave[pzsave] = ixgro.toString()
                    mysave[pzsave] = jx.toString()
                    nysave[pzsave] = kx.toString()
                    cysave[pzsave] = px.toString()
                    sysave[pzsave] = qx.toString()
                    oysave[pzsave] = lx.toString()
                    pysave[pzsave] = mx.toString()
                    tallysave[pzsave] = tallx.toString()
                    receivedsave[pzsave] = receivex.toString()

                    o.putExtra("renm", asave)
                    o.putExtra("from_req", "update_request")
                    o.putExtra("remanu", lysave)
                    o.putExtra("rekey", idddsave)
                    o.putExtra("rehsn", dsysave)
                    o.putExtra("reprice", hysave)
                    o.putExtra("requan", gysave)
                    o.putExtra("rebc", fysave)
                    o.putExtra("retotal", kysave)
                    o.putExtra("regrosstotal", kygrosave)
                    o.putExtra("recess", mysave)
                    o.putExtra("reigst", nysave)
                    o.putExtra("recgst", cysave)
                    o.putExtra("resgst", sysave)
                    o.putExtra("retally", tallysave)
                    o.putExtra("groschk",groschk)
                    o.putExtra("idpro", idprokysave)
                    o.putExtra("supplieridfr",supplieridfr)

                    o.putExtra("rereceived", receivedsave)
                    o.putExtra("reigst_total", oysave)
                    o.putExtra("recesstotal", pysave)
                    o.putExtra("reimmg", immysave)
                    o.putExtra("req_id", reqid)
                    o.putExtra("req_liids", reqliid)
                    o.putExtra("req_prnms", reprnms)
                    o.putExtra("req_date", reqdt)
                    o.putExtra("req_name", reqnm)
                    o.putExtra("req_mail", reqmail)
                    o.putExtra("req_esti", restimt)
                    o.putExtra("edclick",edclick)
                    o.putExtra("incompstr",incompstr)
                    o.putExtra("deletelistener",deletelistener)
                    o.putExtra("req_supnm", supnm)
                    o.putExtra("req_supadd1", supadd1)
                    o.putExtra("req_supadd2", supadd2)
                    o.putExtra("req_supadd3", supadd3)
                    o.putExtra("req_supgst", supgst)
                    o.putExtra("req_supcity", supcity)
                    o.putExtra("req_supstate", supstate)
                    o.putExtra("req_supph", supph)
                    o.putExtra("status", status)
                    o.putExtra("orikys", oriky)
                    o.putExtra("images", imagelink)
                    o.putExtra("viewsuppin", viewsuppin)
                    o.putExtra("addsuppin", addsuppin)
                    o.putExtra("deletesuppin", deletesuppin)
                    o.putExtra("editsuppin", editesuppin)
                    o.putExtra("transfersuppin", transfersuppin)
                    o.putExtra("exportsuppin", exportsuppin)

                    o.putExtra("viewpurord", viewpurord)
                    o.putExtra("addpurord", addpurord)
                    o.putExtra("deletepurord", deletepurord)
                    o.putExtra("editpurord", editepurord)
                    o.putExtra("transferpurord", transferpurord)
                    o.putExtra("exportpurord", exportpurord)
                    o.putExtra("sendpurord", sendpurpo)


                    o.putExtra("request_datedup",request_datedup)
                    o.putExtra("reqest_datedup",reqest_datedup)
                    o.putExtra("supp_namedup",supp_namedup)
                    o.putExtra("supp_gstdup",supp_gstdup)
                    o.putExtra("supp_addredup",supp_addredup)
                    o.putExtra("befnm",befnm)


                    o.putExtra("viewpurreq", viewpurreq)
                    o.putExtra("addpurreq", addpurreq)
                    o.putExtra("deletepurreq", deletepurreq)
                    o.putExtra("editpurreq", editepurreq)
                    o.putExtra("transferpurreq", transferpurreq)
                    o.putExtra("exportpurreq", exportpurreq)




                    o.putExtra("ids",ids)
                    startActivity(o)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()


            }
                else{
                    if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
                    }
                }

        }
            setNegativeButton("No") { dialog, whichButton ->

                groschk=""
                val o = Intent(this@RequestUpdateActivity, RequestBottproActivity::class.java)
                o.putExtra("from_req", "update_request")
                o.putExtra("renm", asave)

                o.putExtra("remanu", lysave)
                o.putExtra("rekey", idddsave)
                o.putExtra("rehsn", dsysave)
                o.putExtra("reprice", hysave)
                o.putExtra("requan", gysave)
                o.putExtra("rebc", fysave)
                o.putExtra("retotal", kysave)
                o.putExtra("regrosstotal", kygrosave)
                o.putExtra("recess", mysave)
                o.putExtra("reigst", nysave)
                o.putExtra("recgst", cysave)
                o.putExtra("resgst", sysave)
                o.putExtra("retally", tallysave)
                o.putExtra("rereceived", receivedsave)
                o.putExtra("reigst_total", oysave)
                o.putExtra("recesstotal", pysave)
                o.putExtra("groschk",groschk)
                o.putExtra("idpro", idprokysave)
                o.putExtra("deletelistener",deletelistener)
                o.putExtra("reimmg", immysave)
                o.putExtra("req_id", reqid)
                o.putExtra("req_liids", reqliid)
                o.putExtra("req_prnms", reprnms)
                o.putExtra("req_date", reqdt)
                o.putExtra("req_name", reqnm)
                o.putExtra("req_mail", reqmail)
                o.putExtra("req_esti", restimt)
                o.putExtra("edclick",edclick)
                o.putExtra("incompstr",incompstr)
                o.putExtra("supplieridfr",supplieridfr)

                o.putExtra("req_supnm", supnm)
                o.putExtra("req_supadd1", supadd1)
                o.putExtra("req_supadd2", supadd2)
                o.putExtra("req_supadd3", supadd3)
                o.putExtra("req_supgst", supgst)
                o.putExtra("req_supcity", supcity)
                o.putExtra("req_supstate", supstate)
                o.putExtra("req_supph", supph)
                o.putExtra("status", status)
                o.putExtra("orikys", oriky)
                o.putExtra("images", imagelink)
                o.putExtra("viewsuppin", viewsuppin)
                o.putExtra("addsuppin", addsuppin)
                o.putExtra("deletesuppin", deletesuppin)
                o.putExtra("editsuppin", editesuppin)
                o.putExtra("transfersuppin", transfersuppin)
                o.putExtra("exportsuppin", exportsuppin)

                o.putExtra("viewpurord", viewpurord)
                o.putExtra("addpurord", addpurord)
                o.putExtra("deletepurord", deletepurord)
                o.putExtra("editpurord", editepurord)
                o.putExtra("transferpurord", transferpurord)
                o.putExtra("exportpurord", exportpurord)
                o.putExtra("sendpurord", sendpurpo)

                o.putExtra("viewpurreq", viewpurreq)
                o.putExtra("addpurreq", addpurreq)
                o.putExtra("deletepurreq", deletepurreq)
                o.putExtra("editpurreq", editepurreq)
                o.putExtra("transferpurreq", transferpurreq)
                o.putExtra("exportpurreq", exportpurreq)
                o.putExtra("request_datedup",request_datedup)
                o.putExtra("reqest_datedup",reqest_datedup)
                o.putExtra("supp_namedup",supp_namedup)
                o.putExtra("supp_gstdup",supp_gstdup)
                o.putExtra("supp_addredup",supp_addredup)
                o.putExtra("befnm",befnm)

                o.putExtra("ids",ids)

                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
                dialog.dismiss()
            }
            val dialog = builder.create()
            dialog.show()



            }
            }
    companion object {



        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        var updatestatus= String()
        var reqid = String()
        var status= String()
        var edclick= String()
        private var req_updatedis: Button? = null

        private var userbackdis: ImageButton? = null
        private var scrollView2dis:ScrollView?=null
        private var cess_edtdis:EditText?=null
        private var igst_edtdis:EditText?=null
        private var quan_req_firstdis:EditText?=null
        private var reqpridis:EditText?=null

        private var editdis:ImageButton? =null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE
                req_updatedis!!.isEnabled=false


               val color = 0x96ffffff;
                val  drawables =  ColorDrawable(color.toInt());
                scrollView2dis!!.foreground=drawables

                cess_edtdis!!.isEnabled=false
                igst_edtdis!!.isEnabled=false
                quan_req_firstdis!!.isEnabled=false
                reqpridis!!.isEnabled=false

                userbackdis!!.isEnabled=false


                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }


            }
            else
            {

                if(status=="Pending") {


                    if ((updatestatus == "update_req_list")&&(edclick.isEmpty()==true)&&(reqid!="Auto-generated")) {
                        req_updatedis!!.visibility=View.INVISIBLE
                        editdis!!.visibility=View.VISIBLE
                        cess_edtdis!!.isEnabled=false
                        igst_edtdis!!.isEnabled=false
                        quan_req_firstdis!!.isEnabled=false
                        reqpridis!!.isEnabled=false
                        req_updatedis!!.isEnabled=false

                    } else if ((updatestatus == "update_req_upd")&&(edclick.isEmpty()==true)&&(reqid!="Auto-generated")) {
                        req_updatedis!!.visibility=View.INVISIBLE
                        editdis!!.visibility=View.VISIBLE
                        cess_edtdis!!.isEnabled=false
                        igst_edtdis!!.isEnabled=false
                        quan_req_firstdis!!.isEnabled=false
                        reqpridis!!.isEnabled=false
                        req_updatedis!!.isEnabled=false

                    } else if ((updatestatus == "start_update_req")&&(edclick.isEmpty()==true)&&(reqid!="Auto-generated")) {
                        req_updatedis!!.visibility=View.INVISIBLE
                        editdis!!.visibility=View.VISIBLE
                        cess_edtdis!!.isEnabled=false
                        igst_edtdis!!.isEnabled=false
                        quan_req_firstdis!!.isEnabled=false
                        reqpridis!!.isEnabled=false
                        req_updatedis!!.isEnabled=false

                    }
                    else if((updatestatus == "update_req_list")||(updatestatus == "update_req_upd")||(updatestatus == "start_update_req")&&(edclick=="clicked"))
                    {

                        req_updatedis!!.visibility=View.VISIBLE
                        editdis!!.visibility=View.GONE
                        cess_edtdis!!.isEnabled=true
                        igst_edtdis!!.isEnabled=true
                        quan_req_firstdis!!.isEnabled=true
                        reqpridis!!.isEnabled=true
                        req_updatedis!!.isEnabled=true
                    }

                }
                else if(status=="Approved"){
                    req_updatedis!!.visibility = View.GONE
                    cess_edtdis!!.isEnabled=false
                    igst_edtdis!!.isEnabled=false
                    quan_req_firstdis!!.isEnabled=false
                    reqpridis!!.isEnabled=false
                    req_updatedis!!.isEnabled=false

                }



                constraintLayout3dis!!.visibility=View.GONE

                scrollView2dis!!.setBackgroundColor(Color.parseColor("#32ffffff"))
                scrollView2dis!!.foreground=null
                userbackdis!!.isEnabled=true

                relativeslayoutdis!!.visibility=View.GONE







            }
        }
    }

    fun popup(st:String){
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
