package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_changestverifyact.*

class changestverifyact : AppCompatActivity() {
    internal lateinit var sessions: SessionManagement
    internal lateinit var myDb: Databasehelper_service

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_changestverifyact)

        userback.setOnClickListener {
            onBackPressed()

        }
        myDb = Databasehelper_service(this)

        sessions = SessionManagement(applicationContext)
        acverify.setOnClickListener {
            if(net_status()==true) {
                val alert = AlertDialog.Builder(this@changestverifyact)
                val inflater = this.layoutInflater
                val dialog = alert.create()
                dialog.setView(inflater.inflate(R.layout.loginpop, null))
                dialog.show()
                val ok = dialog.findViewById<Button>(R.id.ok) as Button


                ok.setOnClickListener { views ->

                    //Logout from current session and delete all local service.
                    sessions.logoutUser()
                    myDb.deleteall()
                    val f = Intent(this@changestverifyact, ScanActivity::class.java)
                    startActivity(f)
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                    finish()
                }


            }

        }

    }
    fun net_status():Boolean{//Checks the internet state.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
    override fun onBackPressed() {//Back action
        val f = Intent(this@changestverifyact, MainActivity::class.java)
        startActivity(f)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
        finish()
    }
}
