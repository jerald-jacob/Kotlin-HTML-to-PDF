package com.example.vinitas.gallery.sampledata

import android.util.Log.getStackTraceString
import com.zfdang.multiple_images_selector.SelectorSettings


class ImageItem(var name: String, var path: String, var time: Long) {


    val isCamera: Boolean
        get() = this.path == SelectorSettings.CAMERA_ITEM_PATH

    override fun equals(o: Any?): Boolean {
        try {
            val other = o as ImageItem?
            return this.path.equals(other!!.path, ignoreCase = true)
        } catch (e: ClassCastException) {

        }

        return super.equals(o)
    }

    override fun toString(): String {
        return "ImageItem{" +
                "name='" + name + '\''.toString() +
                ", path='" + path + '\''.toString() +
                ", time=" + time +
                '}'.toString()
    }

    companion object {
        private val TAG = "ImageItem"
        val CAMERA_PATH = "Camera"
    }
}