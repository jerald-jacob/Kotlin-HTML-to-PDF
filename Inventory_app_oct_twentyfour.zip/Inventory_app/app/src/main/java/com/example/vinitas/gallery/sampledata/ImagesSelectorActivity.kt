package com.example.vinitas.gallery.sampledata
import android.Manifest
import android.app.Activity
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.StrictMode
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.ActionBar
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.example.vinitas.inventory_app.R

import com.zfdang.multiple_images_selector.OnFolderRecyclerViewInteractionListener
import com.zfdang.multiple_images_selector.OnImageRecyclerViewInteractionListener
import com.zfdang.multiple_images_selector.SelectorSettings
import com.zfdang.multiple_images_selector.models.FolderItem
import com.zfdang.multiple_images_selector.models.FolderListContent
import com.zfdang.multiple_images_selector.models.ImageItem
import com.zfdang.multiple_images_selector.models.ImageListContent
import com.zfdang.multiple_images_selector.utilities.FileUtils
import com.zfdang.multiple_images_selector.utilities.StringUtils

import java.io.File
import java.io.IOException
import java.util.ArrayList

import rx.Observable
import rx.Subscriber
import rx.android.schedulers.AndroidSchedulers
import rx.functions.Func1
import rx.schedulers.Schedulers
import xyz.danoz.recyclerviewfastscroller.vertical.VerticalRecyclerViewFastScroller

class ImagesSelectorActivitys : AppCompatActivity(), OnImageRecyclerViewInteractionListener, OnFolderRecyclerViewInteractionListener, View.OnClickListener {

    private val mColumnCount = 3

    // custom action bars
    private var mButtonBack: ImageView? = null
    private var mButtonConfirm: Button? = null

    private var recyclerView: RecyclerView? = null

    // folder selecting related


    private var mPopupAnchorView: View? = null
    private var mFolderSelectButton: TextView? = null
    private var mFolderPopupWindow: FolderPopupWindow? = null

    private var currentFolderPath: String? = null
    internal var contentResolver:ContentResolver? =null

    private var mTempImageFile: File? = null

    private val projections = arrayOf(MediaStore.Images.Media.DATA, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media._ID)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_images_selector)


           val builder =  StrictMode.VmPolicy.Builder();
    StrictMode.setVmPolicy(builder.build());

        // hide actionbar
        val actionBar = supportActionBar
        actionBar?.hide()

        // get parameters from bundle
        val intent = intent
        SelectorSettings.mMaxImageNumber = intent.getIntExtra(SelectorSettings.SELECTOR_MAX_IMAGE_NUMBER, SelectorSettings.mMaxImageNumber)
        SelectorSettings.isShowCamera = intent.getBooleanExtra(SelectorSettings.SELECTOR_SHOW_CAMERA, SelectorSettings.isShowCamera)
        SelectorSettings.mMinImageSize = intent.getIntExtra(SelectorSettings.SELECTOR_MIN_IMAGE_SIZE, SelectorSettings.mMinImageSize)

        val selected = intent.getStringArrayListExtra(SelectorSettings.SELECTOR_INITIAL_SELECTED_LIST)
        ImageListContent.SELECTED_IMAGES.clear()
        if (selected != null && selected.size > 0) {
            ImageListContent.SELECTED_IMAGES.addAll(selected)
        }

        // initialize widgets in custom actionbar
        mButtonBack = findViewById<View>(R.id.selector_button_back) as ImageView
        mButtonBack!!.setOnClickListener(this)

        mButtonConfirm = findViewById<View>(R.id.selector_button_confirm) as Button
        mButtonConfirm!!.setOnClickListener(this)

        // initialize recyclerview
        val rview = findViewById<View>(R.id.image_recycerview)
        // Set the adapter
        if (rview is RecyclerView) {
            val context = rview.getContext()
            recyclerView = rview
            if (mColumnCount <= 1) {
                recyclerView!!.layoutManager = LinearLayoutManager(context)
            } else {
                recyclerView!!.layoutManager = GridLayoutManager(context, mColumnCount)
            }
            recyclerView!!.adapter = ImageRecyclerViewAdapter(ImageListContent.IMAGES, this)

            val fastScroller = findViewById<View>(R.id.recyclerview_fast_scroller) as VerticalRecyclerViewFastScroller
            // Connect the recycler to the scroller (to let the scroller scroll the list)
            fastScroller.setRecyclerView(recyclerView)
            // Connect the scroller to the recycler (to let the recycler scroll the scroller's handle)
            recyclerView!!.addOnScrollListener(fastScroller.onScrollListener)
        }

        // popup windows will be anchored to this view
        mPopupAnchorView = findViewById(R.id.selector_footer)

        // initialize buttons in footer
        mFolderSelectButton = findViewById<View>(R.id.selector_image_folder_button) as TextView
        mFolderSelectButton!!.setText(R.string.selector_folder_all)
        mFolderSelectButton!!.setOnClickListener {
            if (mFolderPopupWindow == null) {
                mFolderPopupWindow = FolderPopupWindow()
                mFolderPopupWindow!!.initPopupWindow(this@ImagesSelectorActivitys)
            }

            if (mFolderPopupWindow!!.isShowing) {
                mFolderPopupWindow!!.dismiss()
            } else {
                mFolderPopupWindow!!.showAtLocation(mPopupAnchorView, Gravity.BOTTOM, 10, 150)
            }
        }

        currentFolderPath = ""
        FolderListContent.clear()
        ImageListContent.clear()

        updateDoneButton()

        requestReadStorageRuntimePermission()
    }

    fun requestReadStorageRuntimePermission() {
        if (ContextCompat.checkSelfPermission(this@ImagesSelectorActivitys, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this@ImagesSelectorActivitys,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                    MY_PERMISSIONS_REQUEST_STORAGE_CODE)
        } else {
            LoadFolderAndImages()
        }
    }


    fun requestCameraRuntimePermissions() {
        if (ContextCompat.checkSelfPermission(this@ImagesSelectorActivitys, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this@ImagesSelectorActivitys, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this@ImagesSelectorActivitys,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA),
                    MY_PERMISSIONS_REQUEST_CAMERA_CODE)
        } else {
            launchCamera()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            MY_PERMISSIONS_REQUEST_STORAGE_CODE -> {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.size == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    LoadFolderAndImages()
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this@ImagesSelectorActivitys, getString(R.string.selector_permission_error), Toast.LENGTH_SHORT).show()
                }
                return
            }
            MY_PERMISSIONS_REQUEST_CAMERA_CODE -> {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.size == 2 && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                    launchCamera()
                } else {
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(this@ImagesSelectorActivitys, getString(R.string.selector_permission_error), Toast.LENGTH_SHORT).show()
                }
                return
            }
        }
    }

    // this method is to load images and folders for all
    fun LoadFolderAndImages() {
        Log.d(TAG, "Load Folder And Images...")
        Observable.just("")
                .flatMap {
                    val results = ArrayList<ImageItem>()

                    val contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                    val where = MediaStore.Images.Media.SIZE + " > " + SelectorSettings.mMinImageSize
                    val sortOrder = MediaStore.Images.Media.DATE_ADDED + " DESC"

                    contentResolver = getContentResolver()
                    val cursor = contentResolver!!.query(contentUri, projections, where, null, sortOrder)
                    if (cursor == null) {
                        Log.d(TAG, "call: " + "Empty images")
                    } else if (cursor.moveToFirst()) {
                        var allImagesFolderItem: FolderItem? = null
                        val pathCol = cursor.getColumnIndex(MediaStore.Images.Media.DATA)
                        val nameCol = cursor.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
                        val DateCol = cursor.getColumnIndex(MediaStore.Images.Media.DATE_ADDED)
                        do {
                            val path = cursor.getString(pathCol)
                            val name = cursor.getString(nameCol)
                            val dateTime = cursor.getLong(DateCol)

                            val item = ImageItem(name, path, dateTime)

                            // if FolderListContent is still empty, add "All Images" option
                            if (FolderListContent.FOLDERS.size == 0) {
                                // add folder for all image
                                FolderListContent.selectedFolderIndex = 0

                                // use first image's path as cover image path
                                allImagesFolderItem = FolderItem(getString(R.string.selector_folder_all), "", path)
                                FolderListContent.addItem(allImagesFolderItem)

                                // show camera icon ?
                                if (SelectorSettings.isShowCamera) {
                                    results.add(ImageListContent.cameraItem)
                                    allImagesFolderItem.addImageItem(ImageListContent.cameraItem)
                                }
                            }

                            // add image item here, make sure it appears after the camera icon
                            results.add(item)

                            // add current image item to all
                            allImagesFolderItem!!.addImageItem(item)

                            // find the parent folder for this image, and add path to folderList if not existed
                            val folderPath = File(path).parentFile.absolutePath
                            var folderItem: FolderItem? = FolderListContent.getItem(folderPath)
                            if (folderItem == null) {
                                // does not exist, create it
                                folderItem = FolderItem(StringUtils.getLastPathSegment(folderPath), folderPath, path)
                                FolderListContent.addItem(folderItem)
                            }
                            folderItem.addImageItem(item)
                        } while (cursor.moveToNext())
                        cursor.close()
                    } // } else if (cursor.moveToFirst()) {
                    Observable.from(results)
                }
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(object : Subscriber<ImageItem>() {
                    override fun onCompleted() {}

                    override fun onError(e: Throwable) {
                        Log.d(TAG, "onError: " + Log.getStackTraceString(e))
                    }

                    override fun onNext(imageItem: ImageItem) {
                        // Log.d(TAG, "onNext: " + imageItem.toString());
                        ImageListContent.addItem(imageItem)
                        recyclerView!!.adapter.notifyItemChanged(ImageListContent.IMAGES.size - 1)
                    }
                })
    }

    fun updateDoneButton() {
        if (ImageListContent.SELECTED_IMAGES.size == 0) {
            mButtonConfirm!!.isEnabled = false
        } else {
            mButtonConfirm!!.isEnabled = true
        }

        val caption = resources.getString(R.string.selector_action_done, ImageListContent.SELECTED_IMAGES.size, SelectorSettings.mMaxImageNumber)
        mButtonConfirm!!.text = caption
    }

    fun OnFolderChange() {
        mFolderPopupWindow!!.dismiss()

        val folder = FolderListContent.getSelectedFolder()
        if (!TextUtils.equals(folder.path, this.currentFolderPath)) {
            this.currentFolderPath = folder.path
            mFolderSelectButton!!.text = folder.name

            ImageListContent.IMAGES.clear()
            ImageListContent.IMAGES.addAll(folder.mImages)
            recyclerView!!.adapter.notifyDataSetChanged()
        } else {
            Log.d(TAG, "OnFolderChange: " + "Same folder selected, skip loading.")
        }
    }


    override fun onFolderItemInteraction(item: FolderItem) {
        // dismiss popup, and update image list if necessary
        OnFolderChange()
    }

    override fun onImageItemInteraction(item: ImageItem) {
        if (ImageListContent.bReachMaxNumber) {
            val hint = resources.getString(R.string.selector_reach_max_image_hint, SelectorSettings.mMaxImageNumber)
            Toast.makeText(this@ImagesSelectorActivitys, hint, Toast.LENGTH_SHORT).show()
            ImageListContent.bReachMaxNumber = false
        }

        if (item.isCamera) {
            requestCameraRuntimePermissions()
        }

        updateDoneButton()
    }


    fun launchCamera() {
        val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (cameraIntent.resolveActivity(packageManager) != null) {
            // set the output file of camera
            try {

                mTempImageFile = FileUtils.createTmpFile(this)

            } catch (e: IOException) {
                Log.e(TAG, "launchCamera: ", e)
            }

            if (mTempImageFile != null && mTempImageFile!!.exists()) {

                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(mTempImageFile))
                    startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE)

            } else {

            }
        } else {

        }

    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        // after capturing image, return the image path as selected result
        if (requestCode == CAMERA_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                if (mTempImageFile != null) {
                    // notify system

                    sendBroadcast(Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(mTempImageFile!!)))

                    val resultIntent = Intent()
                    ImageListContent.clear()
                    ImageListContent.SELECTED_IMAGES.add(mTempImageFile!!.absolutePath)
                    resultIntent.putStringArrayListExtra(SelectorSettings.SELECTOR_RESULTS, ImageListContent.SELECTED_IMAGES)
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }
            } else {
                // if user click cancel, delete the temp file
                while (mTempImageFile != null && mTempImageFile!!.exists()) {
                    val success = mTempImageFile!!.delete()
                    if (success) {
                        mTempImageFile = null
                    }
                }
            }
        }
    }


    override fun onClick(v: View) {

        if (v === mButtonBack) {
            setResult(Activity.RESULT_CANCELED)
            finish()
        } else if (v === mButtonConfirm) {
            val data = Intent()
            data.putStringArrayListExtra(SelectorSettings.SELECTOR_RESULTS, ImageListContent.SELECTED_IMAGES)
            setResult(Activity.RESULT_OK, data)
            finish()
        }
    }

    companion object {

        private val TAG = "ImageSelector"
        private val ARG_COLUMN_COUNT = "column-count"

        private val MY_PERMISSIONS_REQUEST_STORAGE_CODE = 197
        private val MY_PERMISSIONS_REQUEST_CAMERA_CODE = 341
        private val CAMERA_REQUEST_CODE = 694
    }
}