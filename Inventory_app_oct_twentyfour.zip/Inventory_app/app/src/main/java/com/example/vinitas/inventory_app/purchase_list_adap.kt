package com.example.vinitas.inventory_app

/**
 * Created by Vinitas on 22-12-2017.
 */
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Environment
import android.support.constraint.ConstraintLayout
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import com.squareup.picasso.Picasso

import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.activity_purcathird_main.*
import java.io.File

/**
 * Created by vinitas IT on 13-12-2017.
 */
class purchse_list_adaps(//to reference the Activity
        private val context: Activity,
        //to store the list of countries
        private val pronameArray:   ArrayList<String>,
        /* private val idArray:   ArrayList<String>,*/ //to store the list of Listcountries
        private val manufacturerArray:  ArrayList<String>,
        private val hsnArray:  ArrayList<String>,
        private val barcodeArray :     ArrayList<String>,
        private val quantityArray:    ArrayList<String>,
        private val priceArray:  ArrayList<String>,
        private val totArray:  ArrayList<String>,
        private val cessArray:  ArrayList<String>,
        private val keyArray:  ArrayList<String>,
        private val igstArray:  ArrayList<String>,
        private val cgstArray:  ArrayList<String>,
        private val sgstArray:  ArrayList<String>,
        private val igsttotArray:  ArrayList<String>,
        private val cesstotArray:  ArrayList<String>,
        private val tallyArray:  ArrayList<String>,
        private val receivedArray:  ArrayList<String>,
        private val receivedprice:  ArrayList<String>,
        private val receivedtaxtot:  ArrayList<String>,
        private val receivedcesstot:  ArrayList<String>,
        private val receivedgrosstot:  ArrayList<String>,
        private val receivedtotal:  ArrayList<String>,
        private val productImArray: ArrayList<String>,
        private val imnmhigh: Array<String>,
        private val icohighArray: Array<String>): ArrayAdapter<Any>(context, R.layout.act_purchorderitems, pronameArray as List<Any>) {

    private var mCurrentAnimator: Animator? = null

    private var mShortAnimationDuration: Int = 0


    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.act_purchorderitems, null, true)

        val nameTextField = rowView.findViewById<View>(R.id.pnm) as TextView
        /*       val idTextField = rowView.findViewById<View>(R.id.id) as TextView*/
        val subnameTextField = rowView.findViewById<View>(R.id.psubnm) as TextView
        val hsnTextField = rowView.findViewById<View>(R.id.hsn) as TextView
        val bcnameTextField = rowView.findViewById<View>(R.id.bc) as TextView
        val cessTextField = rowView.findViewById<View>(R.id.cess) as TextView
        val sohnameTextField = rowView.findViewById<View>(R.id.soh) as TextView
        val totnameTextField = rowView.findViewById<View>(R.id.tot) as  TextView
        val pricenameTextField = rowView.findViewById<View>(R.id.price) as TextView
        val keyarrayTextField = rowView.findViewById<View>(R.id.keyarr) as TextView
        val igstarrayTextField = rowView.findViewById<View>(R.id.Igst) as TextView
        val cgstarrayTextField = rowView.findViewById<View>(R.id.cgst) as TextView
        val sgstarrayTextField = rowView.findViewById<View>(R.id.sgst) as TextView
        val igsttotarrayTextField = rowView.findViewById<View>(R.id.igsttot) as TextView
        val cesstotarrayTextField = rowView.findViewById<View>(R.id.cesstot) as TextView
        val tallyarrayTextField = rowView.findViewById<View>(R.id.pur_tally) as TextView
        val receivearrayTextField = rowView.findViewById<View>(R.id.pur_received) as TextView
        val receivepriceTextField = rowView.findViewById<View>(R.id.recprice) as TextView
        val receivetotalTextField = rowView.findViewById<View>(R.id.rectot) as TextView
        val receivetaxtotalTextField = rowView.findViewById<View>(R.id.rectaxtot) as TextView
        val receivecesstotalTextField = rowView.findViewById<View>(R.id.reccesstot) as TextView
        val receivegrosstotTextField = rowView.findViewById<View>(R.id.recgrosstot) as TextView
        val productim= rowView.findViewById<View>(R.id.primg) as CircleImageView


        val bc=rowView.findViewById<View>(R.id.textView10) as TextView
        val rec=rowView.findViewById<View>(R.id.textView12) as TextView
        val rec1=rowView.findViewById<View>(R.id.textView11) as TextView


        try {
            if (context.pur_list.isClickable == false) {

                nameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                cessTextField.setTextColor(Color.parseColor("#d3d3d3"));
                totnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                hsnTextField.setTextColor(Color.parseColor("#d3d3d3"));
                bcnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                sohnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                pricenameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                keyarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                igstarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                cgstarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                sgstarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                igsttotarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                cesstotarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                tallyarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                receivearrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                subnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                bc.setTextColor(Color.parseColor("#d3d3d3"));
                rec.setTextColor(Color.parseColor("#d3d3d3"));
                rec1.setTextColor(Color.parseColor("#d3d3d3"));
            }


            if (context.pur_list.isClickable == true) {


                nameTextField.setTextColor(Color.parseColor("#000000"));
                cessTextField.setTextColor(Color.parseColor("#666666"));
                totnameTextField.setTextColor(Color.parseColor("#666666"));
                hsnTextField.setTextColor(Color.parseColor("#666666"));
                bcnameTextField.setTextColor(Color.parseColor("#666666"));
                sohnameTextField.setTextColor(Color.parseColor("#808080"));
                pricenameTextField.setTextColor(Color.parseColor("#666666"));
                keyarrayTextField.setTextColor(Color.parseColor("#666666"));
                igstarrayTextField.setTextColor(Color.parseColor("#666666"));
                cgstarrayTextField.setTextColor(Color.parseColor("#666666"));
                sgstarrayTextField.setTextColor(Color.parseColor("#666666"));
                igsttotarrayTextField.setTextColor(Color.parseColor("#666666"));
                cesstotarrayTextField.setTextColor(Color.parseColor("#666666"));
                tallyarrayTextField.setTextColor(Color.parseColor("#666666"));
                receivearrayTextField.setTextColor(Color.parseColor("#808080"));
                subnameTextField.setTextColor(Color.parseColor("#666666"));
                bc.setTextColor(Color.parseColor("#666666"));
                rec.setTextColor(Color.parseColor("#666666"));
                rec1.setTextColor(Color.parseColor("#666666"));

            }
        }
        catch (e:Exception){

        }

        productim.setOnClickListener {position
            val kd = imnmhigh[position]
            println("IMAG NAME VIEW"+kd)

            val k=productim.drawable


            println("POSITION OF ICO"+position)

            val jk=context.findViewById<ListView>(R.id.pur_product_list) as ListView

            jk.isEnabled=false
            jk.isClickable=false


            val kj=context.findViewById<ConstraintLayout>(R.id.constrsuppro) as ConstraintLayout
            kj.setBackgroundColor(Color.parseColor("#43161616"))
            zoomImageFromThumb(productim,k,position)


        }


        try {

            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            val k = imnmhigh[position]
            val recacnm = k.removeSuffix(".jpg")

            var y = recacnm + ".png"

            val file = File(dir, y)
            println("CONTENT URI" + file)
            if (file.exists()) {
                val contentUri = Uri.fromFile(File("$path/$y"))
                try {
                    Picasso.with(context)
                            .load(contentUri)
                            .into(productim);
                }
                catch (e:Exception){

                }
            }
            else{
                try {
                    Picasso.with(context)
                            .load(productImArray[position])
                            .into(productim);
                }
                catch (e:Exception){

                }
            }
        }
        catch (e:Exception){
            try {
                Picasso.with(context)
                        .load(productImArray[position])
                        .into(productim);
            }
            catch (e:Exception){

            }
        }


        mShortAnimationDuration = context.resources.getInteger(
                android.R.integer.config_shortAnimTime);


        //this code sets the values of the objects to values from the arrays
        nameTextField.text = pronameArray[position]
        /*   idTextField.text = idArray[position]*/
        subnameTextField.text = manufacturerArray[position]
        cessTextField.text = cessArray[position]
        totnameTextField.text=totArray[position]
        hsnTextField.text = hsnArray[position]
        bcnameTextField.text=barcodeArray[position]
        sohnameTextField.text=quantityArray[position]
        pricenameTextField.text = priceArray[position]
        keyarrayTextField.text = keyArray[position]
        igstarrayTextField.text=igstArray[position]
        cgstarrayTextField.text=cgstArray[position]
        sgstarrayTextField.text=sgstArray[position]
        igsttotarrayTextField.text=igsttotArray[position]
        cesstotarrayTextField.text=cesstotArray[position]
        tallyarrayTextField.text=tallyArray[position]


        if(receivedArray[position].isEmpty()){
            receivearrayTextField.setText("0")
        }
        else if(receivedArray[position].isNotEmpty()){
            receivearrayTextField.text=receivedArray[position]
        }

        receivepriceTextField.text=receivedprice[position]
        receivetotalTextField.text=receivedtotal[position]
        receivetaxtotalTextField.text=receivedtaxtot[position]
        receivecesstotalTextField.text=receivedcesstot[position]
        receivegrosstotTextField.text=receivedgrosstot[position]



       /* if(pronameArray.lastIndex.toString().isEmpty()&&
        manufacturerArray.lastIndex.toString().isEmpty()&&
        hsnArray.lastIndex.toString().isEmpty()&&
        barcodeArray.lastIndex.toString().isEmpty()&&
        quantityArray.lastIndex.toString().isEmpty()&&
        priceArray.lastIndex.toString().isEmpty()&&
        totArray.lastIndex.toString().isEmpty()&&
        cessArray.lastIndex.toString().isEmpty()&&
        keyArray.lastIndex.toString().isEmpty()&&
        igstArray.lastIndex.toString().isEmpty()&&
        cgstArray.lastIndex.toString().isEmpty()&&
        sgstArray.lastIndex.toString().isEmpty()&&
        igsttotArray.lastIndex.toString().isEmpty()&&
        cesstotArray.lastIndex.toString().isEmpty()&&
        tallyArray.lastIndex.toString().isEmpty()&&
        receivedArray.lastIndex.toString().isEmpty()&&
        receivedprice.lastIndex.toString().isEmpty()&&
        receivedtaxtot.lastIndex.toString().isEmpty()&&
        receivedcesstot.lastIndex.toString().isEmpty()&&
        receivedgrosstot.lastIndex.toString().isEmpty()&&
        receivedtotal.lastIndex.toString().isEmpty()&&
        productImArray.lastIndex.toString().isEmpty()){

            sohnameTextField.visibility=View.INVISIBLE
            rec1.visibility=View.INVISIBLE
            productim.visibility=View.INVISIBLE

            context.pur_list.

        }*/




        //infoTextField.text = infoArray[position]
        return rowView
    }

    private fun zoomImageFromThumb(thumbView: View, imageResId: Drawable, pos:Int) {
        // If there's an animation in progress, cancel it
        // immediately and proceed with this one.
        mCurrentAnimator?.cancel()

        // Load the high-resolution "zoomed-in" image.
        val expandedImageView = context.findViewById<View>(
                R.id.expanded_image) as ImageView
        val rel = context.findViewById<RelativeLayout>(
                R.id.relative) as RelativeLayout

        val jk=context.findViewById<ListView>(R.id.pur_product_list) as ListView

        /* val kj=context.findViewById<ConstraintLayout>(R.id.const) as ConstraintLayout*/

        val nm=context.findViewById<TextView>(R.id.nameser) as TextView

        val ico = context.findViewById<CircleImageView>(R.id.primg) as CircleImageView
        expandedImageView.setImageDrawable(imageResId)


        // Calculate the starting and ending bounds for the zoomed-in image.
        // This step involves lots of math. Yay, math.
        val startBounds = Rect()
        val finalBounds = Rect()
        val globalOffset = Point()

        // The start bounds are the global visible rectangle of the thumbnail,
        // and the final bounds are the global visible rectangle of the container
        // view. Also set the container view's offset as the origin for the
        // bounds, since that's the origin for the positioning animation
        // properties (X, Y).
        thumbView.getGlobalVisibleRect(startBounds)
        val kk = context.findViewById<View>(R.id.containersd)
        context.findViewById<View>(R.id.containersd)
                .getGlobalVisibleRect(finalBounds, globalOffset)
        startBounds.offset(-globalOffset.x, -globalOffset.y)
        finalBounds.offset(-globalOffset.x, -globalOffset.y)

        // Adjust the start bounds to be the same aspect ratio as the final
        // bounds using the "center crop" technique. This prevents undesirable
        // stretching during the animation. Also calculate the start scaling
        // factor (the end scaling factor is always 1.0).
        val startScale: Float
        if (finalBounds.width().toFloat() / finalBounds.height() > startBounds.width().toFloat() / startBounds.height()) {
            // Extend start bounds horizontally
            startScale = startBounds.height().toFloat() / finalBounds.height()
            val startWidth = startScale * finalBounds.width()
            val deltaWidth = (startWidth - startBounds.width()) / 2
            startBounds.left -= deltaWidth.toInt()
            startBounds.right += deltaWidth.toInt()
        } else {
            // Extend start bounds vertically
            startScale = startBounds.width().toFloat() / finalBounds.width()
            val startHeight = startScale * finalBounds.height()
            val deltaHeight = (startHeight - startBounds.height()) / 2
            startBounds.top -= deltaHeight.toInt()
            startBounds.bottom += deltaHeight.toInt()
        }

        // Hide the thumbnail and show the zoomed-in view. When the animation
        // begins, it will position the zoomed-in view in the place of the
        // thumbnail.
        thumbView.alpha = 1f
        expandedImageView.visibility = View.VISIBLE
        kk.visibility = View.VISIBLE
        rel.visibility=View.VISIBLE
        nm.visibility=View.VISIBLE

        nm.text=pronameArray[pos]



        // Set the pivot point for SCALE_X and SCALE_Y transformations
        // to the top-left corner of the zoomed-in view (the default
        // is the center of the view).
        expandedImageView.pivotX = 0f
        expandedImageView.pivotY = 0f

        // Construct and run the parallel animation of the four translation and
        // scale properties (X, Y, SCALE_X, and SCALE_Y).
        val set = AnimatorSet()
        set
                .play(ObjectAnimator.ofFloat(expandedImageView, View.X,
                        startBounds.left.toFloat(), finalBounds.left.toFloat()))
                .with(ObjectAnimator.ofFloat(expandedImageView, View.Y,
                        startBounds.top.toFloat(), finalBounds.top.toFloat()))
                .with(ObjectAnimator.ofFloat(expandedImageView, View.SCALE_X,
                        startScale, 1f))
                .with(ObjectAnimator.ofFloat(expandedImageView,
                        View.SCALE_Y, startScale, 1f))
        set.setDuration(mShortAnimationDuration.toLong())
        set.interpolator = DecelerateInterpolator()
        set.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                mCurrentAnimator = null
            }

            override fun onAnimationCancel(animation: Animator) {
                mCurrentAnimator = null
            }
        })
        set.start()
        mCurrentAnimator = set

        // Upon clicking the zoomed-in image, it should zoom back down
        // to the original bounds and show the thumbnail instead of
        // the expanded image.
        val startScaleFinal = startScale



        // Animate the four positioning/sizing properties in parallel,
        // back to their original values.
        val kj = context.findViewById<ConstraintLayout>(R.id.constrsuppro) as ConstraintLayout
        rel.setOnClickListener {


            kj.setBackgroundColor(Color.parseColor("#ffffff"))
            mCurrentAnimator?.cancel()
            val set = AnimatorSet()
            set.play(ObjectAnimator
                    .ofFloat(expandedImageView, View.X, startBounds.left.toFloat()))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.Y, startBounds.top.toFloat()))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.SCALE_X, startScale))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.SCALE_Y, startScale))
            set.setDuration(mShortAnimationDuration.toLong())
            set.interpolator = DecelerateInterpolator()
            set.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    thumbView.alpha = 1f
                    nm.visibility=View.GONE
                    expandedImageView.visibility = View.GONE
                    kk.visibility = View.GONE

                    rel.visibility = View.GONE
                    jk.isEnabled=true
                    jk.isClickable=true
                    ico.isEnabled=true
                    ico.isClickable=true

                    mCurrentAnimator = null
                }

                override fun onAnimationCancel(animation: Animator) {
                    thumbView.alpha = 1f
                    expandedImageView.visibility = View.GONE
                    nm.visibility=View.GONE
                    kk.visibility = View.GONE
                    rel.visibility=View.GONE

                    jk.isEnabled=true
                    jk.isClickable=true

                    mCurrentAnimator = null
                }
            })
            set.start()
            mCurrentAnimator = set
        }

        expandedImageView.setOnClickListener {pos

            val k = imnmhigh[pos]
            println("IMAG NAME VIEW"+k)
            expandedImageView.visibility = View.GONE
            kj.setBackgroundColor(Color.parseColor("#ffffff"))
            nm.visibility=View.GONE
            kk.visibility = View.GONE
            rel.visibility=View.GONE

            jk.isEnabled=true
            jk.isClickable=true


            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

            val dir = File(path);




            val recacnm = k.removeSuffix(".jpg")

            var y = recacnm + ".png"

            val file = File(dir, y)
            println("CONTENT URI GG" + file)
            if (file.exists()) {
                val contentUri = Uri.fromFile(File("$path/$y"))

                println("CONTENT URI" + contentUri)
                /*    var redrawb = image1.drawable
            val bitmap = (redrawb as BitmapDrawable).getBitmap()*/
                /*  val baos = ByteArrayOutputStream()
          bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
          val b = baos.toByteArray()*/
                if (contentUri != null) {
                    val shareIntent = Intent(context, ZoomProduct::class.java)
                    shareIntent.putExtra("im", "imageadap")
                    shareIntent.putExtra("drawb", contentUri.toString())
                    shareIntent.putExtra("nameser",pronameArray[pos])
                    context.startActivity(shareIntent)
                }
            } else {
                val shareIntent = Intent(context, ZoomProduct::class.java)
                shareIntent.putExtra("im", "imageadap")
                shareIntent.putExtra("drawb", icohighArray[pos])
                shareIntent.putExtra("nameser",pronameArray[pos])
                context.startActivity(shareIntent)
            }
        }




    }
}