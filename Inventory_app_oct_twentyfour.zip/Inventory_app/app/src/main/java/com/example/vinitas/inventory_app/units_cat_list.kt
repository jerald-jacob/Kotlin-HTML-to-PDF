package com.example.vinitas.inventory_app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_units_cat_list.*

class units_cat_list : AppCompatActivity() {
    var db = FirebaseFirestore.getInstance()
    var TAG = "tag"
    var dup=""

    data class s(var cat: String)
    lateinit var di : String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_units_cat_list)

        net_status()  // Check net status

        unit_back.setOnClickListener {
            finish()
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)


        }
        getdata()   //Get all unit measure categories from db.



        //-------------------Click Add (FAB) button to add unit measure and insert to db--------------------------//

        unit_add.setOnClickListener {
            val alert = AlertDialog.Builder(this@units_cat_list)
            val inflater = this.layoutInflater

            val dialog = alert.create()
            dialog.setView(inflater.inflate(R.layout.unit_popup,null))
            dialog.show()
            val ok = dialog.findViewById<Button>(R.id.unit_ok) as Button
            val cancel = dialog.findViewById<Button>(R.id.unit_cancel) as Button
            val edit = dialog.findViewById<EditText>(R.id.units) as EditText

            ok.setOnClickListener {
                if (edit.text.isNotEmpty()==true) {
                    val cate = edit.text.toString()
                    val data = s(cat = cate)
                    //if ((did.text.toString()).isEmpty()) {
                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialog.setTitleText("Saving...")
                    pDialog.setCancelable(false)
                    pDialog.show();
                    ok.isEnabled = false
                    db.collection("unit")
                            .add(data)
                            .addOnSuccessListener { documentReference ->
                                Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                Toast.makeText(this, "Category Added", Toast.LENGTH_LONG).show()
                                edit.setText("")
                                ok.isEnabled = true
                                pDialog.dismiss()
                                dialog.hide()

                                getdata()
                            }
                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error adding document", e)
                                Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                                unit_progress.visibility = View.GONE
                            }
                }else{
                    Toast.makeText(this, "Nothing Added", Toast.LENGTH_LONG).show()
                }
            }
            cancel.setOnClickListener {
                dialog.dismiss()
            }
        }
    }
    fun getdata(){
        var category = arrayListOf<String>()

        var d = arrayListOf<String>()

        var dlt = arrayListOf<String>()
        val list_item = ArrayList<String>()
        units_cat_list.setOnItemClickListener { adapterView, view, i, l ->
            adapterView.getItemAtPosition(1).toString()
            di = d.get(i).toString()
            Log.d(TAG,"  "+di)
            popup()
        }


        ////////---------------------------DELETE-------------------------------------//////////

        units_cat_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        units_cat_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = units_cat_list.getCheckedItemCount()
                val l = d.get(position)
                Log.i(TAG," "+l)
                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")
                Log.d(TAG," "+id)
                //list_item.add(id);
                if (checked) {
                    list_item.add(id.toString()) // Add to list when checked ==  true
                    dlt.add(l)
                    Log.i(TAG,"itm "+dlt.size)
                   // Log.i(TAG,"itm "+dlt.get(position))
                } else {
                    list_item.remove(id.toString())
                    dlt.remove(l)
                    Log.i(TAG,"itm "+dlt.size)
                    Log.d(TAG,"id  "+id)
                }

            }

            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB
                toolbar7.visibility = View.GONE
                mode.getMenuInflater().inflate(R.menu.list, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                val builder = AlertDialog.Builder(this@units_cat_list)
                with(builder) {
                    setTitle("Delete from category?")
                    setMessage("Are you sure want to delete?")
                    setPositiveButton("Yes") { dialog, whichButton ->
                        val deleteSize = dlt.size
                        Log.i("tsdfs","  "+dlt.size)
                        /*val cate = null
                        val data = s(cat = cate)*/
                        val i = 0
                        Log.d("dlt"," "+dlt.get(i))
                        val itemId = item.getItemId()
                        if (itemId == R.id.delete) {
                            for (i in dlt) {
                                db.collection("unit").document(i)
                                        .delete()
                                        .addOnSuccessListener {
                                            dlt.clear()
                                            Toast.makeText(applicationContext, "" + deleteSize + " Items deleted", Toast.LENGTH_SHORT).show()
                                            // save_progress.visibility = android.view.View.GONE
                                            getdata()
                                        }
                                        .addOnFailureListener {
                                            Toast.makeText(applicationContext, "not updated", Toast.LENGTH_LONG).show()
                                            //save_progress.visibility = android.view.View.GONE
                                        }
                            }
                        }
                        /* checkedCount = 0*/
                        list_item.clear()
                        mode.finish()
                    }
                    setNegativeButton("No") { dialog, whichButton ->
                        //showMessage("Close the game or anything!")
                        dialog.dismiss()
                        list_item.clear()
                        mode.finish()
                    }

                    // Dialog
                    val dialog = builder.create()

                    dialog.show()
                }


                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                dlt.clear()
                toolbar7.visibility =View.VISIBLE
            }
        })
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();
        db.collection("unit")
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // r.clear()
                        Log.d(TAG,"cleared")
if(task.result.isEmpty==false) {
    imageView10.visibility=View.GONE

    for (document in task.result) {

        //r.clear()
        Log.d(TAG, "dapet" + document.id + " => " + document.data)
        val dd = document.data
        val cat = dd["cat"].toString()
        category.add(cat)
        d.add(document.id.toString())
        val list = listAdapter(this, category, d)
        val lists = findViewById<ListView>(R.id.units_cat_list) as ListView
        lists.adapter = list
        list.notifyDataSetChanged()
       pDialog.dismiss()

    }
}
                        else{
    imageView10.visibility=View.VISIBLE
pDialog.dismiss()
                        }
                    } else {
                        Log.w(TAG, "Error getting documents.", task.exception)
                    }
                }
    }


    //----------------------------------If we click existing data,it will  displayed in popup, we can  update it. --------//

    fun popup(){
        val alert = AlertDialog.Builder(this@units_cat_list)
        val inflater = this.layoutInflater
        val dialog = alert.create()
        dialog.setView(inflater.inflate(R.layout.unit_popup,null))
        dialog.show()
        val ok = dialog.findViewById<Button>(R.id.unit_ok) as Button
        val cancel = dialog.findViewById<Button>(R.id.unit_cancel) as Button
        val edit = dialog.findViewById<EditText>(R.id.units) as EditText
        db.collection("unit").document(di.toString())
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        if (task.result != null) {
                            Log.d("data", "is" + task.result.data)
                            edit.setText(task.result.get("cat").toString())
                            dup=task.result.get("cat").toString()

                        } else {
                            Log.d("data", "is not here")
                        }
                    } else {
                        Log.d("task is not success", "full" + task.exception)
                    }

                }
        ok.setOnClickListener {


            if ((edit.text.isNotEmpty() == true)&&(dup != edit.text.toString())) {
                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Saving...")
                pDialog.setCancelable(false)
                pDialog.show();
                val cate = edit.text.toString()
                val data = s(cat = cate)
                //if ((did.text.toString()).isEmpty()) {
                //progress.visibility = View.VISIBLE
                ok.isEnabled = false
                cancel.isEnabled = false
                db.collection("unit").document(di.toString())
                        .set(data)
                        .addOnSuccessListener {
                            Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()
                            // save_progress.visibility = android.view.View.GONE
                            dialog.dismiss()
                            getdata()
                            pDialog.dismiss()
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show()
                            //save_progress.visibility = android.view.View.GONE
                        }
            } else {
                dialog.dismiss()
            }
        }
        cancel.setOnClickListener {
            dialog.hide()
        }
    }
    override fun onBackPressed() {
        finish()
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

    }
    fun net_status():Boolean{  ///Check net status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
