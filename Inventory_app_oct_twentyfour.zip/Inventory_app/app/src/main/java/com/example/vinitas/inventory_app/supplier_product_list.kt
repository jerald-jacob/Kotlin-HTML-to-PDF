package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.AbsListView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog

import com.google.firebase.firestore.FirebaseFirestore
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.supplier_product_list.*
import java.util.*

class supplier_product_list : AppCompatActivity() {


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""






    var names = String()
    /* var reqid = String()
     var reqdt = String()
     var reqnm = String()
     var reqmail = String()
     var reqph = String()
     var reqest = String()
     var supnm = String()
     var supadd1 = String()
     var supadd2 = String()
     var supadd3 = String()
     var supgst = String()
     var supph = String()
     var supcity = String()
     var supstate = String()*/
    var nms = String()
    var ph = String()
    var reqliid = String()
    var reprnms = String()
    var pono = String()
    var recstatus = String()
    var reqdt = String()
    var desc = String()
    var orddate = String()
    var postatus = String()
    var namesori = String()
    var namesphones = String()
    var keybrnch=String()
    var namesphonesori = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var idli= arrayOf<String>()
    var image=String()

    var frmvali= String()

    val db = FirebaseFirestore.getInstance()
    val TAG = "some"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.supplier_product_list)
        val bundle = intent.extras
        var frm = bundle!!.get("from_pur").toString()


net_status()



        var a= bundle.get("namess") as Array<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/
        val c=bundle.get("orderarray") as Array<String>
        val ds=bundle.get("hsn") as Array<String>
        /*    val l=bundle.get("item") as Array<String>*/
        val f=bundle.get("poarray") as Array<String>
        val g=bundle.get("complete") as Array<String>
        val h=bundle.get("price") as Array<String>
        val i=bundle.get("total") as Array<String>
        val j=bundle.get("cess") as Array<String>
        val r=bundle.get("igst") as Array<String>
        val p=bundle.get("cgst") as Array<String>
        val sg=bundle.get("sgst") as Array<String>
        val s=bundle.get("igsttotal") as Array<String>
        val q=bundle.get("cesstotarray") as Array<String>
        val qtall=bundle.get("tallyarray") as Array<String>
        val rec=bundle.get("receivedarray") as Array<String>
        val idddpri=bundle.get("receivedarray_pri") as Array<String>
        val idddtaxtot=bundle.get("receivedarray_taxtot") as Array<String>
        val idddtot=bundle.get("receivedarray_tot") as Array<String>
        val idddcesstot=bundle.get("receivedarray_cesstot") as Array<String>
        val idddgrosstot=bundle.get("receivedarray_grosstot") as Array<String>
        val iddd=bundle.get("idsofli") as Array<String>
        val k=bundle.get("im") as Array<String>




        try {
            val e = intent.getStringExtra("desc")
            desc = e
            val f = intent.getStringExtra("reqdate")
            reqdt = f
            val ff = intent.getStringExtra("orddate")
            orddate = ff

            val stat = intent.getStringExtra("duedate")
            postatus = stat
            println("PO STATUSSS"+postatus)
        } catch (e: Exception) {

        }
        val aa = intent.getStringExtra("nms")
        nms=aa
        val liis = intent.getStringExtra("reqliid")
        reqliid = liis
        val b = intent.getStringExtra("ph")
        ph=b
        val lii = intent.getStringExtra("pono")
        pono = lii

        val nm = intent.getStringExtra("reprnms")
        reprnms = nm

        frmvali=intent.getStringExtra("backvald")
        var pronameArraycpy     = arrayListOf<String>()
        var hsnArraycpy          = arrayListOf<String>()

        var manufacturerArraycpy = arrayListOf<String>()
        var barcodeArraycpy     = arrayListOf<String>()
        var quantityArraycpy     = arrayListOf<String>()
        var priceArraycpy       = arrayListOf<String>()
        var totArraycpy         = arrayListOf<String>()
        var cessArraycpy         = arrayListOf<String>()
        var igstArraycpy= arrayListOf<String>()
        var cgstArraycpy= arrayListOf<String>()
        var sgstArraycpy= arrayListOf<String>()

        var igsttotArraycpy = arrayListOf<String>()
        var cesstotalArraycpy = arrayListOf<String>()
        var tallyArraycpy = arrayListOf<String>()
        var receivedArraycpy = arrayListOf<String>()
        var receivedArraypricpy = arrayListOf<String>()
        var receivedArraytaxtotcpy = arrayListOf<String>()
        var receivedArraytotalcpy = arrayListOf<String>()
        var receivedArraygrosstotalcpy = arrayListOf<String>()
        var receivedArraycesstotalcpy = arrayListOf<String>()

        var imageArraycpy        = arrayListOf<String>()
        var idupArraycpy=arrayListOf<String>()

        var  pronameArray       = arrayOf<String>()
        var  hsnArray           = arrayOf<String>()
        var  manufacturerArray  = arrayOf<String>()
        var  barcodeArray       = arrayOf<String>()
        var  quantityArray      = arrayOf<String>()
        var  priceArray         = arrayOf<String>()
        var  totArray           = arrayOf<String>()
        var  cessArray          = arrayOf<String>()
        var  imageArray         = arrayOf<String>()
        var  igstArray         = arrayOf<String>()
        var  cgstArray         = arrayOf<String>()
        var  sgstArray         = arrayOf<String>()
        var  igsttotArray         = arrayOf<String>()
        var  cesstotalArray         = arrayOf<String>()
        var receivedArray = arrayOf<String>()
        var receivedArraypri = arrayOf<String>()
        var receivedArraytaxtot = arrayOf<String>()
        var receivedArraytotal = arrayOf<String>()
        var receivedArraygrosstotal = arrayOf<String>()
        var receivedArraycesstotal = arrayOf<String>()
        var tallyArray = arrayOf<String>()
        var keyArray=arrayOf<String>()



        var  pronameArrayori     = arrayOf<String>()
        var  hsnArrayori         = arrayOf<String>()
        var  manufacturerArrayori= arrayOf<String>()
        var  barcodeArrayori      = arrayOf<String>()
        var  quantityArrayori     = arrayOf<String>()
        var  priceArrayori        = arrayOf<String>()
        var  totArrayori         = arrayOf<String>()
        var  cessArrayori        = arrayOf<String>()
        var igstArrayori =arrayOf<String>()
        var cgstArrayori =arrayOf<String>()
        var sgstArrayori =arrayOf<String>()
        var igsttotArrayori =arrayOf<String>()
        var cesstotalArrayori =arrayOf<String>()
        var tallyArrayori =arrayOf<String>()
        var receivedArrayori =arrayOf<String>()
        var receivedArraypriori = arrayOf<String>()
        var receivedArraytaxtotori = arrayOf<String>()
        var receivedArraytotalori = arrayOf<String>()
        var receivedArraygrosstotalori = arrayOf<String>()
        var receivedArraycesstotalori = arrayOf<String>()

        var  imageArrayori        = arrayOf<String>()
        var keyArrayori=arrayOf<String>()

        var d = arrayListOf<String>()

        var dlt = arrayListOf<String>()


        pronameArrayori= a.clone()
        hsnArrayori= ds.clone()
        manufacturerArrayori =c.clone()
        barcodeArrayori=f.clone()
        quantityArrayori=g.clone()
        priceArrayori=h.clone()
        totArrayori =i.clone()
        receivedArrayori=rec.clone()
        cessArrayori =j.clone()
        igstArrayori =r.clone()
        cgstArrayori =p.clone()
        sgstArrayori =sg.clone()
        igsttotArrayori=s.clone()
        cesstotalArrayori=q.clone()
        tallyArrayori=qtall.clone()
        receivedArraypriori=idddpri.clone()
        receivedArraytotalori=idddtot.clone()
        receivedArraytaxtotori=idddtaxtot.clone()
        receivedArraycesstotalori=idddcesstot.clone()
        receivedArraygrosstotalori=idddgrosstot.clone()
        imageArrayori=k.clone()
        keyArrayori=iddd.clone()

/*
       if(frm=="pur_emptylist")
       {
           val namebr=intent.getStringExtra("branch")
           val locbr=intent.getStringExtra("address")
           val brkey=intent.getStringExtra("brnchid")
           purpro_nm.setText(namebr)
           println("BRANCH NAME"+purpro_nm.text)
           purpro_loc.setText(locbr)
           purpro_brnchkey.setText(brkey)
           keybrnch=purpro_brnchkey.text.toString()
           names=purpro_nm.text.toString()
           namesphones=purpro_loc.text.toString()
       }*/


        /*private fun addImageView(layout: LinearLayout) {
             val imageView = ImageView(this)
             imageView.setImageResource(R.drawable.ic_launcher)
             layout.addView(imageView)
         }*/








        fun get() {
            supplier_product_list.setOnItemClickListener { parent, view, position, id ->

                val az=pronameArray.get(position)
                val bz=hsnArray.get(position)
                val t = manufacturerArray.get(position)
                val cz=quantityArray.get(position)
                val mz=barcodeArray.get(position)
                val fz=priceArray.get(position)
                val oz=totArray.get(position)
                val qz=cessArray.get(position)
                val qigz=igstArray.get(position)
                val higz=cgstArray.get(position)
                val digz=sgstArray.get(position)
                val qigtotz=igsttotArray.get(position)
                val qcesstotz=cesstotalArray.get(position)
                val qtallyz=tallyArray.get(position)
                val qtallypri=receivedArraypri.get(position)
                val qtallytot=receivedArraytotal.get(position)
                val qtallytaxtot=receivedArraytaxtot.get(position)
                val qtallycesstot=receivedArraycesstotal.get(position)
                val qtallygross=receivedArraygrosstotal.get(position)
                val rece=receivedArray.get(position)
                val imz=imageArray.get(position)
                val li=keyArray.get(position)


                pronameArraycpy.add(az)
                manufacturerArraycpy.add(t)
                hsnArraycpy.add(bz)
                quantityArraycpy.add(cz)
                barcodeArraycpy.add(mz)
                priceArraycpy.add(fz)
                totArraycpy.add(oz)
                cessArraycpy.add(qz)
                igstArraycpy.add(qigz)
                cgstArraycpy.add(higz)
                sgstArraycpy.add(digz)
                igsttotArraycpy.add(qigtotz)
                cesstotalArraycpy.add(qcesstotz)
                tallyArraycpy.add(qtallyz)
                receivedArraypricpy.add(qtallypri)
                receivedArraytaxtotcpy.add(qtallytaxtot)
                receivedArraycesstotalcpy.add(qtallycesstot)
                receivedArraygrosstotalcpy.add(qtallygross)
                receivedArraytotalcpy.add(qtallytot)
                receivedArraycpy.add(rece)
                imageArraycpy.add(imz.toString())
                idupArraycpy.add(li)




                var a=pronameArraycpy.toString()
                var atr=a.removeSurrounding("[","]")

                var bs=manufacturerArraycpy.toString()
                var btr=bs.removeSurrounding("[","]")

                var cs=hsnArraycpy.toString()
                var cstr=cs.removeSurrounding("[","]")

                var ds=quantityArraycpy.toString()
                var dstr=ds.removeSurrounding("[","]")

                var es=barcodeArraycpy.toString()
                var estr=es.removeSurrounding("[","]")

                var fs=priceArraycpy.toString()
                var fstr=fs.removeSurrounding("[","]")

                var gs=totArraycpy.toString()
                var gstr=gs.removeSurrounding("[","]")

                var hs=cessArraycpy.toString()
                var hstr=hs.removeSurrounding("[","]")


                var ijs=igstArraycpy.toString()
                var ijsstr=ijs.removeSurrounding("[","]")


                var rjs=cgstArraycpy.toString()
                var rjsstr=rjs.removeSurrounding("[","]")


                var sjs=sgstArraycpy.toString()
                var sjsstr=sjs.removeSurrounding("[","]")





                var jjs=igsttotArraycpy.toString()
                var jjsstr=jjs.removeSurrounding("[","]")

                var kjs=cesstotalArraycpy.toString()
                var kjsstr=kjs.removeSurrounding("[","]")

                var ljs=tallyArraycpy.toString()
                var ljsstr=ljs.removeSurrounding("[","]")


                var ujs=receivedArraypricpy.toString()
                var ujsstr=ujs.removeSurrounding("[","]")




                var vjs=receivedArraytaxtotcpy.toString()
                var vjsstr=vjs.removeSurrounding("[","]")



                var wjs=receivedArraycesstotalcpy.toString()
                var wjsstr=wjs.removeSurrounding("[","]")


                var xjs=receivedArraygrosstotalcpy.toString()
                var xjsstr=xjs.removeSurrounding("[","]")

                var yjs=receivedArraytotalcpy.toString()
                var yjsstr=yjs.removeSurrounding("[","]")



                var mjs=receivedArraycpy.toString()
                var mjsstr=mjs.removeSurrounding("[","]")

                var njs=imageArraycpy.toString()
                var njsstr=njs.removeSurrounding("[","]")


                pronameArrayori=pronameArrayori.plusElement(atr)
                manufacturerArrayori=manufacturerArrayori.plusElement(btr)
                hsnArrayori=hsnArrayori.plusElement(cstr)
                quantityArrayori=quantityArrayori.plusElement(dstr)
                barcodeArrayori=barcodeArrayori.plusElement(estr)
                priceArrayori=priceArrayori.plusElement(fstr)
                totArrayori=totArrayori.plusElement(gstr)
                cessArrayori=cessArrayori.plusElement(hstr)
                igstArrayori=igstArrayori.plusElement(ijsstr)
                cgstArrayori=cgstArrayori.plusElement(rjsstr)
                sgstArrayori=sgstArrayori.plusElement(sjsstr)
                igsttotArrayori=igsttotArrayori.plusElement(jjsstr)
                cesstotalArrayori=cesstotalArrayori.plusElement(kjsstr)
                tallyArrayori=tallyArrayori.plusElement(ljsstr)
                receivedArrayori=receivedArrayori.plusElement(mjsstr)
                receivedArraypriori=receivedArraypriori.plusElement(ujsstr)
                receivedArraytotalori=receivedArraytotalori.plusElement(yjsstr)
                receivedArraytaxtotori=receivedArraytaxtotori.plusElement(vjsstr)
                receivedArraygrosstotalori=receivedArraygrosstotalori.plusElement(xjsstr)
                receivedArraycesstotalori=receivedArraycesstotalori.plusElement(wjsstr)
                imageArrayori=imageArrayori.plusElement(njsstr)
                keyArrayori=keyArrayori.plusElement("")

                namesori=names
                namesphonesori=namesphones
                println(pronameArraycpy.lastIndex)




                /* b.putExtra("pur_branch",namesori)
                 b.putExtra("pur_address",namesphonesori)
                 b.putExtra("pur_brkey",keybrnch)
                 b.putExtra("pur_redate",datestk)
                 b.putExtra("pur_redesc",descstk)
                 b.putExtra("pur_restkid",idstk)
                 b.putExtra("pur_reiddb",iddbs)
                 b.putExtra("pur_reiddofli",keyArrayori)*/

                val b = Intent(applicationContext,Supplier_thirdMainActivity::class.java)
                        .putStringArrayListExtra("dlt",dlt)
                println(Arrays.toString(pronameArrayori))
                println(Arrays.toString(priceArrayori))

                b.putExtra("from_suppin","suppin_list_single")
                b.putExtra("pur_pname",pronameArrayori)
                b.putExtra("pur_pitem",manufacturerArrayori)
                b.putExtra("pur_phsn",hsnArrayori)
                b.putExtra("pur_porder",quantityArrayori)

                b.putExtra("pur_pprice",priceArrayori)
                b.putExtra("pur_ptot",totArrayori)
                b.putExtra("pur_poarray",barcodeArrayori)
                b.putExtra("pur_cessarray",cessArrayori)
                b.putExtra("pur_igstarray",igstArrayori)
                b.putExtra("pur_cgstarray",cgstArrayori)
                b.putExtra("pur_sgstarray",sgstArrayori)
                b.putExtra("pur_igsttotarray",igsttotArrayori)
                b.putExtra("pur_cesstotalarray",cesstotalArrayori)
                b.putExtra("pur_reiddofli",keyArrayori)
                b.putExtra("pur_tallyarray",tallyArrayori)
                b.putExtra("pur_receivedarray",receivedArrayori)
                b.putExtra("pur_receivedarraypri",receivedArraypriori)
                b.putExtra("pur_receivedarraytotal",receivedArraytotalori)
                b.putExtra("pur_receivedarraytaxtot",receivedArraytaxtotori)
                b.putExtra("pur_receivedarraycesstot",receivedArraycesstotalori)
                b.putExtra("pur_receivedarraygrosstot",receivedArraygrosstotalori)

                /* b.putExtra("pur_branch",namesori)
                 b.putExtra("pur_address",namesphonesori)
                 b.putExtra("pur_brkey",keybrnch)
                 b.putExtra("pur_redate",datestk)
                 b.putExtra("pur_redesc",descstk)
                 b.putExtra("pur_restkid",idstk)
                 b.putExtra("pur_reiddb",iddbs)
                 b.putExtra("pur_reiddofli",keyArrayori)*/

                b.putExtra("pur_imi",imageArrayori)
                b.putExtra("pono",pono)
                b.putExtra("names",reprnms)
                b.putExtra("redesc",desc)
                b.putExtra("reorddate",orddate)
                b.putExtra("reestdt",reqdt)
                b.putExtra("reduedate",postatus)

                b.putExtra("reids",reqliid)
                b.putExtra("titnm",nms)
                b.putExtra("tiphone",ph)
                b.putExtra("backvald",frmvali)


                startActivity(b)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }






            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();
            db.collection("supplier_products")
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Log.d(TAG, "cleared")
                            for (document in task.result) {
                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data
                                pronameArray = pronameArray.plusElement(dd["sp_nm"].toString() + " - " + dd["spwg_vol"].toString() + "ml")

                                manufacturerArray = manufacturerArray.plusElement(dd["spmfr"].toString())
                                hsnArray = hsnArray.plusElement(dd["sphsn"].toString())

                                quantityArray = quantityArray.plusElement("1")

                                priceArray = priceArray.plusElement(dd["spprice"].toString())
                                totArray = totArray.plusElement(dd["spprice"].toString())
                                barcodeArray = barcodeArray.plusElement(dd["spbc"].toString())
                                cessArray = cessArray.plusElement(dd["spcess"].toString())
                                igstArray = igstArray.plusElement(dd["spigst"].toString())
                                cgstArray = cgstArray.plusElement(dd["spcgst"].toString())
                                sgstArray = sgstArray.plusElement(dd["spsgst"].toString())
                                igsttotArray = igsttotArray.plusElement(dd["sptaxtot"].toString())
                                cesstotalArray = cesstotalArray.plusElement(dd["spcesstot"].toString())
                                tallyArray = tallyArray.plusElement("Not tallied")
                                receivedArray = receivedArray.plusElement("0")
                                receivedArraypri = receivedArraypri.plusElement("0")
                                receivedArraytaxtot = receivedArraytaxtot.plusElement("0")
                                receivedArraytotal = receivedArraytotal.plusElement("0")
                                receivedArraygrosstotal = receivedArraygrosstotal.plusElement("0")
                                receivedArraycesstotal = receivedArraycesstotal.plusElement("0")


                                try {
                                    var im = dd["img1url"].toString()
                                    image = im
                                    if (im.isNotEmpty()) {

                                        imageArray = imageArray.plusElement(im)
                                    } else {
                                        imageArray = imageArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                    }
                                } catch (e: Exception) {

                                }
                                keyArray = keyArray.plusElement("")

                                d.add(document.id.toString())


                                val whatever = supp_invoice_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, receivedArraypri, receivedArraytaxtot, receivedArraycesstotal, receivedArraygrosstotal, receivedArraytotal, imageArray)
                                supplier_product_list.adapter = whatever
                            pDialog.dismiss()
                            }
                        } else {
                            pDialog.dismiss()
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }
                    }
        }
        get()




        swipeContainer.setOnRefreshListener {

            get()

                   }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)


        supplier_product_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        supplier_product_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = supplier_product_list.getCheckedItemCount()
                val l = d.get(position)
                val az=pronameArray.get(position)
                val bz=hsnArray.get(position)
                val t = manufacturerArray.get(position)
                val cz=quantityArray.get(position)
                val mz=barcodeArray.get(position)
                val fz=priceArray.get(position)
                val oz=totArray.get(position)
                val qz=cessArray.get(position)
                val qigz=igstArray.get(position)
                val higz=cgstArray.get(position)
                val digz=sgstArray.get(position)
                val qigtotz=igsttotArray.get(position)
                val qcesstotz=cesstotalArray.get(position)
                val qtallyz=tallyArray.get(position)
                val qtallypri=receivedArraypri.get(position)
                val qtallytot=receivedArraytotal.get(position)
                val qtallytaxtot=receivedArraytaxtot.get(position)
                val qtallycesstot=receivedArraycesstotal.get(position)
                val qtallygross=receivedArraygrosstotal.get(position)
                val rece=receivedArray.get(position)
                val imz=imageArray.get(position)
                val li=keyArray.get(position)
                Log.i(TAG," "+l)
                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")
                Log.d(TAG," "+id)
                //list_item.add(id);
                val tex = CircleImageView(this@supplier_product_list)
                val textLayoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                textLayoutParams.setMargins(20, 0, 0, 0)
                textLayoutParams.height=100
                textLayoutParams.width=100
                tex.setBorderColor(Color.BLACK)
                tex.setBorderWidth(1)
                tex.setPadding(4,4,4,4)
                tex.setLayoutParams(textLayoutParams)
                try {
                    Picasso.with(this@supplier_product_list)
                            .load(imageArray[position])
                            .into(tex);
                }
                catch (e:Exception){

                }
                tex.setTag(l)
                linearlayout.setGravity(Gravity.CENTER)
                tex.setOnClickListener {
                    val r = linearlayout.findViewWithTag<View>(l)
                    linearlayout.removeView(r)
                    Log.d("list","    "+supplier_product_list.setItemChecked(position,false))
                }
                if (checked) {
                    // list_item.add(id.toString()) // Add to list when checked ==  true

                    dlt.add(l)
                    pronameArraycpy.add(az)
                    manufacturerArraycpy.add(t)
                    hsnArraycpy.add(bz)
                    quantityArraycpy.add(cz)
                    barcodeArraycpy.add(mz)
                    priceArraycpy.add(fz)
                    totArraycpy.add(oz)
                    cessArraycpy.add(qz)
                    igstArraycpy.add(qigz)
                    cgstArraycpy.add(higz)
                    sgstArraycpy.add(digz)
                    igsttotArraycpy.add(qigtotz)
                    cesstotalArraycpy.add(qcesstotz)
                    tallyArraycpy.add(qtallyz)
                    receivedArraypricpy.add(qtallypri)
                    receivedArraytaxtotcpy.add(qtallytaxtot)
                    receivedArraycesstotalcpy.add(qtallycesstot)
                    receivedArraygrosstotalcpy.add(qtallygross)
                    receivedArraytotalcpy.add(qtallytot)
                    receivedArraycpy.add(rece)
                    imageArraycpy.add(imz.toString())
                    idupArraycpy.add(li)
                    imageArray=imageArray.plusElement(image)

                    Log.i(TAG,"itm "+dlt.size)
                    Log.d("list","    "+supplier_product_list.getCheckedItemPositions())
                    linearlayout.addView(tex)
                    horizontalScrollView.visibility=View.VISIBLE
                } else {
                    val r = linearlayout.findViewWithTag<View>(l)
                    dlt.remove(l)
                    pronameArraycpy.remove(az)
                    manufacturerArraycpy.remove(t)
                    hsnArraycpy.remove(bz)
                    quantityArraycpy.remove(cz)
                    barcodeArraycpy.remove(mz)
                    priceArraycpy.remove(fz)
                    totArraycpy.remove(oz)
                    cessArraycpy.remove(qz)
                    igstArraycpy.remove(qigz)
                    cgstArraycpy.remove(higz)
                    sgstArraycpy.remove(digz)
                    igsttotArraycpy.remove(qigtotz)
                    cesstotalArraycpy.remove(qcesstotz)
                    tallyArraycpy.remove(qtallyz)
                    receivedArraycpy.remove(rece)
                    receivedArraypricpy.remove(qtallypri)
                    receivedArraytaxtotcpy.remove(qtallytaxtot)
                    receivedArraycesstotalcpy.remove(qtallycesstot)
                    receivedArraygrosstotalcpy.remove(qtallygross)
                    receivedArraytotalcpy.remove(qtallytot)
                    imageArraycpy.remove(imz.toString())
                    idupArraycpy.remove(li)
                    /*       imageArray=imageArray.plusElement(R.drawable.loreal_bottl)*/


                    Log.d("tag","   "+r)
                    linearlayout.removeView(r)
                    Log.i(TAG,"itm "+dlt.size)
                    Log.d(TAG,"id  "+id)
                    Log.d(TAG,"id  "+position)
                }


            }


            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB
                supplier_product_list_toolbar.visibility = View.INVISIBLE
                mode.getMenuInflater().inflate(R.menu.product_select, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                val deleteSize =dlt.size
                Log.i("tsdfs","  "+dlt.size)
                /*val cate = null
                val data = s(cat = cate)*/
                val i = 0
                Log.d("dlt"," "+dlt.get(i))
                val itemId = item.getItemId()
                if (itemId == R.id.ok) {
                    println(pronameArraycpy.size)
                    //if (this@product_list_activity.equals("product_list_activity"))
                    for(i in 0 until pronameArraycpy.size)
                    {
                        pronameArrayori=pronameArrayori.plusElement(pronameArraycpy.get(i))
                        manufacturerArrayori=manufacturerArrayori.plusElement(manufacturerArraycpy.get(i))
                        hsnArrayori=hsnArrayori.plusElement(hsnArraycpy.get(i))
                        quantityArrayori=quantityArrayori.plusElement(quantityArraycpy.get(i))
                        barcodeArrayori=barcodeArrayori.plusElement(barcodeArraycpy.get(i))
                        priceArrayori=priceArrayori.plusElement(priceArraycpy.get(i))
                        totArrayori=totArrayori.plusElement(totArraycpy.get(i))
                        cessArrayori=cessArrayori.plusElement(cessArraycpy.get(i))
                        igstArrayori=igstArrayori.plusElement(igstArraycpy.get(i))
                        cgstArrayori=cgstArrayori.plusElement(cgstArraycpy.get(i))
                        sgstArrayori=sgstArrayori.plusElement(sgstArraycpy.get(i))
                        igsttotArrayori=igsttotArrayori.plusElement(igsttotArraycpy.get(i))
                        cesstotalArrayori=cesstotalArrayori.plusElement(cesstotalArraycpy.get(i))
                        tallyArrayori=tallyArrayori.plusElement(tallyArraycpy.get(i))
                        receivedArrayori=receivedArrayori.plusElement(receivedArraycpy.get(i))
                        receivedArraypriori=receivedArraypriori.plusElement(receivedArraypricpy.get(i))
                        receivedArraytotalori=receivedArraytotalori.plusElement(receivedArraytotalcpy.get(i))
                        receivedArraytaxtotori=receivedArraytaxtotori.plusElement(receivedArraytaxtotcpy.get(i))
                        receivedArraygrosstotalori=receivedArraygrosstotalori.plusElement(receivedArraygrosstotalcpy.get(i))
                        receivedArraycesstotalori=receivedArraycesstotalori.plusElement(receivedArraycesstotalcpy.get(i))
                        imageArrayori=imageArrayori.plusElement(imageArraycpy.get(i))
                        keyArrayori=keyArrayori.plusElement("")

                        namesori=names
                        namesphonesori=namesphones
                        println(pronameArraycpy.lastIndex)
                        if(pronameArraycpy.lastIndex == i)
                        {
                            Log.d("fdgshgtgh","NAMESSSSSSSSSSSSSSSSS             "   + Arrays.toString(pronameArrayori))
                        }
                    }
                    val b = Intent(applicationContext,Supplier_thirdMainActivity::class.java)
                            .putStringArrayListExtra("dlt",dlt)
                    println(Arrays.toString(pronameArrayori))
                    println(Arrays.toString(priceArrayori))

                    b.putExtra("from_suppin","suppin_list")
                    b.putExtra("pur_pname",pronameArrayori)
                    b.putExtra("pur_pitem",manufacturerArrayori)
                    b.putExtra("pur_phsn",hsnArrayori)
                    b.putExtra("pur_porder",quantityArrayori)

                    b.putExtra("pur_pprice",priceArrayori)
                    b.putExtra("pur_ptot",totArrayori)
                    b.putExtra("pur_poarray",barcodeArrayori)
                    b.putExtra("pur_cessarray",cessArrayori)
                    b.putExtra("pur_igstarray",igstArrayori)
                    b.putExtra("pur_cgstarray",cgstArrayori)
                    b.putExtra("pur_sgstarray",sgstArrayori)
                    b.putExtra("pur_igsttotarray",igsttotArrayori)
                    b.putExtra("pur_cesstotalarray",cesstotalArrayori)
                    b.putExtra("pur_reiddofli",keyArrayori)
                    b.putExtra("pur_tallyarray",tallyArrayori)
                    b.putExtra("pur_receivedarray",receivedArrayori)
                    b.putExtra("pur_receivedarraypri",receivedArraypriori)
                    b.putExtra("pur_receivedarraytotal",receivedArraytotalori)
                    b.putExtra("pur_receivedarraytaxtot",receivedArraytaxtotori)
                    b.putExtra("pur_receivedarraycesstot",receivedArraycesstotalori)
                    b.putExtra("pur_receivedarraygrosstot",receivedArraygrosstotalori)

                    /* b.putExtra("pur_branch",namesori)
                     b.putExtra("pur_address",namesphonesori)
                     b.putExtra("pur_brkey",keybrnch)
                     b.putExtra("pur_redate",datestk)
                     b.putExtra("pur_redesc",descstk)
                     b.putExtra("pur_restkid",idstk)
                     b.putExtra("pur_reiddb",iddbs)
                     b.putExtra("pur_reiddofli",keyArrayori)*/

                    b.putExtra("pur_imi",imageArrayori)
                    b.putExtra("pono",pono)
                    b.putExtra("names",reprnms)
                    b.putExtra("redesc",desc)
                    b.putExtra("reorddate",orddate)
                    b.putExtra("reestdt",reqdt)
                    b.putExtra("reduedate",postatus)

                    b.putExtra("reids",reqliid)
                    b.putExtra("titnm",nms)
                    b.putExtra("tiphone",ph)
                    b.putExtra("backvald",frmvali)

                    startActivity(b)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()


                    /*for (i in dlt) {
                        Log.d("dlt","  "+i)
                    }*/
                }
                /* checkedCount = 0*/
                // list_item.clear()

                mode.finish()
                return true
            }
            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                dlt.clear()
                linearlayout.removeAllViews()
                horizontalScrollView.visibility=View.GONE
                supplier_product_list_toolbar.visibility =View.VISIBLE
            }
        })
    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
