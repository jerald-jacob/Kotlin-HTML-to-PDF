package com.example.vinitas.inventory_app

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.StrictMode
import android.support.annotation.NonNull
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.daimajia.slider.library.Animations.DescriptionAnimation
import com.daimajia.slider.library.SliderLayout
import com.daimajia.slider.library.SliderTypes.BaseSliderView
import com.daimajia.slider.library.SliderTypes.TextSliderView
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.vansuita.pickimage.bean.PickResult
import com.vansuita.pickimage.bundle.PickSetup
import com.vansuita.pickimage.dialog.PickImageDialog
import kotlinx.android.synthetic.main.activity_supplier_add.*
import kotlinx.android.synthetic.main.exit_popup_prod.*
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import org.xmlpull.v1.XmlPullParserFactory
import java.io.*
import java.net.URL
import java.util.*
import kotlin.collections.ArrayList

class SupplierAddMain : AppCompatActivity(), BaseSliderView.OnSliderClickListener {
internal lateinit var myDb: DatabaseSupplierhelper
    val REQUEST_CODE = 100
    val PERMISSION_REQUEST = 200



    var getval= String()
    var suppsel=String()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    var d = arrayListOf<String>()
    //image url's
    var f1: String = ""
    var s1: String = ""
    var t1: String = ""
    var fo1: String = ""
    var fif1: String = ""
    //image name's
    var fn1: String = ""
    var sn1: String = ""
    var tn1: String = ""
    var fon1: String = ""
    var fifn1: String = ""


    var img1urlhigh:String=""
    var img2urlhigh:String=""
    var img3urlhigh:String=""
    var img4urlhigh:String=""
    var img5urlhigh:String=""
    //image name's
    var img1nhigh:String=""
    var img2nhigh:String=""
    var img3nhigh:String=""
    var img4nhigh:String=""
    var img5nhigh:String=""

    //image url's
    var f1edit:String=""
    var s1edit:String=""
    var t1edit:String=""
    var fo1edit:String=""
    var fif1edit:String=""
    //image name's
    var fn1edit:String=""
    var sn1edit:String=""
    var tn1edit:String=""
    var fon1edit:String=""
    var fifn1edit:String=""


    var f1edithigh:String=""
    var s1edithigh:String=""
    var t1edithigh:String=""
    var fo1edithigh:String=""
    var fif1edithigh:String=""
    //image name's
    var fn1edithigh:String=""
    var sn1edithigh:String=""
    var tn1edithigh:String=""
    var fon1edithigh:String=""
    var fifn1edithigh:String=""


    var suppnamevalidate= String()
    var suppmobcat1validate= "Mobile"
    var suppmobcat2validate= "Mobile"
    var suppmobcat3validate= "Mobile"
    var suppaddress1validate= String()
    var suppmobilevalidate= String()
    var suppmobile21validate= String()
    var suppmobile31validate= String()
    var suppmobile41validate= String()
    var suppaddress2validate= String()
    var suppaddress3validate= String()
    var suppcityvalidate= String()
    var suppstatevalidate= String()
    var supppinvalidate= String()
    var contactprsvalidate= String()
    var prodkyvalidate= String()
    var gpsvalidate= String()
    var suppemailvalidate= String()
    var suppgstvalidate= String()

var prokeylistener= String()
    var file_maps = arrayListOf<String>()


    var startlistprokey= String()
    var productprokey= String()


    var editcli= String()
    //supplier

    private var addsupp: String=""
    private var editesupp:String=""
    private var deletesupp:String=""
     private var viewsupp:String=""
     private var importsupp:String=""
     private var exportsupp:String=""

    var notsv=arrayOf<String>()

    var newsvky=String()

    var disab= String()
    var fieldlistener= String()


    var mresultsarr= arrayListOf<String>()
    var cacnm1= String()
/*
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                val barcode = data.getStringExtra("barcode")

                processScannedData(barcode.toString())
            }
        }
    }*/
data class k(
        var status:String
)

    data class c(

            var spnm: String,
            var spid: Any,

            var spmobcat1: Any,
            var spmobcat2: Any,
            var spmobcat3: Any,
            var spmobcat4: Any,
            var spmob1: String,
            var spmob2: String,
            var spmob3: String,
            var spmob4: String,
            var spaddress1: String,
            var spaddress2: Any,
            var spaddress3: Any,
            var spcity: String,
            var spstate: String,
            var sppincode: String,
            var sppgpsco_or: String,
            var spemail: Any,
            var spcontact_person: String,
            var spgst: Any,
            var spimglink: String,
            var prodkey: String,
            var status: String,
            var img1n:Any,
            var img2n:Any,
            var img3n:Any,
            var img4n:Any,
            var img5n:Any,
            var img1url:Any,
            var img2url:Any,
            var img3url:Any,
            var img4url:Any,
            var img5url:Any,



            var img1nhigh:String,     //image 1 name
            var img2nhigh:String,     //image 2 name
            var img3nhigh:String,     //image 3 name
            var img4nhigh:String,     //image 4 name
            var img5nhigh:String,     //image 5 name
            var img1urlhigh:String,     //image 1 url
            var img2urlhigh:String,     //image 2 url
            var img3urlhigh:String,     //image 3 url
            var img4urlhigh:String,     //image 4 url
            var img5urlhigh:String     //image 5 url


    )
    override fun onSliderClick(slider: BaseSliderView?) {
        return
    }
    var TAG = "some"

    var radioGroup1: RadioGroup? = null
    var deals: RadioButton? = null
    var db = FirebaseFirestore.getInstance()

    var saveconlis= String()

    var savearr= ArrayList<String>()
    var prsvarr= ArrayList<String>()

    internal lateinit var myDbs: Databasehelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supplier_add)



net_status()  //Check internet status.

        myDbs = Databasehelper(this)

 //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@SupplierAddMain) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }

//Define No connection view and other views when inetrnet connection is off.
        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        bottnav = findViewById(R.id.bottonNavBar)
        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        consdis=findViewById(R.id.cons)
        scroll2_sliderdis=findViewById(R.id.scroll2_slider)
        scroll2_slider2dis=findViewById(R.id.scroll2_slider2)
        gallerydis=findViewById(R.id.gallery)
        editdis=findViewById(R.id.supp_edit)
        addLogText(NetworkUtil.getConnectivityStatusString(this@SupplierAddMain))


        sup_back.setOnClickListener {

           onBackPressed()
        }





        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
           myDb = DatabaseSupplierhelper(this)
        radioGroup1 = (findViewById<View>(R.id.radioGroup1) as RadioGroup)


        val come = intent.extras
        val i=come.getString("supppro")




        //Comes from supplier's product list page

        if(i=="productfrm")
        {
            val hsnT1 = intent.getStringExtra("mob")
            val hsndes1 = intent.getStringExtra("mob1")
            val price1 = intent.getStringExtra("mob2")


           /* if(hsnT1=="Mobile"){
                val categories1 = ArrayList<String>()
                categories1.add("$hsnT1")
                categories1.add("Phone")
                val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
                dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                supp_mob.adapter = dataAdaptermob
            }
            else if(hsnT1=="Phone"){
                val categories1 = ArrayList<String>()
                categories1.add("$hsnT1")
                categories1.add("Mobile")
                val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
                dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                supp_mob.adapter = dataAdaptermob
            }
            if(hsndes1=="Mobile"){
                val categories1 = ArrayList<String>()
                categories1.add("$hsndes1")
                categories1.add("Phone")
                val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
                dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                supp_mob1.adapter = dataAdaptermob
            }
            else if(hsndes1=="Phone"){
                val categories1 = ArrayList<String>()
                categories1.add("$hsndes1")
                categories1.add("Mobile")
                val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
                dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                supp_mob1.adapter = dataAdaptermob
            }

            if(price1=="Mobile"){
                val categories1 = ArrayList<String>()
                categories1.add("$price1")
                categories1.add("Phone")
                val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
                dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                supp_mob2.adapter = dataAdaptermob
            }
            else if(price1=="Phone"){
                val categories1 = ArrayList<String>()
                categories1.add("$price1")
                categories1.add("Mobile")
                val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
                dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                supp_mob2.adapter = dataAdaptermob
            }*/







            val sname1 = intent!!.getStringExtra("sname1")
            println("MNAMESSSS "+sname1)
            val listenrsave=intent.getStringExtra("listnrsaves")
            saveconlis=listenrsave
            prokeylistener=saveconlis

            println("MNAMESSSS GUYs "+prokeylistener)

            val fieldlistenrsave=intent.getStringExtra("fieldlistnrsaves")
             fieldlistener=fieldlistenrsave

            editcli=intent.getStringExtra("editclisupp")

try {
    startlistprokey = intent.getStringExtra("startlistprky")
    productprokey = intent.getStringExtra("profrmprky")
}
catch (e:Exception){

}


            val sid1 = intent.getStringExtra("sid1")
            val sdur1 = intent.getStringExtra("scon1")

            val Tax1 = intent.getStringExtra("mobile")
            val intax1 = intent.getStringExtra("mobile1")
            val cess1 = intent.getStringExtra("mobile2")
            val Ctax1 = intent.getStringExtra("saddress")
            val Stax1 = intent.getStringExtra("saddress1")
            val taxtot1 = intent.getStringExtra("saddress2")
            val css1 = intent.getStringExtra("scity")
            val grosstot1 = intent.getStringExtra("sstate")
            val payemp1 = intent.getStringExtra("spin")
            val paybonus1 = intent.getStringExtra("sgps")
            val currency1 = intent.getStringExtra("smail")
            val percentage1 = intent.getStringExtra("sgstcd")
            val per1 = intent.getStringExtra("status")
            val svsky = intent.getStringExtra("svsky")
            supp_savekey.setText(svsky)



            println("MOB OR PH  "+hsnT1)



            try{

                img1urlhigh=intent.getStringExtra("img1urlhigh")
                img2urlhigh=intent.getStringExtra("img2urlhigh")
                img3urlhigh=intent.getStringExtra("img3urlhigh")
                img4urlhigh=intent.getStringExtra("img4urlhigh")
                img5urlhigh=intent.getStringExtra("img5urlhigh")
                //image name's
                img1nhigh=intent.getStringExtra("img1nhigh")
                img2nhigh=intent.getStringExtra("img2nhigh")
                img3nhigh=intent.getStringExtra("img3nhigh")
                img4nhigh=intent.getStringExtra("img4nhigh")
                img5nhigh=intent.getStringExtra("img5nhigh")

                //image url's
                f1edit=intent.getStringExtra("f1edit")
                s1edit=intent.getStringExtra("s1edit")
                t1edit=intent.getStringExtra("t1edit")
                fo1edit=intent.getStringExtra("fo1edit")
                fif1edit=intent.getStringExtra("fif1edit")
                //image name's
                fn1edit=intent.getStringExtra("fn1edit")
                sn1edit=intent.getStringExtra("sn1edit")
                tn1edit=intent.getStringExtra("tn1edit")
                fon1edit=intent.getStringExtra("fon1edit")
                fifn1edit=intent.getStringExtra("fifn1edit")


                f1edithigh=intent.getStringExtra("f1edithigh")
                s1edithigh=intent.getStringExtra("s1edithigh")
                t1edithigh=intent.getStringExtra("t1edithigh")
                fo1edithigh=intent.getStringExtra("fo1edithigh")
                fif1edithigh=intent.getStringExtra("fif1edithigh")
                //image name's
                fn1edithigh=intent.getStringExtra("fn1edithigh")
                sn1edithigh=intent.getStringExtra("sn1edithigh")
                tn1edithigh=intent.getStringExtra("tn1edithigh")
                fon1edithigh=intent.getStringExtra("fon1edithigh")
                fifn1edithigh=intent.getStringExtra("fifn1edithigh")



                file_maps=intent.getStringArrayListExtra("file_maps")
                mresultsarr=intent.getStringArrayListExtra("mresultsarr")

                println("filemaps"+file_maps)

            }
            catch (e:Exception){

            }








            val ad = intent.getStringExtra("addspro")
            val ed = intent.getStringExtra("editspro")
            val del = intent.getStringExtra("deletespro")
            val vi=intent.getStringExtra("viewspro")
            val im=intent.getStringExtra("importspro")
            val ex=intent.getStringExtra("exportspro")
            if (ad != null) {
                addsupp = ad
            }
            if (ed != null) {
                editesupp = ed
            }
            if (del != null) {
                deletesupp = del
            }
            if (vi != null) {
                viewsupp = vi
            }
            if (im != null) {
                importsupp = im
            }
            if (ex != null) {
                exportsupp = ex
            }

            try {

                val pkey = intent.getStringExtra("prky")
                pro_savekey.setText(pkey.toString())

                productprokey=pro_savekey.text.toString()
                println("KEYS FROM PRODUCT LISTTTT"+pro_savekey.text)
                fn1 = intent.getStringExtra("img1")
                sn1 = intent.getStringExtra("img2")
                tn1 = intent.getStringExtra("img3")
                fon1 = intent.getStringExtra("img4")
                fifn1 = intent.getStringExtra("img5")


                 f1 = intent.getStringExtra("url1")

                 s1 = intent.getStringExtra("url2")
                 t1 = intent.getStringExtra("url3")
                 fo1 = intent.getStringExtra("url4")
                 fif1 = intent.getStringExtra("url5")

                if(f1.isNotEmpty()||s1.isNotEmpty()){
                    imageView11.visibility=View.GONE
                    imageButton2.visibility=View.GONE
                    gallery.visibility=View.VISIBLE
                }








                val image_view = findViewById<ImageView>(R.id.imageView11)
                val image_button = findViewById(R.id.imageButton2) as ImageView



                //Navigate to add multi images activity - (AddImagesActivity_supp)
                image_button.setOnClickListener {
                    scroll2_slider.removeAllSliders()
                    val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                    b.putExtra("id", id.text.toString())
                    b.putExtra("f1", f1)
                    b.putExtra("fn1", fn1)
                    b.putExtra("s1", s1)
                    b.putExtra("sn1", sn1)
                    b.putExtra("t1", t1)
                    b.putExtra("tn1", tn1)
                    b.putExtra("fo1", fo1)
                    b.putExtra("fon1", fon1)
                    b.putExtra("fif1", fif1)
                    b.putExtra("fifn1", fifn1)
                    b.putExtra("f1high", img1urlhigh)
                    b.putExtra("fn1high", img1nhigh)
                    b.putExtra("s1high", img2urlhigh)
                    b.putExtra("sn1high", img2nhigh)
                    b.putExtra("t1high", img3urlhigh)
                    b.putExtra("tn1high",img3nhigh)
                    b.putExtra("fo1high", img4urlhigh)
                    b.putExtra("fon1high", img4nhigh)
                    b.putExtra("fif1high", img5urlhigh)
                    b.putExtra("fifn1high",img5nhigh)
                    b.putExtra("mresult", mresultsarr)
                    b.putExtra("cacnm1", cacnm1)
                    b.putExtra("listener",prokeylistener)
                    b.putExtra("fieldlistener",fieldlistener)
                    b.putExtra("f1edithigh", f1edithigh)
                    b.putExtra("fn1edithigh", fn1edithigh)
                    b.putExtra("s1edithigh", s1edithigh)
                    b.putExtra("sn1edithigh", sn1edithigh)
                    b.putExtra("t1edithigh", t1edithigh)
                    b.putExtra("tn1edithigh", tn1edithigh)
                    b.putExtra("fo1edithigh", fo1edithigh)
                    b.putExtra("fon1edithigh", fon1edithigh)
                    b.putExtra("fif1edithigh", fif1edithigh)
                    b.putExtra("fifn1edithigh", fifn1edithigh)
                    b.putExtra("f1high", img1urlhigh)
                    b.putExtra("fn1high", img1nhigh)
                    b.putExtra("s1high", img2urlhigh)
                    b.putExtra("sn1high", img2nhigh)
                    b.putExtra("t1high", img3urlhigh)
                    b.putExtra("tn1high",img3nhigh)
                    b.putExtra("fo1high", img4urlhigh)
                    b.putExtra("fon1high", img4nhigh)
                    b.putExtra("fif1high", img5urlhigh)
                    b.putExtra("fifn1high",img5nhigh)


                    b.putExtra("f1edit", f1edit)
                    b.putExtra("fn1edit", fn1edit)
                    b.putExtra("s1edit", s1edit)
                    b.putExtra("sn1edit", sn1edit)
                    b.putExtra("t1edit", t1edit)
                    b.putExtra("tn1edit", tn1edit)
                    b.putExtra("fo1edit", fo1edit)
                    b.putExtra("fon1edit", fon1edit)
                    b.putExtra("fif1edit", fif1edit)
                    b.putExtra("fifn1edit", fifn1edit)



                    startActivityForResult(b, 0)
                    gallery.isEnabled = true
                }
                image_view.setOnClickListener {

                    //Navigate to add multi images activity - (AddImagesActivity_supp)


                    scroll2_slider.removeAllSliders()
                    val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                    b.putExtra("id", id.text.toString())
                    b.putExtra("f1", f1)
                    b.putExtra("fn1", fn1)
                    b.putExtra("s1", s1)
                    b.putExtra("sn1", sn1)
                    b.putExtra("t1", t1)
                    b.putExtra("tn1", tn1)
                    b.putExtra("fo1", fo1)
                    b.putExtra("fon1", fon1)
                    b.putExtra("fif1", fif1)
                    b.putExtra("fifn1", fifn1)
                    b.putExtra("f1high", img1urlhigh)
                    b.putExtra("fn1high", img1nhigh)
                    b.putExtra("s1high", img2urlhigh)
                    b.putExtra("sn1high", img2nhigh)
                    b.putExtra("t1high", img3urlhigh)
                    b.putExtra("tn1high",img3nhigh)
                    b.putExtra("fo1high", img4urlhigh)
                    b.putExtra("fon1high", img4nhigh)
                    b.putExtra("fif1high", img5urlhigh)
                    b.putExtra("fifn1high",img5nhigh)
                    b.putExtra("mresult", mresultsarr)
                    b.putExtra("cacnm1", cacnm1)
                    b.putExtra("listener",prokeylistener)
                    b.putExtra("fieldlistener",fieldlistener)
                    b.putExtra("f1edithigh", f1edithigh)
                    b.putExtra("fn1edithigh", fn1edithigh)
                    b.putExtra("s1edithigh", s1edithigh)
                    b.putExtra("sn1edithigh", sn1edithigh)
                    b.putExtra("t1edithigh", t1edithigh)
                    b.putExtra("tn1edithigh", tn1edithigh)
                    b.putExtra("fo1edithigh", fo1edithigh)
                    b.putExtra("fon1edithigh", fon1edithigh)
                    b.putExtra("fif1edithigh", fif1edithigh)
                    b.putExtra("fifn1edithigh", fifn1edithigh)
                    b.putExtra("f1high", img1urlhigh)
                    b.putExtra("fn1high", img1nhigh)
                    b.putExtra("s1high", img2urlhigh)
                    b.putExtra("sn1high", img2nhigh)
                    b.putExtra("t1high", img3urlhigh)
                    b.putExtra("tn1high",img3nhigh)
                    b.putExtra("fo1high", img4urlhigh)
                    b.putExtra("fon1high", img4nhigh)
                    b.putExtra("fif1high", img5urlhigh)
                    b.putExtra("fifn1high",img5nhigh)

                    b.putExtra("f1edit", f1edit)
                    b.putExtra("fn1edit", fn1edit)
                    b.putExtra("s1edit", s1edit)
                    b.putExtra("sn1edit", sn1edit)
                    b.putExtra("t1edit", t1edit)
                    b.putExtra("tn1edit", tn1edit)
                    b.putExtra("fo1edit", fo1edit)
                    b.putExtra("fon1edit", fon1edit)
                    b.putExtra("fif1edit", fif1edit)
                    b.putExtra("fifn1edit", fifn1edit)

                    startActivityForResult(b, 0)
                    gallery.isEnabled = true
                }










            }
            catch (e:Exception){

                fn1 = intent.getStringExtra("img1")
                sn1 = intent.getStringExtra("img2")
                tn1 = intent.getStringExtra("img3")
                fon1 = intent.getStringExtra("img4")
                fifn1 = intent.getStringExtra("img5")


                f1 = intent.getStringExtra("url1")

                s1 = intent.getStringExtra("url2")
                t1 = intent.getStringExtra("url3")
                fo1 = intent.getStringExtra("url4")
                fif1 = intent.getStringExtra("url5")

                if(f1.isNotEmpty()||s1.isNotEmpty()){
                    imageView11.visibility=View.GONE
                    imageButton2.visibility=View.GONE
                    scrollpro.visibility=View.VISIBLE
                    gallery.visibility=View.VISIBLE
                }

                scroll2_slider.setOnClickListener {
                    scroll2_slider.removeAllSliders()

                    //Navigate to add multi images activity - (AddImagesActivity_supp)

                    scroll2_slider.isEnabled = false
                    val b = Intent(applicationContext, AddImagesActivity_supp::class.java)
                    b.putExtra("id", id.text.toString())
                    b.putExtra("f1", f1)
                    b.putExtra("fn1", fn1)
                    b.putExtra("s1", s1)
                    b.putExtra("sn1", sn1)
                    b.putExtra("t1", t1)
                    b.putExtra("tn1", tn1)
                    b.putExtra("fo1", fo1)
                    b.putExtra("fon1", fon1)
                    b.putExtra("fif1", fif1)
                    b.putExtra("fifn1", fifn1)


                    b.putExtra("f1edit", f1edit)
                    b.putExtra("fn1edit", fn1edit)
                    b.putExtra("s1edit", s1edit)
                    b.putExtra("sn1edit", sn1edit)
                    b.putExtra("t1edit", t1edit)
                    b.putExtra("tn1edit", tn1edit)
                    b.putExtra("fo1edit", fo1edit)
                    b.putExtra("fon1edit", fon1edit)
                    b.putExtra("fif1edit", fif1edit)
                    b.putExtra("fifn1edit", fifn1edit)
                    startActivityForResult(b, 0)



                    scroll2_slider.isEnabled = true
                }




                gallery.setOnClickListener {

                    //Navigate to add multi images activity - (AddImagesActivity_supp)


                    scroll2_slider.removeAllSliders()


                    gallery.isEnabled = false
                    val b = Intent(applicationContext, AddImagesActivity_supp::class.java)
                    b.putExtra("id", id.text.toString())
                    b.putExtra("f1", f1)
                    b.putExtra("fn1", fn1)
                    b.putExtra("s1", s1)
                    b.putExtra("sn1", sn1)
                    b.putExtra("t1", t1)
                    b.putExtra("tn1", tn1)
                    b.putExtra("fo1", fo1)
                    b.putExtra("fon1", fon1)
                    b.putExtra("fif1", fif1)
                    b.putExtra("fifn1", fifn1)


                    b.putExtra("f1edit", f1edit)
                    b.putExtra("fn1edit", fn1edit)
                    b.putExtra("s1edit", s1edit)
                    b.putExtra("sn1edit", sn1edit)
                    b.putExtra("t1edit", t1edit)
                    b.putExtra("tn1edit", tn1edit)
                    b.putExtra("fo1edit", fo1edit)
                    b.putExtra("fon1edit", fon1edit)
                    b.putExtra("fif1edit", fif1edit)
                    b.putExtra("fifn1edit", fifn1edit)



                    b.putExtra("f1high", img1urlhigh)
                    b.putExtra("fn1high", img1nhigh)
                    b.putExtra("s1high", img2urlhigh)
                    b.putExtra("sn1high", img2nhigh)
                    b.putExtra("t1high", img3urlhigh)
                    b.putExtra("tn1high",img3nhigh)
                    b.putExtra("fo1high", img4urlhigh)
                    b.putExtra("fon1high", img4nhigh)
                    b.putExtra("fif1high", img5urlhigh)
                    b.putExtra("fifn1high",img5nhigh)
                    b.putExtra("mresult", mresultsarr)
                    b.putExtra("cacnm1", cacnm1)
                    b.putExtra("listener",prokeylistener)
                    b.putExtra("fieldlistener",fieldlistener)
                    b.putExtra("f1edithigh", f1edithigh)
                    b.putExtra("fn1edithigh", fn1edithigh)
                    b.putExtra("s1edithigh", s1edithigh)
                    b.putExtra("sn1edithigh", sn1edithigh)
                    b.putExtra("t1edithigh", t1edithigh)
                    b.putExtra("tn1edithigh", tn1edithigh)
                    b.putExtra("fo1edithigh", fo1edithigh)
                    b.putExtra("fon1edithigh", fon1edithigh)
                    b.putExtra("fif1edithigh", fif1edithigh)
                    b.putExtra("fifn1edithigh", fifn1edithigh)
                    b.putExtra("f1high", img1urlhigh)
                    b.putExtra("fn1high", img1nhigh)
                    b.putExtra("s1high", img2urlhigh)
                    b.putExtra("sn1high", img2nhigh)
                    b.putExtra("t1high", img3urlhigh)
                    b.putExtra("tn1high",img3nhigh)
                    b.putExtra("fo1high", img4urlhigh)
                    b.putExtra("fon1high", img4nhigh)
                    b.putExtra("fif1high", img5urlhigh)
                    b.putExtra("fifn1high",img5nhigh)
                    startActivityForResult(b, 0)



                    gallery.isEnabled = true
                }


                println("URLLLLSSSS catch ")


            }
            val urlimg = intent.getStringExtra("url")

            val descrip1 = intent.getStringExtra("sids")




            supp_nm.setText(sname1)
            supp_id.setText(sid1)
            supp_conpers.setText(sdur1)
            /*supp_mob.adapter=hsnT1*/
            /*hsndes.setText(hsndes1)
            price.setText(price1)*/
            supp_mobile.setText(Tax1)
            supp_mobile1.setText(intax1)
            supp_mobile2.setText(cess1)
            supp_address.setText(Ctax1)
            supp_address2.setText(Stax1)
            supp_address3.setText(taxtot1)
            supp_city.setText(css1)
            supp_state.setText(grosstot1)
            supp_pin.setText(payemp1)
            supp_gps.setText(paybonus1)
            supp_email.setText(currency1)
            supp_gstcode.setText(percentage1)
            statussup.setText(per1)

            supp_imgurl.setText(urlimg)

            id.setText(descrip1)
            println("else  " + id.text.toString())

            val categories1 = ArrayList<String>()
            categories1.add("Mobile")
            categories1.add("Phone")
            val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
            dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            supp_mob.adapter = dataAdaptermob
            supp_mob1.adapter = dataAdaptermob
            supp_mob2.adapter = dataAdaptermob
            supp_mob3.adapter = dataAdaptermob


            if(supp_id.text.toString()!="Auto - generated") {


                val getone = myDb.getOne(id.text.toString())

                if (getone.moveToNext()) {


                    if(getone.getString(3)=="Mobile"){
                        supp_mob.setSelection(0)
                    }
                    else{
                        supp_mob.setSelection(1)
                    }

                    if(getone.getString(4)=="Mobile"){
                        supp_mob1.setSelection(0)
                    }
                    else{
                        supp_mob1.setSelection(1)
                    }


                    if(getone.getString(5)=="Mobile"){
                        supp_mob2.setSelection(0)
                    }
                    else{
                        supp_mob2.setSelection(1)
                    }





                    suppnamevalidate=getone.getString(1)


                    suppmobilevalidate=getone.getString(6)


                    suppmobile21validate=getone.getString(7)


                    suppmobile31validate=getone.getString(8)


                    suppmobile41validate=getone.getString(9)




                    suppmobcat1validate=getone.getString(3)


                    suppmobcat2validate=getone.getString(4)

                    suppmobcat3validate=getone.getString(5)


                    suppaddress1validate=getone.getString(10)


                    suppaddress2validate=getone.getString(11)


                    suppaddress3validate=getone.getString(12)


                    suppcityvalidate=getone.getString(13)


                    suppstatevalidate=getone.getString(14)


                    supppinvalidate=getone.getString(15)

                    suppemailvalidate=getone.getString(17)

                    contactprsvalidate=getone.getString(18)

                    suppgstvalidate=getone.getString(19)
                    
                    prodkyvalidate=getone.getString(21)



                }

            }




            if((editcli=="clicked")&&(supp_id.text.toString()!="Auto - generated")){
                supp_edit.visibility=View.INVISIBLE
                imageButtonvert.visibility=View.VISIBLE
                println("EDIT CLICK FROM PRODUCT"+editcli)
            }

            //Visible edit button and disable all views
            else if((editcli.isEmpty()==true)&&(supp_id.text.toString()!="Auto - generated")){
                supp_edit.visibility=View.VISIBLE
                supp_save.visibility=View.INVISIBLE
                imageButtonvert.visibility=View.VISIBLE
                println("EDIT CLICK FROM PRODUCT"+editcli)

                supp_nm.isEnabled = false
                supp_id.isEnabled = false
                supp_mobile.isEnabled = false

                supp_mobile1.isEnabled = false
                supp_mobile2.isEnabled = false
                supp_mobile3.isEnabled = false
                supp_mob.isEnabled=false
                supp_mob1.isEnabled=false
                supp_mob2.isEnabled=false
                supp_mob3.isEnabled=false
                supp_address.isEnabled = false
                supp_address2.isEnabled = false
                supp_address3.isEnabled = false
                supp_city.isEnabled = false
                supp_state.isEnabled = false
                supp_pin.isEnabled = false
                imageButton2.isEnabled=false
                imageView11.isEnabled=false
                supp_email.isEnabled = false
                supp_conpers.isEnabled = false
                supp_gstcode.isEnabled = false
                supp_gps.isEnabled = false

            }







            val image_view = findViewById<ImageView>(R.id.imageView11)
            val image_button = findViewById(R.id.imageButton2) as ImageView

            //Navigate to add multi images activity - (AddImagesActivity_supp)

            image_button.setOnClickListener {
                scroll2_slider.removeAllSliders()
                val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                b.putExtra("id", id.text.toString())
                b.putExtra("f1", f1)
                b.putExtra("fn1", fn1)
                b.putExtra("s1", s1)
                b.putExtra("sn1", sn1)
                b.putExtra("t1", t1)
                b.putExtra("tn1", tn1)
                b.putExtra("fo1", fo1)
                b.putExtra("fon1", fon1)
                b.putExtra("fif1", fif1)
                b.putExtra("fifn1", fifn1)


                b.putExtra("f1edit", f1edit)
                b.putExtra("fn1edit", fn1edit)
                b.putExtra("s1edit", s1edit)
                b.putExtra("sn1edit", sn1edit)
                b.putExtra("t1edit", t1edit)
                b.putExtra("tn1edit", tn1edit)
                b.putExtra("fo1edit", fo1edit)
                b.putExtra("fon1edit", fon1edit)
                b.putExtra("fif1edit", fif1edit)
                b.putExtra("fifn1edit", fifn1edit)



                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)
                b.putExtra("mresult", mresultsarr)
                b.putExtra("cacnm1", cacnm1)
                b.putExtra("listener",prokeylistener)
                b.putExtra("fieldlistener",fieldlistener)
                b.putExtra("f1edithigh", f1edithigh)
                b.putExtra("fn1edithigh", fn1edithigh)
                b.putExtra("s1edithigh", s1edithigh)
                b.putExtra("sn1edithigh", sn1edithigh)
                b.putExtra("t1edithigh", t1edithigh)
                b.putExtra("tn1edithigh", tn1edithigh)
                b.putExtra("fo1edithigh", fo1edithigh)
                b.putExtra("fon1edithigh", fon1edithigh)
                b.putExtra("fif1edithigh", fif1edithigh)
                b.putExtra("fifn1edithigh", fifn1edithigh)
                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)

                b.putExtra("addsupp", addsupp)
                b.putExtra("editsupp", editesupp)
                b.putExtra("deletesupp", deletesupp)


                startActivityForResult(b, 0)
                gallery.isEnabled = true
            }


            //Navigate to add multi images activity - (AddImagesActivity_supp)


            image_view.setOnClickListener {
                scroll2_slider.removeAllSliders()
                val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                b.putExtra("id", id.text.toString())
                b.putExtra("f1", f1)
                b.putExtra("fn1", fn1)
                b.putExtra("s1", s1)
                b.putExtra("sn1", sn1)
                b.putExtra("t1", t1)
                b.putExtra("tn1", tn1)
                b.putExtra("fo1", fo1)
                b.putExtra("fon1", fon1)
                b.putExtra("fif1", fif1)
                b.putExtra("fifn1", fifn1)


                b.putExtra("f1edit", f1edit)
                b.putExtra("fn1edit", fn1edit)
                b.putExtra("s1edit", s1edit)
                b.putExtra("sn1edit", sn1edit)
                b.putExtra("t1edit", t1edit)
                b.putExtra("tn1edit", tn1edit)
                b.putExtra("fo1edit", fo1edit)
                b.putExtra("fon1edit", fon1edit)
                b.putExtra("fif1edit", fif1edit)
                b.putExtra("fifn1edit", fifn1edit)



                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)
                b.putExtra("mresult", mresultsarr)
                b.putExtra("cacnm1", cacnm1)
                b.putExtra("listener",prokeylistener)
                b.putExtra("fieldlistener",fieldlistener)
                b.putExtra("f1edithigh", f1edithigh)
                b.putExtra("fn1edithigh", fn1edithigh)
                b.putExtra("s1edithigh", s1edithigh)
                b.putExtra("sn1edithigh", sn1edithigh)
                b.putExtra("t1edithigh", t1edithigh)
                b.putExtra("tn1edithigh", tn1edithigh)
                b.putExtra("fo1edithigh", fo1edithigh)
                b.putExtra("fon1edithigh", fon1edithigh)
                b.putExtra("fif1edithigh", fif1edithigh)
                b.putExtra("fifn1edithigh", fifn1edithigh)
                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)

                b.putExtra("addsupp", addsupp)
                b.putExtra("editsupp", editesupp)
                b.putExtra("deletesupp", deletesupp)


                startActivityForResult(b, 0)
                gallery.isEnabled = true
            }





            //Edit button click and enable all views
            supp_edit.setOnClickListener {
                if (editesupp == "true" || editesupp.isNullOrEmpty()) {
                    supp_edit.visibility = View.INVISIBLE
                    supp_save.visibility = View.VISIBLE
                    sup_clear.visibility = View.INVISIBLE
                    sup_back.visibility = View.VISIBLE

                    editcli="clicked"

                    if(supp_id.text.toString().equals("Auto-generated")){
                        imageButtonvert.visibility=View.GONE
                    }
                    else if(supp_id.text.toString()!="Auto-generated"){
                        imageButtonvert.visibility=View.VISIBLE

                    }
                    supp_save.setText("SAVE")
                    supp_nm.isEnabled = true
                    supp_id.isEnabled = false
                    supp_mobile.isEnabled = true
                    supp_mobile1.isEnabled = true
                    supp_mobile2.isEnabled = true

                    supp_mob.isEnabled=true
                    supp_mob1.isEnabled=true
                    supp_mob2.isEnabled=true
                    supp_mob3.isEnabled=true
                    supp_mobile3.isEnabled = true
                    supp_address.isEnabled = true
                    supp_address2.isEnabled = true
                    supp_address3.isEnabled = true
                    supp_city.isEnabled = true
                    supp_state.isEnabled = true
                    supp_pin.isEnabled = true

                    supp_email.isEnabled = true
                    supp_conpers.isEnabled = true
                    supp_gstcode.isEnabled = true


                } else if (editesupp == "false") {
                    popup("edit")
                }

            }




            //file maps array contains image links  and  Handler() func is load links on slider view.

if(file_maps.isNotEmpty()){
    scroll2_slider2.visibility = View.VISIBLE
    scrollpro.visibility=View.GONE
    Handler().postDelayed(Runnable { loadim() }, 500)
}



        }

            //get id from list
            //val url = intent.getStringExtra("url")


           /* val b = intent.getStringExtra("id")
            val a = intent.getStringExtra("newid")


            if (b != null) {
                id.setText(b)//updateting list
            }*/



//Comes for insert new supliers
else if(i=="addsupp"){


            sup_back.visibility = View.VISIBLE
            val g=intent.getStringExtra("newid")

            val ad = intent.getStringExtra("addsupps")
            val ed = intent.getStringExtra("editsupp")
            val del = intent.getStringExtra("deletesupp")
            val vi=intent.getStringExtra("viewsupp")
            val im=intent.getStringExtra("importsupp")
            val ex=intent.getStringExtra("exportsupp")

            try{
                suppsel=intent.getStringExtra("suppsel")
            }
            catch(e:Exception){

            }

            if (ad != null) {
                addsupp = ad
            }
            if (ed != null) {
                editesupp = ed
            }
            if (del != null) {
                deletesupp = del
            }
            if (vi != null) {
                viewsupp = vi
            }
            if (im != null) {
                importsupp = im
            }
            if (ex != null) {
                exportsupp = ex
            }


            supp_savekey.setText(g)
            prokeylistener="what"

            println("SAVE KEYSSS"+supp_savekey.text)



            val categories1 = ArrayList<String>()
            categories1.add("Mobile")
            categories1.add("Phone")

            val image_view = findViewById(R.id.imageView11) as ImageView
            val image_button = findViewById(R.id.imageButton2) as ImageView



            //Navigate to add multi images activity - (AddImagesActivity_supp)

            image_button.setOnClickListener {

                val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                b.putExtra("id", id.text.toString())
                b.putExtra("f1", f1)
                b.putExtra("fn1", fn1)
                b.putExtra("s1", s1)
                b.putExtra("sn1", sn1)
                b.putExtra("t1", t1)
                b.putExtra("tn1", tn1)
                b.putExtra("fo1", fo1)
                b.putExtra("fon1", fon1)
                b.putExtra("fif1", fif1)
                b.putExtra("fifn1", fifn1)


                b.putExtra("f1edit", f1edit)
                b.putExtra("fn1edit", fn1edit)
                b.putExtra("s1edit", s1edit)
                b.putExtra("sn1edit", sn1edit)
                b.putExtra("t1edit", t1edit)
                b.putExtra("tn1edit", tn1edit)
                b.putExtra("fo1edit", fo1edit)
                b.putExtra("fon1edit", fon1edit)
                b.putExtra("fif1edit", fif1edit)
                b.putExtra("fifn1edit", fifn1edit)



                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)
                b.putExtra("mresult", mresultsarr)
                b.putExtra("cacnm1", cacnm1)
                b.putExtra("listener",prokeylistener)
                b.putExtra("fieldlistener",fieldlistener)
                b.putExtra("f1edithigh", f1edithigh)
                b.putExtra("fn1edithigh", fn1edithigh)
                b.putExtra("s1edithigh", s1edithigh)
                b.putExtra("sn1edithigh", sn1edithigh)
                b.putExtra("t1edithigh", t1edithigh)
                b.putExtra("tn1edithigh", tn1edithigh)
                b.putExtra("fo1edithigh", fo1edithigh)
                b.putExtra("fon1edithigh", fon1edithigh)
                b.putExtra("fif1edithigh", fif1edithigh)
                b.putExtra("fifn1edithigh", fifn1edithigh)
                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)

                b.putExtra("addsupp", addsupp)
                b.putExtra("editsupp", editesupp)
                b.putExtra("deletesupp", deletesupp)


                startActivityForResult(b, 0)
                gallery.isEnabled = true
            }


            //Navigate to add multi images activity - (AddImagesActivity_supp)

            image_view.setOnClickListener {

                val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                b.putExtra("id", id.text.toString())
                b.putExtra("f1", f1)
                b.putExtra("fn1", fn1)
                b.putExtra("s1", s1)
                b.putExtra("sn1", sn1)
                b.putExtra("t1", t1)
                b.putExtra("tn1", tn1)
                b.putExtra("fo1", fo1)
                b.putExtra("fon1", fon1)
                b.putExtra("fif1", fif1)
                b.putExtra("fifn1", fifn1)


                b.putExtra("f1edit", f1edit)
                b.putExtra("fn1edit", fn1edit)
                b.putExtra("s1edit", s1edit)
                b.putExtra("sn1edit", sn1edit)
                b.putExtra("t1edit", t1edit)
                b.putExtra("tn1edit", tn1edit)
                b.putExtra("fo1edit", fo1edit)
                b.putExtra("fon1edit", fon1edit)
                b.putExtra("fif1edit", fif1edit)
                b.putExtra("fifn1edit", fifn1edit)



                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)
                b.putExtra("mresult", mresultsarr)
                b.putExtra("cacnm1", cacnm1)
                b.putExtra("listener",prokeylistener)
                b.putExtra("fieldlistener",fieldlistener)
                b.putExtra("f1edithigh", f1edithigh)
                b.putExtra("fn1edithigh", fn1edithigh)
                b.putExtra("s1edithigh", s1edithigh)
                b.putExtra("sn1edithigh", sn1edithigh)
                b.putExtra("t1edithigh", t1edithigh)
                b.putExtra("tn1edithigh", tn1edithigh)
                b.putExtra("fo1edithigh", fo1edithigh)
                b.putExtra("fon1edithigh", fon1edithigh)
                b.putExtra("fif1edithigh", fif1edithigh)
                b.putExtra("fifn1edithigh", fifn1edithigh)
                b.putExtra("f1high", img1urlhigh)
                b.putExtra("fn1high", img1nhigh)
                b.putExtra("s1high", img2urlhigh)
                b.putExtra("sn1high", img2nhigh)
                b.putExtra("t1high", img3urlhigh)
                b.putExtra("tn1high",img3nhigh)
                b.putExtra("fo1high", img4urlhigh)
                b.putExtra("fon1high", img4nhigh)
                b.putExtra("fif1high", img5urlhigh)
                b.putExtra("fifn1high",img5nhigh)

               b.putExtra("addsupp", addsupp)
               b.putExtra("editsupp", editesupp)
               b.putExtra("deletesupp", deletesupp)

                startActivityForResult(b, 0)
                gallery.isEnabled = true
            }


            val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
            dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            supp_mob.adapter = dataAdaptermob
            supp_mob1.adapter = dataAdaptermob
            supp_mob2.adapter = dataAdaptermob
            supp_mob3.adapter = dataAdaptermob



        }






        /*gps.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                Handler().postDelayed({
                    val gmmIntentUri = Uri.parse("geo:0,0?q=")
                    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                    mapIntent.`package` = "com.google.android.apps.maps"
                    startActivity(mapIntent)
                }, 1000)
            }
        })*/



        // vert menu contains Popup with the title of Enable/Disable


        imageButtonvert.setOnClickListener({


            val popup = PopupMenu(this@SupplierAddMain, imageButtonvert)

            popup.menuInflater.inflate(R.menu.menu_main_supp, popup.menu)
            val m1 = popup.menu.getItem(0)
            if (deletesupp == "true" || deletesupp.isNullOrEmpty()) {
                if (statussup.text == "Disable") {
                    m1.title = "Enable supplier"

                    popup.setOnMenuItemClickListener { item ->  //Click disable title and change the status of the product as 'DISABLED'
                        statussup.setText("Active")




                        if (item.itemId ==R.id.imsupp) {


                            if(net_status()==true) {

                                var idmy = supp_savekey.text.toString()
                                var suppname = (supp_nm.text).toString()
                                var suppid = (supp_id.text).toString()

                                var suppmobcat1 = supp_mob.selectedItem.toString()
                                var suppmobcat2 = supp_mob1.selectedItem.toString()
                                var suppmobcat3 = supp_mob2.selectedItem.toString()
                                var suppmobcat4=supp_mob3.selectedItem.toString()
                                var suppaddress1 = (supp_address.text).toString()
                                var suppmobile = (supp_mobile.text).toString()
                                var suppmobile21 = (supp_mobile1.text).toString()
                                var suppmobile31 = (supp_mobile2.text).toString()
                                var suppmobile41 = (supp_mobile3.text).toString()
                                var suppaddress2 = (supp_address2.text).toString()
                                var suppaddress3 = (supp_address3.text).toString()
                                var suppcity = (supp_city.text).toString()
                                var suppstate = (supp_state.text).toString()
                                var supppin = (supp_pin.text).toString()
                                var contactprs = (supp_conpers.text).toString()
                                var prodky = (pro_savekey.text).toString()
                                var gps = (supp_gps.text).toString()

                                var suppemail = (supp_email.text).toString()

                                var suppgst = (supp_gstcode.text).toString()
                                var suppimglink = (supp_imgurl.text).toString()

                                val img1n = fn1
                                val img2n = sn1
                                val img3n = tn1
                                val img4n = fon1
                                val img5n = fifn1
                                val img1url = f1
                                val img2url = s1
                                val img3url = t1
                                val img4url = fo1
                                val img5url = fif1

                                val builder = AlertDialog.Builder(this@SupplierAddMain)
                                with(builder) {
                                    setTitle("Confirm?")
                                    setMessage("Are you sure want to enable?")
                                    setPositiveButton("Yes") { dialog, whichButton ->

                                        pDialogs = SweetAlertDialog(this@SupplierAddMain, SweetAlertDialog.PROGRESS_TYPE);
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                        pDialogs!!.setTitleText("Enabling...");
                                        pDialogs!!.setCancelable(false);
                                        pDialogs!!.show();
                                        statussup.text = "Active"
                                        var status = (statussup.text).toString()
                                        disab = "change"
                                        val map = mutableMapOf<String, Any?>()
                                        map.put("status", status)
                                        db.collection("suppliers").document(id.text.toString())
                                                .update(map)
                                                .addOnSuccessListener {
                                                    val isInserted = myDb.updatedata(idmy, suppname, suppid, suppmobcat1,
                                                            suppmobcat2, suppmobcat3, suppmobile, suppmobile21, suppmobile31, suppmobile41,
                                                            suppaddress1, suppaddress2, suppaddress3, suppcity, suppstate, supppin, gps, suppemail,
                                                            contactprs, suppgst, suppimglink, prodky, status, img1n, img2n, img3n, img4n, img5n,
                                                            img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh,
                                                            img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,suppmobcat4)

                                                    if (isInserted == true) {
                                                    } else {
                                                    }
                                                    pDialogs!!.dismiss()
                                                    Toast.makeText(applicationContext, "Enabled", Toast.LENGTH_LONG).show()
                                                    val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                                    i.putExtra("frm_main", "main")
                                                    i.putExtra("addsupp", addsupp)
                                                    i.putExtra("editsupp", editesupp)
                                                    i.putExtra("deletesupp", deletesupp)
                                                    i.putExtra("viewsupp", viewsupp)
                                                    i.putExtra("importsupp", importsupp)
                                                    i.putExtra("exportsupp", exportsupp)

                                                    startActivity(i)
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                                    finish()


                                                }
                                    }
                                    setNegativeButton("No") { dialog, whichButton ->
                                        dialog.dismiss()
                                    }

                                    val dialog = builder.create()

                                    dialog.show()

                                }
                            }
                            else{
                                Toast.makeText(this@SupplierAddMain, "You're offline", Toast.LENGTH_SHORT).show()

                            }

                        }
                        true
                    }

                    popup.show()
                } else if (statussup.text == "Active") {
                    m1.title = "Disable supplier"
                    popup.setOnMenuItemClickListener { item ->  //Click enable title and change the status of the product as 'Active'
                        statussup.setText("Disable")
                        Toast.makeText(this@SupplierAddMain, "" + item, Toast.LENGTH_SHORT).show()

                        if (item.itemId ==R.id.imsupp) {
                            if(net_status()==true) {
                                var idmy = supp_savekey.text.toString()
                                var suppname = (supp_nm.text).toString()
                                var suppid = (supp_id.text).toString()

                                var suppmobcat1 = supp_mob.selectedItem.toString()
                                var suppmobcat2 = supp_mob1.selectedItem.toString()
                                var suppmobcat3 = supp_mob2.selectedItem.toString()
                                var suppmobcat4=supp_mob3.selectedItem.toString()

                                var suppaddress1 = (supp_address.text).toString()
                                var suppmobile = (supp_mobile.text).toString()
                                var suppmobile21 = (supp_mobile1.text).toString()
                                var suppmobile31 = (supp_mobile2.text).toString()
                                var suppmobile41 = (supp_mobile3.text).toString()
                                var suppaddress2 = (supp_address2.text).toString()
                                var suppaddress3 = (supp_address3.text).toString()
                                var suppcity = (supp_city.text).toString()
                                var suppstate = (supp_state.text).toString()
                                var supppin = (supp_pin.text).toString()
                                var contactprs = (supp_conpers.text).toString()
                                var prodky = (pro_savekey.text).toString()
                                var gps = (supp_gps.text).toString()

                                var suppemail = (supp_email.text).toString()

                                var suppgst = (supp_gstcode.text).toString()
                                var suppimglink = (supp_imgurl.text).toString()

                                val img1n = fn1
                                val img2n = sn1
                                val img3n = tn1
                                val img4n = fon1
                                val img5n = fifn1
                                val img1url = f1
                                val img2url = s1
                                val img3url = t1
                                val img4url = fo1
                                val img5url = fif1
                                val builder = AlertDialog.Builder(this@SupplierAddMain)
                                with(builder) {
                                    setTitle("Confirm?")
                                    setMessage("Are you sure want to disable?")
                                    setPositiveButton("Yes") { dialog, whichButton ->
                                        pDialogs = SweetAlertDialog(this@SupplierAddMain, SweetAlertDialog.PROGRESS_TYPE);
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                        pDialogs!!.setTitleText("Disabling...");
                                        pDialogs!!.setCancelable(false);
                                        pDialogs!!.show();


                                        statussup.text = "Disable"
                                        var status = (statussup.text).toString()
                                        disab = "change"
                                        val map = mutableMapOf<String, Any?>()
                                        map.put("status", status)
                                        db.collection("suppliers").document(id.text.toString())
                                                .update(map)
                                                .addOnSuccessListener {
                                                    val isInserted = myDb.updatedata(idmy, suppname, suppid, suppmobcat1,
                                                            suppmobcat2, suppmobcat3, suppmobile, suppmobile21, suppmobile31, suppmobile41,
                                                            suppaddress1, suppaddress2, suppaddress3, suppcity, suppstate, supppin, gps, suppemail,
                                                            contactprs, suppgst, suppimglink, prodky, status, img1n, img2n, img3n, img4n, img5n,
                                                            img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,suppmobcat4)

                                                    if (isInserted == true) {
                                                    } else {
                                                    }
                                                    pDialogs!!.dismiss()

                                                    Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()

                                                    val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                                    i.putExtra("frm_main", "main")
                                                    i.putExtra("addsupp", addsupp)
                                                    i.putExtra("editsupp", editesupp)
                                                    i.putExtra("deletesupp", deletesupp)
                                                    i.putExtra("viewsupp", viewsupp)
                                                    i.putExtra("importsupp", importsupp)
                                                    i.putExtra("exportsupp", exportsupp)

                                                    startActivity(i)
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                                    finish()

                                                }

                                    }

                                    setNegativeButton("No") { dialog, whichButton ->
                                        dialog.dismiss()
                                    }

                                    val dialog = builder.create()

                                    dialog.show()

                                }
                            }
                            else{
                                Toast.makeText(this@SupplierAddMain, "You're offline", Toast.LENGTH_SHORT).show()

                            }
                        }
                        true
                    }
                    popup.show()
                }
            }
            else if (deletesupp=="false"){
                popup("Disable or Enable")
            }


        })



        //Navigate to maps activity
        supp_gps.setOnClickListener {
            val map = Intent(this,MapsActivity::class.java)

            map.putExtra("img1",fn1)
            map.putExtra("img2", sn1)
            map.putExtra("img3", tn1)
            map.putExtra("img4", fon1)
            map.putExtra("img5",fifn1 )
            map.putExtra("url1",f1)
            map.putExtra("url2",s1)
            map.putExtra("url3",t1)
            map.putExtra("url4",fo1)
            map.putExtra("url5",fif1)


            startActivityForResult(map,1)
        }

        supp_mobile.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->
            supp_mobile1.visibility = View.VISIBLE
            supp_mob1.visibility = View.VISIBLE

        })

        //mobile custom add
        supp_mobile1.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->
            supp_mobile2.visibility = View.VISIBLE
            supp_mob2.visibility = View.VISIBLE

        })
        supp_mobile2.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->
            supp_mobile3.visibility = View.VISIBLE
            supp_mob3.visibility = View.VISIBLE
        })

        supp_mobile.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                supp_phoneerr.visibility = View.INVISIBLE
                if(id.text.toString().isEmpty()){
                    sup_clear.visibility = View.VISIBLE
                    sup_back.visibility = View.INVISIBLE
                }
                if(id.text.toString().isNotEmpty()){
                    sup_clear.visibility = View.GONE
                    sup_back.visibility = View.VISIBLE
                }


            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {

                if(supp_mobile.text.toString().isEmpty()){
                    sup_clear.visibility = View.INVISIBLE
                    sup_back.visibility = View.VISIBLE
                }

            }

        })
        supp_nm.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                supperrnm.visibility = View.INVISIBLE
                if(id.text.toString().isEmpty()){
                    sup_clear.visibility = View.VISIBLE
                    sup_back.visibility = View.INVISIBLE
                }
                if(id.text.toString().isNotEmpty()){
                    sup_clear.visibility = View.GONE
                    sup_back.visibility = View.VISIBLE
                }
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {

                if(supp_nm.text.toString().isEmpty()){
                    sup_clear.visibility = View.INVISIBLE
                    sup_back.visibility = View.VISIBLE
                }
            }

        })
        supp_email.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                supp_mailerr.visibility = View.INVISIBLE
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {}

        })


        //Click clear butto which clear all edittexts
        sup_clear.setOnClickListener {
            sup_clear.visibility = View.INVISIBLE
            sup_back.visibility = View.VISIBLE

            supp_nm.setText("")
            supp_conpers.setText("")

            supp_mobile.setText("")
            supp_mobile1.setText("")
            supp_mobile2.setText("")
            supp_address.setText("")
            supp_address2.setText("")
            supp_address3.setText("")
            supp_city.setText("")
            supp_state.setText("")
            supp_pin.setText("")

            supp_email.setText("")
            supp_gps.setText("")
            supp_gstcode.setText("")
        }

        //Navigate to add multi images activity - (AddImagesActivity_supp)

        gallery.setOnClickListener {
            scroll2_slider.removeAllSliders()
            gallery.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_supp::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)


            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)



            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("listener",prokeylistener)
            b.putExtra("fieldlistener",fieldlistener)

            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)

            b.putExtra("addsupp", addsupp)
            b.putExtra("editsupp", editesupp)
            b.putExtra("deletesupp", deletesupp)
            startActivityForResult(b, 0)
            gallery.isEnabled = true
        }





        //For updating existing supplier

     if(i=="fromsuplist") {
         supp_save.visibility = View.INVISIBLE
         supp_edit.visibility = View.VISIBLE
         sup_clear.visibility = View.GONE
         sup_back.visibility = View.VISIBLE

         val b = intent.getStringExtra("id")
         val a = intent.getStringExtra("newid")
         val ad = intent.getStringExtra("addsupp")
         val ed = intent.getStringExtra("editsupp")
         val del = intent.getStringExtra("deletesupp")
         val vi=intent.getStringExtra("viewsupp")
         val im=intent.getStringExtra("importsupp")
         val ex=intent.getStringExtra("exportsupp")
         if (ad != null) {
             addsupp = ad
         }
         if (ed != null) {
             editesupp = ed
         }
         if (del != null) {
             deletesupp = del
         }
         if (vi != null) {
             viewsupp = vi
         }
         if (im != null) {
             importsupp = im
         }
         if (ex != null) {
             exportsupp = ex
         }
         id.setText(b)
         supp_savekey.setText(b)

         if (id.text.isNotEmpty()) {

             val categories1 = ArrayList<String>()
             categories1.add("Mobile")
             categories1.add("Phone")
             val dataAdaptermob = ArrayAdapter(this@SupplierAddMain, R.layout.support_simple_spinner_dropdown_item, categories1)
             dataAdaptermob.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
             supp_mob.adapter = dataAdaptermob
             supp_mob1.adapter = dataAdaptermob
             supp_mob2.adapter = dataAdaptermob
             supp_mob3.adapter = dataAdaptermob



             val getone = myDb.getOne(id.text.toString())

             if (getone.moveToNext()) {

                 if(getone.getString(3)=="Mobile"){
                     supp_mob.setSelection(0)
                 }
                 else{
                     supp_mob.setSelection(1)
                 }

                 if(getone.getString(4)=="Mobile"){
                     supp_mob1.setSelection(0)
                 }
                 else{
                     supp_mob1.setSelection(1)
                 }


                 if(getone.getString(5)=="Mobile"){
                     supp_mob2.setSelection(0)
                 }
                 else{
                     supp_mob2.setSelection(1)
                 }

                 if(getone.getString(43)=="Mobile"){
                     supp_mob3.setSelection(0)
                 }
                 else{
                     supp_mob3.setSelection(1)
                 }



                 supp_nm.setText(getone.getString(1))
                 suppnamevalidate=getone.getString(1)

                 supp_id.setText(getone.getString(2))
                 supp_mobile.setText(getone.getString(6))
                 suppmobilevalidate=getone.getString(6)

                 supp_mobile1.setText(getone.getString(7))
                 if(getone.getString(7).isNotEmpty()){
                     supp_mob1.visibility=View.VISIBLE
                 }
                 suppmobile21validate=getone.getString(7)

                 supp_mobile2.setText(getone.getString(8))
                 if(getone.getString(8).isNotEmpty()){
                     supp_mob2.visibility=View.VISIBLE
                 }
                 suppmobile31validate=getone.getString(8)

                 supp_mobile3.setText(getone.getString(9))
                 if(getone.getString(9).isNotEmpty()){
                     supp_mob3.visibility=View.VISIBLE
                 }
                 suppmobile41validate=getone.getString(9)




                 suppmobcat1validate=getone.getString(3)


                 suppmobcat2validate=getone.getString(4)

                 suppmobcat3validate=getone.getString(5)

                 supp_address.setText(getone.getString(10))
                 suppaddress1validate=getone.getString(10)

                 supp_address2.setText(getone.getString(11))
                 suppaddress2validate=getone.getString(11)

                 supp_address3.setText(getone.getString(12))
                 suppaddress3validate=getone.getString(12)

                 supp_city.setText(getone.getString(13))
                 suppcityvalidate=getone.getString(13)

                 supp_state.setText(getone.getString(14))
                 suppstatevalidate=getone.getString(14)

                 supp_pin.setText(getone.getString(15))
                 supppinvalidate=getone.getString(15)


                 fn1 = getone.getString(23).toString()

                 sn1 = getone.getString(24).toString()
                 tn1 = getone.getString(25).toString()
                fon1 = getone.getString(26).toString()
                 fifn1 = getone.getString(27).toString()
                 f1 = getone.getString(28).toString()
                 println("IMG URLS DUDE"+f1)
                 println("IMG URLSSSS" + getone.getString(29).toString())
                 println("IMG NAMES" + getone.getString(30).toString())



                s1 = getone.getString(29).toString()
                t1 = getone.getString(30).toString()
                fo1 = getone.getString(31).toString()
               fif1 = getone.getString(32).toString()



                 img1nhigh=getone.getString(33).toString()
                 img2nhigh=getone.getString(34).toString()
                 img3nhigh=getone.getString(35).toString()
                 img4nhigh=getone.getString(36).toString()
                 img5nhigh=getone.getString(37).toString()
                 img1urlhigh=getone.getString(38).toString()
                 img2urlhigh=getone.getString(39).toString()
                 img3urlhigh=getone.getString(40).toString()
                 img4urlhigh=getone.getString(41).toString()
                 img5urlhigh=getone.getString(42).toString()

                 f1edithigh=img1urlhigh
                 fn1edithigh=img1nhigh
                 s1edithigh=img2urlhigh
                 sn1edithigh=img2nhigh
                 t1edithigh=img3urlhigh
                 tn1edithigh=img3nhigh
                 fo1edithigh=img4urlhigh
                 fon1edithigh=img4nhigh
                 fif1edithigh=img5urlhigh
                 fifn1edithigh=img5nhigh



                 f1edit = f1.toString()
                 fn1edit = fn1.toString()
                 s1edit = s1.toString()
                 sn1edit = sn1.toString()
                 t1edit = t1.toString()
                 tn1edit = tn1.toString()
                 fo1edit = fo1.toString()
                 fon1edit = fon1.toString()
                 fif1edit = fif1.toString()
                 fifn1edit = fifn1.toString()






                 if((f1.isNotEmpty())||(s1.isNotEmpty())){
                     imageView11.visibility=View.GONE
                     imageButton2.visibility=View.GONE
                     gallery.visibility=View.VISIBLE
                 }


                 // If imagelinks are not empty then add image links to 'filemaps' array for slider view.
                 //Image links from local storage or online db

                 if (f1.isNullOrEmpty() == false || s1.isNullOrEmpty() == false || t1.isNullOrEmpty() == false || fo1.isNullOrEmpty() == false || fif1.isNullOrEmpty() == false) {


                     scrollpro.visibility = View.VISIBLE


                     scroll2_slider2.visibility = View.VISIBLE
                     imageView11.visibility = View.GONE
                     imageButton2.visibility = View.GONE
                     gallery.visibility = View.VISIBLE
                     if (f1.isNullOrEmpty() == false) {
                         f1 = f1.toString()

                     }
                     if (s1.isNullOrEmpty() == false) {
                         s1 = s1.toString()

                     }
                     if (t1.isNullOrEmpty() == false) {
                         t1 = t1.toString()

                     }
                     if (fo1.isNullOrEmpty() == false) {
                         fo1 = fo1.toString()

                     }
                     if (fif1.isNullOrEmpty() == false) {
                         fif1 = fif1.toString()

                     }
                     if (fn1.isNullOrEmpty() == false) {
                         fn1 = fn1.toString()

                         img1nhigh=img1nhigh.toString()



                         try {

                             val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                             val dir = File(path);
                             if (!dir.exists())
                                 dir.mkdirs()

                             val k = img1nhigh
                             val recacnm = k.removeSuffix(".jpg")
                             cacnm1 = recacnm
                             var y = recacnm + ".png"

                             val file = File(dir, y)
                             println("CONTENT URI" + file)
                             if (file.exists()) {
                                 val contentUri = Uri.fromFile(File("$path/$y"))
                                 file_maps.add(contentUri.toString())
                             }
                             else{
                                 file_maps.add(f1)
                             }
                         }
                         catch (e:Exception){
                             file_maps.add(f1)
                         }

                     }
                     if (sn1.isNullOrEmpty() == false) {
                         sn1 = sn1.toString()

                         img2nhigh=img2nhigh.toString()



                         try {

                             val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                             val dir = File(path);
                             if (!dir.exists())
                                 dir.mkdirs()

                             val k = img2nhigh
                             val recacnm = k.removeSuffix(".jpg")
                             cacnm1 = recacnm
                             var y = recacnm + ".png"

                             val file = File(dir, y)
                             println("CONTENT URI" + file)
                             if (file.exists()) {
                                 val contentUri = Uri.fromFile(File("$path/$y"))
                                 file_maps.add(contentUri.toString())
                             }
                             else{
                                 file_maps.add(s1)
                             }
                         }
                         catch (e:Exception){
                             file_maps.add(s1)
                         }


                     }
                     if (tn1.isNullOrEmpty() == false) {
                         tn1 = tn1.toString()

                         img3nhigh=img3nhigh.toString()



                         try {

                             val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                             val dir = File(path);
                             if (!dir.exists())
                                 dir.mkdirs()

                             val k = img3nhigh
                             val recacnm = k.removeSuffix(".jpg")
                             cacnm1 = recacnm
                             var y = recacnm + ".png"

                             val file = File(dir, y)
                             println("CONTENT URI" + file)
                             if (file.exists()) {
                                 val contentUri = Uri.fromFile(File("$path/$y"))
                                 file_maps.add(contentUri.toString())
                             }
                             else{
                                 file_maps.add(t1)
                             }
                         }
                         catch (e:Exception){
                             file_maps.add(t1)
                         }
                     }
                     if (fon1.isNullOrEmpty() == false) {
                         fon1 = fon1.toString()

                         img4nhigh=img4nhigh.toString()



                         try {

                             val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                             val dir = File(path);
                             if (!dir.exists())
                                 dir.mkdirs()

                             val k = img4nhigh
                             val recacnm = k.removeSuffix(".jpg")
                             cacnm1 = recacnm
                             var y = recacnm + ".png"

                             val file = File(dir, y)
                             println("CONTENT URI" + file)
                             if (file.exists()) {
                                 val contentUri = Uri.fromFile(File("$path/$y"))
                                 file_maps.add(contentUri.toString())
                             }
                             else{
                                 file_maps.add(fo1)
                             }
                         }
                         catch (e:Exception){
                             file_maps.add(fo1)
                         }

                     }
                     if (fifn1.isNullOrEmpty() == false) {
                         fifn1 = fifn1.toString()

                         img5nhigh=img5nhigh.toString()



                         try {

                             val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                             val dir = File(path);
                             if (!dir.exists())
                                 dir.mkdirs()

                             val k = img5nhigh
                             val recacnm = k.removeSuffix(".jpg")
                             cacnm1 = recacnm
                             var y = recacnm + ".png"

                             val file = File(dir, y)
                             println("CONTENT URI" + file)
                             if (file.exists()) {
                                 val contentUri = Uri.fromFile(File("$path/$y"))
                                 file_maps.add(contentUri.toString())
                             }
                             else{
                                 file_maps.add(fif1)
                             }
                         }
                         catch (e:Exception){
                             file_maps.add(fif1)
                         }


                     }
                 } else {
                     scroll2_slider2.visibility = View.GONE

                     scroll2_slider.visibility = View.VISIBLE


                     imageView11.visibility = View.VISIBLE
                     imageButton2.visibility = View.VISIBLE
                     gallery.visibility = View.GONE
                 }


                 supp_email.setText(getone.getString(17))
                 suppemailvalidate=getone.getString(17)
                 supp_conpers.setText(getone.getString(18))
                 contactprsvalidate=getone.getString(18)
                 supp_gstcode.setText(getone.getString(19))
                 suppgstvalidate=getone.getString(19)
                 supp_imgurl.setText(getone.getString(20))
                 statussup.setText(getone.getString(22))
                 pro_savekey.setText(getone.getString(21))
                 prodkyvalidate=getone.getString(21)





                 val image_view = findViewById<ImageView>(R.id.imageView11)
                 val image_button = findViewById(R.id.imageButton2) as ImageView


                 //Navigate to add multi images activity - (AddImagesActivity_supp)


                 image_button.setOnClickListener {
                     scroll2_slider.removeAllSliders()
                     val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                     b.putExtra("id", id.text.toString())
                     b.putExtra("f1", f1)
                     b.putExtra("fn1", fn1)
                     b.putExtra("s1", s1)
                     b.putExtra("sn1", sn1)
                     b.putExtra("t1", t1)
                     b.putExtra("tn1", tn1)
                     b.putExtra("fo1", fo1)
                     b.putExtra("fon1", fon1)
                     b.putExtra("fif1", fif1)
                     b.putExtra("fifn1", fifn1)


                     b.putExtra("f1edit", f1edit)
                     b.putExtra("fn1edit", fn1edit)
                     b.putExtra("s1edit", s1edit)
                     b.putExtra("sn1edit", sn1edit)
                     b.putExtra("t1edit", t1edit)
                     b.putExtra("tn1edit", tn1edit)
                     b.putExtra("fo1edit", fo1edit)
                     b.putExtra("fon1edit", fon1edit)
                     b.putExtra("fif1edit", fif1edit)
                     b.putExtra("fifn1edit", fifn1edit)



                     b.putExtra("f1high", img1urlhigh)
                     b.putExtra("fn1high", img1nhigh)
                     b.putExtra("s1high", img2urlhigh)
                     b.putExtra("sn1high", img2nhigh)
                     b.putExtra("t1high", img3urlhigh)
                     b.putExtra("tn1high",img3nhigh)
                     b.putExtra("fo1high", img4urlhigh)
                     b.putExtra("fon1high", img4nhigh)
                     b.putExtra("fif1high", img5urlhigh)
                     b.putExtra("fifn1high",img5nhigh)
                     b.putExtra("mresult", mresultsarr)
                     b.putExtra("cacnm1", cacnm1)
                     b.putExtra("listener",prokeylistener)
                     b.putExtra("fieldlistener",fieldlistener)
                     b.putExtra("f1edithigh", f1edithigh)
                     b.putExtra("fn1edithigh", fn1edithigh)
                     b.putExtra("s1edithigh", s1edithigh)
                     b.putExtra("sn1edithigh", sn1edithigh)
                     b.putExtra("t1edithigh", t1edithigh)
                     b.putExtra("tn1edithigh", tn1edithigh)
                     b.putExtra("fo1edithigh", fo1edithigh)
                     b.putExtra("fon1edithigh", fon1edithigh)
                     b.putExtra("fif1edithigh", fif1edithigh)
                     b.putExtra("fifn1edithigh", fifn1edithigh)
                     b.putExtra("f1high", img1urlhigh)
                     b.putExtra("fn1high", img1nhigh)
                     b.putExtra("s1high", img2urlhigh)
                     b.putExtra("sn1high", img2nhigh)
                     b.putExtra("t1high", img3urlhigh)
                     b.putExtra("tn1high",img3nhigh)
                     b.putExtra("fo1high", img4urlhigh)
                     b.putExtra("fon1high", img4nhigh)
                     b.putExtra("fif1high", img5urlhigh)
                     b.putExtra("fifn1high",img5nhigh)

                     b.putExtra("addsupp", addsupp)
                     b.putExtra("editsupp", editesupp)
                     b.putExtra("deletesupp", deletesupp)



                     startActivityForResult(b, 0)
                     gallery.isEnabled = true
                 }


                 //Navigate to add multi images activity - (AddImagesActivity_supp)


                 image_view.setOnClickListener {
                     scroll2_slider.removeAllSliders()
                     val b = Intent(this@SupplierAddMain, AddImagesActivity_supp::class.java)
                     b.putExtra("id", id.text.toString())
                     b.putExtra("f1", f1)
                     b.putExtra("fn1", fn1)
                     b.putExtra("s1", s1)
                     b.putExtra("sn1", sn1)
                     b.putExtra("t1", t1)
                     b.putExtra("tn1", tn1)
                     b.putExtra("fo1", fo1)
                     b.putExtra("fon1", fon1)
                     b.putExtra("fif1", fif1)
                     b.putExtra("fifn1", fifn1)


                     b.putExtra("f1edit", f1edit)
                     b.putExtra("fn1edit", fn1edit)
                     b.putExtra("s1edit", s1edit)
                     b.putExtra("sn1edit", sn1edit)
                     b.putExtra("t1edit", t1edit)
                     b.putExtra("tn1edit", tn1edit)
                     b.putExtra("fo1edit", fo1edit)
                     b.putExtra("fon1edit", fon1edit)
                     b.putExtra("fif1edit", fif1edit)
                     b.putExtra("fifn1edit", fifn1edit)



                     b.putExtra("f1high", img1urlhigh)
                     b.putExtra("fn1high", img1nhigh)
                     b.putExtra("s1high", img2urlhigh)
                     b.putExtra("sn1high", img2nhigh)
                     b.putExtra("t1high", img3urlhigh)
                     b.putExtra("tn1high",img3nhigh)
                     b.putExtra("fo1high", img4urlhigh)
                     b.putExtra("fon1high", img4nhigh)
                     b.putExtra("fif1high", img5urlhigh)
                     b.putExtra("fifn1high",img5nhigh)
                     b.putExtra("mresult", mresultsarr)
                     b.putExtra("cacnm1", cacnm1)
                     b.putExtra("listener",prokeylistener)
                     b.putExtra("fieldlistener",fieldlistener)
                     b.putExtra("f1edithigh", f1edithigh)
                     b.putExtra("fn1edithigh", fn1edithigh)
                     b.putExtra("s1edithigh", s1edithigh)
                     b.putExtra("sn1edithigh", sn1edithigh)
                     b.putExtra("t1edithigh", t1edithigh)
                     b.putExtra("tn1edithigh", tn1edithigh)
                     b.putExtra("fo1edithigh", fo1edithigh)
                     b.putExtra("fon1edithigh", fon1edithigh)
                     b.putExtra("fif1edithigh", fif1edithigh)
                     b.putExtra("fifn1edithigh", fifn1edithigh)
                     b.putExtra("f1high", img1urlhigh)
                     b.putExtra("fn1high", img1nhigh)
                     b.putExtra("s1high", img2urlhigh)
                     b.putExtra("sn1high", img2nhigh)
                     b.putExtra("t1high", img3urlhigh)
                     b.putExtra("tn1high",img3nhigh)
                     b.putExtra("fo1high", img4urlhigh)
                     b.putExtra("fon1high", img4nhigh)
                     b.putExtra("fif1high", img5urlhigh)
                     b.putExtra("fifn1high",img5nhigh)

                     b.putExtra("addsupp", addsupp)
                     b.putExtra("editsupp", editesupp)
                     b.putExtra("deletesupp", deletesupp)

                     startActivityForResult(b, 0)
                     gallery.isEnabled = true
                 }




                 prokeylistener=pro_savekey.text.toString()
                 startlistprokey=pro_savekey.text.toString()
                 println("PRO SAVE KEYYYY" + pro_savekey.text)
                 try {
                     supp_gps.setText(getone.getString(16))
                     gpsvalidate=getone.getString(16)
                 } catch (e: Exception) {
                     Toast.makeText(applicationContext, "Empty Co-ordinates", Toast.LENGTH_SHORT).show()
                 }

                 /* val newurl = URL(supp_imgurl.text as String?).openStream()
                                val mIcon_val = BitmapFactory.decodeStream(newurl)
                                card.setImageBitmap(mIcon_val)*/



                 supp_mobile1.visibility = View.VISIBLE





                 //Disabling all fields

                 supp_nm.isEnabled = false
                 supp_id.isEnabled = false
                 supp_mobile.isEnabled = false

                 supp_mobile1.isEnabled = false
                 supp_mobile2.isEnabled = false
                 supp_mobile3.isEnabled = false
                 supp_mob.isEnabled=false
                 supp_mob1.isEnabled=false
                 supp_mob2.isEnabled=false
                 supp_mob3.isEnabled=false
                 supp_address.isEnabled = false
                 supp_address2.isEnabled = false
                 supp_address3.isEnabled = false
                 supp_city.isEnabled = false
                 supp_state.isEnabled = false
                 supp_pin.isEnabled = false
                    imageButton2.isEnabled=false
                 imageView11.isEnabled=false
                 supp_email.isEnabled = false
                 supp_conpers.isEnabled = false
                 supp_gstcode.isEnabled = false
                 supp_gps.isEnabled = false


                 Handler().postDelayed(Runnable { loadim() }, 1000)

             }
         } else {
             supp_save.setText("SAVE")
         }



         //Navigate to add multi images activity - (AddImagesActivity_supp)


         gallery.setOnClickListener {

             pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
             pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
             pDialogs!!.setTitleText("Loading...");
             pDialogs!!.setCancelable(false);
             pDialogs!!.show();
          scroll2_slider.removeAllSliders()
             gallery.isEnabled = false

             val b = Intent(applicationContext, AddImagesActivity_supp::class.java)
             b.putExtra("id", id.text.toString())
             b.putExtra("f1", f1)
             b.putExtra("fn1", fn1)
             b.putExtra("s1", s1)
             b.putExtra("sn1", sn1)
             b.putExtra("t1", t1)
             b.putExtra("tn1", tn1)
             b.putExtra("fo1", fo1)
             b.putExtra("fon1", fon1)
             b.putExtra("fif1", fif1)
             b.putExtra("fifn1", fifn1)


             b.putExtra("f1edit", f1edit)
             b.putExtra("fn1edit", fn1edit)
             b.putExtra("s1edit", s1edit)
             b.putExtra("sn1edit", sn1edit)
             b.putExtra("t1edit", t1edit)
             b.putExtra("tn1edit", tn1edit)
             b.putExtra("fo1edit", fo1edit)
             b.putExtra("fon1edit", fon1edit)
             b.putExtra("fif1edit", fif1edit)
             b.putExtra("fifn1edit", fifn1edit)



             b.putExtra("f1high", img1urlhigh)
             b.putExtra("fn1high", img1nhigh)
             b.putExtra("s1high", img2urlhigh)
             b.putExtra("sn1high", img2nhigh)
             b.putExtra("t1high", img3urlhigh)
             b.putExtra("tn1high",img3nhigh)
             b.putExtra("fo1high", img4urlhigh)
             b.putExtra("fon1high", img4nhigh)
             b.putExtra("fif1high", img5urlhigh)
             b.putExtra("fifn1high",img5nhigh)
             b.putExtra("mresult", mresultsarr)
             b.putExtra("cacnm1", cacnm1)
             b.putExtra("listener",prokeylistener)
             b.putExtra("fieldlistener",fieldlistener)
             b.putExtra("f1edithigh", f1edithigh)
             b.putExtra("fn1edithigh", fn1edithigh)
             b.putExtra("s1edithigh", s1edithigh)
             b.putExtra("sn1edithigh", sn1edithigh)
             b.putExtra("t1edithigh", t1edithigh)
             b.putExtra("tn1edithigh", tn1edithigh)
             b.putExtra("fo1edithigh", fo1edithigh)
             b.putExtra("fon1edithigh", fon1edithigh)
             b.putExtra("fif1edithigh", fif1edithigh)
             b.putExtra("fifn1edithigh", fifn1edithigh)
             b.putExtra("f1high", img1urlhigh)
             b.putExtra("fn1high", img1nhigh)
             b.putExtra("s1high", img2urlhigh)
             b.putExtra("sn1high", img2nhigh)
             b.putExtra("t1high", img3urlhigh)
             b.putExtra("tn1high",img3nhigh)
             b.putExtra("fo1high", img4urlhigh)
             b.putExtra("fon1high", img4nhigh)
             b.putExtra("fif1high", img5urlhigh)
             b.putExtra("fifn1high",img5nhigh)

             b.putExtra("addsupp", addsupp)
             b.putExtra("editsupp", editesupp)
             b.putExtra("deletesupp", deletesupp)



             startActivityForResult(b, 0)
             pDialogs!!.dismiss()
             gallery.isEnabled = true
         }

         //Edit click and enables all fields

         supp_edit.setOnClickListener {
             if (editesupp == "true" || editesupp.isNullOrEmpty()) {
                 supp_edit.visibility = View.INVISIBLE
                 supp_save.visibility = View.VISIBLE
                 sup_clear.visibility = View.INVISIBLE
                 sup_back.visibility = View.VISIBLE
                 gallery.visibility=View.VISIBLE

                 editcli="clicked"

                 if(supp_id.text.toString().equals("Auto-generated")){
                     imageButtonvert.visibility=View.GONE
                 }
                 else if(supp_id.text.toString()!="Auto-generated"){
                     imageButtonvert.visibility=View.VISIBLE

                 }
                 supp_save.setText("SAVE")
                 supp_nm.isEnabled = true
                 supp_id.isEnabled = false
                 supp_mobile.isEnabled = true
                 supp_mobile1.isEnabled = true
                 supp_mobile2.isEnabled = true
                 supp_mob.isEnabled=true
                 supp_mob1.isEnabled=true
                 supp_mob2.isEnabled=true
                 supp_mob3.isEnabled=true
                 imageButton2.isEnabled=true
                 imageView11.isEnabled=true

                 supp_mobile3.isEnabled = true
                 supp_address.isEnabled = true
                 supp_address2.isEnabled = true
                 supp_address3.isEnabled = true
                 supp_city.isEnabled = true
                 supp_state.isEnabled = true
                 supp_pin.isEnabled = true

                 supp_email.isEnabled = true
                 supp_conpers.isEnabled = true
                 supp_gstcode.isEnabled = true


             } else if (editesupp == "false") {
                 popup("edit")
             }

         }
     }
       /* if (f1.isNullOrEmpty() == false || s1.isNullOrEmpty() == false || t1.isNullOrEmpty() == false || fo1.isNullOrEmpty() == false || fif1.isNullOrEmpty() == false) {


            scrollpro.visibility = View.VISIBLE


            scroll2_slider2.visibility = View.VISIBLE
            imageView11.visibility = View.GONE
            imageButton2.visibility = View.GONE
            gallery.visibility = View.VISIBLE
            if (f1.isNullOrEmpty() == false) {
                f1 = f1.toString()
                file_maps.add(f1)
            }
            if (s1.isNullOrEmpty() == false) {
                s1 = s1.toString()
                file_maps.add(s1)
            }
            if (t1.isNullOrEmpty() == false) {
                t1 = t1.toString()
                file_maps.add(t1)
            }
            if (fo1.isNullOrEmpty() == false) {
                fo1 = fo1.toString()
                file_maps.add(fo1)
            }
            if (fif1.isNullOrEmpty() == false) {
                fif1 = fif1.toString()
                file_maps.add(fif1)
            }
            if (fn1.isNullOrEmpty() == false) {
                fn1 = fn1.toString()
            }
            if (sn1.isNullOrEmpty() == false) {
                sn1 = sn1.toString()
            }
            if (tn1.isNullOrEmpty() == false) {
                tn1 = tn1.toString()
            }
            if (fon1.isNullOrEmpty() == false) {
                fon1 = fon1.toString()
            }
            if (fifn1.isNullOrEmpty() == false) {
                fifn1 = fifn1.toString()
            }
        } else {
            scroll2_slider2.visibility = View.GONE

            scroll2_slider.visibility = View.VISIBLE


            imageView11.visibility = View.VISIBLE
            imageButton2.visibility = View.VISIBLE
            gallery.visibility = View.GONE
        }*/



       /* supp_nm.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if(supp_nm.text.toString().equals("")){
                    fieldlistener=""
                }
            }
        })
        supp_address.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

                 fieldlistener="change"

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if(supp_address.text.toString().equals("")){
                    fieldlistener=""
                }
            }
        })
        supp_mobile.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (supp_mobile.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_mobile1.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (supp_mobile1.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_mobile2.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if (supp_mobile2.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_address2.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                 if (supp_address2.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_address3.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

             fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if (supp_address3.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_city.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if (supp_city.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_state.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if (supp_state.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_pin.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if (supp_pin.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_conpers.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (supp_conpers.text.toString().equals("")) {
                    fieldlistener = ""
                }

            }
        })
        supp_gps.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if (supp_gps.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_email.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if (supp_email.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })
        supp_gstcode.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                 fieldlistener="change"
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                 if (supp_gstcode.text.toString().equals("")) {
                    fieldlistener = ""
                }
            }
        })*/









        //------------------ BOTTOM NAVIGATION TO SUPPLIER's PRODUCT LIST ACTIVITY (SupplierSecondmain)--------------------//

        radioGroup1!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            val suppadd: Intent
            Log.i("matching", "matching inside1 bro" + checkedId)
            when (checkedId) {
                R.id.matching -> {

                }
                R.id.watchList -> {

scroll2_slider.removeAllSliders()

                        Log.i("matching", "matching inside1 watchlistAdapter" + checkedId)
                        suppadd = Intent(baseContext, SupplierSecondmain::class.java)
                        suppadd.putExtra("sndproky", "fromsupplier")
                        suppadd.putExtra("supp_name", supp_nm.text.toString())
                        suppadd.putExtra("supp_id", supp_id.text.toString())
                        suppadd.putExtra("supp_cont", supp_conpers.text.toString())
                        suppadd.putExtra("mob", supp_mob.selectedItem.toString())
                        suppadd.putExtra("mob1", supp_mob1.selectedItem.toString())
                        suppadd.putExtra("mob2", supp_mob2.selectedItem.toString())
                        suppadd.putExtra("mobile", supp_mobile.text.toString())
                        suppadd.putExtra("mobile1", supp_mobile1.text.toString())
                        suppadd.putExtra("mobile2", supp_mobile2.text.toString())
                        suppadd.putExtra("supp_address", supp_address.text.toString())
                        suppadd.putExtra("supp_address1", supp_address2.text.toString())
                        suppadd.putExtra("supp_address2", supp_address3.text.toString())
                        suppadd.putExtra("supp_city", supp_city.text.toString())
                        suppadd.putExtra("supp_state", supp_state.text.toString())
                        suppadd.putExtra("supp_pin", supp_pin.text.toString())
                        suppadd.putExtra("supp_gps", supp_gps.text.toString())
                        suppadd.putExtra("supp_mail", supp_email.text.toString())
                        suppadd.putExtra("supp_gstcd", supp_gstcode.text.toString())
                        suppadd.putExtra("supp_imurl", supp_imgurl.text.toString())
                        suppadd.putExtra("supp_status", statussup.text.toString())
                        suppadd.putExtra("s_id", id.text.toString())
                        suppadd.putExtra("supp_key", supp_savekey.text.toString())
                        suppadd.putExtra("supprod_key", pro_savekey.text.toString())
                        suppadd.putExtra("listener",prokeylistener)
                        suppadd.putExtra("fieldlistener",fieldlistener)
                    suppadd.putExtra("startlistprky",startlistprokey)
                    suppadd.putExtra("profrmprky",productprokey)


                    suppadd.putExtra("f",f1)

                    println("IMGS"+f1)
                        suppadd.putExtra("s",s1)
                        suppadd.putExtra("t",t1)
                        suppadd.putExtra("fo",fo1)
                        suppadd.putExtra("fif",fif1)
                        //image name's
                        suppadd.putExtra("fn",fn1)
                        suppadd.putExtra("sn",sn1)
                        suppadd.putExtra("tn",tn1)
                        suppadd.putExtra("fon",fon1)
                        suppadd.putExtra("fifn",fifn1)

                     suppadd.putExtra("img1urlhigh",img1urlhigh)
                     suppadd.putExtra("img2urlhigh",img2urlhigh)
                     suppadd.putExtra("img3urlhigh",img3urlhigh)
                     suppadd.putExtra("img4urlhigh",img4urlhigh)
                     suppadd.putExtra("img5urlhigh",img5urlhigh)
                     suppadd.putExtra("img1nhigh",img1nhigh)
                     suppadd.putExtra("img2nhigh",img2nhigh)
                     suppadd.putExtra("img3nhigh",img3nhigh)
                     suppadd.putExtra("img4nhigh",img4nhigh)
                     suppadd.putExtra("img5nhigh",img5nhigh)


                    suppadd.putExtra("f1edit",f1edit)
                    suppadd.putExtra("s1edit",s1edit)
                    suppadd.putExtra("t1edit",t1edit)
                    suppadd.putExtra("fo1edit",fo1edit)
                    suppadd.putExtra("fif1edit",fif1edit)
                    suppadd.putExtra("fn1edit",fn1edit)
                    suppadd.putExtra("sn1edit",sn1edit)
                    suppadd.putExtra("tn1edit",tn1edit)
                    suppadd.putExtra("fon1edit",fon1edit)
                    suppadd.putExtra("fifn1edit",fifn1edit)
                    suppadd.putExtra("f1edithigh",f1edithigh)
                    suppadd.putExtra("s1edithigh",s1edithigh)
                    suppadd.putExtra("t1edithigh",t1edithigh)
                    suppadd.putExtra("fo1edithigh",fo1edithigh)
                    suppadd.putExtra("fif1edithigh",fif1edithigh)
                    suppadd.putExtra("fn1edithigh",fn1edithigh)
                    suppadd.putExtra("sn1edithigh",sn1edithigh)
                    suppadd.putExtra("tn1edithigh",tn1edithigh)
                    suppadd.putExtra("fon1edithigh",fon1edithigh)
                    suppadd.putExtra("fifn1edithigh",fifn1edithigh)

                    suppadd.putExtra("file_maps",file_maps)
                    suppadd.putExtra("mresultsarr",mresultsarr)
                    suppadd.putExtra("editcli", editcli)
                    suppadd.putExtra("addsupp", addsupp)
                        suppadd.putExtra("editesupp", editesupp)
                        suppadd.putExtra("deletesupp", deletesupp)
                        suppadd.putExtra("viewsupp", viewsupp)
                        suppadd.putExtra("importsupp", importsupp)
                        suppadd.putExtra("exportsupp", exportsupp)
                        startActivity(suppadd)
                        overridePendingTransition(0, 0)
                        finish()
                    }
                    /*else if (viewsupp=="false"){
                        popup("View")
                    }*/

                else -> {
                }
            }
        })



       /* sup_back.setOnClickListener {
            try{
                if (supp_id.text.toString().equals("Auto - generated")) {
                    val path = pro_savekey.text.toString()
                    var ii = path.split(",")

                    for (i in 0 until ii.size) {
                        var a = ii[i]
                        a = a.trim()
                        println("DELETING KEYYY BACK PRESSED" + pro_savekey.text)
                        println("SUPP_ID" + supp_id.text)
                        db.collection("supplier_products").document(a)
                                .delete()
                                .addOnSuccessListener {
                                    Toast.makeText(this, "Exited", Toast.LENGTH_LONG).show()
                                    finish()
                                }
                                .addOnFailureListener {


                                }

                    }
                }
                else {
                    finish()
                }
            }
            catch (e:Exception){
                finish()
            }

        }*/




        //---------------------SAVE ACTION---------------------------------//

        supp_save.setOnClickListener { view ->


            if (net_status() == true) {

                if (supp_imgurl.text == "") {
                    supp_imgurl.text = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                }

                if (supp_email.text.equals("")) {

                }
                val emailInput = supp_email.text.toString().trim();
                val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                if (emailInput.matches(emailPattern.toRegex())) {


                } else {

                    if (supp_email.text.toString().isNotEmpty() == true) {
                        supp_mailerr.visibility = View.VISIBLE
                        supp_mailerr.setText("Invalid email")
                    } else {

                    }

                }


                if (supp_nm.length() == 0) {
                    supperrnm.visibility = View.VISIBLE

                    supperrnm.setText("Required field*")
                    Toast.makeText(applicationContext,"Please fill required fields",Toast.LENGTH_SHORT).show()
                }
                if (supp_mobile.length() == 0) {
                    supp_phoneerr.visibility = View.VISIBLE

                    supp_phoneerr.setText("Required field*")
                    Toast.makeText(applicationContext,"Please fill required fields",Toast.LENGTH_SHORT).show()

                }

                if ((id.text == "") && (supperrnm.visibility == View.INVISIBLE) && (supp_phoneerr.visibility == View.INVISIBLE)) {

                    onStarClicked1()        //For new supplier insert

                }


                if(id.text.toString().isNotEmpty()) {


                    //-------------------Below code for Update existing supplier----------------------//

                     if((startlistprokey!=productprokey)&&(productprokey.isNotEmpty())){
                        fieldlistener="change"
                    }
                     if ((suppnamevalidate != supp_nm.text.toString()) || (suppmobilevalidate != supp_mobile.text.toString()) || (suppmobile21validate != supp_mobile1.text.toString())
                            || (suppmobile31validate != supp_mobile2.text.toString()) || (suppmobile41validate != supp_mobile3.text.toString()) || (suppmobcat1validate != supp_mob.selectedItem.toString()) ||
                            (suppmobcat2validate != supp_mob1.selectedItem.toString()) || (suppmobcat3validate != supp_mob2.selectedItem.toString()) || (suppaddress1validate != supp_address.text.toString()) ||
                            (suppaddress2validate != supp_address2.text.toString()) || (suppaddress3validate != supp_address3.text.toString()) || (suppcityvalidate != supp_city.text.toString()) ||
                            (suppstatevalidate != supp_state.text.toString()) || (supppinvalidate != supp_pin.text.toString()) || ((contactprsvalidate != supp_conpers.text.toString())) ||
                            (gpsvalidate != supp_gps.text.toString()) || (suppemailvalidate != supp_email.text.toString()) || (suppgstvalidate != supp_gstcode.text.toString())) {

                        fieldlistener = "change"
                        println("ONBACK URL1 NOT EQUAL" + f1)

                    } else if (((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || (fo1 != fo1edit) || (fif1 != fif1edit))) {
                        println("ONBACK URL1 EDIT NOT EQUAl" + f1)
                        fieldlistener = "change"
                    }

                    var idmy = supp_savekey.text.toString()
                    var suppname = (supp_nm.text).toString()
                    var suppid = (supp_id.text).toString()

                    var suppmobcat1 = supp_mob.selectedItem.toString()
                    var suppmobcat2 = supp_mob1.selectedItem.toString()
                    var suppmobcat3 = supp_mob2.selectedItem.toString()
                    var suppmobcat4 = supp_mob3.selectedItem.toString()
                    var suppaddress1 = (supp_address.text).toString()
                    var suppmobile = (supp_mobile.text).toString()
                    var suppmobile21 = (supp_mobile1.text).toString()
                    var suppmobile31 = (supp_mobile2.text).toString()
                    var suppmobile41 = (supp_mobile3.text).toString()
                    var suppaddress2 = (supp_address2.text).toString()
                    var suppaddress3 = (supp_address3.text).toString()
                    var suppcity = (supp_city.text).toString()
                    var suppstate = (supp_state.text).toString()
                    var supppin = (supp_pin.text).toString()
                    var contactprs = (supp_conpers.text).toString()
                    var prodky = (pro_savekey.text).toString()
                    var gps = (supp_gps.text).toString()

                    var suppemail = (supp_email.text).toString()

                    var suppgst = (supp_gstcode.text).toString()
                    var suppimglink = (supp_imgurl.text).toString()
                    var status = (statussup.text).toString()
                    if (f1.isEmpty()) {

                    }
                    val img1n = fn1
                    val img2n = sn1
                    val img3n = tn1
                    val img4n = fon1
                    val img5n = fifn1
                    val img1url = f1
                    val img2url = s1
                    val img3url = t1
                    val img4url = fo1
                    val img5url = fif1

                    val data = c(spnm = suppname, spid = suppid, spaddress1 = suppaddress1, spaddress2 = suppaddress2, spcontact_person = contactprs,
                            spaddress3 = suppaddress3, spcity = suppcity, spstate = suppstate, sppincode = supppin, spemail = suppemail,
                            spgst = suppgst, spmob1 = suppmobile, spmob2 = suppmobile21, status = status, spmob3 = suppmobile31,
                            spmob4 = suppmobile41, spimglink = suppimglink, spmobcat1 = suppmobcat1, spmobcat2 = suppmobcat2,
                            spmobcat3 = suppmobcat3,spmobcat4 = suppmobcat4, prodkey = prodky, sppgpsco_or = gps,
                            img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n,
                            img1url = img1url, img2url = img2url, img3url = img3url, img4url = img4url, img5url = img5url, img1nhigh = img1nhigh,
                            img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh, img1urlhigh = img1urlhigh,
                            img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)

                    if ((id.text != "") && (supperrnm.visibility == View.INVISIBLE) && (supp_phoneerr.visibility == View.INVISIBLE)&&(fieldlistener=="change")) {

                        pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                        pDialogs!!.setTitleText("Saving...");
                        pDialogs!!.setCancelable(false);
                        pDialogs!!.show();

                        val db = FirebaseFirestore.getInstance()

                        val isInserted = myDb.updatedata(idmy, suppname, suppid, suppmobcat1, suppmobcat2, suppmobcat3,
                                suppmobile, suppmobile21, suppmobile31, suppmobile41, suppaddress1, suppaddress2, suppaddress3,
                                suppcity, suppstate, supppin, gps, suppemail, contactprs, suppgst, suppimglink, prodky, status,
                                img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,suppmobcat4)

                        if (isInserted == true) {
                        } else {
                        }


                        db.collection("suppliers").document(id.text.toString())

                                .set(data)
                                .addOnSuccessListener {
                                    Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()
                                    pDialogs!!.dismiss();
                                    if(suppsel.isEmpty()) {
                                        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                        i.putExtra("frm_main", "main")
                                        i.putExtra("addsupp", addsupp)
                                        i.putExtra("editsupp", editesupp)
                                        i.putExtra("deletesupp", deletesupp)
                                        i.putExtra("viewsupp", viewsupp)
                                        i.putExtra("importsupp", importsupp)
                                        i.putExtra("exportsupp", exportsupp)
                                        startActivity(i)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                        finish()
                                    }
                                    else if(suppsel.isNotEmpty()){
                                        finish()
                                    }


                                }

                                .addOnFailureListener {
                                    Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show()
                                    save_progress.visibility = android.view.View.GONE
                                }


                    }
                    else if((id.text.toString().isNotEmpty())&&(fieldlistener.isEmpty())){
                        Toast.makeText(applicationContext,"Nothing happened for save",Toast.LENGTH_SHORT).show()

                    }
                }

            }
            else{
                Toast.makeText(applicationContext,"Please turn on your connection",Toast.LENGTH_SHORT).show()
            }
        }





    }



    // loadim() func is used to load image links on slider view


    fun loadim() {
        scrollpro.visibility = View.GONE
        if (file_maps.isNotEmpty()) {


            for (r in 0 until file_maps.size) {
                try {
                    val textSliderView = TextSliderView(this)
                    // initialize a SliderLayout
                    Log.d("file_maps", "r  " + file_maps[r])
                    textSliderView
                            //.description(name)
                            .image(file_maps[r])
                            .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                            .setOnSliderClickListener {

                                //Navigate to add multi images activity - (AddImagesActivity_supp)

                                val b = Intent(applicationContext, AddImagesActivity_supp::class.java)
                                b.putExtra("id", id.text.toString())
                                b.putExtra("f1", f1)
                                b.putExtra("fn1", fn1)
                                b.putExtra("s1", s1)
                                b.putExtra("sn1", sn1)
                                b.putExtra("t1", t1)
                                b.putExtra("tn1", tn1)
                                b.putExtra("fo1", fo1)
                                b.putExtra("fon1", fon1)
                                b.putExtra("fif1", fif1)
                                b.putExtra("fifn1", fifn1)


                                b.putExtra("f1edit", f1edit)
                                b.putExtra("fn1edit", fn1edit)
                                b.putExtra("s1edit", s1edit)
                                b.putExtra("sn1edit", sn1edit)
                                b.putExtra("t1edit", t1edit)
                                b.putExtra("tn1edit", tn1edit)
                                b.putExtra("fo1edit", fo1edit)
                                b.putExtra("fon1edit", fon1edit)
                                b.putExtra("fif1edit", fif1edit)
                                b.putExtra("fifn1edit", fifn1edit)



                                b.putExtra("f1high", img1urlhigh)
                                b.putExtra("fn1high", img1nhigh)
                                b.putExtra("s1high", img2urlhigh)
                                b.putExtra("sn1high", img2nhigh)
                                b.putExtra("t1high", img3urlhigh)
                                b.putExtra("tn1high",img3nhigh)
                                b.putExtra("fo1high", img4urlhigh)
                                b.putExtra("fon1high", img4nhigh)
                                b.putExtra("fif1high", img5urlhigh)
                                b.putExtra("fifn1high",img5nhigh)
                                b.putExtra("mresult", mresultsarr)
                                b.putExtra("cacnm1", cacnm1)
                                b.putExtra("listener",prokeylistener)
                                b.putExtra("fieldlistener",fieldlistener)
                                b.putExtra("f1edithigh", f1edithigh)
                                b.putExtra("fn1edithigh", fn1edithigh)
                                b.putExtra("s1edithigh", s1edithigh)
                                b.putExtra("sn1edithigh", sn1edithigh)
                                b.putExtra("t1edithigh", t1edithigh)
                                b.putExtra("tn1edithigh", tn1edithigh)
                                b.putExtra("fo1edithigh", fo1edithigh)
                                b.putExtra("fon1edithigh", fon1edithigh)
                                b.putExtra("fif1edithigh", fif1edithigh)
                                b.putExtra("fifn1edithigh", fifn1edithigh)
                                b.putExtra("f1high", img1urlhigh)
                                b.putExtra("fn1high", img1nhigh)
                                b.putExtra("s1high", img2urlhigh)
                                b.putExtra("sn1high", img2nhigh)
                                b.putExtra("t1high", img3urlhigh)
                                b.putExtra("tn1high",img3nhigh)
                                b.putExtra("fo1high", img4urlhigh)
                                b.putExtra("fon1high", img4nhigh)
                                b.putExtra("fif1high", img5urlhigh)
                                b.putExtra("fifn1high",img5nhigh)

                                b.putExtra("addsupp", addsupp)
                                b.putExtra("editsupp", editesupp)
                                b.putExtra("deletesupp", deletesupp)

                                startActivityForResult(b, 0)
                                scroll2_slider.isEnabled = true
                            }
                    scroll2_slider2.addSlider(textSliderView)
                } catch (e: Exception) {

                }
            }
            scroll2_slider2.setPresetTransformer(SliderLayout.Transformer.Default)
            scroll2_slider2.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
            scroll2_slider2.setCustomAnimation(DescriptionAnimation())
            scroll2_slider2.setDuration(5000)

            //scroll2_preview_suppliers_image2
            try {
                val newurl = URL(file_maps[0]).openStream()
                val img = BitmapFactory.decodeStream(newurl)

            } catch (e: Exception) {

            }
        }
    }


    //Receive image links from multi images activity and load into slider.


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            0 // Do your stuff here...
            -> {
                if (resultCode == Activity.RESULT_OK) {


                    scroll2_slider.removeAllSliders()
                    scroll2_slider2.removeAllSliders()



                    scroll2_slider2.visibility = View.GONE

                    scroll2_slider.visibility = View.VISIBLE

                    val f = data!!.getStringExtra("f");
                    val fn = data!!.getStringExtra("fn");
                    val s = data!!.getStringExtra("s");
                    val sn = data!!.getStringExtra("sn");
                    val t = data!!.getStringExtra("t");
                    val tn = data!!.getStringExtra("tn");
                    val fo = data!!.getStringExtra("fo");
                    val fon = data!!.getStringExtra("fon");
                    val fif = data!!.getStringExtra("fif");
                    val fifn = data!!.getStringExtra("fifn");


                    val fedit = data!!.getStringExtra("fedit")
                    val fnedit = data!!.getStringExtra("fnedit")
                    val sedit = data!!.getStringExtra("sedit")
                    val snedit = data!!.getStringExtra("snedit")
                    val tedit = data!!.getStringExtra("tedit")
                    val tnedit = data!!.getStringExtra("tnedit")
                    val foedit = data!!.getStringExtra("foedit")
                    val fonedit = data!!.getStringExtra("fonedit")
                    val fifedit = data!!.getStringExtra("fifedit")
                    val fifnedit = data!!.getStringExtra("fifnedit");

                    try {
                        mresultsarr = data!!.getStringArrayListExtra("mResult")
                    } catch (e: Exception) {

                    }



                    try {
                        cacnm1 = data!!.getStringExtra("cacnm1")
                    } catch (e: Exception) {

                    }
                    try {
                        prokeylistener = data!!.getStringExtra("savelistner")
                    } catch (e: Exception) {

                    }

                    try {
                        fieldlistener = data!!.getStringExtra("fieldlistner")
                    } catch (e: Exception) {

                    }

                    val fhigh = data!!.getStringExtra("fhigh");
                    val fnhigh = data!!.getStringExtra("fnhigh");
                    val shigh = data!!.getStringExtra("shigh");
                    val snhigh = data!!.getStringExtra("snhigh");
                    val thigh = data!!.getStringExtra("thigh");
                    val tnhigh = data!!.getStringExtra("tnhigh");
                    val fohigh = data!!.getStringExtra("fohigh");
                    val fonhigh = data!!.getStringExtra("fonhigh");
                    val fifhigh = data!!.getStringExtra("fifhigh");
                    val fifnhigh = data!!.getStringExtra("fifnhigh");


                    println("fhigh" + fhigh)
                    println("shigh" + shigh)
                    println("thigh" + thigh)
                    println("fohigh" + fohigh)
                    println("fifhigh" + fifhigh)


                    println("fnhigh" + fnhigh)
                    println("snhigh" + snhigh)
                    println("tnhigh" + tnhigh)
                    println("fonhigh" + fonhigh)
                    println("fifnhigh" + fifnhigh)
                    if (fhigh.isNotEmpty()) {


                        img1urlhigh = fhigh
                        img1nhigh = fnhigh
                    } else {
                        img1urlhigh = ""
                        img1nhigh = ""
                    }
                    if (shigh.isNotEmpty()) {


                        img2urlhigh = shigh
                        img2nhigh = snhigh
                    } else {
                        img2urlhigh = ""
                        img2nhigh = ""
                    }
                    if (thigh.isNotEmpty()) {


                        img3urlhigh = thigh
                        img3nhigh = tnhigh
                    } else {
                        img3urlhigh = ""
                        img3nhigh = ""
                    }
                    if (fohigh.isNotEmpty()) {


                        img4urlhigh = fohigh
                        img4nhigh = fonhigh
                    } else {
                        img4urlhigh = ""
                        img4nhigh = ""
                    }
                    if (fifhigh.isNotEmpty()) {


                        img5urlhigh = fifhigh
                        img5nhigh = fifnhigh
                    } else {

                        img5urlhigh = ""
                        img5nhigh = ""
                    }


                    val fedithigh = data!!.getStringExtra("fedithigh")
                    val fnedithigh = data!!.getStringExtra("fnedithigh")
                    val sedithigh = data!!.getStringExtra("sedithigh")
                    val snedithigh = data!!.getStringExtra("snedithigh")
                    val tedithigh = data!!.getStringExtra("tedithigh")
                    val tnedithigh = data!!.getStringExtra("tnedithigh")
                    val foedithigh = data!!.getStringExtra("foedithigh")
                    val fonedithigh = data!!.getStringExtra("fonedithigh")
                    val fifedithigh = data!!.getStringExtra("fifedithigh")
                    val fifnedithigh = data!!.getStringExtra("fifnedithigh");

                    if (fedithigh.isNotEmpty()) {


                        f1edithigh = fedithigh
                        fn1edithigh = fnedithigh


                    } else {


                        f1edithigh = ""
                        fn1edithigh = ""
                    }
                    if (sedithigh.isNotEmpty()) {


                        s1edithigh = sedithigh
                        sn1edithigh = snedithigh

                    } else {


                        s1edithigh = ""
                        sn1edithigh = ""
                    }
                    if (tedithigh.isNotEmpty()) {

                        t1edithigh = tedithigh
                        tn1edithigh = tnedithigh

                    } else {

                        t1edithigh = ""
                        tn1edithigh = ""
                    }
                    if (foedithigh.isNotEmpty()) {
                        fo1edithigh = foedithigh
                        fon1edithigh = fonedithigh

                    } else {

                        fo1edithigh = ""
                        fon1edithigh = ""
                    }
                    if (fifedithigh.isNotEmpty()) {

                        fif1edithigh = fifedithigh
                        fifn1edithigh = fifnedithigh

                    } else {

                        fif1edithigh = ""
                        fifn1edithigh = ""
                    }





                    if (fedit.isNotEmpty()) {


                        f1edit = fedit
                        fn1edit = fnedit


                    } else {


                        f1edit = ""
                        fn1edit = ""
                    }
                    if (sedit.isNotEmpty()) {


                        s1edit = sedit
                        sn1edit = snedit

                    } else {


                        s1edit = ""
                        sn1edit = ""
                    }
                    if (tedit.isNotEmpty()) {

                        t1edit = tedit
                        tn1edit = tnedit

                    } else {

                        t1edit = ""
                        tn1edit = ""
                    }
                    if (foedit.isNotEmpty()) {
                        fo1edit = foedit
                        fon1edit = fonedit

                    } else {

                        fo1edit = ""
                        fon1edit = ""
                    }
                    if (fifedit.isNotEmpty()) {

                        fif1edit = fifedit
                        fifn1edit = fifnedit

                    } else {

                        fif1edit = ""
                        fifn1edit = ""
                    }

                    Handler().postDelayed(Runnable {
                        val bitmapArray = ArrayList<String>()


                        bitmapArray.clear()
                        if (f.isNotEmpty() || s.isNotEmpty() || t.isNotEmpty() || fo.isNotEmpty() || fif.isNotEmpty()) {
                            imageView11.visibility = View.GONE
                            imageButton2.visibility = View.GONE
                            gallery.visibility = View.VISIBLE
                        } else {
                            imageView11.visibility = View.VISIBLE
                            imageButton2.visibility = View.VISIBLE
                            gallery.visibility = View.GONE
                        }

                        if (f.isNotEmpty()) {
                            d.add(f)


                            f1 = f
                            fn1 = fn

                            if(img1nhigh.isNotEmpty()){
                                try {

                                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                                    val dir = File(path);
                                    if (!dir.exists())
                                        dir.mkdirs()

                                    val k = img1nhigh
                                    val recacnm = k.removeSuffix(".jpg")
                                    cacnm1 = recacnm
                                    var y = recacnm + ".png"

                                    val file = File(dir, y)
                                    println("CONTENT URI" + file)
                                    if (file.exists()) {
                                        val contentUri = Uri.fromFile(File("$path/$y"))
                                        bitmapArray.add(contentUri.toString())
                                    } else {
                                        bitmapArray.add(f1)
                                    }
                                }
                                catch (e:Exception){
                                    bitmapArray.add(f1)
                                }
                            }
                            else{
                                bitmapArray.add(f)
                            }


                        } else {
                            f1 = ""
                            fn1 = ""
                        }
                        if (s.isNotEmpty()) {
                            d.add(s)

                            s1 = s
                            sn1 = sn

                            if(img2nhigh.isNotEmpty()){
                                try {

                                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                                    val dir = File(path);
                                    if (!dir.exists())
                                        dir.mkdirs()

                                    val k = img2nhigh
                                    val recacnm = k.removeSuffix(".jpg")
                                    cacnm1 = recacnm
                                    var y = recacnm + ".png"

                                    val file = File(dir, y)
                                    println("CONTENT URI" + file)
                                    if (file.exists()) {
                                        val contentUri = Uri.fromFile(File("$path/$y"))
                                        bitmapArray.add(contentUri.toString())
                                    } else {
                                        bitmapArray.add(s1)
                                    }
                                }
                                catch (e:Exception){
                                    bitmapArray.add(s1)
                                }
                            }
                            else{
                                bitmapArray.add(s)
                            }

                        } else {
                            s1 = ""
                            sn1 = ""
                        }
                        if (t.isNotEmpty()) {
                            d.add(t)

                            t1 = t
                            tn1 = tn

                            if(img3nhigh.isNotEmpty()){
                                try {

                                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                                    val dir = File(path);
                                    if (!dir.exists())
                                        dir.mkdirs()

                                    val k = img3nhigh
                                    val recacnm = k.removeSuffix(".jpg")
                                    cacnm1 = recacnm
                                    var y = recacnm + ".png"

                                    val file = File(dir, y)
                                    println("CONTENT URI" + file)
                                    if (file.exists()) {
                                        val contentUri = Uri.fromFile(File("$path/$y"))
                                        bitmapArray.add(contentUri.toString())
                                    } else {
                                        bitmapArray.add(t1)
                                    }
                                }
                                catch (e:Exception){
                                    bitmapArray.add(t1)
                                }
                            }
                            else{
                                bitmapArray.add(t)
                            }


                        } else {
                            t1 = ""
                            tn1 = ""
                        }
                        if (fo.isNotEmpty()) {
                            d.add(fo)

                            fo1 = fo
                            fon1 = fon


                            if(img4nhigh.isNotEmpty()){
                                try {

                                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                                    val dir = File(path);
                                    if (!dir.exists())
                                        dir.mkdirs()

                                    val k = img4nhigh
                                    val recacnm = k.removeSuffix(".jpg")
                                    cacnm1 = recacnm
                                    var y = recacnm + ".png"

                                    val file = File(dir, y)
                                    println("CONTENT URI" + file)
                                    if (file.exists()) {
                                        val contentUri = Uri.fromFile(File("$path/$y"))
                                        bitmapArray.add(contentUri.toString())
                                    } else {
                                        bitmapArray.add(fo1)
                                    }
                                }
                                catch (e:Exception){
                                    bitmapArray.add(fo1)
                                }
                            }
                            else{
                                bitmapArray.add(fo)
                            }



                        } else {
                            fo1 = ""
                            fon1 = ""
                        }
                        if (fif.isNotEmpty()) {
                            d.add(fif)


                            fif1 = fif
                            fifn1 = fifn

                            if(img5nhigh.isNotEmpty()){
                                try {

                                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                                    val dir = File(path);
                                    if (!dir.exists())
                                        dir.mkdirs()

                                    val k = img5nhigh
                                    val recacnm = k.removeSuffix(".jpg")
                                    cacnm1 = recacnm
                                    var y = recacnm + ".png"

                                    val file = File(dir, y)
                                    println("CONTENT URI" + file)
                                    if (file.exists()) {
                                        val contentUri = Uri.fromFile(File("$path/$y"))
                                        bitmapArray.add(contentUri.toString())
                                    } else {
                                        bitmapArray.add(fif1)
                                    }
                                }
                                catch (e:Exception){
                                    bitmapArray.add(fif1)
                                }
                            }
                            else{
                                bitmapArray.add(fif)
                            }


                        } else {
                            fif1 = ""
                            fifn1 = ""
                        }
                        Log.d("tag", "  " + bitmapArray)
                        if (bitmapArray.isNotEmpty()) {
                            for (r in 0 until bitmapArray.size) {
                                val textSliderView = TextSliderView(this)
                                // initialize a SliderLayout
                                Log.d("khd", "r  " + bitmapArray[r])
                                textSliderView
                                        //.description(name)
                                        .image(bitmapArray[r])

                                        .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                                        .setOnSliderClickListener {

                                            val b = Intent(applicationContext, AddImagesActivity_supp::class.java)
                                            b.putExtra("id", id.text.toString())
                                            b.putExtra("f1", f1)
                                            b.putExtra("fn1", fn1)
                                            b.putExtra("s1", s1)
                                            b.putExtra("sn1", sn1)
                                            b.putExtra("t1", t1)
                                            b.putExtra("tn1", tn1)
                                            b.putExtra("fo1", fo1)
                                            b.putExtra("fon1", fon1)
                                            b.putExtra("fif1", fif1)
                                            b.putExtra("fifn1", fifn1)
                                            b.putExtra("f1high", img1urlhigh)
                                            b.putExtra("fn1high", img1nhigh)
                                            b.putExtra("s1high", img2urlhigh)
                                            b.putExtra("sn1high", img2nhigh)
                                            b.putExtra("t1high", img3urlhigh)
                                            b.putExtra("tn1high", img3nhigh)
                                            b.putExtra("fo1high", img4urlhigh)
                                            b.putExtra("fon1high", img4nhigh)
                                            b.putExtra("fif1high", img5urlhigh)
                                            b.putExtra("fifn1high", img5nhigh)
                                            b.putExtra("mresult", mresultsarr)
                                            b.putExtra("listener", prokeylistener)
                                            b.putExtra("fieldlistener", fieldlistener)
                                            b.putExtra("f1edithigh", f1edithigh)
                                            b.putExtra("fn1edithigh", fn1edithigh)
                                            b.putExtra("s1edithigh", s1edithigh)
                                            b.putExtra("sn1edithigh", sn1edithigh)
                                            b.putExtra("t1edithigh", t1edithigh)
                                            b.putExtra("tn1edithigh", tn1edithigh)
                                            b.putExtra("fo1edithigh", fo1edithigh)
                                            b.putExtra("fon1edithigh", fon1edithigh)
                                            b.putExtra("fif1edithigh", fif1edithigh)
                                            b.putExtra("fifn1edithigh", fifn1edithigh)

                                            b.putExtra("cacnm1", cacnm1)
                                            b.putExtra("f1edit", f1edit)
                                            b.putExtra("fn1edit", fn1edit)
                                            b.putExtra("s1edit", s1edit)
                                            b.putExtra("sn1edit", sn1edit)
                                            b.putExtra("t1edit", t1edit)
                                            b.putExtra("tn1edit", tn1edit)
                                            b.putExtra("fo1edit", fo1edit)
                                            b.putExtra("fon1edit", fon1edit)
                                            b.putExtra("fif1edit", fif1edit)
                                            b.putExtra("fifn1edit", fifn1edit)
                                            startActivityForResult(b, 0)
                                            scroll2_slider.isEnabled = true
                                        }

                                //add your extra information
                                /*textSliderView.bundle(Bundle())
                    textSliderView.bundle.clear()*/
                                //.putString("extra", bitmapArray[r])
                                scrollpro.visibility=View.GONE
                                scroll2_slider.addSlider(textSliderView)
                            }
                            scroll2_slider.setPresetTransformer(SliderLayout.Transformer.Default)
                            scroll2_slider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                            scroll2_slider.setCustomAnimation(DescriptionAnimation())
                            scroll2_slider.setDuration(5000)

                            //scroll2_preview_suppliers_image
                            val newurl = URL(bitmapArray[0]).openStream()
                            val img = BitmapFactory.decodeStream(newurl)

                        }
                    },500)


                    //bitmapArray.addAll(data.get("bitmapArray"))
                    //println(bitmapArray)
                    Log.d(" ", "result " + f)
                    Log.d(" ", "result " + s)
                    Log.d(" ", "result " + t)
                    Log.d(" ", "result " + fo)
                    Log.d(" ", "result " + fif)
                    /* this.runOnUiThread(Runnable() {
                         file_maps.clear()
                         d.addAll(d)
                         Log.d("map","  "+d)
                     })*/
                }
            }
            1 // GPS Co-ords result
            -> {
                if (requestCode == 1) {
                    if(resultCode == Activity.RESULT_OK){
                        val f=data!!.getStringExtra("f")
                        /*val f11=data!!.getStringExtra("im1");
                        val f2=data!!.getStringExtra("im2");
                        val f3=data!!.getStringExtra("im3");
                        val f4=data!!.getStringExtra("im4");
                        val f5=data!!.getStringExtra("im5");
                        val f6=data!!.getStringExtra("url6");
                        val f7=data!!.getStringExtra("url7");
                        val f8=data!!.getStringExtra("url8");
                        val f9=data!!.getStringExtra("url9");
                        val f10=data!!.getStringExtra("url10");*/





                        println(f)

                        this.runOnUiThread(Runnable() {
                            supp_gps.setText(f)
                            Log.d("map","  "+f)

                        })
                    }
                    if (resultCode == Activity.RESULT_CANCELED) {
                        return;
                    }

                }
            }



        }
    }

    override fun onBackPressed() {


        //Back action

        println("STRING PRONAMES"+prokeylistener)
        println("proSave"+pro_savekey.text.toString())





        if(startlistprokey.equals(productprokey)){

        }
        else if((startlistprokey!=productprokey)&&(productprokey.isNotEmpty())){
            fieldlistener="change"
        }
        println("LISTENER SAVE"+fieldlistener)

        println("VALUE OF IMG2NAME"+sn1)
        println("VALUE OF IMG2NAME EDIT"+sn1edit)

        println("VALUE OF IMG1NAME"+fn1)
        println("VALUE OF IMG1NAME EDIT"+fn1edit)

        println("VALUE OF IMG3NAME"+tn1)
        println("VALUE OF IMG3NAME EDIT"+tn1edit)

        println("VALUE OF IMG4NAME"+fon1)
        println("VALUE OF IMG4NAME EDIT"+fon1edit)

        println("VALUE OF IMG5NAME"+fifn1)
        println("VALUE OF IMG5NAME EDIT"+fifn1edit)




        println("suppnamevalidate  "+suppnamevalidate)
        println("suppmobilevalidate  "+suppmobilevalidate)
        println("suppmobile21validate  "+suppmobile21validate)
        println("suppmobile31validate  "+suppmobile31validate)
        println("suppmobile41validate  "+suppmobile41validate)
        println("suppmobcat1validate  "+suppmobcat1validate)
        println("suppmobcat2validate  "+suppmobcat2validate)
        println("suppmobcat3validate  "+suppmobcat3validate)
        println("suppaddress1validate  "+suppaddress1validate)
        println("suppaddress2validate  "+suppaddress2validate)
        println("suppaddress3validate  "+suppaddress3validate)
        println("suppcityvalidate  "+suppcityvalidate)
        println("suppstatevalidate  "+suppstatevalidate)
        println("supppinvalidate  "+supppinvalidate)
        println("contactprsvalidate  "+contactprsvalidate)
        println("gpsvalidate  "+gpsvalidate)
        println("suppemailvalidate  "+suppemailvalidate)
        println("suppgstvalidate  "+suppgstvalidate)






        println("VALUE OF BONUS STRING"+suppnamevalidate)
        println("VALUE OF BONUS EDITTEXT"+supp_nm.text.toString())

        if((suppnamevalidate!=supp_nm.text.toString())||(suppmobilevalidate!=supp_mobile.text.toString())||(suppmobile21validate!=supp_mobile1.text.toString())
                ||(suppmobile31validate!=supp_mobile2.text.toString())||(suppmobile41validate!=supp_mobile3.text.toString())||(suppmobcat1validate!=supp_mob.selectedItem.toString())||
                (suppmobcat2validate!=supp_mob1.selectedItem.toString())||(suppmobcat3validate!=supp_mob2.selectedItem.toString())||(suppaddress1validate!=supp_address.text.toString())||
                (suppaddress2validate!=supp_address2.text.toString())||(suppaddress3validate!=supp_address3.text.toString())||(suppcityvalidate!=supp_city.text.toString())||
                 (suppstatevalidate!=supp_state.text.toString())||(supppinvalidate!=supp_pin.text.toString())||((contactprsvalidate!=supp_conpers.text.toString()))||
                (gpsvalidate!=supp_gps.text.toString())||(suppemailvalidate!=supp_email.text.toString())||(suppgstvalidate!=supp_gstcode.text.toString())){

            fieldlistener = "change"
            println("ONBACK URL1 NOT EQUAL"+f1)

        }

        else if(((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || ( fo1!= fo1edit) || ( fif1!= fif1edit))){
            println("ONBACK URL1 EDIT NOT EQUAl"+f1)
            fieldlistener = "change"
        }


        // TODO Auto-generated method stub



        //Save popup
    try {
        if ((supp_id.text.toString() == "Auto - generated") && (fieldlistener == "change") || (supp_id.text.toString() == "Auto - generated") && (prokeylistener == "what") && (fieldlistener == "change")) {

            val builder = AlertDialog.Builder(this@SupplierAddMain)
            with(builder) {
                setTitle("Save?")
                setMessage("Do you want to save?")
                setPositiveButton("Yes") { dialog, whichButton ->

                    if (net_status() == true) {

                        if (supp_imgurl.text == "") {
                            supp_imgurl.text = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                        }

                        if (supp_email.text.equals("")) {

                        }
                        val emailInput = supp_email.text.toString().trim();
                        val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                        if (emailInput.matches(emailPattern.toRegex())) {


                        } else {

                            supp_mailerr.visibility = View.VISIBLE
                            supp_mailerr.setText("Invalid email")

                        }


                        if (supp_nm.length() == 0) {
                            supperrnm.visibility = View.VISIBLE

                            supperrnm.setText("Required field*")
                        }
                        if (supp_mobile.length() == 0) {
                            supp_phoneerr.visibility = View.VISIBLE

                            supp_phoneerr.setText("Required field*")
                        }

                        if ((id.text == "") && (supperrnm.visibility == View.INVISIBLE) && (supp_phoneerr.visibility == View.INVISIBLE)) {

                            // onStarClicked1() - New supplier insert func
                            onStarClicked1()


                        }
                    } else {
                        dialog.dismiss()
                    }

                }
                setNegativeButton("No") { dialog, whichButton ->


                    dialog.dismiss()

                    val progressDialog = ProgressDialog(this@SupplierAddMain);
                    progressDialog.setTitle("Please wait...");
                    progressDialog.setMessage("wait for a while...");
                    progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                    progressDialog.show();
                    progressDialog.setCancelable(false);

                    if((pro_savekey.text.toString().isNotEmpty())&&(net_status()==true)) {
                        delofnonid()
                    }
                    else{
                        Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
                    }


                    val del = ArrayList<String>()
                    val storage = FirebaseStorage.getInstance()
                    val storageRef = storage.getReference()
                    if ((fn1.isEmpty() && sn1.isEmpty() && tn1.isEmpty() && fon1.isEmpty() && fifn1.isEmpty())) {

                        if(suppsel.isEmpty()) {
                            progressDialog.dismiss()
                            val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                            i.putExtra("frm_main", "main")
                            i.putExtra("addsupp", addsupp)
                            i.putExtra("editsupp", editesupp)
                            i.putExtra("deletesupp", deletesupp)
                            i.putExtra("viewsupp", viewsupp)
                            i.putExtra("importsupp", importsupp)
                            i.putExtra("exportsupp", exportsupp)
                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                            finish()
                        }
                        else if(suppsel.isNotEmpty()){
                            finish()
                        }
                    }
                    val pathsfile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                    val dir = File(pathsfile);

                    if ((fn1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val k = img1nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(pathsfile);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }

                        del.add(fn1)
                        del.add(img1nhigh)
                    }
                    if ((sn1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val k = img2nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(pathsfile);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        del.add(sn1)
                        del.add(img2nhigh)
                    }
                    if ((tn1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val k = img3nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(pathsfile);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        del.add(tn1)
                        del.add(img3nhigh)
                    }
                    if ((fon1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val k = img4nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(pathsfile);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        del.add(fon1)
                        del.add(img4nhigh)
                    }
                    if ((fifn1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val k = img5nhigh
                        val recacnm = k.removeSuffix(".jpg")

                        var y = recacnm + ".png"
                        val dir = File(pathsfile);
                        val file = File(dir, y)
                        if (file.exists()) {
                            file.delete()
                        }
                        del.add(fifn1)
                        del.add(img5nhigh)
                    }
                    if ((del.size >= 0) && (net_status() == true)) {
                        for (i in del) {
                            val imagesRef = storageRef.child("suppliers").child(i)
                            imagesRef.delete()
                                    .addOnSuccessListener {
                                        if (i == del.get(del.size - 1)) {
                                            if(suppsel.isEmpty()) {

                                            Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                                            val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)

                                            i.putExtra("frm_main", "main")
                                            i.putExtra("addsupp", addsupp)
                                            i.putExtra("editsupp", editesupp)
                                            i.putExtra("deletesupp", deletesupp)
                                            i.putExtra("viewsupp", viewsupp)
                                            i.putExtra("importsupp", importsupp)
                                            i.putExtra("exportsupp", exportsupp)
                                            startActivity(i)
                                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                            finish()
                                        }
                                            else if(suppsel.isNotEmpty()){
                                                finish()
                                            }
                                        }

                                    }
                                    .addOnCompleteListener {
                                    }
                        }
                    } else {
                        if(suppsel.isEmpty()) {

                        progressDialog.dismiss()
                        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)

                        i.putExtra("frm_main", "main")
                        i.putExtra("addsupp", addsupp)
                        i.putExtra("editsupp", editesupp)
                        i.putExtra("deletesupp", deletesupp)
                        i.putExtra("viewsupp", viewsupp)
                        i.putExtra("importsupp", importsupp)
                        i.putExtra("exportsupp", exportsupp)
                        startActivity(i)
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                        finish()
                        }
                        else if(suppsel.isNotEmpty()){
                            finish()
                        }
                    }

                    /* try {
                    if ((f1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("suppliers").child(fn1)
                        imagesRef.delete()
                                .addOnSuccessListener {


                                }
                    }
                    if ((s1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("suppliers").child(sn1)
                        imagesRef.delete()
                                .addOnSuccessListener {

                                }
                    }
                    if ((t1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("suppliers").child(tn1)
                        imagesRef.delete()
                                .addOnSuccessListener {

                                }
                    }

                    if ((fo1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("suppliers").child(fon1)
                        imagesRef.delete()
                                .addOnSuccessListener {

                                }
                    }
                    if ((fif1.isNotEmpty()) && (supp_id.text.toString() == "Auto - generated")) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("suppliers").child(fifn1)
                        imagesRef.delete()
                                .addOnSuccessListener {


                                }
                    }





                }
                catch (e:Exception){

                }*/




                }
                val dialog = builder.create()
                dialog.show()
            }
        } else if ((supp_id.text.toString() != "Auto - generated") && (fieldlistener == "change")&&(net_status()==true)&&(prokeylistener.isEmpty())) {
            val builder = AlertDialog.Builder(this@SupplierAddMain)
            with(builder) {
                setTitle("Save changes?")
                setMessage("Do you want to save?")
                setPositiveButton("Yes") { dialog, whichButton ->
                    if (net_status() == true) {
                        if (supp_imgurl.text == "") {
                            supp_imgurl.text = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                        }

                        if (supp_email.text.equals("")) {

                        }
                        val emailInput = supp_email.text.toString().trim();
                        val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                        if (emailInput.matches(emailPattern.toRegex())) {


                        } else {

                            supp_mailerr.visibility = View.VISIBLE
                            supp_mailerr.setText("Invalid email")

                        }


                        if (supp_nm.length() == 0) {
                            supperrnm.visibility = View.VISIBLE

                            supperrnm.setText("Required field*")
                        }
                        if (supp_mobile.length() == 0) {
                            supp_phoneerr.visibility = View.VISIBLE

                            supp_phoneerr.setText("Required field*")
                        }
                        var idmy = supp_savekey.text.toString()
                        var suppname = (supp_nm.text).toString()
                        var suppid = (supp_id.text).toString()

                        var suppmobcat1 = supp_mob.selectedItem.toString()
                        var suppmobcat2 = supp_mob1.selectedItem.toString()
                        var suppmobcat3 = supp_mob2.selectedItem.toString()
                        var suppmobcat4=supp_mob3.selectedItem.toString()
                        var suppaddress1 = (supp_address.text).toString()
                        var suppmobile = (supp_mobile.text).toString()
                        var suppmobile21 = (supp_mobile1.text).toString()
                        var suppmobile31 = (supp_mobile2.text).toString()
                        var suppmobile41 = (supp_mobile3.text).toString()
                        var suppaddress2 = (supp_address2.text).toString()
                        var suppaddress3 = (supp_address3.text).toString()
                        var suppcity = (supp_city.text).toString()
                        var suppstate = (supp_state.text).toString()
                        var supppin = (supp_pin.text).toString()
                        var contactprs = (supp_conpers.text).toString()
                        var prodky = (pro_savekey.text).toString()
                        var gps = (supp_gps.text).toString()

                        var suppemail = (supp_email.text).toString()

                        var suppgst = (supp_gstcode.text).toString()
                        var suppimglink = (supp_imgurl.text).toString()
                        var status = (statussup.text).toString()
                        if (f1.isEmpty()) {

                        }
                        val img1n = fn1
                        val img2n = sn1
                        val img3n = tn1
                        val img4n = fon1
                        val img5n = fifn1
                        val img1url = f1
                        val img2url = s1
                        val img3url = t1
                        val img4url = fo1
                        val img5url = fif1

                        val data = c(spnm = suppname, spid = suppid, spaddress1 = suppaddress1, spaddress2 = suppaddress2, spcontact_person = contactprs,
                                spaddress3 = suppaddress3, spcity = suppcity, spstate = suppstate, sppincode = supppin, spemail = suppemail,
                                spgst = suppgst, spmob1 = suppmobile, spmob2 = suppmobile21, status = status, spmob3 = suppmobile31,
                                spmob4 = suppmobile41, spimglink = suppimglink, spmobcat1 = suppmobcat1, spmobcat2 = suppmobcat2,
                                spmobcat3 = suppmobcat3,spmobcat4 = suppmobcat4, prodkey = prodky, sppgpsco_or = gps, img1n = img1n, img2n = img2n,
                                img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url, img3url = img3url,
                                img4url = img4url, img5url = img5url, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh,
                                img5nhigh = img5nhigh, img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh,
                                img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)

                        if ((id.text != "") && (supperrnm.visibility == View.INVISIBLE) && (supp_phoneerr.visibility == View.INVISIBLE)) {

                             pDialogs = SweetAlertDialog(this@SupplierAddMain, SweetAlertDialog.PROGRESS_TYPE);
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                            pDialogs!!.setTitleText("Saving...");
                            pDialogs!!.setCancelable(false);
                            pDialogs!!.show();

                            val db = FirebaseFirestore.getInstance()

                            val isInserted = myDb.updatedata(idmy, suppname, suppid, suppmobcat1, suppmobcat2,
                                    suppmobcat3, suppmobile, suppmobile21, suppmobile31, suppmobile41, suppaddress1, suppaddress2,
                                    suppaddress3, suppcity, suppstate, supppin, gps, suppemail, contactprs, suppgst, suppimglink,
                                    prodky, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh,
                                    img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,suppmobcat4)

                            if (isInserted == true) {
                                println("TRUE")

                            } else {
                                println("FALSE")
                            }


                            db.collection("suppliers").document(id.text.toString())

                                    .set(data)
                                    .addOnSuccessListener {
                                        if(suppsel.isEmpty()) {

                                        Toast.makeText(this@SupplierAddMain, "data is updated", Toast.LENGTH_LONG).show()
                                        pDialogs!!.dismiss();
                                        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                        i.putExtra("frm_main", "main")
                                        i.putExtra("addsupp", addsupp)
                                        i.putExtra("editsupp", editesupp)
                                        i.putExtra("deletesupp", deletesupp)
                                        i.putExtra("viewsupp", viewsupp)
                                        i.putExtra("importsupp", importsupp)
                                        i.putExtra("exportsupp", exportsupp)
                                        startActivity(i)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                        finish()

                                        }
                                        else if(suppsel.isNotEmpty()){
                                            finish()
                                        }
                                    }

                                    .addOnFailureListener {
                                        Toast.makeText(this@SupplierAddMain, "not updated", Toast.LENGTH_LONG).show()
                                        save_progress.visibility = android.view.View.GONE
                                    }


                        }
                    } else {
                        dialog.dismiss()
                    }
                }
                setNegativeButton("No") { dialog, whichButton ->


                    println("VALUE OF THE IMAGE NAME" + fn1)
                    println("VALUE OF THE IMAGE NAME EDIT" + fn1edit)
                    if((pro_savekey.text.toString().isNotEmpty())&&(net_status()==true)&&(prokeylistener.isEmpty())) {

                        delofnonid()  ///Delete images when supplier details is not saved
                    }
                    else{
                        if(net_status()==false)
                        {
                            Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()
                        }
                    }


                    try {
                        if (((f1.isNotEmpty())||(s1.isNotEmpty())||(t1.isNotEmpty())||(fo1.isNotEmpty())||(fif1.isNotEmpty())) && (supp_id.text.toString() != "Auto - generated")) {

                            val delname = ArrayList<String>()
                            val delnameedit = ArrayList<String>()
                            val delnamehigh = ArrayList<String>()
                            val delnameedithigh = ArrayList<String>()
                            val delurl = ArrayList<String>()
                            val delurledit = ArrayList<String>()
                            val delurledithigh = ArrayList<String>()
                            val deldbnm = ArrayList<String>()

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                            val dir = File(path);

                            if (fn1 != fn1edit) {
                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fn1)
                                delnamehigh.add(img1nhigh)
                            }
                            if (sn1 != sn1edit) {
                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(sn1)
                                delnamehigh.add(img2nhigh)
                            }
                            if (tn1 != tn1edit) {
                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(tn1)
                                delnamehigh.add(img3nhigh)
                            }
                            if (fon1 != fon1edit) {
                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fon1)
                                delnamehigh.add(img4nhigh)
                            }
                            if (fifn1 != fifn1edit) {
                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fifn1)
                                delnamehigh.add(img5nhigh)
                            }
                            delurl.add(f1edit)
                            delnameedit.add(fn1edit)

                            delurledithigh.add(f1edithigh)
                            delnameedithigh.add(fn1edithigh)

                            dialog.dismiss()

                            val progressDialog = ProgressDialog(this@SupplierAddMain);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);

                            deletedb()


                            if ((delname.size >= 0) && (net_status() == true)) {
                                for (i in delname) {
                                    val storage = FirebaseStorage.getInstance()
                                    val storageRef = storage.getReference()

                                    val imagesRef = storageRef.child("suppliers").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {

                                                if (i == delname.get(delname.size - 1)) {
                                                    for (i in delnamehigh) {
                                                        val imagesRef = storageRef.child("suppliers").child(i)
                                                        imagesRef.delete()
                                                                .addOnSuccessListener {
                                                                    if (i == delnamehigh.get(delnamehigh.size - 1)) {
                                                                        if(suppsel.isEmpty()) {

                                                                        progressDialog.dismiss()
                                                                        Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                                                                        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                                                        i.putExtra("frm_main", "main")
                                                                        i.putExtra("addsupp", addsupp)
                                                                        i.putExtra("editsupp", editesupp)
                                                                        i.putExtra("deletesupp", deletesupp)
                                                                        i.putExtra("viewsupp", viewsupp)
                                                                        i.putExtra("importsupp", importsupp)
                                                                        i.putExtra("exportsupp", exportsupp)
                                                                        startActivity(i)
                                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                                        finish()
                                                                        }
                                                                        else if(suppsel.isNotEmpty()){
                                                                            finish()
                                                                        }
                                                                    }

                                                                }
                                                    }
                                                }

                                            }
                                }


                            } else {
                                if(suppsel.isEmpty()) {

                                progressDialog.dismiss()
                                Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                                val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                i.putExtra("frm_main", "main")
                                i.putExtra("addsupp", addsupp)
                                i.putExtra("editsupp", editesupp)
                                i.putExtra("deletesupp", deletesupp)
                                i.putExtra("viewsupp", viewsupp)
                                i.putExtra("importsupp", importsupp)
                                i.putExtra("exportsupp", exportsupp)
                                startActivity(i)
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                finish()
                                }
                                else if(suppsel.isNotEmpty()){
                                    finish()
                                }
                            }
                        }
                        else{
                            if(suppsel.isEmpty()) {

                            Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                            val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                            i.putExtra("frm_main", "main")
                            i.putExtra("addsupp", addsupp)
                            i.putExtra("editsupp", editesupp)
                            i.putExtra("deletesupp", deletesupp)
                            i.putExtra("viewsupp", viewsupp)
                            i.putExtra("importsupp", importsupp)
                            i.putExtra("exportsupp", exportsupp)
                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                            finish()
                            }
                            else if(suppsel.isNotEmpty()){
                                finish()
                            }
                        }

                    }
                    catch (e:Exception){

                }
            }
                val dialog = builder.create()

                dialog.show()
        }
    }

        else if((supp_id.text.toString()!="Auto - generated")&&(prokeylistener!=pro_savekey.text.toString())){

        val builder = AlertDialog.Builder(this@SupplierAddMain)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")
            setPositiveButton("Yes") { dialog, whichButton ->
                if(net_status()==true) {
                    if (supp_imgurl.text == "") {
                        supp_imgurl.text = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                    }

                    if (supp_email.text.equals("")) {

                    }
                    val emailInput = supp_email.text.toString().trim();
                    val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                    if (emailInput.matches(emailPattern.toRegex())) {


                    } else {

                        supp_mailerr.visibility = View.VISIBLE
                        supp_mailerr.setText("Invalid email")

                    }


                    if (supp_nm.length() == 0) {
                        supperrnm.visibility = View.VISIBLE

                        supperrnm.setText("Required field*")
                        Toast.makeText(applicationContext,"Please fill required fields",Toast.LENGTH_SHORT).show()

                    }
                    if (supp_mobile.length() == 0) {
                        supp_phoneerr.visibility = View.VISIBLE

                        supp_phoneerr.setText("Required field*")
                        Toast.makeText(applicationContext,"Please fill required fields",Toast.LENGTH_SHORT).show()

                    }
                    var idmy = supp_savekey.text.toString()
                    var suppname = (supp_nm.text).toString()
                    var suppid = (supp_id.text).toString()

                    var suppmobcat1 = supp_mob.selectedItem.toString()
                    var suppmobcat2 = supp_mob1.selectedItem.toString()
                    var suppmobcat3 = supp_mob2.selectedItem.toString()
                    var suppmobcat4=supp_mob3.selectedItem.toString()

                    var suppaddress1 = (supp_address.text).toString()
                    var suppmobile = (supp_mobile.text).toString()
                    var suppmobile21 = (supp_mobile1.text).toString()
                    var suppmobile31 = (supp_mobile2.text).toString()
                    var suppmobile41 = (supp_mobile3.text).toString()
                    var suppaddress2 = (supp_address2.text).toString()
                    var suppaddress3 = (supp_address3.text).toString()
                    var suppcity = (supp_city.text).toString()
                    var suppstate = (supp_state.text).toString()
                    var supppin = (supp_pin.text).toString()
                    var contactprs = (supp_conpers.text).toString()
                    var prodky = (pro_savekey.text).toString()
                    var gps = (supp_gps.text).toString()

                    var suppemail = (supp_email.text).toString()

                    var suppgst = (supp_gstcode.text).toString()
                    var suppimglink = (supp_imgurl.text).toString()
                    var status = (statussup.text).toString()
                    if (f1.isEmpty()) {

                    }
                    val img1n = fn1
                    val img2n = sn1
                    val img3n = tn1
                    val img4n = fon1
                    val img5n = fifn1
                    val img1url = f1
                    val img2url = s1
                    val img3url = t1
                    val img4url = fo1
                    val img5url = fif1

                    val data = c(spnm = suppname, spid = suppid, spaddress1 = suppaddress1, spaddress2 = suppaddress2, spcontact_person = contactprs,
                            spaddress3 = suppaddress3, spcity = suppcity, spstate = suppstate, sppincode = supppin, spemail = suppemail,
                            spgst = suppgst, spmob1 = suppmobile, spmob2 = suppmobile21, status = status, spmob3 = suppmobile31,
                            spmob4 = suppmobile41, spimglink = suppimglink, spmobcat1 = suppmobcat1, spmobcat2 = suppmobcat2,
                            spmobcat3 = suppmobcat3,  spmobcat4 = suppmobcat4, prodkey = prodky, sppgpsco_or = gps, img1n = img1n, img2n = img2n,
                            img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url, img3url = img3url,
                            img4url = img4url, img5url = img5url,img1nhigh = img1nhigh,
                            img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,img1urlhigh = img1urlhigh,
                            img2urlhigh = img2urlhigh,img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)

                    if ((id.text != "") && (supperrnm.visibility == View.INVISIBLE) && (supp_phoneerr.visibility == View.INVISIBLE)) {

                        pDialogs = SweetAlertDialog(this@SupplierAddMain, SweetAlertDialog.PROGRESS_TYPE);
                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                        pDialogs!!.setTitleText("Saving...");
                        pDialogs!!.setCancelable(false);
                        pDialogs!!.show();

                        val db = FirebaseFirestore.getInstance()

                        val isInserted = myDb.updatedata(idmy, suppname, suppid, suppmobcat1,
                                suppmobcat2, suppmobcat3, suppmobile, suppmobile21, suppmobile31,
                                suppmobile41, suppaddress1, suppaddress2, suppaddress3, suppcity,
                                suppstate, supppin, gps, suppemail, contactprs, suppgst, suppimglink,
                                prodky, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url,
                                img3url, img4url, img5url,img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh,
                                img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,suppmobcat4)

                        if (isInserted == true) {
                            println("TRUE")

                        } else {
                            println("FALSE")
                        }


                        db.collection("suppliers").document(id.text.toString())

                                .set(data)
                                .addOnSuccessListener {
                                    if(suppsel.isEmpty()) {

                                    Toast.makeText(this@SupplierAddMain, "data is updated", Toast.LENGTH_LONG).show()
                                    pDialogs!!.dismiss();
                                    val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                    i.putExtra("frm_main", "main")
                                    i.putExtra("addsupp", addsupp)
                                    i.putExtra("editsupp", editesupp)
                                    i.putExtra("deletesupp", deletesupp)
                                    i.putExtra("viewsupp", viewsupp)
                                    i.putExtra("importsupp", importsupp)
                                    i.putExtra("exportsupp", exportsupp)
                                    startActivity(i)
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                    finish()

                                    }
                                    else if(suppsel.isNotEmpty()){
                                        finish()
                                    }
                                }

                                .addOnFailureListener {
                                    Toast.makeText(this@SupplierAddMain, "not updated", Toast.LENGTH_LONG).show()
                                    save_progress.visibility = android.view.View.GONE
                                }


                    }
                }
                else{
                    dialog.dismiss()
                }
            }
            setNegativeButton("No") { dialog, whichButton ->
                dialog.dismiss()

                val progressDialog = ProgressDialog(this@SupplierAddMain);
                progressDialog.setTitle("Please wait...");
                progressDialog.setMessage("wait for a while...");
                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                progressDialog.show();
                progressDialog.setCancelable(false);

                var contains = false




                if((prokeylistener.isNotEmpty())&&(net_status()==true)) {

                   val ps = prokeylistener.split(",")

                   for (i in 0 until ps.size) {
                       var asf = ps[i]
                       asf = asf.trim()
                       savearr.add(asf)
                   }


                   val paths = pro_savekey.text.toString()

                   var ii = paths.split(",")

                   for (i in 0 until ii.size) {
                       var a = ii[i]
                       a = a.trim()
                       prsvarr.add(a)
                   }

                   val s = prsvarr.count()
                   val k = savearr.count()

                   println("SAVE" + s)
                   println("SAVESS" + k)

                   for (i in 0 until savearr.size) {

                       val oo = savearr[i]
                       prsvarr.remove(oo)

                   }

                   println("SAVE ARRAY" + prsvarr)

                   for (i in 0 until prsvarr.size) {

                       var op = prsvarr[i]
                       pro_savekey.setText(op)
                       var o = pro_savekey.text.toString()
                       var p = o.removePrefix("[")
                       var pi = p.removeSuffix("]")
                       pro_savekey.text = pi
                       println("PRO" + pro_savekey.text.toString())
                       var ds = pro_savekey.text.toString()

                       db.collection("product").document(ds)
                               .get()
                               .addOnCompleteListener { task ->
                                   try {
                                       var img1 = task.result.get("img1n").toString()
                                       var img2 = task.result.get("img2n").toString()
                                       var img3 = task.result.get("img3n").toString()
                                       var img4 = task.result.get("img4n").toString()
                                       var img5 = task.result.get("img5n").toString()

                                       var img1nhigh = task.result.get("img1nhigh").toString()
                                       var img2nhigh = task.result.get("img2nhigh").toString()
                                       var img3nhigh = task.result.get("img3nhigh").toString()
                                       var img4nhigh = task.result.get("img4nhigh").toString()
                                       var img5nhigh = task.result.get("img5nhigh").toString()

                                       try{
                                           getval=task.result.get("supp_add").toString()
                                       }
                                       catch (e:Exception){

                                       }

                                       if (net_status() == true) {

                                           if (img1.isNotEmpty() == true) {
                                               val storage = FirebaseStorage.getInstance()
                                               val storageRef = storage.getReference()
                                               val imagesRef = storageRef.child("product").child(img1)
                                               imagesRef.delete()
                                                       .addOnSuccessListener {
                                                           val imagesRef = storageRef.child("product").child(img1nhigh)
                                                           imagesRef.delete()
                                                                   .addOnSuccessListener {

                                                                   }

                                                       }
                                           }
                                           if (img2.isNotEmpty() == true) {
                                               val storage = FirebaseStorage.getInstance()
                                               val storageRef = storage.getReference()
                                               val imagesRef = storageRef.child("product").child(img2)
                                               imagesRef.delete()
                                                       .addOnSuccessListener {
                                                           val imagesRef = storageRef.child("product").child(img2nhigh)
                                                           imagesRef.delete()
                                                                   .addOnSuccessListener {

                                                                   }

                                                       }
                                           }
                                           if (img3.isNotEmpty() == true) {
                                               val storage = FirebaseStorage.getInstance()
                                               val storageRef = storage.getReference()
                                               val imagesRef = storageRef.child("product").child(img3)
                                               imagesRef.delete()
                                                       .addOnSuccessListener {
                                                           val imagesRef = storageRef.child("product").child(img3nhigh)
                                                           imagesRef.delete()
                                                                   .addOnSuccessListener {

                                                                   }

                                                       }
                                           }
                                           if (img4.isNotEmpty() == true) {
                                               val storage = FirebaseStorage.getInstance()
                                               val storageRef = storage.getReference()
                                               val imagesRef = storageRef.child("product").child(img4)
                                               imagesRef.delete()
                                                       .addOnSuccessListener {
                                                           val imagesRef = storageRef.child("product").child(img4nhigh)
                                                           imagesRef.delete()
                                                                   .addOnSuccessListener {

                                                                   }

                                                       }
                                           }
                                           if (img5.isNotEmpty() == true) {
                                               val storage = FirebaseStorage.getInstance()
                                               val storageRef = storage.getReference()
                                               val imagesRef = storageRef.child("product").child(img5)
                                               imagesRef.delete()
                                                       .addOnSuccessListener {

                                                           val imagesRef = storageRef.child("product").child(img5nhigh)
                                                           imagesRef.delete()
                                                                   .addOnSuccessListener {

                                                                   }
                                                       }
                                           }


                                       } else {
                                           Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()
                                       }

                                   }
                                   catch (e:Exception){

                                   }
                                   if(getval.isNotEmpty()){
                                       if(getval=="list"){
                                           db.collection("product").document(ds)
                                                   .update("supp_key","")
                                                   .addOnSuccessListener {
                                                       myDbs.deleteData(ds)

                                                   }
                                                   .addOnFailureListener {


                                                   }
                                       }
                                       else if(getval=="add"){
                                           db.collection("product").document(ds)
                                                   .delete()
                                                   .addOnSuccessListener {
                                                       myDbs.deleteData(ds)

                                                   }
                                                   .addOnFailureListener {


                                                   }
                                       }

                                   }

                               }




                   }
               }
                else{

                }

                println("VALUE OF THE IMAGE NAME"+fn1)
                println("VALUE OF THE IMAGE NAME EDIT"+fn1edit)
                try {
                    if (((f1.isNotEmpty())||(s1.isNotEmpty())||(t1.isNotEmpty())||(fo1.isNotEmpty())||(fif1.isNotEmpty())) && (supp_id.text.toString() != "Auto - generated")) {

                        val delname = ArrayList<String>()
                        val delnameedit = ArrayList<String>()
                        val delnamehigh = ArrayList<String>()
                        val delnameedithigh = ArrayList<String>()
                        val delurl = ArrayList<String>()
                        val delurledit = ArrayList<String>()
                        val delurledithigh = ArrayList<String>()
                        val deldbnm = ArrayList<String>()

                        val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                        val dir = File(path);

                        if (fn1 != fn1edit) {
                            val k = img1nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            delname.add(fn1)
                            delnamehigh.add(img1nhigh)
                        }
                        if (sn1 != sn1edit) {
                            val k = img2nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            delname.add(sn1)
                            delnamehigh.add(img2nhigh)
                        }
                        if (tn1 != tn1edit) {
                            val k = img3nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            delname.add(tn1)
                            delnamehigh.add(img3nhigh)
                        }
                        if (fon1 != fon1edit) {
                            val k = img4nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            delname.add(fon1)
                            delnamehigh.add(img4nhigh)
                        }
                        if (fifn1 != fifn1edit) {
                            val k = img5nhigh
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (file.exists()) {
                                file.delete()
                            }
                            delname.add(fifn1)
                            delnamehigh.add(img5nhigh)
                        }
                        delurl.add(f1edit)
                        delnameedit.add(fn1edit)

                        delurledithigh.add(f1edithigh)
                        delnameedithigh.add(fn1edithigh)


                        println("EMP DELNAME"+delname)



                        if ((delname.size >= 0) && (net_status() == true)&&(delname.isNotEmpty())) {
                            for (i in delname) {
                                val storage = FirebaseStorage.getInstance()
                                val storageRef = storage.getReference()

                                val imagesRef = storageRef.child("suppliers").child(i)
                                imagesRef.delete()
                                        .addOnSuccessListener {

                                            if (i == delname.get(delname.size - 1)) {
                                                for (i in delnamehigh) {
                                                    val imagesRef = storageRef.child("suppliers").child(i)
                                                    imagesRef.delete()
                                                            .addOnSuccessListener {
                                                                if (i == delnamehigh.get(delnamehigh.size - 1)) {
                                                                    if(suppsel.isEmpty()) {

                                                                    progressDialog.dismiss()
                                                                    Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                                                                    val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                                                    i.putExtra("frm_main", "main")
                                                                    i.putExtra("addsupp", addsupp)
                                                                    i.putExtra("editsupp", editesupp)
                                                                    i.putExtra("deletesupp", deletesupp)
                                                                    i.putExtra("viewsupp", viewsupp)
                                                                    i.putExtra("importsupp", importsupp)
                                                                    i.putExtra("exportsupp", exportsupp)
                                                                    startActivity(i)
                                                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                                    finish()
                                                                    }
                                                                    else if(suppsel.isNotEmpty()){
                                                                        finish()
                                                                    }
                                                                }

                                                            }
                                                }
                                            }

                                        }
                            }


                        } else {
                            if(suppsel.isEmpty()) {

                            progressDialog.dismiss()
                            Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                            val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                            i.putExtra("frm_main", "main")
                            i.putExtra("addsupp", addsupp)
                            i.putExtra("editsupp", editesupp)
                            i.putExtra("deletesupp", deletesupp)
                            i.putExtra("viewsupp", viewsupp)
                            i.putExtra("importsupp", importsupp)
                            i.putExtra("exportsupp", exportsupp)
                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                            finish()
                            }
                            else if(suppsel.isNotEmpty()){
                                finish()
                            }
                        }
                    }
                    else{
                        println("YES CATCH")
                        if(suppsel.isEmpty()) {

                        progressDialog.dismiss()
                        Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                        i.putExtra("frm_main", "main")
                        i.putExtra("addsupp", addsupp)
                        i.putExtra("editsupp", editesupp)
                        i.putExtra("deletesupp", deletesupp)
                        i.putExtra("viewsupp", viewsupp)
                        i.putExtra("importsupp", importsupp)
                        i.putExtra("exportsupp", exportsupp)
                        startActivity(i)
                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                        finish()
                        }
                        else if(suppsel.isNotEmpty()){
                            finish()
                        }
                    }
                }
                catch (e:Exception){

                }










            }
            val dialog = builder.create()
            dialog.show()
        }




        }

    else{


            if(((supp_id.text.toString() != "Auto - generated") && (fieldlistener == "change")&&(net_status()==true))){
                println("ELSE KULL IF ALERT")
                val builder = AlertDialog.Builder(this@SupplierAddMain)
                with(builder) {
                    setTitle("Save changes?")
                    setMessage("Do you want to save?")
                    setPositiveButton("Yes") { dialog, whichButton ->
                        if (net_status() == true) {
                            if (supp_imgurl.text == "") {
                                supp_imgurl.text = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                            }

                            if (supp_email.text.equals("")) {

                            }
                            val emailInput = supp_email.text.toString().trim();
                            val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
                            if (emailInput.matches(emailPattern.toRegex())) {


                            } else {

                                supp_mailerr.visibility = View.VISIBLE
                                supp_mailerr.setText("Invalid email")

                            }


                            if (supp_nm.length() == 0) {
                                supperrnm.visibility = View.VISIBLE

                                supperrnm.setText("Required field*")
                            }
                            if (supp_mobile.length() == 0) {
                                supp_phoneerr.visibility = View.VISIBLE

                                supp_phoneerr.setText("Required field*")
                            }
                            var idmy = supp_savekey.text.toString()
                            var suppname = (supp_nm.text).toString()
                            var suppid = (supp_id.text).toString()

                            var suppmobcat1 = supp_mob.selectedItem.toString()
                            var suppmobcat2 = supp_mob1.selectedItem.toString()
                            var suppmobcat3 = supp_mob2.selectedItem.toString()
                            var suppmobcat4=supp_mob3.selectedItem.toString()

                            var suppaddress1 = (supp_address.text).toString()
                            var suppmobile = (supp_mobile.text).toString()
                            var suppmobile21 = (supp_mobile1.text).toString()
                            var suppmobile31 = (supp_mobile2.text).toString()
                            var suppmobile41 = (supp_mobile3.text).toString()
                            var suppaddress2 = (supp_address2.text).toString()
                            var suppaddress3 = (supp_address3.text).toString()
                            var suppcity = (supp_city.text).toString()
                            var suppstate = (supp_state.text).toString()
                            var supppin = (supp_pin.text).toString()
                            var contactprs = (supp_conpers.text).toString()
                            var prodky = (pro_savekey.text).toString()
                            var gps = (supp_gps.text).toString()

                            var suppemail = (supp_email.text).toString()

                            var suppgst = (supp_gstcode.text).toString()
                            var suppimglink = (supp_imgurl.text).toString()
                            var status = (statussup.text).toString()
                            if (f1.isEmpty()) {

                            }
                            val img1n = fn1
                            val img2n = sn1
                            val img3n = tn1
                            val img4n = fon1
                            val img5n = fifn1
                            val img1url = f1
                            val img2url = s1
                            val img3url = t1
                            val img4url = fo1
                            val img5url = fif1

                            val data = c(spnm = suppname, spid = suppid, spaddress1 = suppaddress1, spaddress2 = suppaddress2, spcontact_person = contactprs,
                                    spaddress3 = suppaddress3, spcity = suppcity, spstate = suppstate, sppincode = supppin, spemail = suppemail,
                                    spgst = suppgst, spmob1 = suppmobile, spmob2 = suppmobile21, status = status, spmob3 = suppmobile31,
                                    spmob4 = suppmobile41, spimglink = suppimglink, spmobcat1 = suppmobcat1, spmobcat2 = suppmobcat2,
                                    spmobcat3 = suppmobcat3,spmobcat4 = suppmobcat4, prodkey = prodky, sppgpsco_or = gps, img1n = img1n, img2n = img2n,
                                    img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url, img3url = img3url,
                                    img4url = img4url, img5url = img5url, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh,
                                    img5nhigh = img5nhigh, img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh,
                                    img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)

                            if ((id.text != "") && (supperrnm.visibility == View.INVISIBLE) && (supp_phoneerr.visibility == View.INVISIBLE)) {

                                pDialogs = SweetAlertDialog(this@SupplierAddMain, SweetAlertDialog.PROGRESS_TYPE);
                                pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                pDialogs!!.setTitleText("Saving...");
                                pDialogs!!.setCancelable(false);
                                pDialogs!!.show();

                                val db = FirebaseFirestore.getInstance()

                                val isInserted = myDb.updatedata(idmy, suppname, suppid, suppmobcat1, suppmobcat2,
                                        suppmobcat3, suppmobile, suppmobile21, suppmobile31, suppmobile41, suppaddress1, suppaddress2,
                                        suppaddress3, suppcity, suppstate, supppin, gps, suppemail, contactprs, suppgst, suppimglink,
                                        prodky, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh,
                                        img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,suppmobcat4)

                                if (isInserted == true) {
                                    println("TRUE")

                                } else {
                                    println("FALSE")
                                }


                                db.collection("suppliers").document(id.text.toString())

                                        .set(data)
                                        .addOnSuccessListener {
                                            if(suppsel.isEmpty()) {

                                                Toast.makeText(this@SupplierAddMain, "data is updated", Toast.LENGTH_LONG).show()
                                                pDialogs!!.dismiss();
                                                val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                                i.putExtra("frm_main", "main")
                                                i.putExtra("addsupp", addsupp)
                                                i.putExtra("editsupp", editesupp)
                                                i.putExtra("deletesupp", deletesupp)
                                                i.putExtra("viewsupp", viewsupp)
                                                i.putExtra("importsupp", importsupp)
                                                i.putExtra("exportsupp", exportsupp)
                                                startActivity(i)
                                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                                finish()

                                            }
                                            else if(suppsel.isNotEmpty()){
                                                finish()
                                            }
                                        }

                                        .addOnFailureListener {
                                            Toast.makeText(this@SupplierAddMain, "not updated", Toast.LENGTH_LONG).show()
                                            save_progress.visibility = android.view.View.GONE
                                        }


                            }
                        } else {
                            dialog.dismiss()
                        }
                    }
                    setNegativeButton("No") { dialog, whichButton ->


                        println("VALUE OF THE IMAGE NAME" + fn1)
                        println("VALUE OF THE IMAGE NAME EDIT" + fn1edit)
                        if((pro_savekey.text.toString().isNotEmpty())&&(net_status()==true)&&(prokeylistener.isEmpty())) {

                            delofnonid()  ///Delete images when supplier details is not saved
                        }
                        else{
                            if(net_status()==false)
                            {
                                Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()
                            }
                        }


                        try {
                            if (((f1.isNotEmpty())||(s1.isNotEmpty())||(t1.isNotEmpty())||(fo1.isNotEmpty())||(fif1.isNotEmpty())) && (supp_id.text.toString() != "Auto - generated")) {

                                val delname = ArrayList<String>()
                                val delnameedit = ArrayList<String>()
                                val delnamehigh = ArrayList<String>()
                                val delnameedithigh = ArrayList<String>()
                                val delurl = ArrayList<String>()
                                val delurledit = ArrayList<String>()
                                val delurledithigh = ArrayList<String>()
                                val deldbnm = ArrayList<String>()

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

                                val dir = File(path);

                                if (fn1 != fn1edit) {
                                    val k = img1nhigh
                                    val recacnm = k.removeSuffix(".jpg")

                                    var y = recacnm + ".png"
                                    val dir = File(path);
                                    val file = File(dir, y)
                                    if (file.exists()) {
                                        file.delete()
                                    }
                                    delname.add(fn1)
                                    delnamehigh.add(img1nhigh)
                                }
                                if (sn1 != sn1edit) {
                                    val k = img2nhigh
                                    val recacnm = k.removeSuffix(".jpg")

                                    var y = recacnm + ".png"
                                    val dir = File(path);
                                    val file = File(dir, y)
                                    if (file.exists()) {
                                        file.delete()
                                    }
                                    delname.add(sn1)
                                    delnamehigh.add(img2nhigh)
                                }
                                if (tn1 != tn1edit) {
                                    val k = img3nhigh
                                    val recacnm = k.removeSuffix(".jpg")

                                    var y = recacnm + ".png"
                                    val dir = File(path);
                                    val file = File(dir, y)
                                    if (file.exists()) {
                                        file.delete()
                                    }
                                    delname.add(tn1)
                                    delnamehigh.add(img3nhigh)
                                }
                                if (fon1 != fon1edit) {
                                    val k = img4nhigh
                                    val recacnm = k.removeSuffix(".jpg")

                                    var y = recacnm + ".png"
                                    val dir = File(path);
                                    val file = File(dir, y)
                                    if (file.exists()) {
                                        file.delete()
                                    }
                                    delname.add(fon1)
                                    delnamehigh.add(img4nhigh)
                                }
                                if (fifn1 != fifn1edit) {
                                    val k = img5nhigh
                                    val recacnm = k.removeSuffix(".jpg")

                                    var y = recacnm + ".png"
                                    val dir = File(path);
                                    val file = File(dir, y)
                                    if (file.exists()) {
                                        file.delete()
                                    }
                                    delname.add(fifn1)
                                    delnamehigh.add(img5nhigh)
                                }
                                delurl.add(f1edit)
                                delnameedit.add(fn1edit)

                                delurledithigh.add(f1edithigh)
                                delnameedithigh.add(fn1edithigh)

                                dialog.dismiss()

                                val progressDialog = ProgressDialog(this@SupplierAddMain);
                                progressDialog.setTitle("Please wait...");
                                progressDialog.setMessage("wait for a while...");
                                progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                                progressDialog.show();
                                progressDialog.setCancelable(false);

                                deletedb()


                                if ((delname.size >= 0) && (net_status() == true)) {
                                    for (i in delname) {
                                        val storage = FirebaseStorage.getInstance()
                                        val storageRef = storage.getReference()

                                        val imagesRef = storageRef.child("suppliers").child(i)
                                        imagesRef.delete()
                                                .addOnSuccessListener {

                                                    if (i == delname.get(delname.size - 1)) {
                                                        for (i in delnamehigh) {
                                                            val imagesRef = storageRef.child("suppliers").child(i)
                                                            imagesRef.delete()
                                                                    .addOnSuccessListener {
                                                                        if (i == delnamehigh.get(delnamehigh.size - 1)) {
                                                                            if(suppsel.isEmpty()) {

                                                                                progressDialog.dismiss()
                                                                                Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                                                                                val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                                                                i.putExtra("frm_main", "main")
                                                                                i.putExtra("addsupp", addsupp)
                                                                                i.putExtra("editsupp", editesupp)
                                                                                i.putExtra("deletesupp", deletesupp)
                                                                                i.putExtra("viewsupp", viewsupp)
                                                                                i.putExtra("importsupp", importsupp)
                                                                                i.putExtra("exportsupp", exportsupp)
                                                                                startActivity(i)
                                                                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                                                finish()
                                                                            }
                                                                            else if(suppsel.isNotEmpty()){
                                                                                finish()
                                                                            }
                                                                        }

                                                                    }
                                                        }
                                                    }

                                                }
                                    }


                                } else {
                                    if(suppsel.isEmpty()) {

                                        progressDialog.dismiss()
                                        Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                                        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                        i.putExtra("frm_main", "main")
                                        i.putExtra("addsupp", addsupp)
                                        i.putExtra("editsupp", editesupp)
                                        i.putExtra("deletesupp", deletesupp)
                                        i.putExtra("viewsupp", viewsupp)
                                        i.putExtra("importsupp", importsupp)
                                        i.putExtra("exportsupp", exportsupp)
                                        startActivity(i)
                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                        finish()
                                    }
                                    else if(suppsel.isNotEmpty()){
                                        finish()
                                    }
                                }
                            }
                            else{
                                if(suppsel.isEmpty()) {

                                    Toast.makeText(this@SupplierAddMain, "Exited", Toast.LENGTH_LONG).show()
                                    val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                                    i.putExtra("frm_main", "main")
                                    i.putExtra("addsupp", addsupp)
                                    i.putExtra("editsupp", editesupp)
                                    i.putExtra("deletesupp", deletesupp)
                                    i.putExtra("viewsupp", viewsupp)
                                    i.putExtra("importsupp", importsupp)
                                    i.putExtra("exportsupp", exportsupp)
                                    startActivity(i)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                    finish()
                                }
                                else if(suppsel.isNotEmpty()){
                                    finish()
                                }
                            }

                        }
                        catch (e:Exception){

                        }
                    }
                    val dialog = builder.create()

                    dialog.show()
                }
            }

           else if(suppsel.isEmpty()) {

        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
        i.putExtra("frm_main", "main")
        i.putExtra("addsupp", addsupp)
        i.putExtra("editsupp", editesupp)
        i.putExtra("deletesupp", deletesupp)
        i.putExtra("viewsupp", viewsupp)
        i.putExtra("importsupp", importsupp)
        i.putExtra("exportsupp", exportsupp)
        startActivity(i)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

        finish()
            }
            else if(suppsel.isNotEmpty()){
                finish()
            }
    }
}
catch(e:Exception){

    println("YES CATCH")

    if(suppsel.isEmpty()) {

    val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
    i.putExtra("frm_main", "main")
    i.putExtra("addsupp", addsupp)
    i.putExtra("editsupp", editesupp)
    i.putExtra("deletesupp", deletesupp)
    i.putExtra("viewsupp", viewsupp)
    i.putExtra("importsupp", importsupp)
    i.putExtra("exportsupp", exportsupp)
    startActivity(i)
    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

    finish()
    }
    else if(suppsel.isNotEmpty()){
        finish()
    }
}
    }


    fun delofnonid(){
        val path = pro_savekey.text.toString()
        var ii = path.split(",")
        try {
            for (i in 0 until ii.size) {
                var a = ii[i]
                a = a.trim()
                println("DELETING KEYYY BACK PRESSED" + pro_savekey.text)
                println("SUPP_ID" + supp_id.text)

                db.collection("product").document(a)
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                if (task.result != null) {
                                    val img1 = task.result.get("img1n")
                                    val img2 = task.result.get("img2n")
                                    val img3 = task.result.get("img3n")
                                    val img4 = task.result.get("img4n")
                                    val img5 = task.result.get("img5n")
                                    val img1nhigh = task.result.get("img1nhigh")
                                    val img2nhigh = task.result.get("img2nhigh")
                                    val img3nhigh = task.result.get("img3nhigh")
                                    val img4nhigh = task.result.get("img4nhigh")
                                    val img5nhigh = task.result.get("img5nhigh")


                                    try{
                                        getval=task.result.get("supp_add").toString()
                                    }
                                    catch (e:Exception){

                                    }

                                    if (img1 != "") {
                                        val storage = FirebaseStorage.getInstance()
                                        val storageRef = storage.getReference()
                                        val imagesRef = storageRef.child("product").child(img1.toString())
                                        imagesRef.delete()
                                                .addOnSuccessListener {

                                                    val imagesRef = storageRef.child("product").child(img1nhigh.toString())
                                                    imagesRef.delete()
                                                            .addOnSuccessListener {

                                                            }
                                                }
                                    }
                                    if (img2 != "") {
                                        val storage = FirebaseStorage.getInstance()
                                        val storageRef = storage.getReference()
                                        val imagesRef = storageRef.child("product").child(img2.toString())
                                        imagesRef.delete()
                                                .addOnSuccessListener {
                                                    val imagesRef = storageRef.child("product").child(img2nhigh.toString())
                                                    imagesRef.delete()
                                                            .addOnSuccessListener {

                                                            }

                                                }
                                    }
                                    if (img3 != "") {
                                        val storage = FirebaseStorage.getInstance()
                                        val storageRef = storage.getReference()
                                        val imagesRef = storageRef.child("product").child(img3.toString())
                                        imagesRef.delete()
                                                .addOnSuccessListener {

                                                    val imagesRef = storageRef.child("product").child(img3nhigh.toString())
                                                    imagesRef.delete()
                                                            .addOnSuccessListener {

                                                            }
                                                }
                                    }
                                    if (img4 != "") {
                                        val storage = FirebaseStorage.getInstance()
                                        val storageRef = storage.getReference()
                                        val imagesRef = storageRef.child("product").child(img4.toString())
                                        imagesRef.delete()
                                                .addOnSuccessListener {
                                                    val imagesRef = storageRef.child("product").child(img4nhigh.toString())
                                                    imagesRef.delete()
                                                            .addOnSuccessListener {

                                                            }

                                                }
                                    }
                                    if (img5 != "") {
                                        val storage = FirebaseStorage.getInstance()
                                        val storageRef = storage.getReference()
                                        val imagesRef = storageRef.child("product").child(img5.toString())
                                        imagesRef.delete()
                                                .addOnSuccessListener {

                                                    val imagesRef = storageRef.child("product").child(img5nhigh.toString())
                                                    imagesRef.delete()
                                                            .addOnSuccessListener {

                                                            }
                                                }
                                    }
                                } else {

                                }
                            }

                            if(getval.isNotEmpty()){
                                if(getval=="list"){
                                    db.collection("product").document(a)
                                            .update("supp_key","")
                                            .addOnSuccessListener {
                                                myDbs.deleteData(a)

                                            }
                                            .addOnFailureListener {


                                            }
                                }
                                else if(getval=="add"){
                                    db.collection("product").document(a)
                                            .delete()
                                            .addOnSuccessListener {
                                                myDbs.deleteData(a)

                                            }
                                            .addOnFailureListener {


                                            }
                                }

                            }



                        }


            }
        } catch (e: Exception) {

        }
    }



    fun deletedb() {
        if(((fn1 != fn1edit)||(sn1 != sn1edit)||(tn1 != tn1edit)|| (fon1 != fon1edit)||(fifn1 != fifn1edit))&&(net_status()==true)) {
            if ((id.text.isNotEmpty()) && (fn1 != fn1edit)) {
                db.collection("suppliers").document(id.text.toString())
                        .update("img1url", f1edit)
                        .addOnSuccessListener {
                            db.collection("suppliers").document(id.text.toString())
                                    .update("img1n", fn1edit)
                                    .addOnCompleteListener {
                                        db.collection("suppliers").document(id.text.toString())
                                                .update("img1urlhigh", f1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("suppliers").document(id.text.toString())
                                                            .update("img1nhigh", fn1edithigh)

                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (sn1 != sn1edit)) {

                db.collection("suppliers").document(id.text.toString())
                        .update("img2url", s1edit)
                        .addOnSuccessListener {
                            db.collection("suppliers").document(id.text.toString())
                                    .update("img2n", sn1edit)
                                    .addOnCompleteListener {
                                        db.collection("suppliers").document(id.text.toString())
                                                .update("img2urlhigh", s1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("suppliers").document(id.text.toString())
                                                            .update("img2nhigh", sn1edithigh)


                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (tn1 != tn1edit)) {
                db.collection("suppliers").document(id.text.toString())
                        .update("img3url", t1edit)
                        .addOnSuccessListener {
                            db.collection("suppliers").document(id.text.toString())
                                    .update("img3n", tn1edit)
                                    .addOnCompleteListener {
                                        db.collection("suppliers").document(id.text.toString())
                                                .update("img3urlhigh", t1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("suppliers").document(id.text.toString())
                                                            .update("img3nhigh", tn1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (fon1 != fon1edit)) {
                db.collection("suppliers").document(id.text.toString())
                        .update("img4url", fo1edit)
                        .addOnSuccessListener {
                            db.collection("suppliers").document(id.text.toString())
                                    .update("img4n", fon1edit)
                                    .addOnCompleteListener {
                                        db.collection("suppliers").document(id.text.toString())
                                                .update("img4urlhigh", fo1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("suppliers").document(id.text.toString())
                                                            .update("img4nhigh", fon1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (fifn1 != fifn1edit)) {
                db.collection("suppliers").document(id.text.toString())
                        .update("img5url", fif1edit)
                        .addOnSuccessListener {
                            db.collection("suppliers").document(id.text.toString())
                                    .update("img5n", fifn1edit)
                                    .addOnCompleteListener {
                                        db.collection("suppliers").document(id.text.toString())
                                                .update("img5urlhigh", fif1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("suppliers").document(id.text.toString())
                                                            .update("img5nhigh", fifn1edithigh)

                                                }
                                    }

                        }
            }
        }
        else{
            if(suppsel.isEmpty()) {

            val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
            i.putExtra("frm_main", "main")
            i.putExtra("addsupp", addsupp)
            i.putExtra("editsupp", editesupp)
            i.putExtra("deletesupp", deletesupp)
            i.putExtra("viewsupp", viewsupp)
            i.putExtra("importsupp", importsupp)
            i.putExtra("exportsupp", exportsupp)
            startActivity(i)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

            finish()
            }
            else if(suppsel.isNotEmpty()){
                finish()
            }
        }
    }





    ///AUTO GENERTE ID FUNCTION

    private fun onStarClicked1() {
         pDialogs = SweetAlertDialog(this,SweetAlertDialog.PROGRESS_TYPE);
        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialogs!!.setTitleText("Saving...");
        pDialogs!!.setCancelable(false);
        pDialogs!!.show();
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("supplier_counter")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value
                supp_insert(id.toString())


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }



    fun supp_insert(supid1: String) {

        if (supp_imgurl.text == "") {
            supp_imgurl.text = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
        }

        val emailInput =supp_email.text.toString().trim();
        val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        if (emailInput.matches(emailPattern.toRegex())) {


        } else {
            if(supp_email.text.toString().isNotEmpty()==true)
            {
                Toast.makeText(this@SupplierAddMain, "Invalid email address",Toast.LENGTH_SHORT).show();
                supp_mailerr.visibility = View.VISIBLE
                supp_mailerr.setText("Invalid email")
            }
            else{

            }


        }

        if (supp_nm.length() == 0) {
            supperrnm.visibility = View.VISIBLE

            supperrnm.setText("Required field*")
        }
        if (supp_mobile.length() == 0) {
            supp_phoneerr.visibility = View.VISIBLE

            supp_phoneerr.setText("Required field*")
        }

        var idmy=supp_savekey.text.toString()
        var suppname = (supp_nm.text).toString()
        var suppid = "SPL"+supid1

        var suppmobcat1 = supp_mob.selectedItem.toString()
        var suppmobcat2 = supp_mob1.selectedItem.toString()
        var suppmobcat3 = supp_mob2.selectedItem.toString()
        var suppmobcat4=supp_mob3.selectedItem.toString()

        var suppaddress1 = (supp_address.text).toString()
        var suppmobile = (supp_mobile.text).toString()
        var suppmobile21 = (supp_mobile1.text).toString()
        var suppmobile31 = (supp_mobile2.text).toString()
        var suppmobile41 = (supp_mobile3.text).toString()
        var suppaddress2 = (supp_address2.text).toString()
        var suppaddress3 = (supp_address3.text).toString()
        var suppcity = (supp_city.text).toString()
        var suppstate = (supp_state.text).toString()
        var supppin = (supp_pin.text).toString()
        var contactprs = (supp_conpers.text).toString()
        var saveky = (supp_savekey.text).toString()
        var prodky = (pro_savekey.text).toString()
        var suppemail = (supp_email.text).toString()
        var gps=(supp_gps.text).toString()

        var suppgst = (supp_gstcode.text).toString()
        var suppimglink = (supp_imgurl.text).toString()
        var status = (statussup.text).toString()
        if(f1.isEmpty()){

        }
        val img1n=fn1
        val img2n=sn1
        val img3n=tn1
        val img4n=fon1
        val img5n=fifn1



        val img1url=f1
        val img2url=s1
        val img3url=t1
        val img4url=fo1
        val img5url=fif1

        val data = c(spnm = suppname, spid = suppid, spaddress1 = suppaddress1, spaddress2 = suppaddress2,spcontact_person = contactprs,
                spaddress3 = suppaddress3, spcity = suppcity, spstate = suppstate, sppincode = supppin, spemail = suppemail,
                spgst = suppgst, spmob1 = suppmobile, spmob2 = suppmobile21,status = status, spmob3 = suppmobile31, spmob4 = suppmobile41,
                spimglink = suppimglink, spmobcat1 = suppmobcat1, spmobcat2 = suppmobcat2, spmobcat3 = suppmobcat3, spmobcat4 = suppmobcat4,prodkey = prodky,
                sppgpsco_or = gps,img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n,
                img1url = img1url, img2url = img2url, img3url = img3url, img4url = img4url, img5url = img5url,img1nhigh = img1nhigh,
                img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,img1urlhigh = img1urlhigh,
                img2urlhigh = img2urlhigh,img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)



            var db = FirebaseFirestore.getInstance()
        val isInserted = myDb.insertData(idmy,suppname,suppid,suppmobcat1,suppmobcat2,suppmobcat3,
                suppmobile,suppmobile21,suppmobile31,suppmobile41,suppaddress1,suppaddress2,suppaddress3,
                suppcity,suppstate,supppin,gps,suppemail,contactprs,suppgst,suppimglink,prodky,status,
                img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,img1nhigh,
                img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,suppmobcat4)

        if (isInserted == true){
            }
        else{
           }

            db.collection("suppliers").document(supp_savekey.text.toString())
                    .set(data)
                    .addOnSuccessListener { documentReference ->

                        if(suppsel.isEmpty()) {

                        Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()

                        pDialogs!!.dismiss()

                        val i = Intent(this@SupplierAddMain, SupplierListFirstMAin::class.java)
                        i.putExtra("frm_main", "main")
                        i.putExtra("addsupp", addsupp)
                        i.putExtra("editsupp", editesupp)
                        i.putExtra("deletesupp", deletesupp)
                        i.putExtra("viewsupp", viewsupp)
                        i.putExtra("importsupp", importsupp)
                        i.putExtra("exportsupp", exportsupp)

                        startActivity(i)
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                        finish()
                        }
                        else if(suppsel.isNotEmpty()){
                            finish()
                        }

                    }

                    .addOnFailureListener { e ->
                        Log.w(TAG, "Error adding document", e)
                        Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                        save_progress.visibility = android.view.View.GONE
                    }


    }
    fun net_status():Boolean{  ///Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

    companion object {
        //Listens inetrnet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        private var bottnav: LinearLayout? = null
        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis:RelativeLayout?=null
        private var constraintLayout3dis:ConstraintLayout?=null
        private var consdis:ConstraintLayout?=null
        private var scroll2_sliderdis:SliderLayout?=null
        private var scroll2_slider2dis:SliderLayout?=null
        private var gallerydis:ImageButton?=null

        private var editdis:ImageButton?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                                                //And some views will be disabled when net is off


                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                bottnav!!.visibility=View.GONE
                relativeslayoutdis!!.visibility=View.VISIBLE
                constraintLayout3dis!!.visibility=View.VISIBLE
                scroll2_sliderdis!!.isEnabled=false
                scroll2_slider2dis!!.isEnabled=false
                gallerydis!!.isEnabled=false
                for (i  in 0 until consdis!!.getChildCount()) {
                    val child = consdis!!.getChildAt(i);
                    child.setEnabled(false);
                }
                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }

            }
            else
            {

                                                //And some views will be enabled when net is on

                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                bottnav!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.GONE
                constraintLayout3dis!!.visibility=View.GONE
                scroll2_sliderdis!!.isEnabled=true
                scroll2_slider2dis!!.isEnabled=true
                gallerydis!!.isEnabled=true
                for (i  in 0 until consdis!!.getChildCount()) {
                    val child = consdis!!.getChildAt(i);
                    child.setEnabled(true);
                }
            }
        }
    }


    fun popup(st:String){   //Access denied popup
        val pop= android.support.v7.app.AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }
}
    /*fun getImageView(): ImageView {
        val imageView = findViewById<ImageView>(R.id.card) as ImageView
        return imageView
    }

    override fun onPickResult(r: PickResult) {

        if (r.error == null) {
            //If you want the Uri.
            //Mandatory to refresh image from Uri.
            //getImageView().setImageURI(null);

            //Setting the real returned image.
            //getImageView().setImageURI(r.getUri());

            //If you want the Bitmap.

            getImageView().setImageBitmap(r.bitmap)


            val storage = FirebaseStorage.getInstance()
            val storageRef = storage.getReference()
            val generator = Random()
            var n = 100
            n = generator.nextInt(n)
            val imname = "ourimages-$n.jpg"
            val imagesRef = storageRef.child(imname)

//
//
//            // Get the data from an ImageView as bytes
            card.isDrawingCacheEnabled = true
            card.buildDrawingCache()
            val bitmap = card.drawingCache

            val baos = ByteArrayOutputStream()

            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)


            val data = baos.toByteArray()
            val uploadTask = imagesRef.putBytes(data)

            uploadTask.addOnFailureListener(OnFailureListener {
                // Handle unsuccessful uploads
            }).addOnSuccessListener(OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->

               *//* scrollprog.visibility = View.GONE*//*
                val ur = taskSnapshot.downloadUrl

                supp_imgurl.text = ur.toString()
                Toast.makeText(applicationContext, "URL :" + Uri.PARCELABLE_WRITE_RETURN_VALUE, Toast.LENGTH_SHORT).show()



                val localFile: File = File.createTempFile("images21", "jpg")

                imagesRef.getFile(localFile)
                        .addOnSuccessListener {
                            val bmp = BitmapFactory.decodeFile(localFile.absolutePath)
                            card.setImageBitmap(bmp)

                            val root = Environment.getExternalStorageDirectory().toString()
                            val myDir = File(root + "/Firebase Bucket Profile Images")
                            myDir.mkdirs()
                            val generator = Random()
                            var n = 10000
                            n = generator.nextInt(n)
                            val fname = "Firebaseimages-$n.jpg"
                            val file = File(myDir, fname)
                            if (file.exists())
                                file.delete()
                            try {
                                val out = FileOutputStream(file)
                                bmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
                                out.flush()
                                out.close()

                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                            *//*val root1 = Environment.getExternalStorageDirectory().toString()
                            val myDir1= File(root1 + "/CSV Reports")
                            myDir.mkdirs()
                            val generator1 = Random()
                            var n1 = 10000
                            n1 = generator1.nextInt(n1)
                            val fname1 = "Reports-$n.csv"
                            val file1 = File(myDir1, fname1)
                            if (file.exists())
                                file.delete()*//*

                        }
                        .addOnFailureListener { exception ->

                            Toast.makeText(this, exception.message, Toast.LENGTH_LONG).show()
                        }
                        .addOnProgressListener { taskSnapshot ->
                            // progress percentage
                            val progress = 100.0 * taskSnapshot.bytesTransferred / taskSnapshot.totalByteCount

                            // percentage in progress
                            val intProgress = progress.toInt()

                        }
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                val downloadUrl = taskSnapshot.downloadUrl

            })
            uploadTask.addOnProgressListener { taskSnapshot ->


            }.addOnPausedListener { println("Upload is paused") }


            //Image path
            r.getPath();
        } else {
            //Handle possible errors
            //TODO: do what you have to do with r.getError();
            Toast.makeText(this, r.error.message, Toast.LENGTH_LONG).show()
        }
        // Reference to an image file in Firebase Storage


    }


    fun selectpic(view:View)
    {
        PickImageDialog.build(PickSetup()).show(this)
    }*/
