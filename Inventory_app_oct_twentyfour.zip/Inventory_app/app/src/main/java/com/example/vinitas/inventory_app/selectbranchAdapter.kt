package com.example.vinitas.inventory_app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.vinitas.inventory_app.R.id.view
import de.hdodenhof.circleimageview.CircleImageView

/**
 * Created by vinitas stock on 04-01-2018.
 */
class selectbranchAdapter(
        private val context: Activity,
        private val bid: Array<String>,
        private val bn: Array<String>,
        private val loc: Array<String>
      /*  private val dpic: Array<Int>*/) : ArrayAdapter<Any>(context,R.layout.selectbranch_list,bn){
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.selectbranch_list, null, true)
        val branchid = rowView.findViewById<TextView>(R.id.branchid) as TextView
        val branchname = rowView.findViewById<TextView>(R.id.branchname) as TextView
        val location = rowView.findViewById<TextView>(R.id.location) as TextView
/*        val dp = rowView.findViewById<CircleImageView>(R.id.dp) as CircleImageView*/
        branchid.text=bid[position]
        branchname.text = bn[position]
        location.text = loc[position]
        /*dp.setImageResource(dpic[position])*/
        return rowView
    }
}