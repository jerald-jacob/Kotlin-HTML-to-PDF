package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_inventory_settings.*

class Inventory_settings : AppCompatActivity() {





    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory_settings)

net_status()//Check net status




        var bundle=intent.extras
        val k=bundle.get("mids").toString()

        isback.setOnClickListener {

            finish()
        }
        service_cat.setOnClickListener {//Navigate to service category list
            val b = Intent(applicationContext,serv_cat_list::class.java)
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

        }
        product_cat.setOnClickListener {//Navigate to product category list
            val b =  Intent(applicationContext,product_cat_activity::class.java)
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

        }
        manu_cat.setOnClickListener {//Navigate to manufacturer category list
            val b =  Intent(applicationContext,manufacturer_cat_list::class.java)
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

        }
        units_cat.setOnClickListener {//Navigate to Units category list
            val b =  Intent(applicationContext,units_cat_list::class.java)
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

        }
    }

    fun net_status():Boolean{//Check internet status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
