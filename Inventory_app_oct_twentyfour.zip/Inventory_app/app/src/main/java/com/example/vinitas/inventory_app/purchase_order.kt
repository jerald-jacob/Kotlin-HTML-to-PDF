package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import kotlinx.android.synthetic.main.purchase_update.*
import java.text.DecimalFormat
import java.util.*

class Purchase_orderMainActivity : AppCompatActivity() {

    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    var descriplistener=String()
    var listListener=String()



    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""


    var supplieridfr=String()


    var brnchidss = String()
    var editchange= String()

    var groschk= String()
    var suppinv=""



    var fd:Int?=null
    var fgh:Int?=null

    var ids=arrayOf<String>()

    var pzsave:Int = 0
    var asave=arrayListOf<String>()
    var dsysave=arrayListOf<String>()
    var fysave=arrayListOf<String>()
    var gysave=arrayListOf<String>()
    var hysave=arrayListOf<String>()
    var kysave=arrayListOf<String>()
    var kygrosave=arrayListOf<String>()

    var cysave=arrayListOf<String>()
    var sysave=arrayListOf<String>()

    var mysave=arrayListOf<String>()
    var nysave=arrayListOf<String>()
    var oysave=arrayListOf<String>()
    var pysave=arrayListOf<String>()
    var tallysave=arrayListOf<String>()
    var receivedsave=arrayListOf<String>()
    var idddsave= arrayListOf<String>()
    var lysave= arrayListOf<String>()
    var immysave= arrayListOf<String>()
    var idprokysave= arrayListOf<String>()
    var sprisave    =  arrayListOf<String>()
    var stotsave =arrayListOf<String>()
    var staxtsave =arrayListOf<String>()
    var sgrosssave =arrayListOf<String>()
    var scesstotsave =arrayListOf<String>()

    var nms = String()

    var ph = String()
    var reqliid = String()
    var reprnms = String()
    var pono = String()
    var recstatus = String()
    var reqdt = String()
    var desc = String()
    var orddate = String()
    var postatus = String()
    var recprice = String()
    var rectoal = String()
    var recquant = String()
    var reccesstot = String()
    var rectaxtot = String()
    var recgrosstot = String()
    var idli = String()
    var brky = String()
    var tallyar = String()
    var receivear = String()





    var orddatedup=String()
    var reqdatedup=String()
    var descripdup=String()



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.purchase_update)



        net_status()            //Check internet status.



        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Purchase_orderMainActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }



        //Define No connection view and other views when inetrnet connection is off.


        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        req_updatedis=findViewById(R.id.pur_update)
        editdisab=findViewById(R.id.edit)
        userbackdis=findViewById(R.id.userback)
        purpridis=findViewById(R.id.purpri)
        quan_receiveddis=findViewById(R.id.quan_received)
        scrollView2dis=findViewById(R.id.scrollView2)

        tax_tot1dis=findViewById(R.id.tax_tot1)
        quan_req_firstdis=findViewById(R.id.quan_req_first)

        val layout = findViewById(R.id.scrollView2) as ScrollView
        val observer = layout.viewTreeObserver
        observer.addOnGlobalLayoutListener {


            val viewHeight = layout.getMeasuredHeight()
            val contentHeight = layout.getChildAt(0).getHeight()

            println("CONTAINR HEIGHT" + viewHeight)
            println("DEVICE HEIGHT" + contentHeight)

            if (viewHeight - contentHeight < 0) {     //arrow mark displays for scrollabe screens.
                // scrollable
                img_arrow.visibility = View.VISIBLE

            }
        }

        img_arrow.setOnClickListener {   // click arrow to scroll down automattically

            layout.scrollTo(0, layout.getBottom());

        }


        val bundle = intent.extras
        var frm = bundle!!.get("from_pur").toString()












        edit.setOnClickListener {
            println("EDT PERMISSION" + editepurord)
            if (editepurord == "true") {

                edit.visibility = View.GONE
                pur_update.visibility = View.VISIBLE
                edclick="click"



                purpri.isEnabled = true
                quan_received.isEnabled = true

            } else if (editepurord == "false") {
                popup("Receive")
            }
        }



        //Get purchase order details from (PurcathirdMainActivity)

        var a = bundle.get("pnm") as ArrayList<String>
        println(a)
        /*     val b=bundle.get("id") as Array<SListtListring>*/

        val dsy = bundle.get("phsn") as ArrayList<String>
        val ly = bundle.get("pmanu") as ArrayList<String>
        val fy = bundle.get("barcode") as ArrayList<String>
        val gy = bundle.get("quan") as ArrayList<String>
        val hy = bundle.get("price") as ArrayList<String>
        val ky = bundle.get("tot") as ArrayList<String>
        val kygro = bundle.get("grosstot") as ArrayList<String>

        val my = bundle.get("cessup") as ArrayList<String>
        val ny = bundle.get("igst") as ArrayList<String>
        val cy = bundle.get("cgst") as ArrayList<String>
        val sy = bundle.get("sgst") as ArrayList<String>
        val oy = bundle.get("igsttotal") as ArrayList<String>
        val py = bundle.get("cesstotarray") as ArrayList<String>
        val iddd = bundle.get("idsofli") as ArrayList<String>
        val idtally = bundle.get("tallyarray") as ArrayList<String>
        val idrec = bundle.get("receivedarray") as ArrayList<String>
        println("REEECCCCIIIEEEVVVVEEE" + (idrec))
        val spri = bundle.get("received_price") as ArrayList<String>
        val stot = bundle.get("received_total") as ArrayList<String>
        val staxt = bundle.get("received_taxtot") as ArrayList<String>
        val scesstot = bundle.get("received_cesstot") as ArrayList<String>
        val sgross = bundle.get("received_grosstot") as ArrayList<String>
        val immy = bundle.get("image") as ArrayList<String>
        val idpros = bundle.get("idpro") as ArrayList<String>

        try {
            ids = bundle.get("ids") as Array<String>
        }
        catch(e:Exception){

        }

        asave = a
        dsysave = dsy
        cysave = cy
        sysave = sy
        fysave = fy
        gysave = gy
        hysave = hy
        kysave = ky
        kygrosave = kygro

        mysave = my
        nysave = ny
        oysave = oy
        pysave = py
        tallysave = idtally
        receivedsave = idrec
        idddsave = iddd
        immysave = immy
        idprokysave = idpros
        lysave = ly
        sprisave = spri
        stotsave = stot
        staxtsave = staxt
        scesstotsave = scesstot
        sgrosssave = sgross


        //Purchase order

        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord = intent.getStringExtra("viewpurord")
        val tranord = intent.getStringExtra("transferpurord")
        val exord = intent.getStringExtra("exportpurord")
        sendpurpo = intent.getStringExtra("sendpurord")

        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }


        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr = intent.getStringExtra("viewpurreq")
        val tranpr = intent.getStringExtra("transferpurreq")
        val expr = intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr
        }
        if (expr != null) {
            exportpurreq = expr
        }


        try {
            orddatedup = intent.getStringExtra("orddatedup")
            reqdatedup = intent.getStringExtra("reqdatedup")
            descripdup = intent.getStringExtra("descripdup")
        } catch (e: Exception) {

        }

        try {
            descriplistener = intent.getStringExtra("descriplistener")
            listListener = intent.getStringExtra("listListener")

        }
        catch (e:Exception){

        }



        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin = intent.getStringExtra("viewsuppin")
        val transuppin = intent.getStringExtra("transfersuppin")
        val exsuppin = intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }



        try {
            val e = intent.getStringExtra("desc")
            desc = e
            val f = intent.getStringExtra("reqdate")
            reqdt = f
            val ff = intent.getStringExtra("orddate")
            orddate = ff

            val stat = intent.getStringExtra("postatus")
            postatus = stat
            println("PO STATUSSS" + postatus)
        } catch (e: Exception) {

        }
        val aa = intent.getStringExtra("nms")
        comttname.setText(aa)
        val liis = intent.getStringExtra("reqliid")
        reqliid = liis
        val b = intent.getStringExtra("ph")
        comphone.setText(b)
        val lii = intent.getStringExtra("pono")
        pono = lii

        val nm = intent.getStringExtra("reprnms")
        reprnms = nm

        val bridd = intent.getStringExtra("brids")
        brnchidss = bridd

        val grochk = intent.getStringExtra("groschk")
        groschk = grochk


        try{
            supplieridfr=intent.getStringExtra("supplieridfr")
        }
        catch (e:Exception){

        }


        try{
            edclick=intent.getStringExtra("edclick")
        }
        catch (e:Exception){

        }


        if(edclick.isEmpty()){
            edit.visibility=View.VISIBLE
            pur_update.visibility = View.INVISIBLE
            purpri.isEnabled = false
            quan_received.isEnabled = false

        }
        else if(edclick.isNotEmpty()||edclick=="click"){
            edit.visibility=View.GONE
            pur_update.visibility = View.VISIBLE
            purpri.isEnabled = true
            quan_received.isEnabled = true
        }


        try{

            suppinv=intent.getStringExtra("suppinv")

        }
        catch (e:Exception){

        }



        val pz = bundle.get("pos") as Int
        pzsave = pz

        var prname = a[pz]
        prd_nm.setText(prname)


        //quantity
        var quant = gy[pz]
        var qu: Int
        qu = quant.toInt()

        quan_req_first.setText(quant)


        //total
        var totalof = ky[pz]
        total.setText(totalof)
        var prtot: Float
        prtot = totalof.toFloat()


        //total
        var totalgroof = kygro[pz]

        var prtotgro: Float
        prtotgro = totalgroof.toFloat()
        gross_tot.setText((String.format("%.2f",totalgroof.toFloat())))

        //hsn code
        var prord = dsy[pz]
        purhsn.setText(prord)
        //price
        var price = hy[pz]

        var pr: Float
        pr = price.toFloat()




        println("PRI"+pr)
        var prsuf=pr.toString()

        var praddzr=String()
        if((pr.toString().endsWith(".1"))||(pr.toString().endsWith(".2"))||(pr.toString().endsWith(".3"))||(pr.toString().endsWith(".4"))
                ||(pr.toString().endsWith(".5"))||(pr.toString().endsWith(".6"))||(pr.toString().endsWith(".7"))||
                (pr.toString().endsWith(".8")) ||(pr.toString().endsWith(".9"))){
            var przr=pr.toString()
            praddzr=przr+"0"
        }
        else{
            praddzr=pr.toString()

        }

        if((prsuf.toString().endsWith(".0"))&&((hy[pz].endsWith(".00")))){
            var ff=prsuf.removeSuffix(".0")
            var kl=ff+".00"
            println("PRI REMOVE"+ff)
            purpri.setText(kl.toString())

            purch_pri.setText(kl.toString())
        }
        else if((prsuf.toString().endsWith(".0"))&&((!hy[pz].endsWith(".00")))){
            var ff=prsuf.removeSuffix(".0")
            var kl=ff+".00"
            println("PRI REMOVE"+ff)
            purpri.setText(ff.toString())

            purch_pri.setText(ff.toString())
        }
        else{

            purpri.setText(praddzr.toString())

            purch_pri.setText(praddzr.toString())
        }


        //barcode
        var bar = fy[pz]
        bcd_pid.setText(bar)


        //cess
        var cssof = my[pz]
        cess_edt.setText(cssof)

        ///IGST
        var igstof = ny[pz]
        igst_edt.setText(igstof)

        //CGST
        var cgstof = cy[pz]
        cgst_edt.setText(cgstof)

        //SGST
        var sgstof = sy[pz]
        scgst_edt.setText(sgstof)


        var igsttotof = oy[pz]
        tax_tot.setText((String.format("%.2f",igsttotof.toFloat())))


        var cesstotof = py[pz]
        cess_amt1.setText((String.format("%.2f",cesstotof.toFloat())))

        var idof = iddd[pz]
        newid.setText(idof)
        idli = newid.text.toString()

        var tally = idtally[pz]
        tallyarr.setText(tally)

        var receive = idrec[pz]
        println("Received count" + receive)
        quan_received.setText(receive)


        var receivepri = spri[pz]
        recprice = receivepri



        var receivetot = stot[pz]
        rectoal = receivetot
        total_two.setText((String.format("%.2f",receivetot.toFloat())))


        var receivetaxtot = staxt[pz]

        taxtotdup=receivetaxtot

        if(receivetaxtot=="00.00"){
            quan_req_first.isEnabled=true
        }

        tax_tot1.setText((String.format("%.2f",receivetaxtot.toFloat())))

        var receivegrosstot = sgross[pz]
        gross_tot1.setText((String.format("%.2f",receivegrosstot.toFloat())))

        var receivecesstot = scesstot[pz]
        cess_amt.setText((String.format("%.2f",receivecesstot.toFloat())))



        prd_nm.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                errnm.visibility = View.INVISIBLE


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {


            }

            override fun afterTextChanged(s: Editable) {
            }
        })


        //Quantity textchangelistener calculates price ,tax,total..,

        quan_req_first.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {

                errqnt.visibility = View.INVISIBLE
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 1F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }
                if (purpri.text.isEmpty()) {
                    prq = 0.0F
                } else {
                    prq = purpri.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq * pri) * (igst / 100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (prq * pri) * (ces / 100)
                cess_amt1.setText("$cesstot")

                val fitot = ttot + cesstot + (prq * pri)
                gross_tot.setText((String.format("%.2f",fitot)))

                var k = purpri.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                total.setText((String.format("%.2f",f)))


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {

                var prq: Float;
                var igst: Float;
                var ces: Float;
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 1F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }
                if (purpri.text.isEmpty()) {
                    prq = 0.0F
                } else {
                    prq = purpri.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq * pri) * (igst / 100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (prq * pri) * (ces / 100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot + (prq * pri)
                gross_tot.setText((String.format("%.2f",fitot)))

                var k = purpri.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                total.setText((String.format("%.2f",f)))


            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //Price textchangelistener calculates price ,tax,total..,
        purpri.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                errpri.visibility = View.INVISIBLE
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                total.setText("")
                gross_tot.setText("")
                purch_pri.setText(pr)
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 0F

                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }

                if (quan_req_first.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_req_first.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }


                var k = quan_req_first.text.toString()
                var l = pri.toBigDecimal()
                val oi = k.toBigDecimal()
                val f = l.times(oi)
                total.setText((String.format("%.2f",f)))
                total_two.setText((String.format("%.2f",f)))
                tax_tot.setText((String.format("%.2f",f.toFloat())))

                //IGST TOTAL
                val ttot = (pri * qty) * (igst / 100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot + (pri * qty)
                gross_tot.setText((String.format("%.2f",fitot)))


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                purch_pri.setText(pr)
                total.setText("")
                gross_tot.setText("")
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 0F

                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }

                if (quan_req_first.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_req_first.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }


                var k = quan_req_first.text.toString()
                var l = pri.toBigDecimal()
                val oi = k.toBigDecimal()
                val f = l.times(oi)
                total.setText((String.format("%.2f",f)))
                total_two.setText((String.format("%.2f",f)))
                tax_tot.setText((String.format("%.2f",f.toFloat())))

                //IGST TOTAL
                val ttot = (pri * qty) * (igst / 100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot + (pri * qty)
                gross_tot.setText((String.format("%.2f",fitot)))
            }

            override fun afterTextChanged(s: Editable) {
            }
        })
        bcd_pid.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })
        purhsn.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

//cess_edt textchangelistener calculates price ,tax,total..,
        cess_edt.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {
                var pri: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                if (purpri.text.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = purpri.text.toString().toFloat()
                }
                if (quan_req_first.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_req_first.text.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = igst_edt.text.toString().replace("%", "").toFloat()
                }
                if (cess.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                cgst_edt.setText("$ans" + "%")
                scgst_edt.setText("$ans" + "%")

                //tax total
                val ttot = (pri * qty) * (igst / 100)
                tax_tot.setText((String.format("%.2f",ttot)))

                //cess total
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                //gross total
                val fitot = ttot + cesstot + (pri * qty)
                gross_tot.setText((String.format("%.2f",fitot)))


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })
        //igst_edt textchangelistener calculates price ,tax,total..,

        igst_edt.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                var pri: Float;
                var prirec: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                var qtyrec: Float;
                if ((purpri.text.isEmpty()) && (purch_pri.text.isEmpty())) {
                    pri = 0.0F
                    prirec = 0.0F
                } else {
                    pri = purpri.text.toString().toFloat()
                    prirec = purch_pri.text.toString().toFloat()
                }
                if ((quan_req_first.text.isEmpty()) && (quan_received.text.isEmpty())) {
                    qty = 1.0F
                    qtyrec = 1.0F
                } else {
                    qty = quan_req_first.text.toString().toFloat()
                    qtyrec = quan_received.text.toString().toFloat()
                }
                if (ig.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = ig.toString().replace("%", "").toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                cgst_edt.setText("$ans" + "%")
                scgst_edt.setText("$ans" + "%")

                //tax total
                val ttot = (pri * qty) * (igst / 100)
                tax_tot.setText((String.format("%.2f",ttot)))

                val ttotrec = (prirec * qtyrec) * (igst / 100)
                tax_tot1.setText((String.format("%.2f",ttotrec)))

                //cess total
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                val cesstotrec = (prirec * qtyrec) * (ces / 100)
                cess_amt.setText((String.format("%.2f",cesstotrec)))

                //gross total
                val fitot = ttot + cesstot + (pri * qty)
                gross_tot.setText((String.format("%.2f",fitot)))

                val fitotrec = ttotrec + cesstotrec + (prirec * qtyrec)
                gross_tot1.setText((String.format("%.2f",fitotrec)))


            }

            override fun beforeTextChanged(ig: CharSequence, start: Int, count: Int, after: Int) {
                var pri: Float;
                var prirec: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                var qtyrec: Float;
                if ((purpri.text.isEmpty()) && (purch_pri.text.isEmpty())) {
                    pri = 0.0F
                    prirec = 0.0F
                } else {
                    pri = purpri.text.toString().toFloat()
                    prirec = purch_pri.text.toString().toFloat()
                }
                if ((quan_req_first.text.isEmpty()) && (quan_received.text.isEmpty())) {
                    qty = 1.0F
                    qtyrec = 1.0F
                } else {
                    qty = quan_req_first.text.toString().toFloat()
                    qtyrec = quan_received.text.toString().toFloat()
                }
                if (ig.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = ig.toString().replace("%", "").toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                cgst_edt.setText("$ans" + "%")
                scgst_edt.setText("$ans" + "%")

                //tax total
                val ttot = (pri * qty) * (igst / 100)
                tax_tot.setText((String.format("%.2f",ttot)))

                val ttotrec = (prirec * qtyrec) * (igst / 100)
                tax_tot1.setText((String.format("%.2f",ttotrec)))

                //cess total
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt1.setText((String.format("%.2f",cesstot)))

                val cesstotrec = (prirec * qtyrec) * (ces / 100)
                cess_amt.setText((String.format("%.2f",cesstotrec)))

                //gross total
                val fitot = ttot + cesstot + (pri * qty)
                gross_tot.setText((String.format("%.2f",fitot)))

                val fitotrec = ttotrec + cesstotrec + (prirec * qtyrec)
                gross_tot1.setText((String.format("%.2f",fitotrec)))


            }

            override fun afterTextChanged(s: Editable) {
            }
        })



        try {
            orddatedup = intent.getStringExtra("orddatedup")
            reqdatedup = intent.getStringExtra("reqdatedup")
            descripdup = intent.getStringExtra("descripdup")
        } catch (e: Exception) {

        }
        try {
            descriplistener = intent.getStringExtra("descriplistener")
            listListener = intent.getStringExtra("listListener")

        }
        catch (e:Exception){

        }


        cgst_edt.isEnabled = false
        scgst_edt.isEnabled = false
        igst_edt.isEnabled = false


        igst_radio.setOnClickListener {
            if (igst_radio.isChecked == true) {
                csgst_radio.isChecked = false
                igst_edt.isEnabled = true
                cgst_edt.setHintTextColor(Color.parseColor("#99546e7a"));
                scgst_edt.setHintTextColor(Color.parseColor("#99546e7a"));
                cgst_edt.isEnabled = false
                scgst_edt.isEnabled = false
                igst_edt.setHintTextColor(Color.parseColor("#546e7a"));
            }
        }
        csgst_radio.setOnClickListener {
            if (csgst_radio.isChecked == true) {
                igst_radio.isChecked = false
                cgst_edt.setHintTextColor(Color.parseColor("#546e7a"));
                scgst_edt.setHintTextColor(Color.parseColor("#546e7a"));
                cgst_edt.isEnabled = true
                scgst_edt.isEnabled = true
                igst_edt.isEnabled = false
                igst_edt.setHintTextColor(Color.parseColor("#99546e7a"));
            }
        }


        //Receive function


        //quan_received textchangelistener calculates price ,tax,total..,

        var tt = "Complete"
        quan_received.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 1F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }
                if (purch_pri.text.isEmpty()) {
                    prq = 0.0F
                } else {
                    prq = purch_pri.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq * pri) * (igst / 100)
                tax_tot1.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (prq * pri) * (ces / 100)
                cess_amt.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot + (prq * pri)
                gross_tot1.setText((String.format("%.2f",fitot)))

                var k = purch_pri.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                total_two.setText((String.format("%.2f",f)))





            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {

                var prq: Float;
                var igst: Float;
                var ces: Float;
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 1F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }
                if (purch_pri.text.isEmpty()) {
                    prq = 0.0F
                } else {
                    prq = purch_pri.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq * pri) * (igst / 100)
                tax_tot1.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (prq * pri) * (ces / 100)
                cess_amt.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot + (prq * pri)
                gross_tot1.setText((String.format("%.2f",fitot)))

                var k = purch_pri.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                total_two.setText(DecimalFormat("#.00").format(f))
                try {
                    if ((pr.toString().toInt() >= quan_req_first.text.toString().toInt())) {
                        tallyarr.setText(tt)
                        postatus = tallyarr.text.toString()
                        println("Received" + tallyarr.text)
                    } else if ((pr.toString().toInt() > 0) && (pr.toString().toInt() < quan_req_first.text.toString().toInt())) {
                        tallyarr.setText("Partially Complete")
                        postatus = tallyarr.text.toString()
                        println("Partially Received" + tallyarr.text)

                    } else if ((pr.toString().toInt() == 0)) {
                        tallyarr.setText("InComplete")
                        postatus = tallyarr.text.toString()
                        println("Partially Received" + tallyarr.text)

                    } else {
                        tallyarr.setText("InComplete")
                        postatus = tallyarr.text.toString()
                    }
                }
                catch (e:Exception){

                }
            }

            override fun afterTextChanged(s: Editable) {




try {
    if ((quan_received.text.toString().toInt() >= quan_req_first.text.toString().toInt())) {
        tallyarr.setText(tt)
        postatus = tallyarr.text.toString()
        println("Received" + tallyarr.text)
    } else if ((quan_received.text.toString().toInt() > 0) && (quan_received.text.toString().toInt() < quan_req_first.text.toString().toInt())) {
        tallyarr.setText("Partially Complete")
        postatus = tallyarr.text.toString()
        println("Partially Received" + tallyarr.text)

    } else if ((quan_received.text.toString().toInt() == 0)) {
        tallyarr.setText("InComplete")
        postatus = tallyarr.text.toString()
        println("Partially Received" + tallyarr.text)

    } else {
        tallyarr.setText("InComplete")
        postatus = tallyarr.text.toString()
    }
}
catch (e:Exception){

}

            }
        })



        purch_pri.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {

                recerrnm.visibility = View.INVISIBLE
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                total_two.setText("")
                gross_tot1.setText("")
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 0F

                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }

                if (quan_received.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_received.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }


                var k = quan_received.text.toString()
                try {
                    var l = pri.toBigDecimal()
                    val oi = k.toBigDecimal()
                    val f = l.times(oi)
                    total_two.setText(f.toString())
                    tax_tot1.setText((String.format("%.2f",f.toFloat())))
                } catch (e: Exception) {

                }


                //IGST TOTAL
                val ttot = (pri * qty) * (igst / 100)
                tax_tot1.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot + (pri * qty)
                gross_tot1.setText((String.format("%.2f",fitot)))


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                total_two.setText("")
                gross_tot1.setText("")
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 0F

                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }

                if (quan_received.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_received.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }


                var k = quan_received.text.toString()
                var l = pri.toBigDecimal()
                val oi = k.toBigDecimal()
                val f = l.times(oi)
                total_two.setText((String.format("%.2f",f)))
                tax_tot1.setText((String.format("%.2f",f.toFloat())))

                //IGST TOTAL
                val ttot = (pri * qty) * (igst / 100)
                tax_tot1.setText((String.format("%.2f",ttot)))

                //CESS TOTAL
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt.setText((String.format("%.2f",cesstot)))

                val fitot = ttot + cesstot + (pri * qty)
                gross_tot1.setText((String.format("%.2f",fitot)))
            }

            override fun afterTextChanged(s: Editable) {
            }
        })



        //----------------------------Update action-----------------------------------//

        pur_update.setOnClickListener {
            if (prd_nm.length() == 0) {
                errnm.visibility = View.VISIBLE

                errnm.setText("Required field*")
            }
            if (purpri.length() == 0) {
                errpri.visibility = View.VISIBLE

                errpri.setText("Required field*")
            }
            if (quan_req_first.length() == 0) {
                errqnt.visibility = View.VISIBLE

                errqnt.setText("Required field*")
            }
            if (purch_pri.length() == 0) {
                recerrnm.visibility = View.VISIBLE

                errqnt.setText("Required field*")
            }




            println("quan_received"+quan_received.text.toString())
            println("quan_req_first"+quan_req_first.text.toString())






            if ((errnm.visibility == View.INVISIBLE) && (errpri.visibility == View.INVISIBLE) && (errqnt.visibility == View.INVISIBLE) && (recerrnm.visibility == View.INVISIBLE) && (transferpurord == "true")) {

                if(quan_received.text.toString().isNotEmpty()){


                    //-----------------------navigate to 'PurcathirdMainActivity'----------------------------//

                        if((hysave[pzsave]!=purpri.text.toString())||(receivedsave[pzsave]!=quan_received.text.toString())||(gysave[pzsave]!=quan_req_first.text.toString())) {
                            groschk = "edited"
                            editchange = "changed"
                        }
                        val o = Intent(this@Purchase_orderMainActivity, PurcathirdMainActivity::class.java)



                        o.putExtra("from_pur", "update_purchase")
                        var dx = prd_nm.text
                        var ex = purhsn.text
                        var fx = purpri.text.toString()
                        var gx = quan_req_first.text
                        var hx = bcd_pid.text
                        var ix = total.text
                        var ixgro = gross_tot.text
                        var jx = cess_edt.text
                        var kx = igst_edt.text.toString()
                        var px = cgst_edt.text.toString()
                        var qx = scgst_edt.text.toString()
                        var lx = tax_tot.text
                        var mx = cess_amt1.text
                        var tallx = tallyarr.text
                        var receivex = quan_received.text
                        var recpri = purch_pri.text
                        var rectot = total_two.text
                        var rectaxtt = tax_tot1.text
                        var reccesstt = cess_amt.text
                        var recgrstt = gross_tot1.text



                        a[pz] = dx.toString()
                        dsy[pz] = ex.toString()
                        fy[pz] = hx.toString()
                        gy[pz] = gx.toString()
                        hy[pz] = fx.toString()
                        ky[pz] = ix.toString()
                        kygrosave[pz] = ixgro.toString()
                        my[pz] = jx.toString()
                        ny[pz] = kx.toString()
                        cy[pz] = px.toString()
                        sy[pz] = qx.toString()
                        oy[pz] = lx.toString()
                        py[pz] = mx.toString()
                        idtally[pz] = tallx.toString()
                        idrec[pz] = receivex.toString()
                        spri[pz] = recpri.toString()
                        stot[pz] = rectot.toString()
                        staxt[pz] = rectaxtt.toString()
                        sgross[pz] = recgrstt.toString()
                        scesstot[pz] = reccesstt.toString()





                        o.putExtra("renm", a)
                        o.putExtra("from_pur", "update_purchase")
                        o.putExtra("remanu", ly)
                        o.putExtra("rekey", iddd)
                        o.putExtra("rehsn", dsy)
                        o.putExtra("reprice", hy)
                        o.putExtra("requan", gy)
                        o.putExtra("rebc", fy)
                        o.putExtra("retotal", ky)
                        o.putExtra("regrosstotal", kygro)
                        o.putExtra("recess", my)
                        o.putExtra("reigst", ny)
                        o.putExtra("recgst", cy)
                        o.putExtra("resgst", sy)
                        o.putExtra("retally", idtally)
                        o.putExtra("rereceived", idrec)
                        o.putExtra("rereceived_pri", spri)
                        o.putExtra("rereceived_tot", stot)
                        o.putExtra("rereceived_taxtot", staxt)
                        o.putExtra("rereceived_cesstot", scesstot)
                        o.putExtra("rereceived_grosstot", sgross)
                        o.putExtra("reigst_total", oy)
                        o.putExtra("recesstotal", py)
                        o.putExtra("reimmg", immy)
                        o.putExtra("idpro", idpros)
                        o.putExtra("pono", pono)
                        o.putExtra("names", reprnms)
                        o.putExtra("redesc", desc)
                        o.putExtra("reorddate", orddate)
                        o.putExtra("reestdt", reqdt)
                        o.putExtra("restatus", postatus)
                        o.putExtra("groschk", groschk)
                        o.putExtra("reids", reqliid)
                        o.putExtra("titnm", comttname.text.toString())
                        o.putExtra("tiphone", comphone.text.toString())
                        o.putExtra("brids", brnchidss)

                    o.putExtra("edclick",edclick)
                    o.putExtra("suppinv",suppinv)

                    o.putExtra("supplieridfr",supplieridfr)

                        o.putExtra("descriplistener",descriplistener)
                        o.putExtra("listListener",listListener)


                        o.putExtra("viewsuppin", viewsuppin)
                        o.putExtra("addsuppin", addsuppin)
                        o.putExtra("deletesuppin", deletesuppin)
                        o.putExtra("editsuppin", editesuppin)
                        o.putExtra("transfersuppin", transfersuppin)
                        o.putExtra("exportsuppin", exportsuppin)


                        o.putExtra("viewpurord", viewpurord)
                        o.putExtra("addpurord", addpurord)
                        o.putExtra("deletepurord", deletepurord)
                        o.putExtra("editpurord", editepurord)
                        o.putExtra("transferpurord", transferpurord)
                        o.putExtra("exportpurord", exportpurord)
                        o.putExtra("sendpurord", sendpurpo)



                        o.putExtra("orddatedup", orddatedup)
                        o.putExtra("reqdatedup", reqdatedup)
                        o.putExtra("descripdup", descripdup)




                        o.putExtra("viewpurreq", viewpurreq)
                        o.putExtra("addpurreq", addpurreq)
                        o.putExtra("deletepurreq", deletepurreq)
                        o.putExtra("editpurreq", editepurreq)
                        o.putExtra("transferpurreq", transferpurreq)
                        o.putExtra("exportpurreq", exportpurreq)



                        o.putExtra("ids", ids)

                        startActivity(o)
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                        finish()


                    }

                else if(quan_received.text.toString().isEmpty()){
                    if((hysave[pzsave]!=purpri.text.toString())||(receivedsave[pzsave]!=quan_received.text.toString())||(gysave[pzsave]!=quan_req_first.text.toString())){
                        groschk="edited"
                        editchange="changed"
                    }

                    //-----------------------navigate to 'PurcathirdMainActivity'----------------------------//

                    val o = Intent(this@Purchase_orderMainActivity, PurcathirdMainActivity::class.java)



                    o.putExtra("from_pur", "update_purchase")
                    var dx = prd_nm.text
                    var ex = purhsn.text
                    var fx = purpri.text.toString()
                    var gx = quan_req_first.text
                    var hx = bcd_pid.text
                    var ix = total.text
                    var ixgro = gross_tot.text

                    var jx = cess_edt.text
                    var kx = igst_edt.text.toString()
                    var px = cgst_edt.text.toString()
                    var qx = scgst_edt.text.toString()
                    var lx = tax_tot.text
                    var mx = cess_amt1.text
                    var tallx = tallyarr.text
                    var receivex = quan_received.text
                    var recpri = purch_pri.text
                    var rectot = total_two.text
                    var rectaxtt = tax_tot1.text
                    var reccesstt = cess_amt.text
                    var recgrstt = gross_tot1.text



                    a[pz] = dx.toString()
                    dsy[pz] = ex.toString()
                    fy[pz] = hx.toString()
                    gy[pz] = gx.toString()
                    hy[pz] = fx.toString()
                    ky[pz] = ix.toString()
                    kygro[pz] = ixgro.toString()

                    my[pz] = jx.toString()
                    ny[pz] = kx.toString()
                    cy[pz] = px.toString()
                    sy[pz] = qx.toString()
                    oy[pz] = lx.toString()
                    py[pz] = mx.toString()
                    idtally[pz] = tallx.toString()
                    idrec[pz] = receivex.toString()
                    spri[pz] = recpri.toString()
                    stot[pz] = rectot.toString()
                    staxt[pz] = taxtotdup.toString()
                    sgross[pz] = recgrstt.toString()
                    scesstot[pz] = reccesstt.toString()





                    o.putExtra("renm", a)
                    o.putExtra("from_pur", "update_purchase")
                    o.putExtra("remanu", ly)
                    o.putExtra("rekey", iddd)
                    o.putExtra("rehsn", dsy)
                    o.putExtra("reprice", hy)
                    o.putExtra("requan", gy)
                    o.putExtra("rebc", fy)
                    o.putExtra("retotal", ky)
                    o.putExtra("regrosstotal", kygro)

                    o.putExtra("recess", my)
                    o.putExtra("reigst", ny)
                    o.putExtra("recgst", cy)
                    o.putExtra("resgst", sy)
                    o.putExtra("retally", idtally)
                    o.putExtra("rereceived", idrec)
                    o.putExtra("rereceived_pri", spri)
                    o.putExtra("rereceived_tot", stot)
                    o.putExtra("rereceived_taxtot", staxt)
                    o.putExtra("rereceived_cesstot", scesstot)
                    o.putExtra("rereceived_grosstot", sgross)
                    o.putExtra("reigst_total", oy)
                    o.putExtra("recesstotal", py)
                    o.putExtra("reimmg", immy)
                    o.putExtra("idpro", idpros)
                    o.putExtra("pono", pono)
                    o.putExtra("names", reprnms)
                    o.putExtra("redesc", desc)
                    o.putExtra("reorddate", orddate)
                    o.putExtra("reestdt", reqdt)
                    o.putExtra("restatus", postatus)
                    o.putExtra("groschk", groschk)
                    o.putExtra("reids", reqliid)
                    o.putExtra("titnm", comttname.text.toString())
                    o.putExtra("tiphone", comphone.text.toString())
                    o.putExtra("brids", brnchidss)
                    o.putExtra("supplieridfr",supplieridfr)

                    o.putExtra("descriplistener",descriplistener)
                    o.putExtra("listListener",listListener)

                    o.putExtra("suppinv",suppinv)

                    o.putExtra("viewsuppin", viewsuppin)
                    o.putExtra("addsuppin", addsuppin)
                    o.putExtra("deletesuppin", deletesuppin)
                    o.putExtra("editsuppin", editesuppin)
                    o.putExtra("transfersuppin", transfersuppin)
                    o.putExtra("exportsuppin", exportsuppin)

                    o.putExtra("edclick",edclick)

                    o.putExtra("viewpurord", viewpurord)
                    o.putExtra("addpurord", addpurord)
                    o.putExtra("deletepurord", deletepurord)
                    o.putExtra("editpurord", editepurord)
                    o.putExtra("transferpurord", transferpurord)
                    o.putExtra("exportpurord", exportpurord)
                    o.putExtra("sendpurord", sendpurpo)



                    o.putExtra("orddatedup", orddatedup)
                    o.putExtra("reqdatedup", reqdatedup)
                    o.putExtra("descripdup", descripdup)




                    o.putExtra("viewpurreq", viewpurreq)
                    o.putExtra("addpurreq", addpurreq)
                    o.putExtra("deletepurreq", deletepurreq)
                    o.putExtra("editpurreq", editepurreq)
                    o.putExtra("transferpurreq", transferpurreq)
                    o.putExtra("exportpurreq", exportpurreq)



                    o.putExtra("ids", ids)

                    startActivity(o)
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                    finish()


                }

                }
            else if (transferpurord == "false") {
                popup("Purchase order")
            } else {
                Toast.makeText(applicationContext, "Please fill required fields", Toast.LENGTH_SHORT).show()
            }


        }

        userback.setOnClickListener {

            onBackPressed()


        }
    }
    override fun onBackPressed() {

        groschk=""
        editchange=""
        println("PRICE  "+hysave[pzsave])
        println("RECEIVED PRICE  "+receivedsave[pzsave])




        if((hysave[pzsave]!=purpri.text.toString())||(receivedsave[pzsave]!=quan_received.text.toString())||(gysave[pzsave]!=quan_req_first.text.toString())){
            groschk="edited"
            editchange="changed"
        }

        if (editchange.isEmpty()) {
            val o = Intent(this@Purchase_orderMainActivity, PurcathirdMainActivity::class.java)

            o.putExtra("from_pur", "update_purchase")
            o.putExtra("renm", asave)

            o.putExtra("remanu", lysave)
            o.putExtra("rekey", idddsave)
            o.putExtra("rehsn", dsysave)
            o.putExtra("reprice", hysave)
            o.putExtra("requan", gysave)
            o.putExtra("rebc", fysave)
            o.putExtra("retotal", kysave)
            o.putExtra("regrosstotal", kygrosave)
            o.putExtra("supplieridfr",supplieridfr)

            o.putExtra("recess", mysave)
            o.putExtra("reigst", nysave)
            o.putExtra("recgst", cysave)
            o.putExtra("resgst", sysave)
            o.putExtra("retally", tallysave)
            o.putExtra("rereceived", receivedsave)
            o.putExtra("rereceived_pri", sprisave)
            o.putExtra("rereceived_tot", stotsave)
            o.putExtra("rereceived_taxtot", staxtsave)
            o.putExtra("rereceived_cesstot", scesstotsave)
            o.putExtra("rereceived_grosstot", sgrosssave)
            o.putExtra("reigst_total", oysave)
            o.putExtra("recesstotal", pysave)
            o.putExtra("reimmg", immysave)
            o.putExtra("idpro", idprokysave)
            o.putExtra("pono", pono)
            o.putExtra("names", reprnms)
            o.putExtra("redesc", desc)
            o.putExtra("reorddate", orddate)
            o.putExtra("reestdt", reqdt)
            o.putExtra("restatus", postatus)
            o.putExtra("groschk",groschk)
            o.putExtra("descriplistener",descriplistener)
            o.putExtra("listListener",listListener)
            o.putExtra("ids",ids)
            o.putExtra("reids", reqliid)
            o.putExtra("titnm", comttname.text.toString())
            o.putExtra("tiphone", comphone.text.toString())
            o.putExtra("brids", brnchidss)
            o.putExtra("suppinv",suppinv)


            o.putExtra("viewsuppin", viewsuppin)
            o.putExtra("addsuppin", addsuppin)
            o.putExtra("deletesuppin", deletesuppin)
            o.putExtra("editsuppin", editesuppin)
            o.putExtra("transfersuppin", transfersuppin)
            o.putExtra("exportsuppin", exportsuppin)


            o.putExtra("viewpurord", viewpurord)
            o.putExtra("addpurord", addpurord)
            o.putExtra("deletepurord", deletepurord)
            o.putExtra("editpurord", editepurord)
            o.putExtra("transferpurord", transferpurord)
            o.putExtra("exportpurord", exportpurord)
            o.putExtra("sendpurord", sendpurpo)

            o.putExtra("edclick",edclick)

            o.putExtra("orddatedup",orddatedup)
            o.putExtra("reqdatedup",reqdatedup)
            o.putExtra("descripdup",descripdup)

            o.putExtra("viewpurreq", viewpurreq)
            o.putExtra("addpurreq", addpurreq)
            o.putExtra("deletepurreq", deletepurreq)
            o.putExtra("editpurreq", editepurreq)
            o.putExtra("transferpurreq", transferpurreq)
            o.putExtra("exportpurreq", exportpurreq)


            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
        else if (editchange == "changed") {
            savepopup()

        }
        }

    fun savepopup() {
        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord = intent.getStringExtra("viewpurord")
        val tranord = intent.getStringExtra("transferpurord")
        val exord = intent.getStringExtra("exportpurord")

        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }
        val builder = AlertDialog.Builder(this@Purchase_orderMainActivity)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")

            setPositiveButton("Yes") { dialog, whichButton ->
                if (prd_nm.length() == 0) {
                    errnm.visibility = View.VISIBLE

                    errnm.setText("Required field*")
                }
                if (purpri.length() == 0) {
                    errpri.visibility = View.VISIBLE

                    errpri.setText("Required field*")
                }
                if (quan_req_first.length() == 0) {
                    errqnt.visibility = View.VISIBLE

                    errqnt.setText("Required field*")
                }
                if (purch_pri.length() == 0) {
                    recerrnm.visibility = View.VISIBLE

                    errqnt.setText("Required field*")
                }

                /*try {
                    fd = quan_received.text.toString().toInt()
                    fgh = quan_req_first.text.toString().toInt()


                    if (fd.toString().isNotEmpty()) {
                        if (fd!! > fgh!!) {
                            quan_received.isEnabled = false
                            val builder = AlertDialog.Builder(this@Purchase_orderMainActivity)
                            with(builder) {
                                setTitle("Exceed")
                                setMessage("Received quantity is higher than quantity required.")
                                builder.setCancelable(false)

                                setPositiveButton("Ok") { dialog, whichButton ->

                                    quan_received.setText("")
                                    quan_received.isEnabled = true

                                    dialog.dismiss()
                                }
                                val dialog = builder.create()
                                dialog.show()
                            }
                        }

                    }

                }
                catch (e:Exception){

                }*/



                if ((errnm.visibility == View.INVISIBLE) && (errpri.visibility == View.INVISIBLE) && (errqnt.visibility == View.INVISIBLE) && (recerrnm.visibility == View.INVISIBLE) && (transferpurord == "true")&&(net_status()==true)) {


                    if(quan_received.text.toString().isNotEmpty()){

                            val o = Intent(this@Purchase_orderMainActivity, PurcathirdMainActivity::class.java)
                            o.putExtra("from_pur", "update_purchase")
                            var dx = prd_nm.text
                            var ex = purhsn.text
                            var fx = purpri.text.toString()
                            var gx = quan_req_first.text
                            var hx = bcd_pid.text
                            var ix = total.text
                            var ixgro = gross_tot.text

                            var jx = cess_edt.text
                            var kx = igst_edt.text.toString()
                            var px = cgst_edt.text.toString()
                            var qx = scgst_edt.text.toString()
                            var lx = tax_tot.text
                            var mx = cess_amt1.text
                            var tallx = tallyarr.text
                            var receivex = quan_received.text
                            var recpri = purch_pri.text
                            var rectot = total_two.text
                            var rectaxtt = tax_tot1.text
                            var reccesstt = cess_amt.text
                            var recgrstt = gross_tot1.text



                            asave[pzsave] = dx.toString()
                            dsysave[pzsave] = ex.toString()
                            fysave[pzsave] = hx.toString()
                            gysave[pzsave] = gx.toString()
                            hysave[pzsave] = fx.toString()
                            kysave[pzsave] = ix.toString()
                            kygrosave[pzsave] = ixgro.toString()
                            mysave[pzsave] = jx.toString()
                            nysave[pzsave] = kx.toString()
                            cysave[pzsave] = px.toString()
                            sysave[pzsave] = qx.toString()
                            oysave[pzsave] = lx.toString()
                            pysave[pzsave] = mx.toString()
                            tallysave[pzsave] = tallx.toString()
                            receivedsave[pzsave] = receivex.toString()
                            sprisave[pzsave] = recpri.toString()
                            stotsave[pzsave] = rectot.toString()
                            staxtsave[pzsave] = rectaxtt.toString()
                            sgrosssave[pzsave] = recgrstt.toString()
                            scesstotsave[pzsave] = reccesstt.toString()





                            o.putExtra("renm", asave)
                            o.putExtra("from_pur", "update_purchase")
                            o.putExtra("remanu", lysave)
                            o.putExtra("rekey", idddsave)
                            o.putExtra("rehsn", dsysave)
                            o.putExtra("reprice", hysave)
                            o.putExtra("requan", gysave)
                            o.putExtra("rebc", fysave)
                            o.putExtra("retotal", kysave)
                        o.putExtra("regrosstotal", kygrosave)
                        o.putExtra("supplieridfr",supplieridfr)

                        o.putExtra("recess", mysave)
                            o.putExtra("reigst", nysave)
                            o.putExtra("recgst", cysave)
                            o.putExtra("resgst", sysave)
                            o.putExtra("retally", tallysave)
                            o.putExtra("rereceived", receivedsave)
                            o.putExtra("rereceived_pri", sprisave)
                            o.putExtra("rereceived_tot", stotsave)
                            o.putExtra("rereceived_taxtot", staxtsave)
                            o.putExtra("rereceived_cesstot", scesstotsave)
                            o.putExtra("rereceived_grosstot", sgrosssave)
                            o.putExtra("reigst_total", oysave)
                            o.putExtra("recesstotal", pysave)
                            o.putExtra("reimmg", immysave)
                            o.putExtra("idpro", idprokysave)
                            o.putExtra("pono", pono)
                            o.putExtra("names", reprnms)
                            o.putExtra("redesc", desc)
                            o.putExtra("reorddate", orddate)
                            o.putExtra("reestdt", reqdt)
                            o.putExtra("restatus", postatus)
                            o.putExtra("groschk",groschk)
                            o.putExtra("orddatedup",orddatedup)
                            o.putExtra("reqdatedup",reqdatedup)
                            o.putExtra("descripdup",descripdup)
                            o.putExtra("reids", reqliid)
                            o.putExtra("titnm", comttname.text.toString())
                            o.putExtra("tiphone", comphone.text.toString())
                            o.putExtra("brids", brnchidss)
                            o.putExtra("viewsuppin", viewsuppin)
                            o.putExtra("addsuppin", addsuppin)
                            o.putExtra("deletesuppin", deletesuppin)
                            o.putExtra("editsuppin", editesuppin)
                            o.putExtra("transfersuppin", transfersuppin)
                            o.putExtra("exportsuppin", exportsuppin)
                            o.putExtra("descriplistener",descriplistener)
                            o.putExtra("listListener",listListener)

                            o.putExtra("viewpurord", viewpurord)
                            o.putExtra("addpurord", addpurord)
                            o.putExtra("deletepurord", deletepurord)
                            o.putExtra("editpurord", editepurord)
                            o.putExtra("transferpurord", transferpurord)
                            o.putExtra("exportpurord", exportpurord)
                            o.putExtra("sendpurord", sendpurpo)

                        o.putExtra("suppinv",suppinv)


                        o.putExtra("edclick",edclick)

                            o.putExtra("viewpurreq", viewpurreq)
                            o.putExtra("addpurreq", addpurreq)
                            o.putExtra("deletepurreq", deletepurreq)
                            o.putExtra("editpurreq", editepurreq)
                            o.putExtra("transferpurreq", transferpurreq)
                            o.putExtra("exportpurreq", exportpurreq)



                            o.putExtra("ids",ids)



                            startActivity(o)
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                            finish()

                        }
                    else if(quan_received.text.isEmpty()){
                        val o = Intent(this@Purchase_orderMainActivity, PurcathirdMainActivity::class.java)
                        o.putExtra("from_pur", "update_purchase")
                        var dx = prd_nm.text
                        var ex = purhsn.text
                        var fx = purpri.text.toString()
                        var gx = quan_req_first.text
                        var hx = bcd_pid.text
                        var ix = total.text
                        var ixgro = gross_tot.text
                        var jx = cess_edt.text
                        var kx = igst_edt.text.toString()
                        var px = cgst_edt.text.toString()
                        var qx = scgst_edt.text.toString()
                        var lx = tax_tot.text
                        var mx = cess_amt1.text
                        var tallx = tallyarr.text
                        var receivex = quan_received.text
                        var recpri = purch_pri.text
                        var rectot = total_two.text
                        var rectaxtt = taxtotdup
                        var reccesstt = cess_amt.text
                        var recgrstt = gross_tot1.text



                        asave[pzsave] = dx.toString()
                        dsysave[pzsave] = ex.toString()
                        fysave[pzsave] = hx.toString()
                        gysave[pzsave] = gx.toString()
                        hysave[pzsave] = fx.toString()
                        kysave[pzsave] = ix.toString()
                        kygrosave[pzsave] = ixgro.toString()
                        mysave[pzsave] = jx.toString()
                        nysave[pzsave] = kx.toString()
                        cysave[pzsave] = px.toString()
                        sysave[pzsave] = qx.toString()
                        oysave[pzsave] = lx.toString()
                        pysave[pzsave] = mx.toString()
                        tallysave[pzsave] = tallx.toString()
                        receivedsave[pzsave] = receivex.toString()
                        sprisave[pzsave] = recpri.toString()
                        stotsave[pzsave] = rectot.toString()
                        staxtsave[pzsave] = rectaxtt.toString()
                        sgrosssave[pzsave] = recgrstt.toString()
                        scesstotsave[pzsave] = reccesstt.toString()





                        o.putExtra("renm", asave)
                        o.putExtra("from_pur", "update_purchase")
                        o.putExtra("remanu", lysave)
                        o.putExtra("rekey", idddsave)
                        o.putExtra("rehsn", dsysave)
                        o.putExtra("reprice", hysave)
                        o.putExtra("requan", gysave)
                        o.putExtra("rebc", fysave)
                        o.putExtra("retotal", kysave)
                        o.putExtra("regrosstotal", kygrosave)
                        o.putExtra("supplieridfr",supplieridfr)
                        o.putExtra("edclick",edclick)

                        o.putExtra("recess", mysave)
                        o.putExtra("reigst", nysave)
                        o.putExtra("recgst", cysave)
                        o.putExtra("resgst", sysave)
                        o.putExtra("retally", tallysave)
                        o.putExtra("rereceived", receivedsave)
                        o.putExtra("rereceived_pri", sprisave)
                        o.putExtra("rereceived_tot", stotsave)
                        o.putExtra("rereceived_taxtot", staxtsave)
                        o.putExtra("rereceived_cesstot", scesstotsave)
                        o.putExtra("rereceived_grosstot", sgrosssave)
                        o.putExtra("reigst_total", oysave)
                        o.putExtra("recesstotal", pysave)
                        o.putExtra("reimmg", immysave)
                        o.putExtra("idpro", idprokysave)
                        o.putExtra("pono", pono)
                        o.putExtra("names", reprnms)
                        o.putExtra("redesc", desc)
                        o.putExtra("reorddate", orddate)
                        o.putExtra("reestdt", reqdt)
                        o.putExtra("restatus", postatus)
                        o.putExtra("groschk",groschk)
                        o.putExtra("orddatedup",orddatedup)
                        o.putExtra("reqdatedup",reqdatedup)
                        o.putExtra("descripdup",descripdup)
                        o.putExtra("reids", reqliid)
                        o.putExtra("titnm", comttname.text.toString())
                        o.putExtra("tiphone", comphone.text.toString())
                        o.putExtra("brids", brnchidss)
                        o.putExtra("viewsuppin", viewsuppin)
                        o.putExtra("addsuppin", addsuppin)
                        o.putExtra("deletesuppin", deletesuppin)
                        o.putExtra("editsuppin", editesuppin)
                        o.putExtra("transfersuppin", transfersuppin)
                        o.putExtra("exportsuppin", exportsuppin)
                        o.putExtra("descriplistener",descriplistener)
                        o.putExtra("listListener",listListener)

                        o.putExtra("viewpurord", viewpurord)
                        o.putExtra("addpurord", addpurord)
                        o.putExtra("deletepurord", deletepurord)
                        o.putExtra("editpurord", editepurord)
                        o.putExtra("transferpurord", transferpurord)
                        o.putExtra("exportpurord", exportpurord)
                        o.putExtra("sendpurord", sendpurpo)

                        o.putExtra("suppinv",suppinv)



                        o.putExtra("viewpurreq", viewpurreq)
                        o.putExtra("addpurreq", addpurreq)
                        o.putExtra("deletepurreq", deletepurreq)
                        o.putExtra("editpurreq", editepurreq)
                        o.putExtra("transferpurreq", transferpurreq)
                        o.putExtra("exportpurreq", exportpurreq)



                        o.putExtra("ids",ids)



                        startActivity(o)
                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                        finish()
                    }



                }
                else if(transferpurord=="false"){
                    popup("Purchase order")
                    if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
                    }
                }
            }
            setNegativeButton("No") { dialog, whichButton ->

                groschk = ""
                val o = Intent(this@Purchase_orderMainActivity, PurcathirdMainActivity::class.java)

                o.putExtra("from_pur", "update_purchase")

                o.putExtra("renm", asave)
                o.putExtra("from_pur", "update_purchase")
                o.putExtra("remanu", lysave)
                o.putExtra("rekey", idddsave)
                o.putExtra("rehsn", dsysave)
                o.putExtra("reprice", hysave)
                o.putExtra("requan", gysave)
                o.putExtra("rebc", fysave)
                o.putExtra("retotal", kysave)
                o.putExtra("regrosstotal", kygrosave)
                o.putExtra("supplieridfr",supplieridfr)

                o.putExtra("recess", mysave)
                o.putExtra("reigst", nysave)
                o.putExtra("recgst", cysave)
                o.putExtra("resgst", sysave)
                o.putExtra("retally", tallysave)
                o.putExtra("rereceived", receivedsave)
                o.putExtra("rereceived_pri", sprisave)
                o.putExtra("rereceived_tot", stotsave)
                o.putExtra("rereceived_taxtot", staxtsave)
                o.putExtra("rereceived_cesstot", scesstotsave)
                o.putExtra("rereceived_grosstot", sgrosssave)
                o.putExtra("reigst_total", oysave)
                o.putExtra("recesstotal", pysave)
                o.putExtra("reimmg", immysave)
                o.putExtra("idpro", idprokysave)
                o.putExtra("pono", pono)
                o.putExtra("names", reprnms)
                o.putExtra("redesc", desc)
                o.putExtra("reorddate", orddate)
                o.putExtra("reestdt", reqdt)
                o.putExtra("restatus", postatus)
                o.putExtra("groschk",groschk)
                o.putExtra("suppinv",suppinv)
                o.putExtra("edclick",edclick)

                o.putExtra("reids", reqliid)
                o.putExtra("titnm", comttname.text.toString())
                o.putExtra("tiphone", comphone.text.toString())
                o.putExtra("brids", brnchidss)
                o.putExtra("viewsuppin", viewsuppin)
                o.putExtra("addsuppin", addsuppin)
                o.putExtra("deletesuppin", deletesuppin)
                o.putExtra("editsuppin", editesuppin)
                o.putExtra("transfersuppin", transfersuppin)
                o.putExtra("exportsuppin", exportsuppin)
                o.putExtra("orddatedup",orddatedup)
                o.putExtra("reqdatedup",reqdatedup)
                o.putExtra("descripdup",descripdup)
                o.putExtra("descriplistener",descriplistener)
                o.putExtra("listListener",listListener)

                o.putExtra("viewpurord", viewpurord)
                o.putExtra("addpurord", addpurord)
                o.putExtra("deletepurord", deletepurord)
                o.putExtra("editpurord", editepurord)
                o.putExtra("transferpurord", transferpurord)
                o.putExtra("exportpurord", exportpurord)
                o.putExtra("sendpurord", sendpurpo)

                o.putExtra("ids",ids)


                o.putExtra("viewpurreq", viewpurreq)
                o.putExtra("addpurreq", addpurreq)
                o.putExtra("deletepurreq", deletepurreq)
                o.putExtra("editpurreq", editepurreq)
                o.putExtra("transferpurreq", transferpurreq)
                o.putExtra("exportpurreq", exportpurreq)


                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }

            val dialog = builder.create()
            dialog.show()
        }
    }
    companion object {

        //Listens internet status whether net is on/off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null

        private var purpridis:EditText?=null
        private var quan_receiveddis:EditText?=null
        private var req_updatedis: Button? = null
        private var editdisab:ImageButton?=null

        private var userbackdis: ImageButton? = null
        private var scrollView2dis:ScrollView?=null

        private var taxtotdup=String()
        private var tax_tot1dis:TextView?=null
        private var quan_req_firstdis:EditText?=null
        private val log_str: String? = null
        var edclick=String()
        @RequiresApi(Build.VERSION_CODES.M)
        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                /// if connection is off then all views becomes disable


                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                req_updatedis!!.isEnabled=false
                purpridis!!.isEnabled=false
                val color = 0x96ffffff;
                val  drawables =  ColorDrawable(color.toInt());
                scrollView2dis!!.foreground=drawables
                quan_req_firstdis!!.isEnabled=false
                quan_receiveddis!!.isEnabled=false
                userbackdis!!.isEnabled=false
                editdisab!!.isEnabled=false

                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }


            }
            else
            {


                /// if connection is off then all views becomes enabled

                constraintLayout3dis!!.visibility=View.GONE

                if(edclick.isEmpty()){
                    editdisab!!.visibility=View.VISIBLE
                    req_updatedis!!.visibility=View.GONE
                    req_updatedis!!.isEnabled=false
                    purpridis!!.isEnabled=false

                    quan_receiveddis!!.isEnabled=false


                }
                else if(edclick.isNotEmpty()||edclick=="click"){
                    editdisab!!.visibility=View.GONE
                    req_updatedis!!.visibility=View.VISIBLE
                    req_updatedis!!.isEnabled=true
                    purpridis!!.isEnabled=true
                    quan_receiveddis!!.isEnabled=true
                }
                userbackdis!!.isEnabled=true


                scrollView2dis!!.setBackgroundColor(Color.parseColor("#32ffffff"))
                scrollView2dis!!.foreground=null
                relativeslayoutdis!!.visibility=View.GONE



                if(taxtotdup!!.toString()=="00.00"){
                    quan_req_firstdis!!.isEnabled=true
                }




            }
        }
    }
    fun net_status():Boolean{               //Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
    fun popup(st:String){           //Access Denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }
}