package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.view.View
import android.view.WindowManager
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import kotlinx.android.synthetic.main.activity_stock_transfer.*
import kotlinx.android.synthetic.main.stock_popup.*

class StockTransferActivity : AppCompatActivity() {

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
     private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""







    var idss= String()
    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stock_transfer)


        net_status()//Check internet status.

        //Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@StockTransferActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
        }


        //Define No connection view and other views when inetrnet connection is off.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.container)

        stockvert.setOnClickListener({       //Vert menu contains 'Logout' option.


            val popup = PopupMenu(this@StockTransferActivity, stockvert)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->    //Navigate to pin activity
                Toast.makeText(this@StockTransferActivity, "You are logged out" + item.title, Toast.LENGTH_SHORT).show()

                if(item.title=="Logout"){
                    if(net_status()==true) {
                        val f=Intent(this@StockTransferActivity, PinActivity::class.java)
                        startActivity(f)
                        overridePendingTransition(R.anim.slide_out_right,R.anim.slide_out_right)
                        finish()
                    }
                    else if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
                    }

                }

                true

            }

            popup.show()

        })

        val k=intent.getStringExtra("skey")
        idss=k

        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")

        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }


        //Purchase order





























        println("ADD TRANSFER"+addtrans)
        println("Another ADD TRANSFER"+addtransano)


        userback.setOnClickListener {
            onBackPressed()
        }


        //Click 'Transfer within state' and Navigate to 'WithStateActivity'
        tws.setOnClickListener {
            if(viewtrans=="true") {
                val b = Intent(applicationContext, WithStateActivity::class.java)




                b.putExtra("viewtrans", viewtrans)
                b.putExtra("addtrans", addtrans)
                b.putExtra("edittrans", editetrans)
                b.putExtra("deletetrans", deletetrans)
                b.putExtra("transfertrans", transfertrans)
                b.putExtra("exporttrans", exporttrans)
                b.putExtra("sendtrans", sendtrans)


               b.putExtra("viewtransano", viewtransano)
               b.putExtra("addtransano", addtransano)
               b.putExtra("edittransano", editetransano)
               b.putExtra("deletetransano", deletetransano)
               b.putExtra("transfertransano", transfertransano)
               b.putExtra("exporttransano", exporttransano)
               b.putExtra("sendtransano", sendtransano)

               b.putExtra("viewrec", viewrec)
               b.putExtra("addrec", addrec)
               b.putExtra("deleterec", deleterec)
               b.putExtra("editrec", editrec)
               b.putExtra("transferrec", transferrec)
               b.putExtra("exportrec", exportrec)
               b.putExtra("sendstrec",sendstrec)

b.putExtra("from_br","main")
                b.putExtra("bkey", idss)
                startActivity(b)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            }
            else if(viewtrans=="false"){
                popup("View")
            }
        }

        //Click 'Transfer to another state' and Navigate to 'Anotherstate'


        tas.setOnClickListener {
              val b = Intent(applicationContext, Anotherstate::class.java)




            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)



            b.putExtra("another_bkey",idss)
              startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
        }

        //Click 'Receive Stock' and Navigate to 'ReceiveActivity'


        rs.setOnClickListener {
             val b = Intent(applicationContext,ReceiveActivity::class.java)

            NotificationEventReceiver.setupAlarm(applicationContext)





            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)



            var ii= String()
            ii="Main"
            b.putExtra("from",ii)
              startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
        }
    }

    fun popup(st:String){  //Access denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    override fun onBackPressed() {
        val v=Intent(this@StockTransferActivity,MainActivity::class.java)








        v.putExtra("bid",idss)

        startActivity(v)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()
    }
    fun net_status():Boolean{   ////Check internet status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
    companion object {

 //Listens internet status whether net is on/off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                                 /// if connection is off then all views becomes disable

                constraintLayout3dis!!.visibility= View.VISIBLE
                relativeslayoutdis!!.visibility= View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {

                                 /// if connection is off then all views becomes enabled


                constraintLayout3dis!!.visibility= View.GONE

                relativeslayoutdis!!.visibility= View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }
}
