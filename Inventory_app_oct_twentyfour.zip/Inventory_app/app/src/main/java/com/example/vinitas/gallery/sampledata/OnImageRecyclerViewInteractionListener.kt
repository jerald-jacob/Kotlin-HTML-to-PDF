package com.example.vinitas.gallery.sampledata


import com.zfdang.multiple_images_selector.models.ImageItem

/**
 * Created by zfdang on 2016-4-12.
 */
interface OnImageRecyclerViewInteractionListener {
    fun onImageItemInteraction(item: ImageItem)
}