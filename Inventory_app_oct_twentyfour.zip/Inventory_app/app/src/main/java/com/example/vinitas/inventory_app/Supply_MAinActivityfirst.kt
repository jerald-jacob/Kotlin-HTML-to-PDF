package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.format.DateFormat.format
import android.util.Log
import android.widget.ListView
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot


import kotlinx.android.synthetic.main.supplier_in_first.*
import java.text.SimpleDateFormat
import java.util.*
import javax.xml.datatype.DatatypeConstants.DAYS

import java.text.ParseException
import java.util.concurrent.TimeUnit
import android.support.annotation.RequiresPermission.Read
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.Query


class  Supplier_first_MainActivity : AppCompatActivity() {










    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""



    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()






    val TAG = "some"
    var db = FirebaseFirestore.getInstance()
    var ids= arrayOf<String>()

    var liids= arrayOf<String>()
    var nameArrayori= arrayOf<String>()
    var voucheridori= arrayOf<String>()

    var phoneArrayori= arrayOf<String>()
    var dateArrayori= arrayOf<String>()
    var priceArrayori= arrayOf<String>()
    var bridArrayori= arrayOf<String>()
    var statusarrayori=arrayOf<String>()
    var datearr=arrayOf<String>()
    var datestarr=arrayOf<String>()
    var datesarr=arrayOf<String>()
    var name=arrayOf<String>()
    var imurl=arrayOf<String>()
    var imagenm=arrayOf<String>()
    var dinvdt=arrayOf<String>()
    var descrip=arrayOf<String>()
    var pay= String()
    var urll= String()
    var invoice= String()
 var descriptionss=arrayOf<String>()


    var broriky = String()
    var brorival = String()

    var s = String()


    var sd = String()
    var x = String()
    var reg = String()
    var esc = String()
    var upstr = String()
    var numberstr = String()
    var descr = String()
    var regtr = String()
    var nmstr = String()
    var kyval = String()
    var dtdate= String()
    var supkyval = String()
    var bsupkyval = String()
    var origisearch = arrayOf<String>()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.supplier_in_first)

            net_status()  // Check net status


                //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Supplier_first_MainActivity) > 0)
        {

        }
        else{

        }

        //Define No connection view and other views when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.suppfirstcontain)

        search.setOnClickListener {  //Image button search  action
            cardsearch.visibility = View.VISIBLE
            search.visibility=View.GONE
            imageButtonmnu.visibility=View.GONE
            textView.visibility=View.GONE
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@Supplier_first_MainActivity,R.anim.slide_to_right))
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }



        imageButtonmnu.setOnClickListener({    //Vert menu contains 'Logout' option.


            val popup = PopupMenu(this@Supplier_first_MainActivity, imageButtonmnu)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                if (item.title == "Logout") {    //Navigate to pin activity
                    if(net_status()==true){
                        Toast.makeText(this@Supplier_first_MainActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                        val f = Intent(this@Supplier_first_MainActivity, PinActivity::class.java)
                        startActivity(f)
                        finish()
                    }
                    else{
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()

                    }

                }
                true
            }

            popup.show()
        })



        val i=intent.extras
        var frm=i!!.get("from_ver")



        /*else if(frm=="verify") {
            try {
                val o = intent.getStringExtra("status")
                s = o
            } catch (e: Exception) {

            }
        }*/




      /*  swipeContainer.setOnRefreshListener {
            supinact()
        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/



        if(frm=="main"){


            val p=intent.getStringExtra("brkey")
            broriky=p






            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }


            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }


            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")

            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            println("LOGINN KEYYYY"+broriky)
            supinact()

        }
        else if(frm=="supp_four")
        {
            val p=intent.getStringExtra("bridkey")
            broriky=p

            supinact()









            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin=intent.getStringExtra("viewsuppin")
            val transuppin=intent.getStringExtra("transfersuppin")
            val exsuppin=intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr=intent.getStringExtra("viewpurreq")
            val tranpr=intent.getStringExtra("transferpurreq")
            val expr=intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr
            }
            if (expr != null) {
                exportpurreq = expr
            }


            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord=intent.getStringExtra("viewpurord")
            val tranord=intent.getStringExtra("transferpurord")
            val exord=intent.getStringExtra("exportpurord")
            sendpurpo=intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }
        }


        //-----------------------------------SERACH------------------------------------//


        searchedit.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                progressBar10.visibility=View.VISIBLE



                supplier_list.visibility=View.GONE
                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"

                val ps = "^[a-zA-Z ]+$"
                val datev= "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$"
                println("TYPED VALUED" + x)




                fun dateget() {
                    if (s.length >=2) {
                        noresfo.visibility=View.GONE
                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var bridArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var imgurlArray = arrayOf<String>()
                        var imgnameArray = arrayOf<String>()

                        var vou_idarray=arrayOf<String>()



                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()


                        db.collection("${broriky}_Supplier Invoice").orderBy("date").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)
                                                var dt = document.data
                                                var brids = (dt["branchid"]).toString()



                                                if (brorival == brids) {


                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)

                                                    println(idss)
                                                    var name = (dt["prod_nms"]).toString()
                                                    var phone = (dt["supplier_phone"]).toString()
                                                    var datee = (dt["datest"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()

                                                    var datest = (dt["datest"]).toString()
                                                    var dates = (dt["voucher_number"]).toString()
                                                    var sta = (dt["status"]).toString()
                                                    println("STATUSSSSSS" + sta)
                                                    println("Dateeee" + datee)

                                                    var vou_id = (dt["voucher_id"]).toString()
                                                    vou_idarray=vou_idarray.plusElement(vou_id)


                                                    val c = Calendar.getInstance()
                                                    val df = SimpleDateFormat("dd/MM/yyyy")

                                                    val formattedDate = df.format(c.time)


                                                    /*val fromDate = formattedDate
                                            val toDate = invdt
                                            var diff: Long = 0

                                            try {

                                                //Convert to Date
                                                val startDate = df.parse(fromDate)
                                                val c1 = Calendar.getInstance()
                                                //Change to Calendar Date
                                                c1.time = startDate

                                                //Convert to Date
                                                val endDate = df.parse(toDate)
                                                val c2 = Calendar.getInstance()
                                                //Change to Calendar Date
                                                c2.time = endDate

                                                //get Time in milli seconds
                                                val ms1 = c1.timeInMillis
                                                val ms2 = c2.timeInMillis
                                                //get difference in milli seconds
                                                diff = (ms2 - ms1)
                                                //Find number of days by dividing the mili seconds
                                                val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                                println("Number of days difference is: " + diffInDays)

                                                descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                                statusArray = statusArray.plusElement("Incomplete")

                                            } catch (e: ParseException) {
                                                e.printStackTrace()
                                            }*/



                                                    try {
                                                        var urlimg = (dt["imgurl"]).toString()
                                                        urll = urlimg
                                                        var deudt = (dt["payment_duedate"]).toString()
                                                        pay = deudt
                                                        var invdt = (dt["invoice_date"]).toString()
                                                        invoice = invdt

                                                        var imgnm=(dt["imagename"]).toString()


                                                        val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                                        val dateBeforeString = formattedDate
                                                        val dateAfterString = invdt
                                                        val dateBefore = myFormat.parse(dateBeforeString)
                                                        val dateAfter = myFormat.parse(dateAfterString)
                                                        val difference = dateAfter.time - dateBefore.time
                                                        val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                                        /* You can also convert the milliseconds to days using this method
                                    * float daysBetween =
                                    *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                                    */
                                                        println("Number of Days between dates: " + daysBetween)
                                                        if ((daysBetween > 0)&&(sta!="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                                        } else if ((daysBetween <= 0)&&(sta!="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                                        }
                                                        else if ((daysBetween <= 0)&&(sta=="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                                        }
                                                        statusArray = statusArray.plusElement("")
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")

                                                        imgurlArray = imgurlArray.plusElement(urlimg)
                                                        imurl = imgurlArray

                                                        imgnameArray=imgnameArray.plusElement(imgnm)
                                                        imagenm=imgnameArray



                                                        var descripss=(dt["description"]).toString()
                                                        descriptionss=descriptionss.plusElement(descripss)
                                                    } catch (e: Exception) {
                                                        var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                                        imgurlArray = imgurlArray.plusElement(urlimg)



                                                        imgnameArray=imgnameArray.plusElement("")

                                                        imagenm=imgnameArray


                                                        statusArray = statusArray.plusElement("")
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")
                                                        imurl = imgurlArray
                                                        var deudt = ""
                                                        pay = deudt
                                                        var invdt = ""
                                                        invoice = invdt
                                                        descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")
                                                        var descripss=(dt["description"]).toString()
                                                        descriptionss=descriptionss.plusElement(descripss)
                                                    }


                                                    /* try {
                                                 var sta = (dt["postatus"]).toString()
                                                 if (sta == "complete") {
                                                     descr = "Complete"
                                                     statusArray1 = statusArray1.plusElement(descr)
                                                     statusArray = statusArray.plusElement("")
                                                 } else {
                                                     descr = "Incomplete"
                                                     statusArray = statusArray.plusElement(descr)
                                                     statusArray1 = statusArray1.plusElement("")
                                                 }
                                             }*/








                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    bridArray = bridArray.plusElement(brids)
                                                    if(dates=="Siv"){
                                                        dateArray = dateArray.plusElement("Dt - " + datee)
                                                    }
                                                    else if(dates.isNotEmpty()&&dates!="Siv"){
                                                        dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                                                    }
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(datee)
                                                    datesarr = datesarr.plusElement(pay)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArray
                                                    statusarrayori=statusarrayori.plusElement(sta)
                                                    dinvdt = dinvdt.plusElement(invoice)
                                                    voucheridori=vou_idarray
                                                    datestarr=datestarr.plusElement(datest)
                                                    descrip = descrip.plusElement(dates)
                                                    ids = idss
                                                    liids = idss


                                                    progressBar10.visibility=View.GONE
                                                    supplier_list.visibility=View.VISIBLE
                                                    noresfo.visibility=View.GONE

                                                    println("If SAVE KEYYYY" + brorival)

                                                    val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity,imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                                    wlist.adapter = whatever
                                                    /*  catch (e: Exception) {

                                                       }*/
                                                }
                                                else

                                                {
                                                    progressBar10.visibility=View.GONE
                                                    supplier_list.visibility=View.GONE
                                                    noresfo.visibility=View.VISIBLE

                                                }


                                            }


                                        }

                                        else {
                                            println("NO RECORDSSSS FOUNDD")
                                            noresfo.visibility = View.VISIBLE
                                            progressBar10.visibility=View.GONE

                                            supplier_list.visibility = View.GONE
                                        }


                                   /* } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                    else{

                        noresfo.visibility = View.VISIBLE
                        progressBar10.visibility=View.GONE

                        supplier_list.visibility = View.GONE


                    }
                }



                fun priget() {
                    if ((s.length >= 2)&&(regtr == "num"))
                    {
                        noresfo.visibility = View.GONE

                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var bridArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var imgurlArray = arrayOf<String>()
                        var statusArray2pr=arrayOf<String>()
                        var statusArray3cncl=arrayOf<String>()

                        var imgnameArray = arrayOf<String>()

                        var vou_idarray=arrayOf<String>()


                        db.collection("${broriky}_Supplier Invoice").orderBy("gross_tot").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var brids = (dt["branchid"]).toString()



                                                if (brorival == brids) {
                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)

                                                    println(idss)
                                                    var name = (dt["prod_nms"]).toString()
                                                    var phone = (dt["supplier_phone"]).toString()
                                                    var datee = (dt["datest"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var datest = (dt["datest"]).toString()
                                                    var vou_id = (dt["voucher_id"]).toString()

                                                    var dates = (dt["voucher_number"]).toString()
                                                    var sta = (dt["status"]).toString()
                                                    println("STATUSSSSSS" + sta)
                                                    println("Dateeee" + datee)


                                                    val c = Calendar.getInstance()
                                                    val df = SimpleDateFormat("dd/MM/yyyy")

                                                    val formattedDate = df.format(c.time)


                                                    /*val fromDate = formattedDate
                                            val toDate = invdt
                                            var diff: Long = 0

                                            try {

                                                //Convert to Date
                                                val startDate = df.parse(fromDate)
                                                val c1 = Calendar.getInstance()
                                                //Change to Calendar Date
                                                c1.time = startDate

                                                //Convert to Date
                                                val endDate = df.parse(toDate)
                                                val c2 = Calendar.getInstance()
                                                //Change to Calendar Date
                                                c2.time = endDate

                                                //get Time in milli seconds
                                                val ms1 = c1.timeInMillis
                                                val ms2 = c2.timeInMillis
                                                //get difference in milli seconds
                                                diff = (ms2 - ms1)
                                                //Find number of days by dividing the mili seconds
                                                val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                                println("Number of days difference is: " + diffInDays)

                                                descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                                statusArray = statusArray.plusElement("Incomplete")

                                            } catch (e: ParseException) {
                                                e.printStackTrace()
                                            }*/



                                                    try {
                                                        var urlimg = (dt["imgurl"]).toString()
                                                        urll = urlimg
                                                        var deudt = (dt["payment_duedate"]).toString()
                                                        pay = deudt
                                                        var invdt = (dt["invoice_date"]).toString()
                                                        invoice = invdt

                                                        var imgnm=(dt["imagename"]).toString()

                                                        val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                                        val dateBeforeString = formattedDate
                                                        val dateAfterString = invdt
                                                        val dateBefore = myFormat.parse(dateBeforeString)
                                                        val dateAfter = myFormat.parse(dateAfterString)
                                                        val difference = dateAfter.time - dateBefore.time
                                                        val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                                        /* You can also convert the milliseconds to days using this method
                                    * float daysBetween =
                                    *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                                    */
                                                        println("Number of Days between dates: " + daysBetween)
                                                        if ((daysBetween > 0)&&(sta!="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                                        } else if ((daysBetween <= 0)&&(sta!="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                                        }
                                                        else if ((daysBetween <= 0)&&(sta=="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                                        }
                                                        statusArray = statusArray.plusElement("")
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")
                                                        imgurlArray = imgurlArray.plusElement(urlimg)
                                                        imurl = imgurlArray

                                                        imgnameArray=imgnameArray.plusElement(imgnm)

                                                        imagenm=imgnameArray



                                                        var descripss=(dt["description"]).toString()
                                                        descriptionss=descriptionss.plusElement(descripss)
                                                    } catch (e: Exception) {
                                                        var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                                        imgurlArray = imgurlArray.plusElement(urlimg)

                                                        statusArray = statusArray.plusElement("")
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")


                                                        imgnameArray=imgnameArray.plusElement("")
                                                        imagenm=imgnameArray

                                                        imurl = imgurlArray
                                                        var deudt = ""
                                                        pay = deudt
                                                        var invdt = ""
                                                        invoice = invdt
                                                        descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")

                                                        var descripss=(dt["description"]).toString()
                                                        descriptionss=descriptionss.plusElement(descripss)
                                                    }


                                                    /* try {
                                                 var sta = (dt["postatus"]).toString()
                                                 if (sta == "complete") {
                                                     descr = "Complete"
                                                     statusArray1 = statusArray1.plusElement(descr)
                                                     statusArray = statusArray.plusElement("")
                                                 } else {
                                                     descr = "Incomplete"
                                                     statusArray = statusArray.plusElement(descr)
                                                     statusArray1 = statusArray1.plusElement("")
                                                 }
                                             }*/







                                                    vou_idarray=vou_idarray.plusElement(vou_id)


                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    bridArray = bridArray.plusElement(brids)
                                                    if(dates=="Siv"){
                                                        dateArray = dateArray.plusElement("Dt - " + datee)
                                                    }
                                                    else if(dates.isNotEmpty()&&dates!="Siv"){
                                                        dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                                                    }
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(datee)
                                                    datesarr = datesarr.plusElement(pay)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArray
                                                    dinvdt = dinvdt.plusElement(invoice)
                                                    statusarrayori=statusarrayori.plusElement(sta)
                                                    voucheridori=vou_idarray
                                                    datestarr=datestarr.plusElement(datest)
                                                    descrip = descrip.plusElement(dates)
                                                    ids = idss
                                                    liids = idss
                                                    println("If SAVE KEYYYY" + brorival)
                                                    progressBar10.visibility=View.GONE
                                                    noresfo.visibility=View.GONE
                                                    supplier_list.visibility=View.VISIBLE
                                                        val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity,imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                                        val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                                        wlist.adapter = whatever
                                                 /*  catch (e: Exception) {

                                                    }*/
                                                }
                                                else

                                                {
                                                    progressBar10.visibility=View.GONE
                                                    supplier_list.visibility=View.GONE
                                                    noresfo.visibility=View.VISIBLE

                                                }


                                            }


                                        }

                                        else {
                                            println("NO RECORDSSSS FOUNDD")
                                           dateget()

                                        }


                                   /* } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                }



                if (x.trim().matches(regexStr.toRegex()))

                {
                    upstr = x
                    println("CAME INTO NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    regtr = "num"
                    priget()

                    //write code here for success
                }


                if ((x != reg)&&(!s.contains("/")))

                {
                    val upperString = x.toUpperCase()
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("STRINGSSSS" + upstr)
                }
                else if(s.contains("/")){
                    dateget()
                }






                //_____________________________NAME SEARCH__________________________________//


                fun nameget() {


                    if ((s.length >= 3) && (x != reg)) {
                        noresfo.visibility = View.GONE

                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var bridArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var imgurlArray = arrayOf<String>()
                        var imgnameArray = arrayOf<String>()
                        var vou_idarray=arrayOf<String>()


                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()
                        db.collection("${broriky}_Supplier Invoice").orderBy("supplier_name").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)


                                                var dt = document.data
                                                var brids = (dt["branchid"]).toString()



                                                if (brorival == brids)
                                                {
                                                    println("If SAVE KEYYYY" + brorival)
                                                    try {
                                                        var id = (document.id)
                                                        idss = idss.plusElement(id)

                                                        println(idss)
                                                        var name = (dt["prod_nms"]).toString()
                                                        var phone = (dt["supplier_phone"]).toString()
                                                        var datee = (dt["datest"]).toString()
                                                        var tot = (dt["gross_tot"]).toString()
                                                        var datest = (dt["datest"]).toString()

                                                        var dates = (dt["voucher_number"]).toString()
                                                        var sta = (dt["status"]).toString()
                                                        println("STATUSSSSSS" + sta)
                                                        println("Dateeee" + datee)


                                                        val c = Calendar.getInstance()
                                                        val df = SimpleDateFormat("dd/MM/yyyy")

                                                        val formattedDate = df.format(c.time)


                                                        /*val fromDate = formattedDate
                                                val toDate = invdt
                                                var diff: Long = 0

                                                try {

                                                    //Convert to Date
                                                    val startDate = df.parse(fromDate)
                                                    val c1 = Calendar.getInstance()
                                                    //Change to Calendar Date
                                                    c1.time = startDate

                                                    //Convert to Date
                                                    val endDate = df.parse(toDate)
                                                    val c2 = Calendar.getInstance()
                                                    //Change to Calendar Date
                                                    c2.time = endDate

                                                    //get Time in milli seconds
                                                    val ms1 = c1.timeInMillis
                                                    val ms2 = c2.timeInMillis
                                                    //get difference in milli seconds
                                                    diff = (ms2 - ms1)
                                                    //Find number of days by dividing the mili seconds
                                                    val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                                    println("Number of days difference is: " + diffInDays)

                                                    descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                                    statusArray = statusArray.plusElement("Incomplete")

                                                } catch (e: ParseException) {
                                                    e.printStackTrace()
                                                }*/



                                                        try {

                                                            var urlimg = (dt["imgurl"]).toString()
                                                            urll = urlimg
                                                            var deudt = (dt["payment_duedate"]).toString()
                                                            pay = deudt
                                                            var invdt = (dt["invoice_date"]).toString()
                                                            invoice = invdt

                                                            var imgnm=(dt["imagename"]).toString()


                                                            val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                                            val dateBeforeString = formattedDate
                                                            val dateAfterString = invdt
                                                            val dateBefore = myFormat.parse(dateBeforeString)
                                                            val dateAfter = myFormat.parse(dateAfterString)
                                                            val difference = dateAfter.time - dateBefore.time
                                                            val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                                            /* You can also convert the milliseconds to days using this method
                                        * float daysBetween =
                                        *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                                        */
                                                            println("Number of Days between dates: " + daysBetween)
                                                            if ((daysBetween > 0)&&(sta!="Paid")) {
                                                                descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                                            } else if ((daysBetween <= 0)&&(sta!="Paid")) {
                                                                descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                                            }
                                                            else if ((daysBetween <= 0)&&(sta=="Paid")) {
                                                                descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                                            }
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr=statusArray2pr.plusElement("")
                                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                                            imgurlArray = imgurlArray.plusElement(urlimg)
                                                            imurl = imgurlArray

                                                            imgnameArray=imgnameArray.plusElement(imgnm)
                                                            imagenm=imgnameArray

                                                            var descripss=(dt["description"]).toString()
                                                            descriptionss=descriptionss.plusElement(descripss)
                                                        } catch (e: Exception) {
                                                            var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                                            imgurlArray = imgurlArray.plusElement(urlimg)

                                                            imgnameArray=imgnameArray.plusElement("")

                                                            imagenm=imgnameArray


                                                            statusArray = statusArray.plusElement("Incomplete")
                                                            statusArray1 = statusArray1.plusElement("")
                                                            imurl = imgurlArray
                                                            var deudt = ""
                                                            pay = deudt
                                                            var invdt = ""
                                                            invoice = invdt
                                                            descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")
                                                            var descripss=(dt["description"]).toString()
                                                            descriptionss=descriptionss.plusElement(descripss)

                                                        }


                                                        /* try {
                                                     var sta = (dt["postatus"]).toString()
                                                     if (sta == "complete") {
                                                         descr = "Complete"
                                                         statusArray1 = statusArray1.plusElement(descr)
                                                         statusArray = statusArray.plusElement("")
                                                     } else {
                                                         descr = "Incomplete"
                                                         statusArray = statusArray.plusElement(descr)
                                                         statusArray1 = statusArray1.plusElement("")
                                                     }
                                                 }*/






                                                        var vou_id = (dt["voucher_id"]).toString()
                                                        vou_idarray=vou_idarray.plusElement(vou_id)


                                                        text = text.plusElement((dt["supplier_name"]).toString())
                                                        nameArray = nameArray.plusElement(name)
                                                        bridArray = bridArray.plusElement(brids)
                                                        if(dates=="Siv"){
                                                            dateArray = dateArray.plusElement("Dt - " + datee)
                                                        }
                                                        else if(dates.isNotEmpty()&&dates!="Siv"){
                                                            dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                                                        }
                                                        priceArray = priceArray.plusElement(tot)
                                                        nameArrayori = text
                                                        dateArrayori = dateArray
                                                        priceArrayori = priceArray
                                                        statusarrayori=statusarrayori.plusElement(sta)
                                                        datearr = datearr.plusElement(datee)
                                                        datesarr = datesarr.plusElement(pay)
                                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                                        bridArrayori = bridArray
                                                        dinvdt = dinvdt.plusElement(invoice)
                                                        datestarr=datestarr.plusElement(datest)
                                                        voucheridori=vou_idarray

                                                        descrip = descrip.plusElement(dates)
                                                        ids = idss
                                                        liids = idss

                                                        progressBar10.visibility=View.GONE
                                                        noresfo.visibility=View.GONE
                                                        supplier_list.visibility=View.VISIBLE
                                                        val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity, imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray2pr)
                                                        val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                                        wlist.adapter = whatever
                                                    }
                                                    catch (e: Exception) {

                                                    }
                                                } else {
                                                    progressBar10.visibility=View.GONE
                                                    noresfo.visibility=View.VISIBLE
                                                    supplier_list.visibility=View.GONE

                                                }

                                            }


                                        } else {
                                            db.collection("${broriky}_Supplier Invoice").orderBy("prod_nms").startAt(upstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)


                                                                    var dt = document.data
                                                                    var brids = (dt["branchid"]).toString()



                                                                    if (brorival == brids) {
                                                                        println("If SAVE KEYYYY" + brorival)
                                                                        try {
                                                                            var id = (document.id)
                                                                            idss = idss.plusElement(id)

                                                                            println(idss)
                                                                            var name = (dt["prod_nms"]).toString()
                                                                            var phone = (dt["supplier_phone"]).toString()
                                                                            var datee = (dt["datest"]).toString()
                                                                            var tot = (dt["gross_tot"]).toString()
                                                                            var datest = (dt["datest"]).toString()

                                                                            var dates = (dt["voucher_number"]).toString()
                                                                            var sta = (dt["status"]).toString()
                                                                            println("STATUSSSSSS" + sta)
                                                                            println("Dateeee" + datee)


                                                                            val c = Calendar.getInstance()
                                                                            val df = SimpleDateFormat("dd/MM/yyyy")

                                                                            val formattedDate = df.format(c.time)


                                                                            /*val fromDate = formattedDate
                                                                    val toDate = invdt
                                                                    var diff: Long = 0

                                                                    try {

                                                                        //Convert to Date
                                                                        val startDate = df.parse(fromDate)
                                                                        val c1 = Calendar.getInstance()
                                                                        //Change to Calendar Date
                                                                        c1.time = startDate

                                                                        //Convert to Date
                                                                        val endDate = df.parse(toDate)
                                                                        val c2 = Calendar.getInstance()
                                                                        //Change to Calendar Date
                                                                        c2.time = endDate

                                                                        //get Time in milli seconds
                                                                        val ms1 = c1.timeInMillis
                                                                        val ms2 = c2.timeInMillis
                                                                        //get difference in milli seconds
                                                                        diff = (ms2 - ms1)
                                                                        //Find number of days by dividing the mili seconds
                                                                        val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                                                        println("Number of days difference is: " + diffInDays)

                                                                        descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                                                        statusArray = statusArray.plusElement("Incomplete")

                                                                    } catch (e: ParseException) {
                                                                        e.printStackTrace()
                                                                    }*/



                                                                            try {

                                                                                var urlimg = (dt["imgurl"]).toString()
                                                                                urll = urlimg
                                                                                var deudt = (dt["payment_duedate"]).toString()
                                                                                pay = deudt
                                                                                var invdt = (dt["invoice_date"]).toString()
                                                                                invoice = invdt

                                                                                var imgnm = (dt["imagename"]).toString()


                                                                                val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                                                                val dateBeforeString = formattedDate
                                                                                val dateAfterString = invdt
                                                                                val dateBefore = myFormat.parse(dateBeforeString)
                                                                                val dateAfter = myFormat.parse(dateAfterString)
                                                                                val difference = dateAfter.time - dateBefore.time
                                                                                val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                                                                /* You can also convert the milliseconds to days using this method
                                                            * float daysBetween =
                                                            *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                                                            */
                                                                                println("Number of Days between dates: " + daysBetween)
                                                                                if ((daysBetween > 0) && (sta != "Paid")) {
                                                                                    descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                                                                } else if ((daysBetween <= 0) && (sta != "Paid")) {
                                                                                    descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                                                                } else if ((daysBetween <= 0) && (sta == "Paid")) {
                                                                                    descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                                                                }
                                                                                statusArray = statusArray.plusElement("")
                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                imgurlArray = imgurlArray.plusElement(urlimg)
                                                                                imurl = imgurlArray

                                                                                imgnameArray = imgnameArray.plusElement(imgnm)
                                                                                imagenm = imgnameArray

                                                                                var descripss = (dt["description"]).toString()
                                                                                descriptionss = descriptionss.plusElement(descripss)
                                                                            } catch (e: Exception) {
                                                                                var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                                                                imgurlArray = imgurlArray.plusElement(urlimg)

                                                                                imgnameArray = imgnameArray.plusElement("")

                                                                                imagenm = imgnameArray


                                                                                statusArray = statusArray.plusElement("Incomplete")
                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                imurl = imgurlArray
                                                                                var deudt = ""
                                                                                pay = deudt
                                                                                var invdt = ""
                                                                                invoice = invdt
                                                                                descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")
                                                                                var descripss = (dt["description"]).toString()
                                                                                descriptionss = descriptionss.plusElement(descripss)

                                                                            }


                                                                            /* try {
                                                                         var sta = (dt["postatus"]).toString()
                                                                         if (sta == "complete") {
                                                                             descr = "Complete"
                                                                             statusArray1 = statusArray1.plusElement(descr)
                                                                             statusArray = statusArray.plusElement("")
                                                                         } else {
                                                                             descr = "Incomplete"
                                                                             statusArray = statusArray.plusElement(descr)
                                                                             statusArray1 = statusArray1.plusElement("")
                                                                         }
                                                                     }*/


                                                                            var vou_id = (dt["voucher_id"]).toString()
                                                                            vou_idarray = vou_idarray.plusElement(vou_id)


                                                                            text = text.plusElement((dt["supplier_name"]).toString())
                                                                            nameArray = nameArray.plusElement(name)
                                                                            bridArray = bridArray.plusElement(brids)
                                                                            if (dates == "Siv") {
                                                                                dateArray = dateArray.plusElement("Dt - " + datee)
                                                                            } else if (dates.isNotEmpty() && dates != "Siv") {
                                                                                dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                                                                            }
                                                                            priceArray = priceArray.plusElement(tot)
                                                                            nameArrayori = text
                                                                            dateArrayori = dateArray
                                                                            priceArrayori = priceArray
                                                                            datearr = datearr.plusElement(datee)
                                                                            datesarr = datesarr.plusElement(pay)
                                                                            statusarrayori=statusarrayori.plusElement(sta)
                                                                            phoneArrayori = phoneArrayori.plusElement(phone)
                                                                            bridArrayori = bridArray
                                                                            dinvdt = dinvdt.plusElement(invoice)
                                                                            datestarr = datestarr.plusElement(datest)
                                                                            voucheridori = vou_idarray

                                                                            descrip = descrip.plusElement(dates)
                                                                            ids = idss
                                                                            liids = idss

                                                                            progressBar10.visibility = View.GONE
                                                                            noresfo.visibility = View.GONE
                                                                            supplier_list.visibility = View.VISIBLE
                                                                            val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity, imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray2pr)
                                                                            val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                                                            wlist.adapter = whatever
                                                                        } catch (e: Exception) {

                                                                        }
                                                                    } else {
                                                                        progressBar10.visibility = View.GONE
                                                                        noresfo.visibility = View.VISIBLE
                                                                        supplier_list.visibility = View.GONE

                                                                    }

                                                                }


                                                            }
                                                            else {
                                                                db.collection("${broriky}_Supplier Invoice").orderBy("status").startAt(upstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {

                                                                                        Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                                        println(document.data)


                                                                                        var dt = document.data
                                                                                        var brids = (dt["branchid"]).toString()



                                                                                        if (brorival == brids) {
                                                                                            println("If SAVE KEYYYY" + brorival)
                                                                                            try {
                                                                                                var id = (document.id)
                                                                                                idss = idss.plusElement(id)

                                                                                                println(idss)
                                                                                                var name = (dt["prod_nms"]).toString()
                                                                                                var phone = (dt["supplier_phone"]).toString()
                                                                                                var datee = (dt["datest"]).toString()
                                                                                                var tot = (dt["gross_tot"]).toString()
                                                                                                var datest = (dt["datest"]).toString()

                                                                                                var dates = (dt["voucher_number"]).toString()
                                                                                                var sta = (dt["status"]).toString()
                                                                                                println("STATUSSSSSS" + sta)
                                                                                                println("Dateeee" + datee)


                                                                                                val c = Calendar.getInstance()
                                                                                                val df = SimpleDateFormat("dd/MM/yyyy")

                                                                                                val formattedDate = df.format(c.time)


                                                                                                /*val fromDate = formattedDate
                                                                                        val toDate = invdt
                                                                                        var diff: Long = 0

                                                                                        try {

                                                                                            //Convert to Date
                                                                                            val startDate = df.parse(fromDate)
                                                                                            val c1 = Calendar.getInstance()
                                                                                            //Change to Calendar Date
                                                                                            c1.time = startDate

                                                                                            //Convert to Date
                                                                                            val endDate = df.parse(toDate)
                                                                                            val c2 = Calendar.getInstance()
                                                                                            //Change to Calendar Date
                                                                                            c2.time = endDate

                                                                                            //get Time in milli seconds
                                                                                            val ms1 = c1.timeInMillis
                                                                                            val ms2 = c2.timeInMillis
                                                                                            //get difference in milli seconds
                                                                                            diff = (ms2 - ms1)
                                                                                            //Find number of days by dividing the mili seconds
                                                                                            val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                                                                            println("Number of days difference is: " + diffInDays)

                                                                                            descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                                                                            statusArray = statusArray.plusElement("Incomplete")

                                                                                        } catch (e: ParseException) {
                                                                                            e.printStackTrace()
                                                                                        }*/



                                                                                                try {

                                                                                                    var urlimg = (dt["imgurl"]).toString()
                                                                                                    urll = urlimg
                                                                                                    var deudt = (dt["payment_duedate"]).toString()
                                                                                                    pay = deudt
                                                                                                    var invdt = (dt["invoice_date"]).toString()
                                                                                                    invoice = invdt

                                                                                                    var imgnm = (dt["imagename"]).toString()


                                                                                                    val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                                                                                    val dateBeforeString = formattedDate
                                                                                                    val dateAfterString = invdt
                                                                                                    val dateBefore = myFormat.parse(dateBeforeString)
                                                                                                    val dateAfter = myFormat.parse(dateAfterString)
                                                                                                    val difference = dateAfter.time - dateBefore.time
                                                                                                    val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                                                                                    /* You can also convert the milliseconds to days using this method
                                                                                * float daysBetween =
                                                                                *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                                                                                */
                                                                                                    println("Number of Days between dates: " + daysBetween)
                                                                                                    if ((daysBetween > 0) && (sta != "Paid")) {
                                                                                                        descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                                                                                    } else if ((daysBetween <= 0) && (sta != "Paid")) {
                                                                                                        descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                                                                                    } else if ((daysBetween <= 0) && (sta == "Paid")) {
                                                                                                        descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                                                                                    }
                                                                                                    statusArray = statusArray.plusElement("")
                                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                                    imgurlArray = imgurlArray.plusElement(urlimg)
                                                                                                    imurl = imgurlArray

                                                                                                    imgnameArray = imgnameArray.plusElement(imgnm)
                                                                                                    imagenm = imgnameArray

                                                                                                    var descripss = (dt["description"]).toString()
                                                                                                    descriptionss = descriptionss.plusElement(descripss)
                                                                                                } catch (e: Exception) {
                                                                                                    var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                                                                                    imgurlArray = imgurlArray.plusElement(urlimg)

                                                                                                    imgnameArray = imgnameArray.plusElement("")

                                                                                                    imagenm = imgnameArray


                                                                                                    statusArray = statusArray.plusElement("Incomplete")
                                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                                    imurl = imgurlArray
                                                                                                    var deudt = ""
                                                                                                    pay = deudt
                                                                                                    var invdt = ""
                                                                                                    invoice = invdt
                                                                                                    descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")
                                                                                                    var descripss = (dt["description"]).toString()
                                                                                                    descriptionss = descriptionss.plusElement(descripss)

                                                                                                }


                                                                                                /* try {
                                                                                             var sta = (dt["postatus"]).toString()
                                                                                             if (sta == "complete") {
                                                                                                 descr = "Complete"
                                                                                                 statusArray1 = statusArray1.plusElement(descr)
                                                                                                 statusArray = statusArray.plusElement("")
                                                                                             } else {
                                                                                                 descr = "Incomplete"
                                                                                                 statusArray = statusArray.plusElement(descr)
                                                                                                 statusArray1 = statusArray1.plusElement("")
                                                                                             }
                                                                                         }*/


                                                                                                var vou_id = (dt["voucher_id"]).toString()
                                                                                                vou_idarray = vou_idarray.plusElement(vou_id)


                                                                                                text = text.plusElement((dt["supplier_name"]).toString())
                                                                                                nameArray = nameArray.plusElement(name)
                                                                                                bridArray = bridArray.plusElement(brids)
                                                                                                if (dates == "Siv") {
                                                                                                    dateArray = dateArray.plusElement("Dt - " + datee)
                                                                                                } else if (dates.isNotEmpty() && dates != "Siv") {
                                                                                                    dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                                                                                                }
                                                                                                priceArray = priceArray.plusElement(tot)
                                                                                                nameArrayori = text
                                                                                                dateArrayori = dateArray
                                                                                                priceArrayori = priceArray
                                                                                                datearr = datearr.plusElement(datee)
                                                                                                statusarrayori=statusarrayori.plusElement(sta)
                                                                                                datesarr = datesarr.plusElement(pay)
                                                                                                phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                                bridArrayori = bridArray
                                                                                                dinvdt = dinvdt.plusElement(invoice)
                                                                                                datestarr = datestarr.plusElement(datest)
                                                                                                voucheridori = vou_idarray

                                                                                                descrip = descrip.plusElement(dates)
                                                                                                ids = idss
                                                                                                liids = idss

                                                                                                progressBar10.visibility = View.GONE
                                                                                                noresfo.visibility = View.GONE
                                                                                                supplier_list.visibility = View.VISIBLE
                                                                                                val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity, imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray2pr)
                                                                                                val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                                                                                wlist.adapter = whatever
                                                                                            } catch (e: Exception) {

                                                                                            }
                                                                                        } else {
                                                                                            progressBar10.visibility = View.GONE
                                                                                            noresfo.visibility = View.VISIBLE
                                                                                            supplier_list.visibility = View.GONE

                                                                                        }

                                                                                    }


                                                                                }
                                                                                else{
                                                                                    db.collection("${broriky}_Supplier Invoice").orderBy("voucher_number").startAt(upstr).endAt(esc)
                                                                                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                                                if (e != null) {
                                                                                                }
                                                                                                if (value.isEmpty == false) {
                                                                                                    for (document in value) {

                                                                                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                                                            println(document.data)


                                                                                                            var dt = document.data
                                                                                                            var brids = (dt["branchid"]).toString()




                                                                                                            if (brorival == brids) {

                                                                                                                println("If SAVE KEYYYY" + brorival)
                                                                                                                try {

                                                                                                                    var id = (document.id)
                                                                                                                    idss = idss.plusElement(id)

                                                                                                                    println(idss)
                                                                                                                    var name = (dt["prod_nms"]).toString()
                                                                                                                    var phone = (dt["supplier_phone"]).toString()
                                                                                                                    var datee = (dt["datest"]).toString()
                                                                                                                    var tot = (dt["gross_tot"]).toString()
                                                                                                                    var datest = (dt["datest"]).toString()

                                                                                                                    var dates = (dt["voucher_number"]).toString()
                                                                                                                    var sta = (dt["status"]).toString()
                                                                                                                    println("STATUSSSSSS" + sta)
                                                                                                                    println("Dateeee" + datee)
                                                                                                                    var vou_id = (dt["voucher_id"]).toString()
                                                                                                                    vou_idarray = vou_idarray.plusElement(vou_id)

                                                                                                                    voucheridori = vou_idarray

                                                                                                                    val c = Calendar.getInstance()
                                                                                                                    val df = SimpleDateFormat("dd/MM/yyyy")

                                                                                                                    val formattedDate = df.format(c.time)


                                                                                                                    /*val fromDate = formattedDate
                                                                                                            val toDate = invdt
                                                                                                            var diff: Long = 0

                                                                                                            try {

                                                                                                                //Convert to Date
                                                                                                                val startDate = df.parse(fromDate)
                                                                                                                val c1 = Calendar.getInstance()
                                                                                                                //Change to Calendar Date
                                                                                                                c1.time = startDate

                                                                                                                //Convert to Date
                                                                                                                val endDate = df.parse(toDate)
                                                                                                                val c2 = Calendar.getInstance()
                                                                                                                //Change to Calendar Date
                                                                                                                c2.time = endDate

                                                                                                                //get Time in milli seconds
                                                                                                                val ms1 = c1.timeInMillis
                                                                                                                val ms2 = c2.timeInMillis
                                                                                                                //get difference in milli seconds
                                                                                                                diff = (ms2 - ms1)
                                                                                                                //Find number of days by dividing the mili seconds
                                                                                                                val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                                                                                                println("Number of days difference is: " + diffInDays)

                                                                                                                descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                                                                                                statusArray = statusArray.plusElement("Incomplete")

                                                                                                            } catch (e: ParseException) {
                                                                                                                e.printStackTrace()
                                                                                                            }*/



                                                                                                                    try {
                                                                                                                        var urlimg = (dt["imgurl"]).toString()
                                                                                                                        urll = urlimg
                                                                                                                        var deudt = (dt["payment_duedate"]).toString()
                                                                                                                        pay = deudt
                                                                                                                        var invdt = (dt["invoice_date"]).toString()
                                                                                                                        invoice = invdt


                                                                                                                        var imgnm = (dt["imagename"]).toString()


                                                                                                                        val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                                                                                                        val dateBeforeString = formattedDate
                                                                                                                        val dateAfterString = invdt
                                                                                                                        val dateBefore = myFormat.parse(dateBeforeString)
                                                                                                                        val dateAfter = myFormat.parse(dateAfterString)
                                                                                                                        val difference = dateAfter.time - dateBefore.time
                                                                                                                        val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                                                                                                        /* You can also convert the milliseconds to days using this method
                                                                                                    * float daysBetween =
                                                                                                    *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                                                                                                    */
                                                                                                                        println("Number of Days between dates: " + daysBetween)
                                                                                                                        if ((daysBetween > 0) && (sta != "Paid")) {
                                                                                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                                                                                                        } else if ((daysBetween <= 0) && (sta != "Paid")) {
                                                                                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                                                                                                        } else if ((daysBetween <= 0) && (sta == "Paid")) {
                                                                                                                            descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                                                                                                        }
                                                                                                                        statusArray = statusArray.plusElement("")
                                                                                                                        statusArray1 = statusArray1.plusElement("")

                                                                                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                                                                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                                                        imgurlArray = imgurlArray.plusElement(urlimg)
                                                                                                                        imurl = imgurlArray

                                                                                                                        imgnameArray = imgnameArray.plusElement(imgnm)
                                                                                                                        imagenm = imgnameArray


                                                                                                                        var descripss = (dt["description"]).toString()
                                                                                                                        descriptionss = descriptionss.plusElement(descripss)
                                                                                                                    } catch (e: Exception) {
                                                                                                                        var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                                                                                                        imgurlArray = imgurlArray.plusElement(urlimg)

                                                                                                                        imgnameArray = imgnameArray.plusElement("")

                                                                                                                        imagenm = imgnameArray


                                                                                                                        statusArray = statusArray.plusElement("")
                                                                                                                        statusArray1 = statusArray1.plusElement("")
                                                                                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                                                                                        statusArray3cncl = statusArray3cncl.plusElement("")

                                                                                                                        imurl = imgurlArray
                                                                                                                        var deudt = ""
                                                                                                                        pay = deudt
                                                                                                                        var invdt = ""
                                                                                                                        invoice = invdt
                                                                                                                        descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")
                                                                                                                        var descripss = (dt["description"]).toString()
                                                                                                                        descriptionss = descriptionss.plusElement(descripss)
                                                                                                                    }


                                                                                                                    /* try {
                                                                                                                 var sta = (dt["postatus"]).toString()
                                                                                                                 if (sta == "complete") {
                                                                                                                     descr = "Complete"
                                                                                                                     statusArray1 = statusArray1.plusElement(descr)
                                                                                                                     statusArray = statusArray.plusElement("")
                                                                                                                 } else {
                                                                                                                     descr = "Incomplete"
                                                                                                                     statusArray = statusArray.plusElement(descr)
                                                                                                                     statusArray1 = statusArray1.plusElement("")
                                                                                                                 }
                                                                                                             }*/






                                                                                                                    vou_idarray = vou_idarray.plusElement(vou_id)



                                                                                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                                                                                    nameArray = nameArray.plusElement(name)
                                                                                                                    bridArray = bridArray.plusElement(brids)
                                                                                                                    dateArray = dateArray.plusElement("Dt - " + datee + ",Voucher No " + dates)
                                                                                                                    priceArray = priceArray.plusElement(tot)
                                                                                                                    nameArrayori = text
                                                                                                                    dateArrayori = dateArray
                                                                                                                    priceArrayori = priceArray
                                                                                                                    datearr = datearr.plusElement(datee)
                                                                                                                    datesarr = datesarr.plusElement(pay)
                                                                                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                                                                                    bridArrayori = bridArray
                                                                                                                    dinvdt = dinvdt.plusElement(invoice)
                                                                                                                    datestarr = datestarr.plusElement(datest)
                                                                                                                    statusarrayori = statusarrayori.plusElement(sta)
                                                                                                                    voucheridori = vou_idarray
                                                                                                                    descrip = descrip.plusElement(dates)
                                                                                                                    ids = idss
                                                                                                                    liids = idss
                                                                                                                    println("Original KEYYYY" + brids)
                                                                                                                    println("LOGIINNNN KEYYYY" + brorival)

                                                                                                                    progressBar10.visibility = View.GONE
                                                                                                                    supplier_list.visibility = View.VISIBLE
                                                                                                                    noresfo.visibility = View.GONE
                                                                                                                    val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity, imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                                                                    val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                                                                                                    wlist.adapter = whatever
                                                                                                                } catch (e: Exception) {

                                                                                                                }
                                                                                                            } else {
                                                                                                                progressBar10.visibility = View.GONE
                                                                                                                supplier_list.visibility = View.GONE
                                                                                                                noresfo.visibility = View.VISIBLE
                                                                                                            }

                                                                                                        }


                                                                                                    } else {
                                                                                                    progressBar10.visibility = View.GONE
                                                                                                    supplier_list.visibility = View.GONE
                                                                                                    noresfo.visibility = View.VISIBLE

                                                                                                    }

                                                                                            })
                                                                            }

                                                            })
                                                        }

                                        })

                                        }

/*
                                    } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }

                }

                if ((x.trim().matches(ps.toRegex())) && (x != reg)) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("STRINGSSSS" + upstr)
                    nameget()
                }
                if((s.length >= 4) && (x != reg)&&((!s.contains("/"))))

                {
                    noresfo.visibility = View.GONE

                    var text = arrayOf<String>()
                    var idss = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var dateArray = arrayOf<String>()
                    var priceArray = arrayOf<String>()
                    var bridArray = arrayOf<String>()
                    var descriptionArray = arrayOf<String>()
                    var statusArray = arrayOf<String>()
                    var statusArray1 = arrayOf<String>()
                    var imgurlArray = arrayOf<String>()
                    var imgnameArray = arrayOf<String>()
var statusArray2pr = arrayOf<String>()
var statusArray3cncl = arrayOf<String>()

                    var vou_idarray=arrayOf<String>()



                    db.collection("${broriky}_Supplier Invoice").orderBy("voucher_number").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {

                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                            println(document.data)


                                            var dt = document.data
                                            var brids = (dt["branchid"]).toString()




                                            if (brorival == brids) {

                                                println("If SAVE KEYYYY" + brorival)
                                                try {

                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)

                                                    println(idss)
                                                    var name = (dt["prod_nms"]).toString()
                                                    var phone = (dt["supplier_phone"]).toString()
                                                    var datee = (dt["datest"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var datest = (dt["datest"]).toString()

                                                    var dates = (dt["voucher_number"]).toString()
                                                    var sta = (dt["status"]).toString()
                                                    println("STATUSSSSSS" + sta)
                                                    println("Dateeee" + datee)
                                                    var vou_id = (dt["voucher_id"]).toString()
                                                    vou_idarray=vou_idarray.plusElement(vou_id)

                                                    voucheridori=vou_idarray

                                                    val c = Calendar.getInstance()
                                                    val df = SimpleDateFormat("dd/MM/yyyy")

                                                    val formattedDate = df.format(c.time)


                                                    /*val fromDate = formattedDate
                                            val toDate = invdt
                                            var diff: Long = 0

                                            try {

                                                //Convert to Date
                                                val startDate = df.parse(fromDate)
                                                val c1 = Calendar.getInstance()
                                                //Change to Calendar Date
                                                c1.time = startDate

                                                //Convert to Date
                                                val endDate = df.parse(toDate)
                                                val c2 = Calendar.getInstance()
                                                //Change to Calendar Date
                                                c2.time = endDate

                                                //get Time in milli seconds
                                                val ms1 = c1.timeInMillis
                                                val ms2 = c2.timeInMillis
                                                //get difference in milli seconds
                                                diff = (ms2 - ms1)
                                                //Find number of days by dividing the mili seconds
                                                val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                                println("Number of days difference is: " + diffInDays)

                                                descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                                statusArray = statusArray.plusElement("Incomplete")

                                            } catch (e: ParseException) {
                                                e.printStackTrace()
                                            }*/



                                                    try {
                                                        var urlimg = (dt["imgurl"]).toString()
                                                        urll = urlimg
                                                        var deudt = (dt["payment_duedate"]).toString()
                                                        pay = deudt
                                                        var invdt = (dt["invoice_date"]).toString()
                                                        invoice = invdt


                                                        var imgnm=(dt["imagename"]).toString()


                                                        val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                                        val dateBeforeString = formattedDate
                                                        val dateAfterString = invdt
                                                        val dateBefore = myFormat.parse(dateBeforeString)
                                                        val dateAfter = myFormat.parse(dateAfterString)
                                                        val difference = dateAfter.time - dateBefore.time
                                                        val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                                        /* You can also convert the milliseconds to days using this method
                                    * float daysBetween =
                                    *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                                    */
                                                        println("Number of Days between dates: " + daysBetween)
                                                        if ((daysBetween > 0)&&(sta!="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                                        } else if ((daysBetween <= 0)&&(sta!="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                                        }
                                                        else if ((daysBetween <= 0)&&(sta=="Paid")) {
                                                            descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                                        }
                                                        statusArray = statusArray.plusElement("")
                                                        statusArray1 = statusArray1.plusElement("")

                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")

                                                        imgurlArray = imgurlArray.plusElement(urlimg)
                                                        imurl = imgurlArray

                                                        imgnameArray=imgnameArray.plusElement(imgnm)
                                                        imagenm=imgnameArray


                                                        var descripss=(dt["description"]).toString()
                                                        descriptionss=descriptionss.plusElement(descripss)
                                                    } catch (e: Exception) {
                                                        var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                                        imgurlArray = imgurlArray.plusElement(urlimg)

                                                        imgnameArray=imgnameArray.plusElement("")

                                                        imagenm=imgnameArray


                                                        statusArray = statusArray.plusElement("")
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")

                                                        imurl = imgurlArray
                                                        var deudt = ""
                                                        pay = deudt
                                                        var invdt = ""
                                                        invoice = invdt
                                                        descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")
                                                        var descripss=(dt["description"]).toString()
                                                        descriptionss=descriptionss.plusElement(descripss)
                                                    }


                                                    /* try {
                                                 var sta = (dt["postatus"]).toString()
                                                 if (sta == "complete") {
                                                     descr = "Complete"
                                                     statusArray1 = statusArray1.plusElement(descr)
                                                     statusArray = statusArray.plusElement("")
                                                 } else {
                                                     descr = "Incomplete"
                                                     statusArray = statusArray.plusElement(descr)
                                                     statusArray1 = statusArray1.plusElement("")
                                                 }
                                             }*/






                                                    vou_idarray=vou_idarray.plusElement(vou_id)



                                                    text = text.plusElement((dt["supplier_name"]).toString())
                                                    nameArray = nameArray.plusElement(name)
                                                    bridArray = bridArray.plusElement(brids)
                                                    dateArray = dateArray.plusElement("Dt - " + datee + ",Voucher No " + dates)
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = text
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(datee)
                                                    datesarr = datesarr.plusElement(pay)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                                    bridArrayori = bridArray
                                                    dinvdt = dinvdt.plusElement(invoice)
                                                    datestarr=datestarr.plusElement(datest)
                                                    statusarrayori=statusarrayori.plusElement(sta)
                                                    voucheridori=vou_idarray
                                                    descrip = descrip.plusElement(dates)
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brids)
                                                    println("LOGIINNNN KEYYYY" + brorival)

                                                    progressBar10.visibility=View.GONE
                                                    supplier_list.visibility=View.VISIBLE
                                                    noresfo.visibility=View.GONE
                                                    val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity, imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                                    wlist.adapter = whatever
                                                } catch (e: Exception) {

                                                }
                                            } else {
                                                progressBar10.visibility=View.GONE
                                                supplier_list.visibility=View.GONE
                                                noresfo.visibility=View.VISIBLE
                                            }

                                        }


                                    }

                                    else {

                                        nameget()

                                    }

/*
                                } else {
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }*/
                            })

                }

                else if(s.contains("/")){
                    dateget()
                }









                return
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }

            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if (searchedit.text.toString().isEmpty()) {
                    progressBar10.visibility=View.GONE
                    supplier_list.visibility=View.VISIBLE
                    noresfo.visibility=View.GONE
                    supinact()
                }
            }
        })



        searback1.setOnClickListener {
            searchedit.setText("")
            cardsearch.visibility = View.GONE

            search.visibility=View.VISIBLE
            textView.visibility=View.VISIBLE
            imageButtonmnu.visibility=View.VISIBLE
            progressBar10.visibility=View.GONE



            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@Supplier_first_MainActivity,R.anim.slide_to_left))
            noresfo.visibility = View.GONE
            supplier_list.visibility = View.VISIBLE
            supinact()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }




        // Supplier_list item click and navigate to 'Supplier_thirdMainActivity'

        supplier_list.setOnItemClickListener { parent, views, position, id ->


            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();

            val b = Intent(applicationContext, Supplier_thirdMainActivity::class.java)

            b.putExtra("from_suppin", "startlist_suppinv")
            b.putExtra("sinvnm", nameArrayori[position])
            b.putExtra("status", statusarrayori[position])
            b.putExtra("sinvph", phoneArrayori[position])
            b.putExtra("date", dinvdt[position])
            b.putExtra("estidate", datesarr[position])
            b.putExtra("dtdate", datearr[position])
            b.putExtra("dtdatest", datestarr[position])
            b.putExtra("descss", descriptionss[position])
            b.putExtra("reqids", descrip[position])
            b.putExtra("listids", liids[position])
            b.putExtra("imurl", imurl[position])
            b.putExtra("vouid",voucheridori[position])
            try {
                b.putExtra("imname", imagenm[position])
            }
            catch (e:Exception){

            }


            b.putExtra("brnchids", bridArrayori[position])
            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)


           b.putExtra("viewpurord", viewpurord)
           b.putExtra("addpurord", addpurord)
           b.putExtra("deletepurord", deletepurord)
           b.putExtra("editpurord", editepurord)
           b.putExtra("transferpurord", transferpurord)
           b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)




            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)











            pDialog.dismiss();
            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()
        }



        //If clicks (FAB) add button,navigate to ' MainSecondSupplier_secondActivity' .
        suppli_fab.setOnClickListener {
            val k= Intent(this@Supplier_first_MainActivity,MainSecondSupplier_secondActivity::class.java)

            k.putExtra("from_ver","main")


            k.putExtra("viewsuppin", viewsuppin)
            k.putExtra("addsuppin", addsuppin)
            k.putExtra("deletesuppin", deletesuppin)
            k.putExtra("editsuppin", editesuppin)
            k.putExtra("transfersuppin", transfersuppin)
            k.putExtra("exportsuppin", exportsuppin)



            k.putExtra("viewpurord", viewpurord)
            k.putExtra("addpurord", addpurord)
            k.putExtra("deletepurord", deletepurord)
            k.putExtra("editpurord", editepurord)
            k.putExtra("transferpurord", transferpurord)
            k.putExtra("exportpurord", exportpurord)

            k.putExtra("sendpurord", sendpurpo)




            k.putExtra("viewpurreq", viewpurreq)
            k.putExtra("addpurreq", addpurreq)
            k.putExtra("deletepurreq", deletepurreq)
            k.putExtra("editpurreq", editepurreq)
            k.putExtra("transferpurreq", transferpurreq)
            k.putExtra("exportpurreq", exportpurreq)








            k.putExtra("brky",broriky)
            startActivity(k)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()

        }


        userback.setOnClickListener {
            onBackPressed()
        }
    }



    fun dateget() {
        if (s.length >=3) {
            var text = arrayOf<String>()
            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var bridArray = arrayOf<String>()
            var descriptionArray = arrayOf<String>()
            var statusArray = arrayOf<String>()
            var statusArray1 = arrayOf<String>()
            var imgurlArray = arrayOf<String>()
            var imgnameArray = arrayOf<String>()
            var vou_idarray=arrayOf<String>()
var statusArray2pr = arrayOf<String>()
var statusArray3cncl = arrayOf<String>()


            db.collection("${broriky}_Supplier Invoice").orderBy("date").startAt(numberstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)
                                    var dt = document.data
                                    var brids = (dt["branchid"]).toString()



                                    if (brorival == brids) {


                                        var id = (document.id)
                                        idss = idss.plusElement(id)

                                        println(idss)
                                        var name = (dt["prod_nms"]).toString()
                                        var phone = (dt["supplier_phone"]).toString()
                                        var datee = (dt["datest"]).toString()
                                        var tot = (dt["gross_tot"]).toString()
                                        var vou_id = (dt["voucher_id"]).toString()
                                        var datest = (dt["datest"]).toString()
                                        var dates = (dt["voucher_number"]).toString()
                                        var sta = (dt["status"]).toString()
                                        println("STATUSSSSSS" + sta)
                                        println("Dateeee" + datee)


                                        val c = Calendar.getInstance()
                                        val df = SimpleDateFormat("dd/MM/yyyy")

                                        val formattedDate = df.format(c.time)


                                        /*val fromDate = formattedDate
                                val toDate = invdt
                                var diff: Long = 0

                                try {

                                    //Convert to Date
                                    val startDate = df.parse(fromDate)
                                    val c1 = Calendar.getInstance()
                                    //Change to Calendar Date
                                    c1.time = startDate

                                    //Convert to Date
                                    val endDate = df.parse(toDate)
                                    val c2 = Calendar.getInstance()
                                    //Change to Calendar Date
                                    c2.time = endDate

                                    //get Time in milli seconds
                                    val ms1 = c1.timeInMillis
                                    val ms2 = c2.timeInMillis
                                    //get difference in milli seconds
                                    diff = (ms2 - ms1)
                                    //Find number of days by dividing the mili seconds
                                    val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                    println("Number of days difference is: " + diffInDays)

                                    descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                    statusArray = statusArray.plusElement("Incomplete")

                                } catch (e: ParseException) {
                                    e.printStackTrace()
                                }*/



                                        try {
                                            var urlimg = (dt["imgurl"]).toString()
                                            urll = urlimg
                                            var deudt = (dt["payment_duedate"]).toString()
                                            pay = deudt
                                            var invdt = (dt["invoice_date"]).toString()
                                            invoice = invdt


                                            var imgnm=(dt["imagename"]).toString()


                                            val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                            val dateBeforeString = formattedDate
                                            val dateAfterString = invdt
                                            val dateBefore = myFormat.parse(dateBeforeString)
                                            val dateAfter = myFormat.parse(dateAfterString)
                                            val difference = dateAfter.time - dateBefore.time
                                            val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                            /* You can also convert the milliseconds to days using this method
                        * float daysBetween =
                        *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                        */
                                            println("Number of Days between dates: " + daysBetween)
                                            if ((daysBetween > 0)&&(sta!="Paid")) {
                                                descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                            } else if ((daysBetween <= 0)&&(sta!="Paid")) {
                                                descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                            }
                                            else if ((daysBetween <= 0)&&(sta=="Paid")) {
                                                descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                            }
                                            statusArray = statusArray.plusElement("")
                                            statusArray1 = statusArray1.plusElement("")

                                            statusArray2pr=statusArray2pr.plusElement("")
                                            statusArray3cncl=statusArray3cncl.plusElement("")

                                            imgurlArray = imgurlArray.plusElement(urlimg)

                                            imurl = imgurlArray
                                            var vou_idarray=arrayOf<String>()
                                            var vou_id = (dt["voucher_id"]).toString()

                                            imgnameArray=imgnameArray.plusElement(imgnm)
                                            imagenm=imgnameArray

                                        } catch (e: Exception) {
                                            var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                            imgurlArray = imgurlArray.plusElement(urlimg)


                                            imgnameArray=imgnameArray.plusElement("")

                                            imagenm=imgnameArray


                                            statusArray = statusArray.plusElement("Incomplete")
                                            statusArray1 = statusArray1.plusElement("")
                                            imurl = imgurlArray
                                            var deudt = ""
                                            pay = deudt
                                            var invdt = ""
                                            invoice = invdt
                                            descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")

                                        }


                                        /* try {
                                     var sta = (dt["postatus"]).toString()
                                     if (sta == "complete") {
                                         descr = "Complete"
                                         statusArray1 = statusArray1.plusElement(descr)
                                         statusArray = statusArray.plusElement("")
                                     } else {
                                         descr = "Incomplete"
                                         statusArray = statusArray.plusElement(descr)
                                         statusArray1 = statusArray1.plusElement("")
                                     }
                                 }*/







                                        vou_idarray=vou_idarray.plusElement(vou_id)
                                        text = text.plusElement((dt["supplier_name"]).toString())
                                        nameArray = nameArray.plusElement(name)
                                        bridArray = bridArray.plusElement(brids)
                                        if(dates=="Siv"){
                                            dateArray = dateArray.plusElement("Dt - " + datee)
                                        }
                                        else if(dates.isNotEmpty()&&dates!="Siv"){
                                            dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                                        }
                                        priceArray = priceArray.plusElement(tot)
                                        nameArrayori = text
                                        dateArrayori = dateArray
                                        priceArrayori = priceArray
                                        datearr = datearr.plusElement(datee)
                                        datesarr = datesarr.plusElement(pay)
                                        statusarrayori=statusarrayori.plusElement(sta)
                                        phoneArrayori = phoneArrayori.plusElement(phone)
                                        voucheridori=vou_idarray
                                        bridArrayori = bridArray
                                        dinvdt = dinvdt.plusElement(invoice)

                                        datestarr=datestarr.plusElement(datest)
                                        descrip = descrip.plusElement(dates)
                                        ids = idss
                                        liids = idss

                                        println("If SAVE KEYYYY" + brorival)
                                        progressBar10.visibility=View.GONE
                                        supplier_list.visibility=View.VISIBLE

                                        val whatever = req_searchsupp_adap(this@Supplier_first_MainActivity,imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                        val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                        wlist.adapter = whatever
                                        /*  catch (e: Exception) {

                                           }*/
                                    }
                                    else

                                    {
                                        noresfo.visibility = View.VISIBLE
                                        supplier_list.visibility = View.GONE
                                        progressBar10.visibility=View.GONE
                                    }


                                }


                            }

                            else {


                                noresfo.visibility = View.VISIBLE
                                progressBar10.visibility=View.GONE
                                supplier_list.visibility = View.GONE
                            }

/*
                        } else {
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }*/
                    })

        }
        else{
            noresfo.visibility=View.VISIBLE
            supplier_list.visibility=View.GONE
            progressBar10.visibility= View.GONE
        }
    }

    fun idget() {
        if ((s.length >= 4) && (x != reg)) {
            noresfo.visibility = View.GONE

            var text = arrayOf<String>()
            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var bridArray = arrayOf<String>()
            var descriptionArray = arrayOf<String>()
            var statusArray = arrayOf<String>()
            var statusArray1 = arrayOf<String>()
            var imgurlArray = arrayOf<String>()
            var imgnameArray = arrayOf<String>()
            var statusArray2pr = arrayOf<String>()
            var statusArray3cncl = arrayOf<String>()
            var vou_idarray=arrayOf<String>()

            db.collection("${broriky}_Supplier Invoice").orderBy("voucher_number").startAt(upstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)


                                    var dt = document.data
                                    var id = (document.id)
                                    idss = idss.plusElement(id)

                                    println(idss)
                                    var name = (dt["prod_nms"]).toString()
                                    var brids = (dt["branchid"]).toString()
                                    var phone = (dt["supplier_phone"]).toString()
                                    var datee = (dt["datest"]).toString()
                                    var tot = (dt["gross_tot"]).toString()

                                     var datest = (dt["datest"]).toString()
                                    var dates = (dt["voucher_number"]).toString()
                                    var sta = (dt["status"]).toString()
                                    println("STATUSSSSSS" + sta)
                                    println("Dateeee" + datee)
                                    var vou_id = (dt["voucher_id"]).toString()



                                    val c = Calendar.getInstance()
                                    val df = SimpleDateFormat("dd/MM/yyyy")

                                    val formattedDate = df.format(c.time)


                                    /*val fromDate = formattedDate
                            val toDate = invdt
                            var diff: Long = 0

                            try {

                                //Convert to Date
                                val startDate = df.parse(fromDate)
                                val c1 = Calendar.getInstance()
                                //Change to Calendar Date
                                c1.time = startDate

                                //Convert to Date
                                val endDate = df.parse(toDate)
                                val c2 = Calendar.getInstance()
                                //Change to Calendar Date
                                c2.time = endDate

                                //get Time in milli seconds
                                val ms1 = c1.timeInMillis
                                val ms2 = c2.timeInMillis
                                //get difference in milli seconds
                                diff = (ms2 - ms1)
                                //Find number of days by dividing the mili seconds
                                val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                                println("Number of days difference is: " + diffInDays)

                                descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                                statusArray = statusArray.plusElement("Incomplete")

                            } catch (e: ParseException) {
                                e.printStackTrace()
                            }*/



                                    try {
                                        var urlimg = (dt["imgurl"]).toString()
                                        urll = urlimg
                                        var deudt = (dt["payment_duedate"]).toString()
                                        pay = deudt
                                        var invdt = (dt["invoice_date"]).toString()
                                        invoice = invdt


                                        var imgnm=(dt["imagename"]).toString()


                                        val myFormat = SimpleDateFormat("dd/MM/yyyy")
                                        val dateBeforeString = formattedDate
                                        val dateAfterString = invdt
                                        val dateBefore = myFormat.parse(dateBeforeString)
                                        val dateAfter = myFormat.parse(dateAfterString)
                                        val difference = dateAfter.time - dateBefore.time
                                        val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                                        /* You can also convert the milliseconds to days using this method
                    * float daysBetween =
                    *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
                    */
                                        println("Number of Days between dates: " + daysBetween)
                                        if ((daysBetween > 0)&&(sta!="Paid")) {
                                            descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                                        } else if ((daysBetween <= 0)&&(sta!="Paid")) {
                                            descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                                        }
                                        else if ((daysBetween <= 0)&&(sta=="Paid")) {
                                            descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                                        }
                                        statusArray = statusArray.plusElement("")
                                        statusArray1 = statusArray1.plusElement("")

                                        statusArray2pr=statusArray2pr.plusElement("")
                                        statusArray3cncl=statusArray3cncl.plusElement("")



                                        imgurlArray = imgurlArray.plusElement(urlimg)
                                        imurl = imgurlArray

                                        imgnameArray=imgnameArray.plusElement(imgnm)
                                        imagenm=imgnameArray

                                    } catch (e: Exception) {
                                        var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                                        imgurlArray = imgurlArray.plusElement(urlimg)

                                        statusArray = statusArray.plusElement("")
                                        statusArray1 = statusArray1.plusElement("")

                                        statusArray2pr=statusArray2pr.plusElement("")
                                        statusArray3cncl=statusArray3cncl.plusElement("")

                                        imgnameArray=imgnameArray.plusElement("")

                                        imagenm=imgnameArray

                                        imurl = imgurlArray
                                        var deudt = ""
                                        pay = deudt
                                        var invdt = ""
                                        invoice = invdt
                                        descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")

                                    }


                                    /* try {
                                 var sta = (dt["postatus"]).toString()
                                 if (sta == "complete") {
                                     descr = "Complete"
                                     statusArray1 = statusArray1.plusElement(descr)
                                     statusArray = statusArray.plusElement("")
                                 } else {
                                     descr = "Incomplete"
                                     statusArray = statusArray.plusElement(descr)
                                     statusArray1 = statusArray1.plusElement("")
                                 }
                             }*/


                                    vou_idarray=vou_idarray.plusElement(vou_id)

                                    text = text.plusElement((dt["supplier_name"]).toString())
                                    nameArray = nameArray.plusElement(name)
                                    bridArray = bridArray.plusElement(brids)
                                    if(dates=="Siv"){
                                        dateArray = dateArray.plusElement("Dt - " + datee)
                                    }
                                    else if(dates.isNotEmpty()&&dates!="Siv"){
                                        dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                                    }
                                    priceArray = priceArray.plusElement(tot)
                                    nameArrayori = text
                                    dateArrayori = dateArray
                                    priceArrayori = priceArray
                                    datearr = datearr.plusElement(datee)
                                    datesarr = datesarr.plusElement(pay)
                                    statusarrayori=statusarrayori.plusElement(sta)

                                    phoneArrayori = phoneArrayori.plusElement(phone)
                                    bridArrayori = bridArray
                                    dinvdt = dinvdt.plusElement(invoice)
                                    datestarr=datestarr.plusElement(datest)
                                    voucheridori=vou_idarray
                                    descrip = descrip.plusElement(dates)
                                    ids = idss
                                    liids = idss
                                    println("Original KEYYYY" + brids)
                                    println("LOGIINNNN KEYYYY" + brorival)
                                    brorival = broriky

                                    if (brorival == brids) {

                                        println("If SAVE KEYYYY" + brorival)
                                        try {
                                            progressBar10.visibility=View.GONE
                                            supplier_list.visibility=View.VISIBLE
                                            val whatever = req_searchsupp_adap(this, imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                            val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                                            wlist.adapter = whatever
                                        } catch (e: Exception) {

                                        }
                                    } else {

                                    }

                                }


                            } else {
                                println("NO RECORDSSSS FOUNDD")
                                dateget()
                                noresfo.visibility = View.VISIBLE
                                supplier_list.visibility=View.GONE
                                progressBar10.visibility= View.GONE




                            }


                      /*  } else {
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }*/
                    })
        }
        else{
            noresfo.visibility=View.VISIBLE
            supplier_list.visibility=View.GONE
            progressBar10.visibility= View.GONE
        }
    }

    override fun onBackPressed() {


        if(cardsearch.visibility==View.VISIBLE){
            cardsearch.visibility=View.GONE

            search.visibility=View.VISIBLE
            textView.visibility=View.VISIBLE
            imageButtonmnu.visibility=View.VISIBLE
            noresfo.visibility=View.INVISIBLE
            progressBar10.visibility=View.GONE
            supplier_list.visibility=View.VISIBLE

            supinact()
        }
        else{
            val k=Intent(this,MainPurchasefirstActivity::class.java)

            k.putExtra("skey", broriky)
            k.putExtra("viewsuppin", viewsuppin)
            k.putExtra("addsuppin", addsuppin)
            k.putExtra("deletesuppin", deletesuppin)
            k.putExtra("editsuppin", editesuppin)
            k.putExtra("transfersuppin", transfersuppin)
            k.putExtra("exportsuppin", exportsuppin)


            k.putExtra("viewpurord", viewpurord)
            k.putExtra("addpurord", addpurord)
            k.putExtra("deletepurord", deletepurord)
            k.putExtra("editpurord", editepurord)
            k.putExtra("transferpurord", transferpurord)
            k.putExtra("exportpurord", exportpurord)
            k.putExtra("sendpurord", sendpurpo)




            k.putExtra("viewpurreq", viewpurreq)
            k.putExtra("addpurreq", addpurreq)
            k.putExtra("deletepurreq", deletepurreq)
            k.putExtra("editpurreq", editepurreq)
            k.putExtra("transferpurreq", transferpurreq)
            k.putExtra("exportpurreq", exportpurreq)




            startActivity(k)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }



    }


    //--------------------------Get and list out the supplier invoice from online db--------------------------//

    fun supinact() {
        try {
           progressBar19.visibility=View.VISIBLE

            db.collection("${broriky}_Supplier Invoice").whereEqualTo("branchid", broriky)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        if (value.isEmpty == false) {

try {
    db.collection("${broriky}_Supplier Invoice").orderBy("voucher_id", Query.Direction.DESCENDING).whereEqualTo("branchid", broriky).limit(15)
            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                var text = arrayOf<String>()
                var idss = arrayOf<String>()
                var nameArray = arrayOf<String>()
                var dateArray = arrayOf<String>()
                var priceArray = arrayOf<String>()
                var bridArray = arrayOf<String>()
                var descriptionArray = arrayOf<String>()
                var statusArray = arrayOf<String>()
                var statusArray1 = arrayOf<String>()
                var imgurlArray = arrayOf<String>()
                var imgnameArray = arrayOf<String>()

                var statusArray2pr = arrayOf<String>()
                var statusArray3cncl = arrayOf<String>()

                var vou_idarray=arrayOf<String>()



                if (e != null) {
                    Log.w("", "Listen failed.", e)
                    return@EventListener
                }
                if (value.isEmpty == false) {

                    imageView10.visibility = View.GONE
                    for (document in value) {

                        Log.d("d", "key --- " + document.id + " => " + document.data)
                        println(document.data)

                        var dt = document.data
                        var id = (document.id)
                        idss = idss.plusElement(id)

                        println(idss)

                        var name = (dt["prod_nms"]).toString()
                        var brids = (dt["branchid"]).toString()
                        var phone = (dt["supplier_phone"]).toString()
                        var datee = (dt["date"]).toString()
                        var datest = (dt["datest"]).toString()


                        var tot = (dt["gross_tot"]).toString()
                        var dates = (dt["voucher_number"]).toString()
                        var sta = (dt["status"]).toString()

                        println("STATUSSSSSS" + sta)
                        println("Dateeee" + datee)
                        brorival = broriky


                        val c = Calendar.getInstance()
                        val df = SimpleDateFormat("dd/MM/yyyy")

                        val formattedDate = df.format(c.time)


                        /*val fromDate = formattedDate
                    val toDate = invdt
                    var diff: Long = 0

                    try {

                        //Convert to Date
                        val startDate = df.parse(fromDate)
                        val c1 = Calendar.getInstance()
                        //Change to Calendar Date
                        c1.time = startDate

                        //Convert to Date
                        val endDate = df.parse(toDate)
                        val c2 = Calendar.getInstance()
                        //Change to Calendar Date
                        c2.time = endDate

                        //get Time in milli seconds
                        val ms1 = c1.timeInMillis
                        val ms2 = c2.timeInMillis
                        //get difference in milli seconds
                        diff = (ms2 - ms1)
                        //Find number of days by dividing the mili seconds
                        val diffInDays = (diff / (24 * 60 * 60 * 1000)).toInt()
                        println("Number of days difference is: " + diffInDays)

                        descriptionArray = descriptionArray.plusElement( sta+", Due in"+diffInDays+"days")
                        statusArray = statusArray.plusElement("Incomplete")

                    } catch (e: ParseException) {
                        e.printStackTrace()
                    }*/



                        try {
                            var urlimg = (dt["imgurl"]).toString()
                            urll = urlimg
                            var deudt = (dt["payment_duedate"]).toString()
                            pay = deudt
                            var invdt = (dt["invoice_date"]).toString()
                            invoice = invdt

                            var imgnm = (dt["imagename"]).toString()
                            var vou_id = (dt["voucher_id"]).toString()

                            vou_idarray=vou_idarray.plusElement(vou_id)
                            val myFormat = SimpleDateFormat("dd/MM/yyyy")
                            val dateBeforeString = formattedDate
                            val dateAfterString = deudt
                            val dateBefore = myFormat.parse(dateBeforeString)
                            val dateAfter = myFormat.parse(dateAfterString)
                            val difference = dateAfter.time - dateBefore.time
                            val daysBetween = (difference / (1000 * 60 * 60 * 24)).toInt()
                            if ((daysBetween > 0)&&(sta!="Paid")) {
                                descriptionArray = descriptionArray.plusElement(sta + ", Due in " + daysBetween + "day(s)")
                            }
                            else if ((daysBetween > 0)&&(sta=="Paid")) {
                                descriptionArray = descriptionArray.plusElement(sta + " on $datee")
                            }

                            else if ((daysBetween <= 0)&&(sta!="Paid")) {
                                descriptionArray = descriptionArray.plusElement(sta + ", Due date exceeded.")

                            }
                            else if ((daysBetween <= 0)&&(sta=="Paid")) {
                                descriptionArray = descriptionArray.plusElement(sta + " on $datee")

                            }

                            /* You can also convert the milliseconds to days using this method
            * float daysBetween =
            *         TimeUnit.DAYS.convert(difference, TimeUnit.MILLISECONDS)
            */
                            println("Number of Days between dates: " + daysBetween)

                            statusArray = statusArray.plusElement("")
                            statusArray1 = statusArray1.plusElement("")
                            statusArray2pr = statusArray2pr.plusElement("")
                            statusArray3cncl = statusArray3cncl.plusElement("")

                            imgurlArray = imgurlArray.plusElement(urlimg)
                            imurl = imgurlArray
                            imgnameArray = imgnameArray.plusElement(imgnm)
                            imagenm = imgnameArray

                            var descripss = (dt["description"]).toString()
                            descriptionss = descriptionss.plusElement(descripss)

                        } catch (e: Exception) {
                            var urlimg = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/empty-document.png?alt=media&token=36496444-892f-4082-88a2-8c98a826a769"
                            imgurlArray = imgurlArray.plusElement(urlimg)

                            statusArray = statusArray.plusElement("")
                            statusArray1 = statusArray1.plusElement("")

                            statusArray2pr = statusArray2pr.plusElement("")
                            statusArray3cncl = statusArray3cncl.plusElement("")

                            imgnameArray = imgnameArray.plusElement("")

                            imagenm = imgnameArray


                            imurl = imgurlArray
                            var deudt = ""
                            pay = deudt
                            var invdt = ""
                            invoice = invdt
                            descriptionArray = descriptionArray.plusElement(sta + ",Due date not specified")

                            var descripss = (dt["description"]).toString()
                            descriptionss = descriptionss.plusElement(descripss)

                        }


                        /* try {
                         var sta = (dt["postatus"]).toString()
                         if (sta == "complete") {
                             descr = "Complete"
                             statusArray1 = statusArray1.plusElement(descr)
                             statusArray = statusArray.plusElement("")
                         } else {
                             descr = "Incomplete"
                             statusArray = statusArray.plusElement(descr)
                             statusArray1 = statusArray1.plusElement("")
                         }
                     }*/









                        text = text.plusElement((dt["supplier_name"]).toString())
                        nameArray = nameArray.plusElement(name)
                        bridArray = bridArray.plusElement(brids)

                        if(dates=="Siv"){
                            dateArray = dateArray.plusElement("Dt - " + datee)
                        }
                        else if(dates.isNotEmpty()&&dates!="Siv"){
                            dateArray = dateArray.plusElement("Dt -" + datee + ",Voucher No " + dates)

                        }


                        priceArray = priceArray.plusElement(tot)
                        nameArrayori = text
                        dateArrayori = dateArray
                        priceArrayori = priceArray
                        datearr = datearr.plusElement(datee)
                        datestarr = datestarr.plusElement(datest)
                        datesarr = datesarr.plusElement(pay)
                        phoneArrayori = phoneArrayori.plusElement(phone)
                        bridArrayori = bridArray
                        dinvdt = dinvdt.plusElement(invoice)
                        voucheridori=vou_idarray
                        statusarrayori=statusarrayori.plusElement(sta)


                        descrip = descrip.plusElement(dates)
                        ids = idss
                        liids = idss

                        /* swipeContainer.setRefreshing(false);*/
                    }
                    text = text.plusElement("")
                    idss = idss.plusElement("")
                    nameArray = nameArray.plusElement("")
                    dateArray = dateArray.plusElement("")
                    priceArray = priceArray.plusElement("NA")
                    bridArray = bridArray.plusElement("")
                    descriptionArray = descriptionArray.plusElement("")
                    statusArray = statusArray.plusElement("")
                    statusArray1 = statusArray1.plusElement("")
                    statusArray2pr = statusArray2pr.plusElement("")
                    statusArray3cncl = statusArray3cncl.plusElement("")
                    imgurlArray = imgurlArray.plusElement("")

                    try {
                        progressBar19.visibility=View.GONE
                        val whatever = supply_first_adap(this, imgurlArray, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                        val wlist = findViewById<ListView>(R.id.supplier_list) as ListView
                        wlist.adapter = whatever

                    } catch (e: Exception) {
                        progressBar19.visibility=View.GONE
                    }
                } else {
                    progressBar19.visibility=View.GONE
                    imageView10.visibility = View.VISIBLE
                }


            })
}
catch (e:Exception){

}
                        } else {
                            progressBar19.visibility=View.GONE
                            imageView10.visibility = View.VISIBLE
                        }
                    })

        } catch (e: Exception) {
            Toast.makeText(applicationContext, "No records found", Toast.LENGTH_SHORT).show()
        }
    }
    companion object {
 //Listens internet status whether net is on/off.

        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                  /// if connection is off then all views becomes disable

                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {
                 /// if connection is off then all views becomes enabled
                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }
    fun net_status():Boolean{ // Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}
