package com.example.vinitas.inventory_app

import android.app.Activity
import android.graphics.Bitmap
import android.net.Uri
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.vinitas.inventory_app.R
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView
import java.net.URI
import java.net.URL

/**
 * Created by vinitas stock on 18-01-2018.
 */
class listAdapter_serv(private val context: Activity,
                  private val icoArray: ArrayList<String>,
                  private val category: ArrayList<String>,
                  private val imgname: ArrayList<String>,
                  private val d: ArrayList<String>) : ArrayAdapter<Any>(context, R.layout.list_style,category as List<Any>?) {
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.list_style, null, true)
        val cat = rowView.findViewById<TextView>(R.id.cat_list_name) as TextView
        val id = rowView.findViewById<TextView>(R.id.cat_list_id) as TextView
        val img = rowView.findViewById<View>(R.id.cat_list_image) as CircleImageView
        val imagename = rowView.findViewById<TextView>(R.id.image_name) as TextView
        cat.text = category[position]
        id.text = d[position]

        try {
            Picasso.with(context)
                    .load(icoArray[position])
                    .into(img);

            imagename.text = imgname[position]
        }
        catch (e:Exception){

        }

        return rowView
    }
}