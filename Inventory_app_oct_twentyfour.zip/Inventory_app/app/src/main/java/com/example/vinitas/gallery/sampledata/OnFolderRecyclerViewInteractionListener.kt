package com.example.vinitas.gallery.sampledata

import com.zfdang.multiple_images_selector.models.FolderItem

/**
 * Created by zfdang on 2016-4-14.
 */
interface OnFolderRecyclerViewInteractionListener {
    fun onFolderItemInteraction(item: FolderItem)
}