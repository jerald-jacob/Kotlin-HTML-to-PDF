package com.example.vinitas.gallery.sampledata

import android.net.Uri
import com.facebook.imagepipeline.image.ImageInfo
import com.facebook.drawee.controller.BaseControllerListener
import com.facebook.drawee.backends.pipeline.Fresco
import com.facebook.drawee.interfaces.DraweeController
import com.facebook.imagepipeline.common.ResizeOptions
import com.facebook.imagepipeline.request.ImageRequestBuilder
import com.facebook.imagepipeline.request.ImageRequest
import com.facebook.drawee.view.SimpleDraweeView


object DraweeUtils {
    private val TAG = "DraweeUtils"

    // http://www.jianshu.com/p/5364957dcf49
    fun showThumb(uri: Uri, draweeView: SimpleDraweeView) {
        val request = ImageRequestBuilder.newBuilderWithSource(uri)
                .setAutoRotateEnabled(true)
                .setResizeOptions(ResizeOptions(200, 200))
                .build()

        val controller = Fresco.newDraweeControllerBuilder()
                .setImageRequest(request)
                .setAutoPlayAnimations(true)
                .setOldController(draweeView.controller)
                .setControllerListener(BaseControllerListener())
                .build()
        draweeView.controller = controller
    }

}