package com.example.vinitas.inventory_app


import android.annotation.SuppressLint
import android.app.Activity
import android.media.tv.TvContract.Channels.CONTENT_TYPE
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.AbsListView
import android.opengl.ETC1.getHeight
import android.os.Build
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.opengl.ETC1.getHeight
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView


/**
 * Created by vinitas IT on 13-12-2017.
 */
class req_searchsupp_adap(
//to reference the Activity
        private val context: Activity,
        private val urlArray: Array<String>,
        private val idArray: Array<String>,//to store the list of countries
        private val compronameArray: Array<String>, //to store the list of countries
        private val itemnmArray    : Array<String>,
        private val orderArray     : Array<String>,
        private val poArray        : Array<String>,
        private val mlArray        : Array<String>,
        private val priceArray     : Array<String>,
        private val compArray        : Array<String>,
        private val partiallycompArray        : Array<String>,
        private val cancelArray       : Array<String>
): ArrayAdapter<Any>(context, R.layout.reqsuppitems, compronameArray) {

    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {

        var g= String()
        var urlArraydup= String()
        var idArraydup= String()//to store the list of countries
        var compronameArraydup= String()//to store the list of countries
        var itemnmArraydup    = String()
        var orderArraydup     = String()
        var poArraydup        = String()
        var mlArraydup       = String()
        var priceArraydup     = String()
        var compArraydup        = String()

        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.reqsuppitems, null, true)
        val rowView1 = inflater.inflate(R.layout.adview, null, true)

        //this code gets references to objects in the listview_row.xml file
        val imTextField    =      rowView.findViewById<View>(R.id.imurl) as TextView
        val idTextField    =      rowView.findViewById<View>(R.id.idd) as TextView
        val companynameTextField    =      rowView.findViewById<View>(R.id.companynm) as TextView
        val itemnameTextField       =      rowView.findViewById<View>(R.id.pur_item)  as TextView
        val ordernameTextField      =      rowView.findViewById<View>(R.id.order)     as TextView
        val ponameTextField         =      rowView.findViewById<View>(R.id.po)        as TextView
        val pricenameTextField      =      rowView.findViewById<View>(R.id.price)     as TextView
        val compnameTextField       =      rowView.findViewById<View>(R.id.complete)  as TextView
        val compnameTextField1      =      rowView.findViewById<View>(R.id.completett)  as TextView

        val compnameTextFieldparcomp       =      rowView.findViewById<View>(R.id.partcomp)  as TextView
        val compnameTextField1cancel      =      rowView.findViewById<View>(R.id.cancel)  as TextView
        /* val mAdView = rowView.findViewById<View>(R.id.adView) as AdView*/





        //this code sets the values of the objects to values from the arrays
/*

          if(priceArray[position]==""){
              imTextField.text=urlArraydup
              idTextField.text =idArraydup
              companynameTextField.text = compronameArraydup
              itemnameTextField.text    =itemnmArraydup
              ordernameTextField.text   = orderArraydup
              ponameTextField.text      = poArraydup
              pricenameTextField.text   = mlArraydup
              compnameTextField.text    = priceArraydup
              compnameTextField1.text    = compArraydup
          }

       else{*/



        imTextField.text = urlArray[position]
        idTextField.text = idArray[position]
        companynameTextField.text = compronameArray[position]
        itemnameTextField.text = itemnmArray[position]
        ordernameTextField.text = orderArray[position]
        ponameTextField.text = poArray[position]
        pricenameTextField.text = mlArray[position]
        compnameTextField.text = priceArray[position]
        compnameTextField1.text = compArray[position]
        compnameTextFieldparcomp.text = partiallycompArray[position]
        compnameTextField1cancel.text = cancelArray[position]

        /* }*/






        /*  if(position==5){
              mAdView.visibility=View.VISIBLE
              val adView = AdView(context)
              adView.adSize = AdSize.BANNER
              adView.adUnitId = "ca-app-pub-3940256099942544/6300978111"


              val adRequest = AdRequest.Builder().build()
              mAdView.loadAd(adRequest)
          }*/

        //infoTextField.text = infoArray[position]


        return rowView

    }



}