package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_supplier_request.*
import java.util.ArrayList

class SupplierRequestActivity : AppCompatActivity() {


    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""






    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""




    val db = FirebaseFirestore.getInstance()
    val TAG = "some"
    var oriky= String()

    var suppsel= String()
    var loc=String()
    var mob=String()
    var service_access:SessionManagement?=null
    var empkey= String()

    var addsupp=String()
    var viewsupp= String()
    var deletesupp= String()
    var editsupp= String()
    var importsupp= String()
    var exportsupp= String()

    var gg= arrayOf<String>()
    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supplier_request)

        net_status()
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@SupplierRequestActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }



        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.constrainsupp)

        val iss=intent.getStringExtra("oribrky")
        oriky=iss

        service_access = SessionManagement(this)
        empkey = service_access!!.userDetails[SessionManagement.employeeky].toString()
        try {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false);
            pDialog.show();
            //val pre = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("dark_theme", false);
            val path = "emp_access/$empkey/inventory"
            val collection = ArrayList<String>()
            db.collection(path).document("supplier")
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.getResult().exists()) {
                            val dd = task.result.data
                           viewsupp = dd.get("view").toString()
                             addsupp = dd.get("add").toString()

                             deletesupp = dd.get("delete").toString()
                             editsupp = dd.get("edit").toString()
                             importsupp = dd.get("import").toString()
                             exportsupp = dd.get("export").toString()
                            println("view : " + viewsupp)
                            println("add : " + addsupp)
                            println("delete : " + deletesupp)
                            println("edit : " + editsupp)
                            println("import : " + importsupp)
                            println("export : " + exportsupp)
                            val session = SessionManagement(this)
                            session.putSupplier_Access(viewsupp, addsupp, deletesupp, editsupp, importsupp, exportsupp)
                            pDialog.dismiss()
                        } else {
                            val session = SessionManagement(this)
                            session.putSupplier_Access("false", "false", "false", "false", "false", "false")
                            pDialog.dismiss()
                        }
                    }
                    .addOnSuccessListener {

                    }
        }
        catch (e:Exception){

        }


        //Purchase request

        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr


            println("PURCHASE REQUEST TRANSFER NEXT"+transferpurreq)


        }
        if (expr != null) {
            exportpurreq = expr
        }


        //Purchase order

        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")
        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }


        //Supplier Invoice

        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }

        var  snameArray = arrayOf<String>()
        var  sphoneArray = arrayOf<String>()
        var slocArray = arrayOf<String>()
        var sstateArray = arrayOf<String>()
        var sgstArray = arrayOf<String>()
        var sadd1 = arrayOf<String>()
        var sadd2 = arrayOf<String>()
        var sadd3 = arrayOf<String>()
        var idArray = arrayOf<String>()
        var statusArray=arrayOf<String>()
        var imgArray=arrayOf<String>()
        var icohighArray = arrayOf<String>()
        var icohighnmArray = arrayOf<String>()


        fun gt() {
            var  snameArraydup = arrayOf<String>()
            var  sphoneArraydup = arrayOf<String>()
            var slocArraydup = arrayOf<String>()
            var sstateArraydup = arrayOf<String>()
            var sgstArraydup = arrayOf<String>()
            var sadd1dup = arrayOf<String>()
            var sadd2dup = arrayOf<String>()
            var sadd3dup = arrayOf<String>()
            var idArraydup = arrayOf<String>()
            var statusArraydup=arrayOf<String>()
            var imgArraydup=arrayOf<String>()

            snameArray=snameArraydup
            sphoneArray=sphoneArraydup
            slocArray=slocArraydup
            sstateArray=sstateArraydup
            sgstArray=sgstArraydup
            sadd1=sadd1dup
            sadd2=sadd2dup
            sadd3=sadd3dup
            idArray=idArraydup
            statusArray=statusArraydup
            imgArray=imgArraydup



            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();

            progressBar3.visibility= View.VISIBLE

            db.collection("suppliers")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                val dd = document.data
                                var id = document.id

                                var statuss=dd["status"].toString()

                                if(statuss=="Active"){
                                    snameArray = snameArray.plusElement(dd["spnm"].toString())
                                    sphoneArray = sphoneArray.plusElement(dd["spmob1"].toString())
                                    mob=(dd["spmob1"].toString())
                                    loc=(dd["spcity"].toString())

                                    if(loc.isNotEmpty()){
                                        slocArray=slocArray.plusElement(loc+", "+mob)
                                    }
                                    else if(loc.isEmpty()){
                                        slocArray=slocArray.plusElement(mob)
                                    }

                                    idArray = idArray.plusElement(id)
                                    sstateArray = sstateArray.plusElement(dd["spstate"].toString())
                                    sgstArray = sgstArray.plusElement(dd["spgst"].toString())
                                    sadd1 = sadd1.plusElement(dd["spaddress1"].toString())
                                    sadd2 = sadd2.plusElement(dd["spaddress2"].toString())
                                    sadd3 = sadd3.plusElement(dd["spaddress3"].toString())
                                    statusArray = statusArray.plusElement(dd["status"].toString())
                                    icohighnmArray =icohighnmArray.plusElement(dd["img1nhigh"].toString());//23
                                    icohighArray=icohighArray.plusElement(dd["img1urlhigh"].toString());//28
                                    try {
                                        var im = dd["img1url"].toString()
                                        if (im.isNotEmpty()) {

                                            imgArray = imgArray.plusElement(im)
                                        } else {
                                            imgArray = imgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                        }
                                    } catch (e: Exception) {

                                    }
                                }
                                else{

                                    pDialog.dismiss()
                                }




                            }
                            pDialog.dismiss()
                            progressBar3.visibility= View.GONE
                            val whatever = request_supp_adap(this, sadd1, sadd2, sadd2, sgstArray, sstateArray,
                                    idArray, statusArray, snameArray, slocArray, sphoneArray, imgArray,icohighnmArray,icohighArray)
                            pur_supplier_list.adapter = whatever


                        } else {

                        }
                    })
        }
        gt()




/*        swipeContainer.setOnRefreshListener {
            gt()
        }

            swipeContainer.setColorSchemeResources(R.color.tool,
                    android.R.color.holo_green_light,
                    android.R.color.holo_orange_light,
                    android.R.color.holo_red_light)*/


        product_list_back_btn.setOnClickListener {
            onBackPressed()
        }


        addsupplier.setOnClickListener {

            suppsel="suppadd"
            if (addsupp == "true") {
                sadd1=gg.clone()
                sadd2=gg.clone()
                sadd2=gg.clone()
                sgstArray=gg.clone()
                sstateArray=gg.clone()
                idArray=gg.clone()
                statusArray=gg.clone()
                snameArray=gg.clone()
                slocArray=gg.clone()
                sphoneArray=gg.clone()
                imgArray=gg.clone()
                icohighnmArray=gg.clone()
                icohighArray=gg.clone()
                val ag = Intent(this@SupplierRequestActivity, SupplierAddMain::class.java)
                ag.putExtra("supppro", "addsupp")
                ag.putExtra("suppsel",suppsel)
                ag.putExtra("addsupps",addsupp)
                ag.putExtra("editsupp",editsupp)
                ag.putExtra("deletesupp",deletesupp)
                ag.putExtra("viewsupp",viewsupp)
                ag.putExtra("importsupp",importsupp)
                ag.putExtra("exportsupp",exportsupp)

                ag.putExtra("newid", db.collection("suppliers").document().id)
                startActivity(ag)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)

            } else {
                popup("add")
                addsupplier.isEnabled = true
            }

        }

        pur_supplier_list.setOnItemClickListener { parent, views, position, id ->

            val k=Intent(this@SupplierRequestActivity,RequestAddActivity::class.java)
            k.putExtra("from_req","from_suppadd")
            k.putExtra("id",idArray[position])
            k.putExtra("name",snameArray[position])
            k.putExtra("mobile",sphoneArray[position])
            k.putExtra("city",slocArray[position])
            k.putExtra("state",sstateArray[position])
            k.putExtra("gst",sgstArray[position])
            k.putExtra("addre1",sadd1[position])
            k.putExtra("addre2",sadd2[position])
            k.putExtra("addre3",sadd3[position])
            k.putExtra("oribrky",oriky)

            k.putExtra("viewsuppin", viewsuppin)
            k.putExtra("addsuppin", addsuppin)
            k.putExtra("deletesuppin", deletesuppin)
            k.putExtra("editsuppin", editesuppin)
            k.putExtra("transfersuppin", transfersuppin)
            k.putExtra("exportsuppin", exportsuppin)


            k.putExtra("viewpurord", viewpurord)
            k.putExtra("addpurord", addpurord)
            k.putExtra("deletepurord", deletepurord)
            k.putExtra("editpurord", editepurord)
            k.putExtra("transferpurord", transferpurord)
            k.putExtra("exportpurord", exportpurord)
            k.putExtra("sendpurord", sendpurpo)




            k.putExtra("viewpurreq", viewpurreq)
            k.putExtra("addpurreq", addpurreq)
            k.putExtra("deletepurreq", deletepurreq)
            k.putExtra("editpurreq", editepurreq)
            k.putExtra("transferpurreq", transferpurreq)
            k.putExtra("exportpurreq", exportpurreq)


            k.putExtra("imglink",imgArray[position])



            startActivity(k)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()


        }

    }

    override fun onBackPressed() {
        val gor=Intent(this,PurchaseRequestActivity::class.java)
        gor.putExtra("viewpurord", viewpurord)
        gor.putExtra("addpurord", addpurord)
        gor.putExtra("deletepurord", deletepurord)
        gor.putExtra("editpurord", editepurord)
        gor.putExtra("transferpurord", transferpurord)
        gor.putExtra("exportpurord", exportpurord)
        gor.putExtra("sendpurord", sendpurpo)


        gor.putExtra("viewpurreq", viewpurreq)
        gor.putExtra("addpurreq", addpurreq)
        gor.putExtra("deletepurreq", deletepurreq)
        gor.putExtra("editpurreq", editepurreq)
        gor.putExtra("transferpurreq", transferpurreq)
        gor.putExtra("exportpurreq", exportpurreq)


        gor.putExtra("viewsuppin", viewsuppin)
        gor.putExtra("addsuppin", addsuppin)
        gor.putExtra("deletesuppin", deletesuppin)
        gor.putExtra("editsuppin", editesuppin)
        gor.putExtra("transfersuppin", transfersuppin)
        gor.putExtra("exportsuppin", exportsuppin)




        gor.putExtra("from_ver","main")
        gor.putExtra("brkey",oriky)
        startActivity(gor)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()
    }
    fun popup(st:String){
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }
    companion object {



        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {



                constraintLayout3dis!!.visibility=View.GONE

                relativeslayoutdis!!.visibility=View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
