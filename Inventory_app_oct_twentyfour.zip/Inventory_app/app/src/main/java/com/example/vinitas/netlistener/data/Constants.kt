object Constants {

    val CONNECT_TO_WIFI = "WIFI"
    val CONNECT_TO_MOBILE = "MOBILE"
    val NOT_CONNECT = "NOT_CONNECT"
    val CONNECTIVITY_ACTION = "android.net.conn.CONNECTIVITY_CHANGE"
}