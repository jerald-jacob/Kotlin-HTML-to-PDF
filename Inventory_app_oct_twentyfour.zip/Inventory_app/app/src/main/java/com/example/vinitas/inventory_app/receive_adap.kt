package com.example.vinitas.inventory_app
/**
 * Created by Vinitas on 22-12-2017.
 */
import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.squareup.picasso.Picasso

import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.scroll_branch_one.*
import kotlinx.android.synthetic.main.scroll_stk_one.*
import java.nio.file.Files.size



/**
 * Created by vinitas IT on 13-12-2017.
 */
class receive_adap(//to reference the Activity
        private val context: Activity,
        //to store the list of countries
        private val pronameArray:   Array<String>,
        /* private val idArray:   ArrayList<String>,*/ //to store the list of countries
        private val manufacturerArray:  Array<String>,
        private val hsnArray:  Array<String>,
        private val barcodeArray :     Array<String>,
        private val quantityArray:    Array<String>,
        private val priceArray:  Array<String>,
        private val totArray:  Array<String>,
        private val cessArray:  Array<String>,
        private val keyArray:  Array<String>,
        private val igstArray:  Array<String>,
        private val igsttotArray:  Array<String>,
        private val cesstotArray:  Array<String>,
        private val tallyArray:  Array<String>,
        private val receivedArray:  Array<String>,
        private val productImArray: Array<String>): ArrayAdapter<Any>(context, R.layout.act_stock_first_items, pronameArray) {

    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val u=position
        val rowView = inflater.inflate(R.layout.act_stock_first_items, null, true)

        //this code gets references to objects in the listview_row.xml file
        val nameTextField = rowView.findViewById<View>(R.id.pnm) as TextView
        /*       val idTextField = rowView.findViewById<View>(R.id.id) as TextView*/
        val subnameTextField = rowView.findViewById<View>(R.id.psubnm) as TextView
        val hsnTextField = rowView.findViewById<View>(R.id.hsn) as TextView
        val bcnameTextField = rowView.findViewById<View>(R.id.bc) as TextView
        val cessTextField = rowView.findViewById<View>(R.id.cess) as TextView
        val sohnameTextField = rowView.findViewById<View>(R.id.soh) as TextView
        val totnameTextField = rowView.findViewById<View>(R.id.tot) as  TextView
        val pricenameTextField = rowView.findViewById<View>(R.id.price) as TextView
        val keyarrayTextField = rowView.findViewById<View>(R.id.keyarr) as TextView
        val igstarrayTextField = rowView.findViewById<View>(R.id.Igst) as TextView
        val igsttotarrayTextField = rowView.findViewById<View>(R.id.igsttot) as TextView
        val cesstotarrayTextField = rowView.findViewById<View>(R.id.cesstot) as TextView
        val tallyarrayTextField = rowView.findViewById<View>(R.id.tally) as TextView
        val receivearrayTextField = rowView.findViewById<View>(R.id.received) as TextView
        val productim= rowView.findViewById<View>(R.id.primg) as CircleImageView


        val bc=rowView.findViewById<View>(R.id.textView10) as TextView
        val rec=rowView.findViewById<View>(R.id.textView12) as TextView



        //this code sets the values of the objects to values from the arrays
        nameTextField.text = pronameArray[position]
        /*   idTextField.text = idArray[position]*/
        subnameTextField.text = manufacturerArray[position]
        cessTextField.text = cessArray[position]
        totnameTextField.text=totArray[position]
        hsnTextField.text = hsnArray[position]
        bcnameTextField.text=barcodeArray[position]
        sohnameTextField.text=quantityArray[position]
        pricenameTextField.text = priceArray[position]
        keyarrayTextField.text = keyArray[position]
        igstarrayTextField.text=igstArray[position]
        igsttotarrayTextField.text=igsttotArray[position]
        cesstotarrayTextField.text=cesstotArray[position]
        tallyarrayTextField.text=tallyArray[position]
        receivearrayTextField.text=receivedArray[position]
        try {
            Picasso.with(context)
                    .load(productImArray[position])
                    .into(productim);
        }
        catch (e:Exception){

        }


        try {
            if (context.st_list.isEnabled == false) {

                nameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                cessTextField.setTextColor(Color.parseColor("#d3d3d3"));
                totnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                hsnTextField.setTextColor(Color.parseColor("#d3d3d3"));
                bcnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                sohnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                pricenameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                keyarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                igstarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));

                igsttotarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                cesstotarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                tallyarrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                receivearrayTextField.setTextColor(Color.parseColor("#d3d3d3"));
                subnameTextField.setTextColor(Color.parseColor("#d3d3d3"));
                bc.setTextColor(Color.parseColor("#d3d3d3"));
                rec.setTextColor(Color.parseColor("#d3d3d3"));

            }


            if (context.st_list.isEnabled == true) {


                nameTextField.setTextColor(Color.parseColor("#000000"));
                cessTextField.setTextColor(Color.parseColor("#666666"));
                totnameTextField.setTextColor(Color.parseColor("#666666"));
                hsnTextField.setTextColor(Color.parseColor("#666666"));
                bcnameTextField.setTextColor(Color.parseColor("#666666"));
                sohnameTextField.setTextColor(Color.parseColor("#808080"));
                pricenameTextField.setTextColor(Color.parseColor("#666666"));
                keyarrayTextField.setTextColor(Color.parseColor("#666666"));
                igstarrayTextField.setTextColor(Color.parseColor("#666666"));

                igsttotarrayTextField.setTextColor(Color.parseColor("#666666"));
                cesstotarrayTextField.setTextColor(Color.parseColor("#666666"));
                tallyarrayTextField.setTextColor(Color.parseColor("#666666"));
                receivearrayTextField.setTextColor(Color.parseColor("#808080"));
                subnameTextField.setTextColor(Color.parseColor("#666666"));
                bc.setTextColor(Color.parseColor("#666666"));
                rec.setTextColor(Color.parseColor("#666666"));


            }
        }
        catch (e:Exception){

        }






        //infoTextField.text = infoArray[position]




        return rowView



    }


}