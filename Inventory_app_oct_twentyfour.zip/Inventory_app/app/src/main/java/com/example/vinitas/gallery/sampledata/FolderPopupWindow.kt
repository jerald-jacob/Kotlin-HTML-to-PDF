package com.example.vinitas.gallery.sampledata

import android.R.attr.y
import android.R.attr.x
import android.view.Display
import com.zfdang.multiple_images_selector.FolderRecyclerViewAdapter
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.content.Context.LAYOUT_INFLATER_SERVICE
import android.view.LayoutInflater
import com.zfdang.multiple_images_selector.OnFolderRecyclerViewInteractionListener
import com.zfdang.multiple_images_selector.models.FolderListContent;
import android.app.Activity
import android.content.Context
import android.graphics.Point
import android.view.View
import android.widget.PopupWindow
import com.example.vinitas.inventory_app.R


class FolderPopupWindow : PopupWindow() {
    private var mContext: Context? = null
    private var conentView: View? = null
    private var recyclerView: RecyclerView? = null
    private var mListener: OnFolderRecyclerViewInteractionListener? = null

    // http://stackoverflow.com/questions/23464232/how-would-you-create-a-popover-view-in-android-like-facebook-comments
    fun initPopupWindow(context: Activity) {
        mContext = context
        if (context is OnFolderRecyclerViewInteractionListener) {
            mListener = context
        } else {

        }

        val layoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        conentView = layoutInflater.inflate(R.layout.popup_folder_recyclerview, null, false)

        val rview = conentView!!.findViewById<View>(R.id.folder_recyclerview)
        // Set the adapter
        if (rview is RecyclerView) {
            recyclerView = rview
            recyclerView!!.layoutManager = LinearLayoutManager(context)
            recyclerView!!.addItemDecoration(DividerItemDecoration(context, LinearLayoutManager.VERTICAL, 0))
            recyclerView!!.adapter = FolderRecyclerViewAdapter(FolderListContent.FOLDERS, mListener)
        }

        // get device size
        val display = context.windowManager.defaultDisplay
        val size = Point()
        display.getSize(size)

        this.contentView = conentView
        this.width = size.x
        this.height = (size.y * 0.618).toInt()
        // http://stackoverflow.com/questions/12232724/popupwindow-dismiss-when-clicked-outside
        this.setBackgroundDrawable(context.resources.getDrawable(R.drawable.popup_background))
        this.isOutsideTouchable = true
        this.isFocusable = true
        this.animationStyle = R.style.AnimationPreview
    }

    companion object {

        private val TAG = "FolderPopupWindow"
    }

}