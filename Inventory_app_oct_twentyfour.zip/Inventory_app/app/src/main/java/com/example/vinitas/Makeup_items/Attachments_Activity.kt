package com.example.vinitas.Makeup_items

import android.app.Activity
import android.Manifest
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import com.google.firebase.firestore.EventListener

import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.daimajia.slider.library.Animations.DescriptionAnimation
import com.daimajia.slider.library.SliderLayout
import com.daimajia.slider.library.SliderTypes.BaseSliderView
import com.daimajia.slider.library.SliderTypes.TextSliderView
import com.example.vinitas.inventory_app.*
import com.example.vinitas.inventory_app.R
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_attachments.*
import java.io.File
import java.net.URL
import java.util.*

class Attachments_Activity : AppCompatActivity(), BaseSliderView.OnSliderClickListener {

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    //SERVICE VARIABLES

    /*internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
*/



    internal lateinit var myDb: Databasehelper_service
    internal lateinit var myDb1: Databasehelper
    //var ur : String ="https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/ourimages-13.jpg?alt=media&token=e9641bdf-30a0-4517-8d44-d7e1987ae2a8"
    //image url's
    var img1url: String = ""
    var img2url: String = ""
    var img3url: String = ""
    var img4url: String = ""
    var img5url: String = ""
    //image name's
    var img1n: String = ""
    var img2n: String = ""
    var img3n: String = ""
    var img4n: String = ""
    var img5n: String = ""

    var img1urlhigh: String = ""
    var img2urlhigh: String = ""
    var img3urlhigh: String = ""
    var img4urlhigh: String = ""
    var img5urlhigh: String = ""
    //image name's
    var img1nhigh: String = ""
    var img2nhigh: String = ""
    var img3nhigh: String = ""
    var img4nhigh: String = ""
    var img5nhigh: String = ""


    var gender: String = ""
    var maincat: String = ""
    var subcat: String = ""
    var des: String = ""
    var fix: String = ""
    var from: String = ""
    var to: String = ""

    var branchky=String()
    var brnm=String()
    var retdatedup=String()
    var imcome = String()

    var cntpri: Int = 0
    var cntnm: Int = 0
    var cntcess: Int = 0
    var cntigst: Int = 0
    var cntvol: Int = 0
    var cnthsc: Int = 0
    var cnthscdes: Int = 0
    var cntsoh: Int = 0
    var cntmx: Int = 0
    var cntmin: Int = 0

    //image url's
    var f1edit: String = ""
    var s1edit: String = ""
    var t1edit: String = ""
    var fo1edit: String = ""
    var fif1edit: String = ""
    //image name's
    var fn1edit: String = ""
    var sn1edit: String = ""
    var tn1edit: String = ""
    var fon1edit: String = ""
    var fifn1edit: String = ""


    var snamevalidate = String()
    var sdurvalidate = String()
    var hsnTvalidate = String()
    var hsndesvalidate = String()
    var pricevalidate = String()
    var intaxvalidate = String()
    var cessvalidate = String()
    var pervalidate = String()


    var returnval= "false"

    var subcatvaldup=String()
    val PERMISSION_REQUEST = 200
    var frmmakeup=String()

    var protypesave=String()

   var rentalchkalready=""
    var retailchkalready=""

    var subcategID=ArrayList<String>()

    var payempvalidate = "false"
    var paybonusvalidate = "false"
    var currencyvalidate = String()
    var percentagevalidate = String()
    var scroll2_fixed_pricevalidate = String()
    var scroll2_price_fromvalidate = String()
    var scroll2_price_tovalidate = String()

    var gendervalidate="Select"
    var maincatvalidate="Select"
    var subcatvalidate=""
    var descvalidate=""
    var bothcome=""
    //image url's
    var f1edithigh: String = ""
    var s1edithigh: String = ""
    var t1edithigh: String = ""
    var fo1edithigh: String = ""
    var fif1edithigh: String = ""
    //image name's
    var fn1edithigh: String = ""
    var sn1edithigh: String = ""
    var tn1edithigh: String = ""
    var fon1edithigh: String = ""
    var fifn1edithigh: String = ""

    var mctgkeys=String()
    var sctgkeys=String()
    var fixed_error: String = ""
    var from_error: String = ""
    var to_error: String = ""
    var gen_error: String = ""
    var main_error: String = ""
    var sub_error: String = ""
    var fix_check: String = "true"
    var from_check: String = "false"

    var maincatId = ArrayList<String>()
    private var add: String = ""
    private var edite: String = ""
    private var delete: String = ""


    var d = arrayListOf<String>()
    var file_maps = arrayListOf<String>()
    var editclick = String()
    var mc = String()
    var frmscrtwo = String()
    override fun onSliderClick(slider: BaseSliderView?) {
        return
    }



    data class s(
            var snm: String,            //service Name
            var sid: String,            //service Id	(Auto Id)
            var dur: String,            //Duration
            var sac: String,            //HSN / SAC Code
            var sacdesc: String,        //HSN / SAC Code
            var pr: String,             //Price
            var tx: String,             //Taxable checkbox
            var igst: String,          //Integrated Tax
            var cess: String,           //Cess
            var cgst: String,          //Central Tax
            var sgst: String,          //State Tax
            var ttot: String,          //Tax total
            var ctot: String,          //Cess total
            var gtot: String,          //Gross total
            var ecomm: String,         //Pay employee commission on this service checkbox
            var ebns: String,          //Pay bonus to employee when this service sold checkbox
            var cry: String,           //Currency	radiobutton
            var ptg: String,           //Percentage	radiobutton
            var bval: String,          //Bonus Value
            var gdr: String,           //Gender
            var mctg: String,          //Main category
            var sctg: String,
            var mctgkey: String,
            var retdate:String,
            var makeupitem:String,
            var sctgkey: String, //Sub Category
            var desc: String,           //Description
            var fp: String,     //Fixed price
            var fpr: String,        //Range of Price	From
            var tpr: String,     //	To
            var status: String,    //status of service
            var img1n: String,     //image 1 name
            var img2n: String,     //image 2 name
            var img3n: String,     //image 3 name
            var img4n: String,     //image 4 name
            var img5n: String,     //image 5 name
            var img1url: String,     //image 1 url
            var img2url: String,     //image 2 url
            var img3url: String,     //image 3 url
            var img4url: String,     //image 4 url
            var img5url: String,     //image 5 url

            var img1nhigh: String,     //image 1 name
            var img2nhigh: String,     //image 2 name
            var img3nhigh: String,     //image 3 name
            var img4nhigh: String,     //image 4 name
            var img5nhigh: String,     //image 5 name
            var img1urlhigh: String,     //image 1 url
            var img2urlhigh: String,     //image 2 url
            var img3urlhigh: String,     //image 3 url
            var img4urlhigh: String,     //image 4 url
            var img5urlhigh: String     //image 5 url
    )

    var listenersave = String()

    var mresultsarr = arrayListOf<String>()
    var cacnm1 = String()
    val TAG = "some"

    var addedSuffix = false
    var SUFFIX = " my suffix"



    //PRODUCT

    var imgurls= String()
    //product

    private var addpro: String=""
    private var stockin_hand= String()
    private var editepro:String=""
    private var deletepro:String=""
    private var viewpro:String=""
    private var importpro:String=""
    private var exportpro:String=""


    var suppcome=""
    var suppky=""
    var suppname=""




    var prosave_key = arrayOf<String>()

    var pnamevalidate=String()
    var pidvalidate=String()
    var volvalidate=String()
    var bcodeidvalidate=String()
    var hscvalidate=String()
    var hscdesvalidate=String()
    var maincatvalidatepro="Select"
    var subcatvalidatepro="Select"
    var listvalidate="Select"
    var pricevalidatepro=String()
    var taxcheckvalidate="false"
    var intgstvalidate=String()
    var centgstvalidate=String()
    var stategstvalidate=String()
    var taxtotvalidate=String()
    var cessvaluevalidate=String()
    var mrpvalidate=String()
    var checkcommisionvalidate="false"
    var checkbonusvalidate="false"
    var retailvalidate="false"
    var backbarvalidate="false"
    var returnablevalidate="false"

    var currencyradiovalidate=String()
    var percenradiovalidate=String()
    var percentagevalvalidate=String()
    var maxstockvalidate=String()
    var minstockvalidate=String()
    var des_boxvalidate=String()
    var stockhandvalidate=String()





    var imlistener= String()
    var brnchkeys=arrayListOf<String>()

    var stkhand=String()



    var editcli=String()

    var cnts:Int=0

    var auto_id=String

    var brkey= String()
    var savefb= String()
    var saveupfb= String()
    var cesscal:Float=0.0F
    var db = FirebaseFirestore.getInstance()


    var dup= String()
    var listListener= String()

    var commonlisteners= String()



    data class s1(

            var p_nm: String,
            var p_id: Any,
            var bc: Any,
            var wg_vol: Any,
            var ut: String,
            var ctgy: String,
            var mfr: String,
            var hsn: Any,
            var desc: Any,
            var price: Any,
            var taxchk: Any,
            var igst: Any,
            var cgst: Any,
            var sgst: Any,
            var cess: Any,
            var taxtot: Any,
            var cesstot: Any,
            var mrp: Any,
            var stock_hand: String,
            var min_stk: Any,
            var mx_stk: Any,
            var emp_com: String,
            var cn_sold: String,
            var curency: Any,
            var status:String,
            var percentage: Any,
            var retail:Any,
            var backbar:Any,
            var returnable:Any,
            var returnableday:Any,
            var percentageval: Any,
            var product_desc: Any,
            var protype:Any,
            var makeupitem:Any,
            var supp_key:Any,
            var supp_name:Any,
            var img1n:Any,
            var img2n:Any,
            var img3n:Any,
            var img4n:Any,
            var img5n:Any,
            var img1url:Any,
            var img2url:Any,
            var img3url:Any,
            var img4url:Any,
            var img5url:Any,


            var img1nhigh:String,     //image 1 name
            var img2nhigh:String,     //image 2 name
            var img3nhigh:String,     //image 3 name
            var img4nhigh:String,     //image 4 name
            var img5nhigh:String,     //image 5 name
            var img1urlhigh:String,     //image 1 url
            var img2urlhigh:String,     //image 2 url
            var img3urlhigh:String,     //image 3 url
            var img4urlhigh:String,     //image 4 url
            var img5urlhigh:String,     //image 5 url


            var orikys:Any
    )
    data class k(
            var status:String
    )
    var froms= String()
    var listcome= String()
    var comepro= String()

    var maincatIdpro = ArrayList<String>()




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attachments)


        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Attachments_Activity) > 0)
        {

        }
        else{

        }



        relativeslayoutdis=findViewById(R.id.relativeslayout)
        consermaindis=findViewById(R.id.consermain)
        firstreldis=findViewById(R.id.firstrel)
        secreldis=findViewById(R.id.secrel)
        texreldis=findViewById(R.id.texrel)
        inreldis=findViewById(R.id.inrel)
        catreldis=findViewById(R.id.catrel)
        desreldis=findViewById(R.id.desrel)
        pricereldis=findViewById(R.id.pricerel)
        lastreldis=findViewById(R.id.lastrel)
        scrollView2dis=findViewById(R.id.scrollView2)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        retailchkdis=findViewById(R.id.retailchk)
        rentalchkdis=findViewById(R.id.rentalchk)
        retquesdis=findViewById(R.id.retques)
        editdis=findViewById(R.id.edit)
        scroll2_gallerydis=findViewById(R.id.scroll2_gallery)
        /*  relativeLayout2dis=findViewById(R.id.relativeLayout2)

          lineardis=findViewById(R.id.linear)
          cambackdis=findViewById(R.id.camback)*/
        addLogText(NetworkUtil.getConnectivityStatusString(this@Attachments_Activity))




        retques.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                retdays.visibility=View.VISIBLE
            }
            if(state==false){
                retdays.visibility=View.GONE
            }

            }




        db.collection("branch")
                .get()
                .addOnCompleteListener { task ->

                    if (task.result != null) {
                        for (document in task.result) {

                            var brid=document.id
                            brnchkeys.add(brid)
                        }
                    }
                }





        val maincategser = ArrayList<String>()
        val adp1ser = ArrayAdapter(this@Attachments_Activity, R.layout.spinner_view, maincategser)
        adp1ser.setDropDownViewResource(R.layout.spinner_view)

        val lists = ArrayList<String>()
        val dataAdapterser = ArrayAdapter(this@Attachments_Activity, R.layout.spinner_view, lists)
        dataAdapterser.setDropDownViewResource(R.layout.spinner_view)

        val subcategser = ArrayList<String>()
        val adp2ser = ArrayAdapter(this@Attachments_Activity, R.layout.spinner_view, subcategser)
        adp2ser.setDropDownViewResource(R.layout.spinner_view)



        try {
            listenersave = intent.getStringExtra("listenersave")
        } catch (e: Exception) {
        }

        try {
            mresultsarr = intent.getStringArrayListExtra("mresult")
        } catch (e: Exception) {

        }
        try {
            cacnm1 = intent.getStringExtra("cacnm1")
        } catch (e: Exception) {

        }

        val maincateg=ArrayList<String>()
        val adp1 = ArrayAdapter(this@Attachments_Activity, R.layout.spinner_view,maincateg)
        adp1.setDropDownViewResource(R.layout.spinner_view)

        val list=ArrayList<String>()
        val dataAdapter = ArrayAdapter(this@Attachments_Activity, R.layout.spinner_view,list)
        dataAdapter.setDropDownViewResource(R.layout.spinner_view)

        val subcateg = ArrayList<String>()
        val adp2 = ArrayAdapter(this@Attachments_Activity, R.layout.spinner_view,subcateg)
        adp2.setDropDownViewResource(R.layout.spinner_view)

        myDb1 = Databasehelper(this)


        val bundle = intent.extras
        try {
            var frm = bundle!!.get("from").toString()
            froms=frm
        }
        catch(e:Exception){

        }




        Handler().postDelayed(Runnable { loadim() }, 1000)



        //scroll2_category spinner



        if (id.text.isNotEmpty()) {
            val getone = myDb.getOne(id.text.toString())
            if (getone.moveToNext()) {

            }
        }

        //scroll2_fixed setOnCheckedChangeListener
        if (scroll2_descrip.text.isEmpty()) {
            scroll2_preview_description.setText("")
            scroll2_preview_description.visibility = View.GONE
        } else {
            scroll2_preview_description.setText(scroll2_descrip.text.toString())
            scroll2_preview_description.visibility = View.VISIBLE
        }
        if (scroll2_fixed.isChecked == true) {
            if (scroll2_fixed_price.text.isEmpty()) {
                /*fixed_error.visibility = View.VISIBLE
                fixed_error.setError(" ")*/
            }
        } else {
            fixed_errors.visibility = View.GONE
        }
        scroll2_fixed.setOnCheckedChangeListener { fixed, b ->
            if (fixed.isChecked == true) {
                println("fixed  " + b)
                fixed.isChecked = true
                scroll2_fixed_price.isEnabled = true
                scroll2_from.isChecked = false
                scroll2_price_from.isEnabled = false
                try {
                    scroll2_price_from.setText("")
                    scroll2_price_to.setText("")
                }
                catch (e:Exception){

                }

                if(id.text.toString().isNotEmpty()){

                    if(scroll2_fixed.isChecked==true){
                        scroll2_fixed_price.setText(fix)
                    }

                }
                else{

                }

                scroll2_price_to.isEnabled = false

                from_errors.visibility = View.GONE
                to_errors.visibility = View.GONE
                if (scroll2_fixed_price.text.isEmpty()) {
                    /*fixed_error.visibility=View.VISIBLE
                    fixed_error.setError(" ")*/
                }
            } else {
                fixed_errors.visibility = View.GONE
            }
        }
        //scroll2_from setOnCheckedChangeListener
        if (scroll2_from.isChecked == true) {
            if (scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
                /*from_error.visibility=View.VISIBLE
                from_error.setError(" ")
                to_error.visibility=View.VISIBLE
                to_error.setError(" ")*/
            }
        } else {
            from_errors.visibility = View.GONE
            to_errors.visibility = View.GONE
        }
        scroll2_from.setOnCheckedChangeListener { fro, b ->
            if (fro.isChecked == true) {
                scroll2_fixed.isChecked = false
                scroll2_fixed_price.isEnabled = false
                scroll2_fixed_price.setText("")
                if(id.text.toString().isNotEmpty()) {
                    if (scroll2_from.isChecked == true) {
                        scroll2_price_from.setText(from)
                        scroll2_price_to.setText(to)
                    }
                }

                fro.isChecked = true
                scroll2_price_from.isEnabled = true
                scroll2_price_to.isEnabled = true
                fixed_errors.visibility = View.GONE
                if (scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
                    /* from_error.visibility=View.VISIBLE
                    from_error.setError(" ")
                    to_error.visibility=View.VISIBLE
                    to_error.setError(" ")*/
                }
            } else {
                from_errors.visibility = View.GONE
                to_errors.visibility = View.GONE
            }
        }

        //description ontextchanged
        if (scroll2_descrip.text.isEmpty()) {
            scroll2_preview_description.visibility = View.GONE
        } else {
            scroll2_preview_description.visibility = View.VISIBLE
        }
        scroll2_descrip.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_description.setText(des)
                if (des.isEmpty()) {
                    scroll2_preview_description.visibility = View.GONE
                } else {
                    scroll2_preview_description.visibility = View.VISIBLE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //fixed price ontextchanged
        if (scroll2_fixed_price.text.isEmpty() && scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
            scroll2_preview_price.setText("Service price")
        }
        scroll2_fixed_price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(price: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("Rs " + price)
                if (price.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (scroll2_fixed_price.text.isEmpty()) {


                } else {
                    fixed_errors.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //from price ontextchanged




        scroll2_price_from.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(from: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("From Rs " + from + " to " + scroll2_price_to.text.toString())
                if (from.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (scroll2_price_to.text.isEmpty() && from.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (from.isEmpty()) {

                } else {
                    from_errors.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

            }
        })


        //to price ontextchanged
        scroll2_price_to.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(to: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString() + " to " + to)
                if (to.isEmpty()) {
                    scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString())
                }
                if (scroll2_price_from.text.isEmpty() && to.isEmpty()) {
                    scroll2_preview_price.setText("Service price")
                }
                if (to.isEmpty()) {

                } else {
                    to_errors.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })




        /* retailradio.setOnCheckedChangeListener { button, state ->
             if (state == true) {



                 secrel.visibility=View.VISIBLE
                 pridel.visibility=View.VISIBLE
                 texrel.visibility=View.VISIBLE



             } else if (state == false) {




                 secrel.visibility=View.GONE
                 pridel.visibility=View.GONE
                 texrel.visibility=View.GONE

             }
         }
         reantalradio.setOnCheckedChangeListener { button, state ->
             if (state == true) {

                 servrel.visibility=View.VISIBLE
                 catrel.visibility=View.VISIBLE


                 pridel.visibility=View.VISIBLE
                 texrel.visibility=View.VISIBLE

             } else if (state == false) {

                 servrel.visibility=View.GONE
                 catrel.visibility=View.GONE


                 pridel.visibility=View.GONE
                 texrel.visibility=View.GONE

             }
         }*/


        retailchk.setOnCheckedChangeListener{button,state ->
            retailerr.visibility=View.INVISIBLE
            rentalerr.visibility=View.INVISIBLE
            if (state == true) {
                secrel.visibility=View.VISIBLE
            }
            if(state==false){
                secrel.visibility=View.GONE
            }
        }
        rentalchk.setOnCheckedChangeListener{button,state ->
            retailerr.visibility=View.INVISIBLE
            rentalerr.visibility=View.INVISIBLE
            if (state == true) {
                servrel.visibility=View.VISIBLE
            }
            if(state==false){
                servrel.visibility=View.GONE
            }
        }


        if(froms=="add"){


            val adser = intent.getStringExtra("add")
            val edser = intent.getStringExtra("edit")
            val delser = intent.getStringExtra("delete")
            if (adser != null) {
                add = adser
            }
            if (edser != null) {
                edite = edser
            }
            if (delser != null) {
                delete = delser
            }

            try {
                val keyss = intent.getStringExtra("keybr")
                branchky=keyss
            }
            catch (e:Exception){

            }

            try{
                frmmakeup=intent.getStringExtra("makeup")
            }
            catch (e:Exception){

            }
            try{

                makeupitemstr=intent.getStringExtra("itemname")
                sl_title.setText(makeupitemstr)
            }
            catch (e:Exception){

            }




            if(makeupitemstr=="FLOWERS"){
                servrelchk.visibility=View.GONE
                servrel.visibility=View.GONE
                pricerel.visibility=View.GONE
                lastrel.visibility=View.GONE
                rentalchk.visibility=View.INVISIBLE
                retailchk.isChecked=true
                retailchk.isEnabled=false
                retques.visibility=View.INVISIBLE
            }

            if(frmmakeup.isEmpty()) {
                db.collection("servicecategory")
                        .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                            if (task.isEmpty == false) {
                                if (task != null) {
                                    maincategser.clear()
                                    maincatId.clear()
                                    maincategser.add("Select")
                                    maincatId.add("")
                                    for (document in task) {
                                        println("document id : " + document.id)
                                        println("document data : " + document.data)
                                        val dd = document.data
                                        maincatId.add(document.id)
                                        val c = dd["cat"].toString()
                                        maincategser.add(c)
                                        println(maincategser)
                                        scroll2_category.adapter = adp1ser
                                        if (maincat.isNullOrEmpty() != true) {
                                            val spinnerPosition = adp1ser.getPosition(maincat.toString())
                                            scroll2_category.setSelection(spinnerPosition)

                                        }
                                    }
                                }
                            }
                        })


                //scroll2_gender spinner onItemSeletedListener   get sub category from db
                scroll2_gender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                        if (p2 == 0) {
                            /*gen_error.visibility=View.VISIBLE
                        gen_error.setError(" ")*/
                        } else {
                            gen_errors.visibility = View.GONE
                        }
                    }
                }

                //scroll2_category spinner onItemSeletedListener
                scroll2_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(maincatId.get(position))
                        val key = maincatId.get(position)

                        mctgkeys = key
                        //scroll2_sub_category spinner
                        if (scroll2_category.selectedItemPosition == 0) {

                            /*main_error.visibility=View.VISIBLE
                        main_error.setError(" ")*/
                        } else {
                            main_errors.visibility = View.GONE
                            db.collection("subcategory")
                                    .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                                        subcategser.clear()
                                        subcategID.clear()
                                        subcateg.add("")
                                        subcategID.add("")



                                        if (task.isEmpty == false) {
                                            if (task != null) {
                                                for (document in task) {
                                                    println("document id : " + document.id)
                                                    println("document data : " + document.data)


                                                    val dd = document.data
                                                    val mainid = dd["main_id"].toString()
                                                    scroll2_sub_category.adapter = adp2ser
                                                    if (mainid == key) {
                                                        val c = dd["cat"].toString()
                                                        subcategser.add(c)
                                                        subcategID.add(document.id)
                                                        println("SUB CATEG" + subcategser)
                                                        scroll2_sub_category.adapter = adp2ser
                                                        scroll2_sub_category.setSelection(0)

                                                        /* if (mc.isNotEmpty()) {
                                                            println("mc  " + mc)
                                                            val spinnerPosition = adp2.getPosition(mc)
                                                            scroll2_sub_category.setSelection(spinnerPosition)
                                                        }*/
                                                    } else {
                                                        /* subcateg.clear()*/

                                                        adp2ser.notifyDataSetChanged()
                                                    }
                                                    if (subcat.isNullOrEmpty() != true) {
                                                        println("true subcat" + subcat)
                                                        val spinnerPosition = adp2ser.getPosition(subcat.toString())
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }
                                                }

                                            }
                                        } else {


                                        }

                                    })
                        }
                    }
                }
                scroll2_sub_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {


                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(subcategID.get(position))
                        val key = subcategID.get(position)

                        sctgkeys = key
                    }
                }
            }

            //----------------------defaultly set main and sub category as 'Wedding'----------------------//

            else if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
                db.collection("servicecategory").whereEqualTo("cat","Wedding")
                        .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                            if (task.isEmpty == false) {
                                if (task != null) {
                                    maincategser.clear()
                                    maincatId.clear()
                                    maincategser.add("Select")
                                    maincatId.add("")
                                    for (document in task) {
                                        println("document id : " + document.id)
                                        println("document data : " + document.data)
                                        val dd = document.data
                                        maincatId.add(document.id)
                                        val c = dd["cat"].toString()
                                        maincategser.add(c)
                                        println(maincateg)
                                        scroll2_category.adapter = adp1ser
                                        if (maincat.isNullOrEmpty() != true) {
                                            val spinnerPosition = adp1ser.getPosition(maincat.toString())
                                            scroll2_category.setSelection(spinnerPosition)

                                        }
                                        else if(maincat.isNullOrEmpty()==true){

                                            scroll2_category.setSelection(1)
                                            scroll2_category.isEnabled=false
                                        }
                                    }
                                }
                            }
                        })


                //scroll2_gender spinner onItemSeletedListener
                scroll2_gender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                        if (p2 == 0) {
                            /*gen_error.visibility=View.VISIBLE
                        gen_error.setError(" ")*/
                        } else {
                            gen_errors.visibility = View.GONE
                        }
                    }
                }

                //scroll2_category spinner onItemSeletedListener
                scroll2_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(maincatId.get(position))
                        val key = maincatId.get(position)

                        mctgkeys = key
                        //scroll2_sub_category spinner
                        if (scroll2_category.selectedItemPosition == 0) {

                            /*main_error.visibility=View.VISIBLE
                        main_error.setError(" ")*/
                        } else {
                            main_errors.visibility = View.GONE
                            db.collection("subcategory").whereEqualTo("main_cat","Wedding")
                                    .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                                        subcategser.clear()
                                        subcategID.clear()
                                        subcategser.add("")
                                        subcategID.add("")



                                        if (task.isEmpty == false) {
                                            if (task != null) {
                                                for (document in task) {
                                                    println("document id : " + document.id)
                                                    println("document data : " + document.data)


                                                    val dd = document.data
                                                    val mainid = dd["main_id"].toString()
                                                    scroll2_sub_category.adapter = adp2ser
                                                    if (mainid == key) {
                                                        val c = dd["cat"].toString()
                                                        subcategser.add(c)
                                                        subcategID.add(document.id)
                                                        println("SUB CATEG" + subcategser)
                                                        scroll2_sub_category.adapter = adp2ser
                                                        scroll2_sub_category.setSelection(0)

                                                        /* if (mc.isNotEmpty()) {
                                                            println("mc  " + mc)
                                                            val spinnerPosition = adp2.getPosition(mc)
                                                            scroll2_sub_category.setSelection(spinnerPosition)
                                                        }*/
                                                    } else {
                                                        /* subcateg.clear()*/

                                                        adp2ser.notifyDataSetChanged()
                                                    }
                                                    if (subcat.isNullOrEmpty() != true) {
                                                        println("true subcat" + subcat)
                                                        val spinnerPosition = adp2ser.getPosition(subcat.toString())
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }
                                                    else if(subcat.isNullOrEmpty() == true){
                                                        scroll2_sub_category.setSelection(2)
                                                        scroll2_sub_category.isEnabled=false

                                                    }
                                                }

                                            }
                                        } else {


                                        }

                                    })
                        }
                    }
                }
                scroll2_sub_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {


                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(subcategID.get(position))
                        val key = subcategID.get(position)

                        sctgkeys = key
                    }
                }
            }


            myDb = Databasehelper_service(this)
            myDb1 = Databasehelper(this)
            val service_access = SessionManagement(this)
            val user = service_access.userDetails
            val name = user[SessionManagement.KEY_NAME]
            branchky = name.toString()

            val namebr = user[SessionManagement.KEY_brnm]
            brnm=namebr.toString()
            myDb.givedata(branchky)



            //----------------------------get product category from db------------------//

            db.collection("productcategory")
                    .get()
                    .addOnCompleteListener {task->


                        if(task.result.isEmpty==false){
                            if (task.result != null){
                                maincateg.clear()
                                maincatIdpro.clear()
                                maincateg.add("Select")
                                maincatIdpro.add("")
                                for (document in task.result){
                                    println("document id : "+document.id)
                                    println("document data : "+document.data)
                                    val dd=document.data
                                    maincatIdpro.add(document.id)
                                    val c = dd["cat"].toString()
                                    maincateg.add(c)
                                    println(maincateg)
                                    cate.adapter=adp1
                                    /*  if (main.isNullOrEmpty()!=true){
                                          val spinnerPosition = adp1.getPosition(main.toString())
                                          cate.setSelection(spinnerPosition)
                                      }*/
                                }
                            }

                            else{

                            }
                        }
                        else
                        {
                            maincateg.add("Select")
                            cate.adapter=adp1
                        }

                    }

            //----------------------------get unit measure category from db------------------//


            db.collection("unit")
                    .get()
                    .addOnCompleteListener {task->
                        if(task.result.isEmpty==false){

                            if (task.result != null){
                                list.clear()
                                maincatIdpro.clear()
                                list.add("Select")
                                maincatIdpro.add("")
                                for (document in task.result){
                                    println("document id : "+document.id)
                                    println("document data : "+document.data)
                                    val dd=document.data
                                    maincatIdpro.add(document.id)
                                    val c = dd["cat"].toString()
                                    list.add(c)
                                    println(maincat)
                                    unitspinner.adapter=dataAdapter
                                    /*  if (main.isNullOrEmpty()!=true){
                                          val spinnerPosition = adp1.getPosition(main.toString())
                                          cate.setSelection(spinnerPosition)
                                      }*/
                                }
                            }
                        }
                        else{
                            list.add("Select")
                            unitspinner.adapter=dataAdapter
                        }
                    }


            //----------------------------get unit manufacturer category from db------------------//

            db.collection("manufacturer")
                    .get()
                    .addOnCompleteListener {task->
                        if(task.result.isEmpty==false){
                            if (task.result != null){
                                subcateg.clear()
                                maincatIdpro.clear()
                                subcateg.add("Select")
                                maincatIdpro.add("")
                                for (document in task.result){
                                    println("document id : "+document.id)
                                    println("document data : "+document.data)
                                    val dd=document.data
                                    maincatIdpro.add(document.id)
                                    val c = dd["cat"].toString()
                                    subcateg.add(c)
                                    println(maincat)
                                    manu.adapter=adp2
                                    /*  if (main.isNullOrEmpty()!=true){
                                          val spinnerPosition = adp1.getPosition(main.toString())
                                          cate.setSelection(spinnerPosition)
                                      }*/
                                }
                            }
                        }
                        else
                        {
                            subcateg.add("Select")
                            manu.adapter=adp2
                        }
                    }


            val a = intent.getStringExtra("newidser")
            val ab = intent.getStringExtra("newidpro")
            newid.setText(ab)//create new service

            if (ab.isNullOrEmpty() == false) {

                disable.visibility = View.GONE

            }
            val ad=intent.getStringExtra("addpro")
            val ed=intent.getStringExtra("editpro")
            val viw=intent.getStringExtra("viewpro")
            val impo=intent.getStringExtra("importpro")
            val expo=intent.getStringExtra("exportpro")
            val del=intent.getStringExtra("deletepro")

            val keyss=intent.getStringExtra("keybr")

            println("HELLO UPDATE EDIT"+ed)

            if (ad!=null)
            {
                addpro = ad
            }
            if(ed!=null){
                editepro = ed
            }
            if (del!=null){
                deletepro = del
            }
            if (viw!=null){
                viewpro = viw
            }
            if (impo!=null){
                importpro = impo
            }
            if (expo!=null){
                exportpro = expo
            }


            comepro="yes"


            branchky = keyss
            idsmy.setText(ab)


            if(branchky.isEmpty()){

                val service_access = SessionManagement(this)
                val user = service_access.userDetails
                val name = user[SessionManagement.KEY_NAME]
                branchky = name.toString()
            }


        }

        else if(froms=="list") {


            //SERVICE LISTCOME{{


            val adser = intent.getStringExtra("add")
            val edser = intent.getStringExtra("edit")
            val delser = intent.getStringExtra("delete")
            if (adser != null) {
                add = adser
            }
            if (edser != null) {
                edite = edser
            }
            if (delser != null) {
                delete = delser
            }

            try {
                val keyss = intent.getStringExtra("keybr")
                branchky=keyss
            }
            catch (e:Exception){

            }

            try{
                frmmakeup=intent.getStringExtra("makeup")
            }
            catch (e:Exception){

            }



            ///-------------------------------Service category adapter---------------------------///
            if(frmmakeup.isEmpty()) {
                db.collection("servicecategory")
                        .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                            if (task.isEmpty == false) {
                                if (task != null) {
                                    maincategser.clear()
                                    maincatId.clear()
                                    maincategser.add("Select")
                                    maincatId.add("")
                                    for (document in task) {
                                        println("document id : " + document.id)
                                        println("document data : " + document.data)
                                        val dd = document.data
                                        maincatId.add(document.id)
                                        val c = dd["cat"].toString()
                                        maincategser.add(c)
                                        println(maincategser)
                                        scroll2_category.adapter = adp1ser
                                        if (maincat.isNullOrEmpty() != true) {
                                            val spinnerPosition = adp1ser.getPosition(maincat.toString())
                                            scroll2_category.setSelection(spinnerPosition)

                                        }
                                    }
                                }
                            }
                        })


                //scroll2_gender spinner onItemSeletedListener
                scroll2_gender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                        if (p2 == 0) {
                            /*gen_error.visibility=View.VISIBLE
                        gen_error.setError(" ")*/
                        } else {
                            gen_errors.visibility = View.GONE
                        }
                    }
                }

                //scroll2_category spinner onItemSeletedListener
                scroll2_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(maincatId.get(position))
                        val key = maincatId.get(position)

                        mctgkeys = key
                        //scroll2_sub_category spinner
                        if (scroll2_category.selectedItemPosition == 0) {

                            /*main_error.visibility=View.VISIBLE
                        main_error.setError(" ")*/
                        } else {
                            main_errors.visibility = View.GONE
                            db.collection("subcategory")
                                    .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                                        subcategser.clear()
                                        subcategID.clear()
                                        subcateg.add("")
                                        subcategID.add("")



                                        if (task.isEmpty == false) {
                                            if (task != null) {
                                                for (document in task) {
                                                    println("document id : " + document.id)
                                                    println("document data : " + document.data)


                                                    val dd = document.data
                                                    val mainid = dd["main_id"].toString()
                                                    scroll2_sub_category.adapter = adp2ser
                                                    if (mainid == key) {
                                                        val c = dd["cat"].toString()
                                                        subcategser.add(c)
                                                        subcategID.add(document.id)
                                                        println("SUB CATEG" + subcategser)
                                                        scroll2_sub_category.adapter = adp2ser
                                                        scroll2_sub_category.setSelection(0)

                                                        /* if (mc.isNotEmpty()) {
                                                            println("mc  " + mc)
                                                            val spinnerPosition = adp2.getPosition(mc)
                                                            scroll2_sub_category.setSelection(spinnerPosition)
                                                        }*/
                                                    } else {
                                                        /* subcateg.clear()*/

                                                        adp2ser.notifyDataSetChanged()
                                                    }
                                                    if (subcat.isNullOrEmpty() != true) {
                                                        println("true subcat" + subcat)
                                                        val spinnerPosition = adp2ser.getPosition(subcat.toString())
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }
                                                }

                                            }
                                        } else {


                                        }

                                    })
                        }
                    }
                }
                scroll2_sub_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {


                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(subcategID.get(position))
                        val key = subcategID.get(position)

                        sctgkeys = key
                    }
                }
            }
            else if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
                db.collection("servicecategory").whereEqualTo("cat","Wedding")
                        .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                            if (task.isEmpty == false) {
                                if (task != null) {
                                    maincategser.clear()
                                    maincatId.clear()
                                    maincategser.add("Select")
                                    maincatId.add("")
                                    for (document in task) {
                                        println("document id : " + document.id)
                                        println("document data : " + document.data)
                                        val dd = document.data
                                        maincatId.add(document.id)
                                        val c = dd["cat"].toString()
                                        maincategser.add(c)
                                        println(maincateg)
                                        scroll2_category.adapter = adp1ser
                                        if (maincat.isNullOrEmpty() != true) {
                                            val spinnerPosition = adp1ser.getPosition(maincat.toString())
                                            scroll2_category.setSelection(spinnerPosition)

                                        }
                                        else if(maincat.isNullOrEmpty()==true){

                                            scroll2_category.setSelection(1)
                                            scroll2_category.isEnabled=false
                                        }
                                    }
                                }
                            }
                        })


                //scroll2_gender spinner onItemSeletedListener
                scroll2_gender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                        if (p2 == 0) {
                            /*gen_error.visibility=View.VISIBLE
                        gen_error.setError(" ")*/
                        } else {
                            gen_errors.visibility = View.GONE
                        }
                    }
                }

                //scroll2_category spinner onItemSeletedListener
                scroll2_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {
                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(maincatId.get(position))
                        val key = maincatId.get(position)

                        mctgkeys = key
                        //scroll2_sub_category spinner
                        if (scroll2_category.selectedItemPosition == 0) {

                            /*main_error.visibility=View.VISIBLE
                        main_error.setError(" ")*/
                        } else {
                            main_errors.visibility = View.GONE
                            db.collection("subcategory").whereEqualTo("main_cat","Wedding")
                                    .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                                        subcategser.clear()
                                        subcategID.clear()
                                        subcategser.add("")
                                        subcategID.add("")



                                        if (task.isEmpty == false) {
                                            if (task != null) {
                                                for (document in task) {
                                                    println("document id : " + document.id)
                                                    println("document data : " + document.data)


                                                    val dd = document.data
                                                    val mainid = dd["main_id"].toString()
                                                    scroll2_sub_category.adapter = adp2ser
                                                    if (mainid == key) {
                                                        val c = dd["cat"].toString()
                                                        subcategser.add(c)
                                                        subcategID.add(document.id)
                                                        println("SUB CATEG" + subcategser)
                                                        scroll2_sub_category.adapter = adp2ser
                                                        scroll2_sub_category.setSelection(0)

                                                        /* if (mc.isNotEmpty()) {
                                                            println("mc  " + mc)
                                                            val spinnerPosition = adp2.getPosition(mc)
                                                            scroll2_sub_category.setSelection(spinnerPosition)
                                                        }*/
                                                    } else {
                                                        /* subcateg.clear()*/

                                                        adp2ser.notifyDataSetChanged()
                                                    }
                                                    if (subcat.isNullOrEmpty() != true) {
                                                        println("true subcat" + subcat)
                                                        val spinnerPosition = adp2ser.getPosition(subcat.toString())
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }
                                                    else if(subcat.isNullOrEmpty() == true){
                                                        scroll2_sub_category.setSelection(2)
                                                        scroll2_sub_category.isEnabled=false

                                                    }
                                                }

                                            }
                                        } else {


                                        }

                                    })
                        }
                    }
                }
                scroll2_sub_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onNothingSelected(p0: AdapterView<*>?) {


                        return
                    }

                    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                        println(subcategID.get(position))
                        val key = subcategID.get(position)

                        sctgkeys = key
                    }
                }
            }


            myDb = Databasehelper_service(this)
            myDb1 = Databasehelper(this)
            val service_access = SessionManagement(this)
            val user = service_access.userDetails
            val name = user[SessionManagement.KEY_NAME]
            branchky = name.toString()

            val namebr = user[SessionManagement.KEY_brnm]
            brnm=namebr.toString()
            myDb.givedata(branchky)


            val b = intent.getStringExtra("id")


            if (b.isNullOrEmpty() == false) {
                id.setText(b)//updating list
                save.visibility = View.INVISIBLE
                edit.visibility = View.VISIBLE

                listcome = "yes"

                val edit = intent.getIntExtra("edit", View.VISIBLE)
                if (edit.equals(View.GONE)) {

                }
                if (state.text.toString().isNullOrEmpty() == false) {
                    println("state is not empty")
                    if (state.text.toString() == "Active") {
                        state.text = "Active"
                    } else if (state.text.toString() == "Disabled") {
                        println("state disabled")
                        state.text = "Disabled"
                    }
                }

            }

            println("id  " + id.text)
            println("new id  " + newid.text)






            if (fix_check.isNullOrEmpty() == false) {
                scroll2_fixed.isChecked = fix_check.toBoolean()
                scroll2_fixed_price.isEnabled = fix_check.toBoolean()
            }
            if (from_check.isNullOrEmpty() == false) {
                scroll2_from.isChecked = from_check.toBoolean()
                scroll2_price_from.isEnabled = from_check.toBoolean()
                scroll2_price_to.isEnabled = from_check.toBoolean()
            }
            if (fixed_error.isNullOrEmpty() == false) {

            }
            if (from_error.isNullOrEmpty() == false) {

            }
            if (to_error.isNullOrEmpty() == false) {

            }


            /* if (status.isNullOrEmpty()==false){
                if (status=="Enabled"){
                    state.setText("Enabled")
                    println("Enabled")
                }else if (status=="Disabled"){
                    state.setText("Disabled")
                    println("Disabled")
                }
            }
            if (lid.isNullOrEmpty()==false){
                id.setText(lid.toString())//updateting list
                save.visibility=View.GONE
                edit.visibility=View.VISIBLE
                val s_edit=intent.getIntExtra("s_edit",View.VISIBLE)
                if (s_edit.equals(View.GONE)) {
                    println("s_edit  "+s_edit)
                    save.visibility = View.VISIBLE
                    edit.visibility = View.GONE
                }else{
                    println("else s_edit  "+s_edit)
                }

            }*/

            //scroll2 page items
            /*var gen = intent.getStringExtra("gender")
            var main = intent.getStringExtra("maincat")
            var sub = intent.getStringExtra("subcat")
            val de = intent.getStringExtra("des")
            val fi = intent.getStringExtra("fix")
            val fro = intent.getStringExtra("from")
            val t = intent.getStringExtra("to")

            //image url's
            var f1=intent.getStringExtra("f")
            var s1=intent.getStringExtra("s")
            var t1=intent.getStringExtra("t")
            var fo1=intent.getStringExtra("fo")
            var fif1=intent.getStringExtra("fif")

            //image name's
            var fn1=intent.getStringExtra("fn")
            var sn1=intent.getStringExtra("sn")
            var tn1=intent.getStringExtra("tn")
            var fon1=intent.getStringExtra("fon")
            var fifn1=intent.getStringExtra("fifn")

            println(des)

            if (f1.isNullOrEmpty()==false&&fn1.isNullOrEmpty()==false){
                img1url=f1
                img1n=fn1
            }
            if (s1.isNullOrEmpty()==false&&sn1.isNullOrEmpty()==false){
                img2url=s1
                img2n=sn1
            }
            if (t1.isNullOrEmpty()==false&&tn1.isNullOrEmpty()==false){
                img3url=t1
                img3n=tn1
            }
            if (fo1.isNullOrEmpty()==false&&fon1.isNullOrEmpty()==false){
                img4url=fo1
                img4n=fon1
            }
            if (fif1.isNullOrEmpty()==false&&fifn1.isNullOrEmpty()==false){
                img5url=fif1
                img5n=fifn1
            }

            val f1edits = intent.getStringExtra("f1edit")
            val s1edits = intent.getStringExtra("s1edit")
            val t1edits = intent.getStringExtra("t1edit")
            val fo1edits = intent.getStringExtra("fo1edit")
            val fif1edits = intent.getStringExtra("fif1edit")

            val fn1edits = intent.getStringExtra("fn1edit")
            val sn1edits = intent.getStringExtra("sn1edit")
            val tn1edits = intent.getStringExtra("tn1edit")
            val fon1edits = intent.getStringExtra("fon1edit")
            val fifn1edits = intent.getStringExtra("fifn1edit")


            if (f1edits.isNullOrEmpty() != true) {
                f1edit=f1edits
                fn1edit=fn1edits
            }

            if (s1edits.isNullOrEmpty() != true) {
                s1edit=s1edits
                sn1edit=sn1edits
            }
            if (t1edits.isNullOrEmpty() != true) {
                t1edit=t1edits
                tn1edit=tn1edits
            }

            if (fo1edits.isNullOrEmpty() != true) {
                fo1edit=fo1edits
                fon1edit=fon1edits
            }

            if (fif1edits.isNullOrEmpty() != true) {
                fif1edit=fif1edits
                fifn1edit=fifn1edits
            }


            //image url's
            var f1high=intent.getStringExtra("fhigh")
            var s1high=intent.getStringExtra("shigh")
            var t1high=intent.getStringExtra("thigh")
            var fo1high=intent.getStringExtra("fohigh")
            var fif1high=intent.getStringExtra("fifhigh")

            //image name's
            var fn1high=intent.getStringExtra("fnhigh")
            var sn1high=intent.getStringExtra("snhigh")
            var tn1high=intent.getStringExtra("tnhigh")
            var fon1high=intent.getStringExtra("fonhigh")
            var fifn1high=intent.getStringExtra("fifnhigh")


            println("f1high"+f1high)
            println("s1high"+s1high)
            println("t1high"+t1high)
            println("f1ohigh"+fo1high)
            println("fif1high"+fif1high)


            println("fn1high"+fn1high)
            println("sn1high"+sn1high)
            println("tn1high"+tn1high)
            println("fon1high"+fon1high)
            println("fifn1high"+fifn1high)

            println(des)

            if (f1high.isNullOrEmpty()==false&&fn1high.isNullOrEmpty()==false){
                img1urlhigh=f1high
                img1nhigh=fn1high

                println("img1urlhigh"+img1urlhigh)
                println("img1nhigh"+img1nhigh)
            }
            if (s1high.isNullOrEmpty()==false&&sn1high.isNullOrEmpty()==false){
                img2urlhigh=s1high
                img2nhigh=sn1high
            }
            if (t1high.isNullOrEmpty()==false&&tn1high.isNullOrEmpty()==false){
                img3urlhigh=t1high
                img3nhigh=tn1high
            }
            if (fo1high.isNullOrEmpty()==false&&fon1high.isNullOrEmpty()==false){
                img4urlhigh=fo1high
                img4nhigh=fon1high
            }
            if (fif1high.isNullOrEmpty()==false&&fifn1high.isNullOrEmpty()==false){
                img5urlhigh=fif1high
                img5nhigh=fifn1high
            }



            val f1editshigh = intent.getStringExtra("f1edithigh")
            val s1editshigh = intent.getStringExtra("s1edithigh")
            val t1editshigh = intent.getStringExtra("t1edithigh")
            val fo1editshigh = intent.getStringExtra("fo1edithigh")
            val fif1editshigh = intent.getStringExtra("fif1edithigh")

            val fn1editshigh = intent.getStringExtra("fn1edithigh")
            val sn1editshigh = intent.getStringExtra("sn1edithigh")
            val tn1editshigh = intent.getStringExtra("tn1edithigh")
            val fon1editshigh = intent.getStringExtra("fon1edithigh")
            val fifn1editshigh = intent.getStringExtra("fifn1edithigh")


            if (f1editshigh.isNullOrEmpty() != true) {
                f1edithigh=f1editshigh
                fn1edithigh=fn1editshigh
            }

            if (s1editshigh.isNullOrEmpty() != true) {
                s1edithigh=s1editshigh
                sn1edithigh=sn1editshigh
            }
            if (t1editshigh.isNullOrEmpty() != true) {
                t1edithigh=t1editshigh
                tn1edithigh=tn1editshigh
            }

            if (fo1editshigh.isNullOrEmpty() != true) {
                fo1edithigh=fo1editshigh
                fon1edithigh=fon1editshigh
            }

            if (fif1editshigh.isNullOrEmpty() != true) {
                fif1edithigh=fif1editshigh
                fifn1edithigh=fifn1editshigh
            }*/


            /*if((f1!=f1edit)||(s1!=s1edit)||(t1!=t1edit)||(fo1!=fo1edit)||(fif1!=fif1edit)){
                listenersave="change"

            }
            else if(sid.text.toString()==""){
                listenersave="change"
            }*/

/*
        if (save.visibility==View.VISIBLE) {
            sname.setText(sname1)
            sid.setText(sid1)
            sdur.setText(sdur1)
            hsnT.setText(hsnT1)
            hsndes.setText(hsndes1)
            price.setText(price1)
            Tax.isChecked = Tax1
            intax.setText(intax1)
            cess.setText(cess1)
            Ctax.setText(Ctax1)
            Stax.setText(Stax1)
            taxtot.setText(taxtot1)
            css.setText(css1)
            grosstot.setText(grosstot1)
            payemp.isChecked = payemp1
            paybonus.isChecked = paybonus1
            currency.isChecked = currency1
            percentage.isChecked = percentage1
            per.setText(per1)

            scroll2_descrip.setText(des)
            scroll2_fixed_price.setText(fix)
            scroll2_price_from.setText(from)
            scroll2_price_to.setText(to)
            if (scroll2_fixed_price.text.isNotEmpty()) {
                scroll2_preview_price.setText("Rs " + scroll2_fixed_price.text.toString())
            }
            if (scroll2_price_from.text.isNotEmpty() && scroll2_price_to.text.isNotEmpty()) {
                scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString() + " to " + scroll2_price_to.text.toString())
            }
        }*/
            //descrip.setText(descrip1)
            /*id.setText(lid)
            println("else  "+id.text.toString())*/

            if (sid.text.isEmpty()) {
                sid.setText("Auto-genereted")
            }


            if (edit.visibility == View.VISIBLE) {
                println("id  " + id.text.toString())
                println("new id  " + newid.text)
                save.visibility = View.INVISIBLE
                edit.visibility = View.VISIBLE
                disable.visibility = View.GONE


                sname.isEnabled = false
                sid.isEnabled = false
                sdur.isEnabled = false
                hsnT.isEnabled = false
                hsndes.isEnabled = false
                price.isEnabled = false
                Tax.isEnabled = false
                intax.isEnabled = false
                cess.isEnabled = false
                Ctax.isEnabled = false
                Stax.isEnabled = false
                taxtot.isEnabled = false
                css.isEnabled = false
                grosstot.isEnabled = false
                payemp.isEnabled = false
                paybonus.isEnabled = false
                currency.isEnabled = false
                percentage.isEnabled = false
                per.isEnabled = false



                rentalchk.isEnabled=false
                retailchk.isEnabled=false
                retques.isEnabled=false
                redays.isEnabled=false
                pid.isEnabled = false

                vol.isEnabled = false
                unitspinner.isEnabled = false
                manu.isEnabled = false
                cate.isEnabled = false
                bcodeid.isEnabled = false


                maxstock.isEnabled = false
                minstock.isEnabled = false
                stockhand.isEnabled = false



                scroll2_category.isEnabled = false
                scroll2_sub_category.isEnabled = false
                scroll2_gender.isEnabled = false
                scroll2_descrip.isEnabled = false
                scroll2_fixed.isEnabled = false
                scroll2_from.isEnabled = false
                scroll2_fixed_price.isEnabled = false
                scroll2_price_from.isEnabled = false
                scroll2_price_to.isEnabled = false
                val getone = myDb.getOne(id.text.toString())
                if (getone.moveToNext()) {
                    mc = getone.getString(22).toString()
                    if (getone.getString(23).toString() != "") {
                        scroll2_descrip.setText(getone.getString(23))
                    }
                    if (getone.getString(24).toString() != "") {
                        scroll2_fixed_price.setText(getone.getString(24).toString())
                        scroll2_preview_price.setText("RS ${getone.getString(24).toString()}")
                    }
                    if (getone.getString(25) != "" && getone.getString(26) != "") {
                        scroll2_price_from.setText(getone.getString(25).toString())
                        scroll2_preview_price.setText("From RS ${getone.getString(25).toString()} to ${getone.getString(26).toString()}")
                    }
                    if (getone.getString(26) != "") {
                        scroll2_price_to.setText(getone.getString(26).toString())
                    }
                }

                if (paybonus.isEnabled == false) {
                    currency.isEnabled = false
                    currency.isEnabled = false
                    percentage.isEnabled = false
                    per.isEnabled = false
                    currency.setTextColor(Color.parseColor("#85546e7a"))
                    percentage.setTextColor(Color.parseColor("#d3d3d3"))
                    per.setTextColor(Color.parseColor("#d3d3d3"))
                }

                edit.setOnClickListener {

                    if (edite == "true" || edite.isNullOrEmpty()) {
                        editclick = "clicked"
                        sname.isEnabled = true

                        sdur.isEnabled = true
                        hsnT.isEnabled = true
                        hsndes.isEnabled = true
                        price.isEnabled = true
                        Tax.isEnabled = true

                        if (Tax.isChecked == true) {

                            intax.isEnabled = true
                            cess.isEnabled = true
                        }


                        taxtot.isEnabled = true
                        css.isEnabled = true
                        grosstot.isEnabled = true
                        payemp.isEnabled = true
                        paybonus.isEnabled = true
                        currency.isEnabled = true
                        percentage.isEnabled = true
                        per.isEnabled = true


                        rentalchk.isEnabled=true
                        if(makeupitemstr!="FLOWERS"){
                            retailchk.isEnabled=true

                        }

                        retques.isEnabled=true
                        redays.isEnabled=true

                        vol.isEnabled = true
                        unitspinner.isEnabled = true
                        manu.isEnabled = true
                        cate.isEnabled = true
                        bcodeid.isEnabled = true


                        maxstock.isEnabled = true
                        minstock.isEnabled = true
                        stockhand.isEnabled = true

                        edit.visibility = View.GONE
                        save.visibility = View.VISIBLE
                        disable.visibility = View.VISIBLE

                        scroll2_category.isEnabled = true
                        scroll2_sub_category.isEnabled = true
                        scroll2_descrip.isEnabled = true
                        scroll2_gender.isEnabled = true
                        if (from != "" || to != "") {
                            scroll2_from.isChecked = true
                            scroll2_from.isEnabled = true
                            scroll2_fixed_price.isEnabled = false
                            scroll2_fixed.isEnabled = true
                            scroll2_fixed.isChecked = false
                            scroll2_price_from.isEnabled = true
                            scroll2_price_to.isEnabled = true
                            scroll2_preview_price.setText("From Rs $from to $to")
                        } else if (fix != "") {
                            scroll2_from.isChecked = false
                            scroll2_from.isEnabled = true
                            scroll2_fixed.isChecked = true
                            scroll2_fixed.isEnabled = true
                            scroll2_price_from.isEnabled = false
                            scroll2_price_to.isEnabled = false
                            scroll2_preview_price.setText(fix)
                        } else {
                            scroll2_from.isChecked = false
                            scroll2_from.isEnabled = true
                            scroll2_fixed_price.isEnabled = true
                            scroll2_fixed.isEnabled = true
                            scroll2_fixed.isChecked = true
                            scroll2_price_from.isEnabled = false
                            scroll2_price_to.isEnabled = false

                        }
                    } else if (edite == "false") {
                        popup("edit")
                    }
                }



                /*  val ces=intent.getStringExtra("cesss")*/
                /*      println("CESS VALUES IN LIST"+ces)*/


                /*  cessvaluevalidate=ces*/



                if (id.text.isNotEmpty()) {
                    println(id.text.toString())
                    val getone = myDb.getOne(id.text.toString())
                    if (getone.moveToNext()) {


                        rentalchk.setChecked(true)
                        rentalchkalready="true"


                        println("sfkuygon     " + getone.getString(0))
                        sname.setText(getone.getString(1))
                        snamevalidate = sname.text.toString()

                        sid.setText(getone.getString(2))
                        sdur.setText(getone.getString(3))
                        sdurvalidate = sdur.text.toString()
                        hsnT.setText(getone.getString(4))
                        hsnTvalidate = hsnT.text.toString()
                        hsndes.setText(getone.getString(5))
                        hsndesvalidate = hsndes.text.toString()

                        price.setText(getone.getString(6))
                        pricevalidate = price.text.toString()

                        Tax.setChecked((getone.getString(7).toBoolean()))



                        retdatedup = getone.getString(50)

                        intax.setText(getone.getString(8))
                        intaxvalidate = intax.text.toString()

                        cess.setText(getone.getString(9))
                        cessvalidate = cess.text.toString()

                        Ctax.setText(getone.getString(10))
                        Stax.setText(getone.getString(11))
                        taxtot.setText(getone.getString(12))
                        css.setText(getone.getString(13))
                        grosstot.setText(getone.getString(14))
                        payemp.setChecked(getone.getString(15).toBoolean())
                        payempvalidate = getone.getString(15)
                        paybonusvalidate = getone.getString(16)
                        currencyvalidate = getone.getString(17)
                        percentagevalidate = getone.getString(18)
                        paybonus.setChecked(getone.getString(16).toBoolean())
                        currency.setChecked(getone.getString(17).toBoolean())
                        percentage.setChecked(getone.getString(18).toBoolean())
                        per.setText(getone.getString(19))
                        pervalidate = per.text.toString()
                        gender = getone.getString(20).toString()
                        maincat = getone.getString(21).toString()
                        subcat = getone.getString(22).toString()


                        makeupitemstr=getone.getString(51).toString()

                        if(makeupitemstr=="FLOWERS"){
                            servrelchk.visibility=View.GONE
                            servrel.visibility=View.GONE
                            pricerel.visibility=View.GONE
                            lastrel.visibility=View.GONE
                            rentalchk.visibility=View.INVISIBLE
                            retques.visibility=View.INVISIBLE
                        }
                        try {
                            retdatedup = getone.getString(50).toString()
                        }
                        catch (e:Exception){

                        }
                        if(retdatedup.isNotEmpty()){
                            retques.isChecked=true
                            returnval="true"
                            retdays.visibility=View.VISIBLE
                            redays.setText(getone.getString(50).toString())

                        }

                        try {
                            mctgkeys = getone.getString(48).toString()
                        } catch (e: Exception) {

                        }
                        try {
                            sctgkeys = getone.getString(49).toString()
                        } catch (e: Exception) {

                        }

                        println("MC SUPER" + subcat)


                        gendervalidate = getone.getString(20).toString()
                        maincatvalidate = getone.getString(21).toString()
                        if (maincatvalidate == "") {
                            maincatvalidate = "Select"
                        }
                        subcatvalidate = getone.getString(22).toString()

                        des = getone.getString(23).toString()
                        descvalidate = getone.getString(23).toString()
                        fix = getone.getString(24).toString()
                        from = getone.getString(25).toString()
                        to = getone.getString(26).toString()
                        scroll2_fixed_price.setText(fix)

                        scroll2_fixed_pricevalidate = fix
                        scroll2_price_fromvalidate = from
                        scroll2_price_tovalidate = to

                        scroll2_price_from.setText(from)
                        scroll2_price_to.setText(to)
                        state.setText(getone.getString(27))

                        scroll2_preview_service_name.setText(getone.getString(1))

                        if (from != "" || to != "") {
                            scroll2_from.isChecked = true
                            scroll2_fixed_price.isEnabled = false
                            scroll2_price_from.isEnabled = true
                            scroll2_price_to.isEnabled = true
                            scroll2_fixed.isChecked = false
                            scroll2_preview_price.setText("From Rs $from to $to")
                        } else if (fix != "") {
                            scroll2_from.isChecked = false
                            scroll2_fixed.isChecked = true
                            scroll2_fixed_price.isEnabled = true
                            scroll2_price_from.isEnabled = false
                            scroll2_price_to.isEnabled = false
                            scroll2_preview_price.setText(fix)
                        }

                        if (frmscrtwo != "scrtwo") {
                            img1n = getone.getString(28).toString()
                            img2n = getone.getString(29).toString()
                            img3n = getone.getString(30).toString()
                            img4n = getone.getString(31).toString()
                            img5n = getone.getString(32).toString()
                            img1url = getone.getString(33).toString()
                            img2url = getone.getString(34).toString()
                            img3url = getone.getString(35).toString()
                            img4url = getone.getString(36).toString()
                            img5url = getone.getString(37).toString()

                            img1nhigh = getone.getString(38).toString()
                            img2nhigh = getone.getString(39).toString()
                            img3nhigh = getone.getString(40).toString()
                            img4nhigh = getone.getString(41).toString()
                            img5nhigh = getone.getString(42).toString()
                            img1urlhigh = getone.getString(43).toString()
                            img2urlhigh = getone.getString(44).toString()
                            img3urlhigh = getone.getString(45).toString()
                            img4urlhigh = getone.getString(46).toString()
                            img5urlhigh = getone.getString(47).toString()

                            f1edithigh = img1urlhigh
                            fn1edithigh = img1nhigh
                            s1edithigh = img2urlhigh
                            sn1edithigh = img2nhigh
                            t1edithigh = img3urlhigh
                            tn1edithigh = img3nhigh
                            fo1edithigh = img4urlhigh
                            fon1edithigh = img4nhigh
                            fif1edithigh = img5urlhigh
                            fifn1edithigh = img5nhigh



                            f1edit = img1url.toString()
                            fn1edit = img1n.toString()
                            s1edit = img2url.toString()
                            sn1edit = img2n.toString()
                            t1edit = img3url.toString()
                            tn1edit = img3n.toString()
                            fo1edit = img4url.toString()
                            fon1edit = img4n.toString()
                            fif1edit = img5url.toString()
                            fifn1edit = img5n.toString()
                        }
                    }
                }

            } else {
                println(newid.text.toString())
            }

                val ad=intent.getStringExtra("addpro")
                val ed=intent.getStringExtra("editpro")
                val viw=intent.getStringExtra("viewpro")
                val impo=intent.getStringExtra("importpro")
                val expo=intent.getStringExtra("exportpro")
                val del=intent.getStringExtra("deletepro")
                stockin_hand=intent.getStringExtra("changestock")
                val keyss=intent.getStringExtra("keybr")




                println("HELLO UPDATE EDIT"+ed)

                if (ad!=null)
                {
                    addpro = ad
                }
                if(ed!=null){
                    editepro = ed
                }
                if (del!=null){
                    deletepro = del
                }
                if (viw!=null){
                    viewpro = viw
                }
                if (impo!=null){
                    importpro = impo
                }
                if (expo!=null){
                    exportpro = expo
                }

                listcome="yes"



                branchky = keyss



                                    if (id.text.isNotEmpty()) {


                                        val database = FirebaseDatabase.getInstance()
                                        val myRef = database.getReference(id.text.toString() + "_" + branchky)

                                        val messageListener = object : ValueEventListener {

                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                if (dataSnapshot.exists()) {

                                                    val message = dataSnapshot.value
                                                    stockhand.setText(message.toString())
                                                    stockhandvalidate=message.toString()
                                                    println("SOH"+message)

                                                }
                                            }

                                            override fun onCancelled(databaseError: DatabaseError)
                                            {
                                                // Failed to read value
                                            }
                                        }

                                        myRef!!.addValueEventListener(messageListener)





                                        save.visibility = View.INVISIBLE
                                        edit.visibility = View.VISIBLE
                                        scroll2_gallery.visibility=View.INVISIBLE




                                        val getone = myDb1.getOne(id.text.toString())

                                        if (getone.moveToNext()) {

                                            var i=0
                                            retailchk.setChecked(true)
                                            retailchkalready="true"
                                            sname.setText(getone.getString(2))

                                            pnamevalidate=getone.getString(2)

                                            sl_title.setText(getone.getString(2))


                                            pid.setText(getone.getString(1))


                                            vol.setText(getone.getString(5))
                                            volvalidate=getone.getString(5)

                                            val k = getone.getString(9)
                                            val kmanu =getone.getString(8)
                                            val categ=getone.getString(7)

                                            maincatvalidatepro=getone.getString(7)
                                            subcatvalidatepro=getone.getString(8)
                                            listvalidate=getone.getString(9)



                                            println("CATE"+categ)
                                            bcodeid.setText(getone.getString(3))
                                            bcodeidvalidate=getone.getString(3)
                                            hsnT.setText(getone.getString(6))
                                            hscvalidate=getone.getString(6)

                                            hsndes.setText(getone.getString(4))
                                            hscdesvalidate=getone.getString(4)

                                            maincateg.add(categ)
                                            println("CATEG"+maincat)
                                            db.collection("productcategory")
                                                    .get()
                                                    .addOnCompleteListener {task->

                                                        if (task.result.isEmpty == false) {
                                                            if (task.result != null) {

                                                                maincatIdpro.clear()

                                                                maincatIdpro.add("")
                                                                for (document in task.result) {
                                                                    i += 1
                                                                    println("document id : " + document.id)
                                                                    println("document data : " + document.data)
                                                                    val dd = document.data
                                                                    maincatIdpro.add(document.id)
                                                                    val c = dd["cat"].toString()



                                                                    if (c == categ) {
                                                                        dup = c
                                                                    } else {
                                                                        maincateg.add(c)
                                                                    }



                                                                    println(maincat)
                                                                    println("CATEG" + maincat)
                                                                    cate.adapter = adp1
                                                                    /*  if (main.isNullOrEmpty()!=true){
                                                                      val spinnerPosition = adp1.getPosition(main.toString())
                                                                      cate.setSelection(spinnerPosition)
                                                                  }*/
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            maincateg.add(categ)

                                                            cate.adapter = adp1
                                                        }


                                                    }



                                            val categories1 = ArrayList<String>()
                                            subcateg.add(kmanu)
                                            println("MANU SPIN"+subcat)

                                            db.collection("manufacturer")
                                                    .get()
                                                    .addOnCompleteListener {task->

                                                        if (task.result.isEmpty == false) {
                                                            if (task.result != null){

                                                                maincatIdpro.clear()

                                                                maincatIdpro.add("")
                                                                for (document in task.result){
                                                                    println("document id : "+document.id)
                                                                    println("document data : "+document.data)
                                                                    val dd=document.data
                                                                    maincatIdpro.add(document.id)
                                                                    val c = dd["cat"].toString()



                                                                    if(c==kmanu){
                                                                        dup=c
                                                                    }
                                                                    else{
                                                                        subcateg.add(c)
                                                                    }
                                                                    println(maincat)
                                                                    println("MANU SPIN"+subcat)
                                                                    manu.adapter=adp2
                                                                    /*  if (main.isNullOrEmpty()!=true){
                                                                          val spinnerPosition = adp1.getPosition(main.toString())
                                                                          cate.setSelection(spinnerPosition)
                                                                      }*/
                                                                }
                                                            }
                                                        }
                                                        else{

                                                            subcateg.add(kmanu)
                                                            manu.adapter=adp2
                                                        }
                                                    }






                                            val categories2 = ArrayList<String>()
                                            list.add(k)

                                            println("UNIT SPIN"+list)

                                            db.collection("unit")
                                                    .get()
                                                    .addOnCompleteListener {task->

                                                        if (task.result.isEmpty == false) {

                                                            if (task.result != null) {

                                                                maincatIdpro.clear()

                                                                maincatIdpro.add("")
                                                                for (document in task.result) {
                                                                    println("document id : " + document.id)
                                                                    println("document data : " + document.data)
                                                                    val dd = document.data
                                                                    maincatIdpro.add(document.id)
                                                                    val c = dd["cat"].toString()




                                                                    if (c == k) {
                                                                        dup = c
                                                                    } else {
                                                                        list.add(c)
                                                                    }
                                                                    println(maincat)
                                                                    println("UNIT SPIN" + list)
                                                                    unitspinner.adapter = dataAdapter
                                                                    /*  if (main.isNullOrEmpty()!=true){
                                                                      val spinnerPosition = adp1.getPosition(main.toString())
                                                                      cate.setSelection(spinnerPosition)
                                                                  }*/
                                                                }
                                                            }


                                                        }
                                                        else{
                                                            list.add(k)
                                                            unitspinner.adapter = dataAdapter


                                                        }
                                                    }





                                            println("PRICE" + getone.getString(11))
                                            img1n = getone.getString(29).toString()

                                            img2n = getone.getString(30).toString()
                                            img3n = getone.getString(31).toString()
                                            img4n = getone.getString(32).toString()
                                            img5n = getone.getString(33).toString()
                                            img1url = getone.getString(34).toString()
                                            println("IMG URLSSSS" + getone.getString(34).toString())
                                            println("IMG NAMES" + getone.getString(29).toString())

                                            img2url = getone.getString(35).toString()
                                            img3url = getone.getString(36).toString()
                                            img4url = getone.getString(37).toString()
                                            img5url = getone.getString(38).toString()

                                            img1nhigh=getone.getString(39).toString()
                                            img2nhigh=getone.getString(40).toString()
                                            img3nhigh=getone.getString(41).toString()
                                            img4nhigh=getone.getString(42).toString()
                                            img5nhigh=getone.getString(43).toString()
                                            img1urlhigh=getone.getString(44).toString()
                                            img2urlhigh=getone.getString(45).toString()
                                            img3urlhigh=getone.getString(46).toString()
                                            img4urlhigh=getone.getString(47).toString()
                                            img5urlhigh=getone.getString(48).toString()


                                            f1edithigh=getone.getString(44).toString()
                                            fn1edithigh=getone.getString(39).toString()
                                            s1edithigh=getone.getString(45).toString()
                                            sn1edithigh=getone.getString(40).toString()
                                            t1edithigh=getone.getString(46).toString()
                                            tn1edithigh=getone.getString(41).toString()
                                            fo1edithigh=getone.getString(47).toString()
                                            fon1edithigh=getone.getString(42).toString()
                                            fif1edithigh=getone.getString(48).toString()
                                            fifn1edithigh=getone.getString(43).toString()



                                            f1edit =  getone.getString(34).toString()
                                            fn1edit = getone.getString(29).toString()
                                            s1edit = getone.getString(35).toString()
                                            sn1edit = getone.getString(30).toString()
                                            t1edit = getone.getString(36).toString()
                                            tn1edit = getone.getString(31).toString()
                                            fo1edit = getone.getString(37).toString()
                                            fon1edit = getone.getString(32).toString()
                                            fif1edit = getone.getString(38).toString()
                                            fifn1edit = getone.getString(33).toString()

                                            if((img1url.isNotEmpty())||(img2url.isNotEmpty())){
                                                camback.visibility=View.GONE
                                                cam.visibility=View.GONE
                                                scroll2_gallery.visibility=View.VISIBLE
                                            }







                                            println("IMG URLSSSS" + getone.getString(34).toString())
                                            price.setText(getone.getString(11))
                                            pricevalidate=getone.getString(11)

                                            Tax.setChecked(getone.getString(15).toBoolean())
                                            taxcheckvalidate=getone.getString(15)

                                            intax.setText(getone.getString(16))
                                            intgstvalidate=getone.getString(16)


                                            println("CESSS"+getone.getString(19))

                                            try {
                                                cess.setText(getone.getString(19))
                                                cessvaluevalidate=getone.getString(19)
                                            }
                                            catch (e:Exception){

                                            }

                                            Ctax.setText(getone.getString(17))


                                            Stax.setText(getone.getString(18))


                                            taxtot.setText(getone.getString(20))





                                            retailvalidate=getone.getString(50)

                                            backbarvalidate=getone.getString(51)
                                            try {
                                                returnablevalidate = getone.getString(53)

                                            }
                                            catch (e:Exception){

                                            }

                                            if(getone.getString(53).isNotEmpty()){
                                                retques.setChecked(getone.getString(53).toBoolean())

                                            }
                                            try {
                                                retdatedup = getone.getString(54).toString()
                                            }
                                            catch (e:Exception){

                                            }
                                            if(getone.getString(54).isNotEmpty()){
                                                retques.isChecked=true
                                                returnval="true"
                                                retdays.visibility=View.VISIBLE
                                                redays.setText(getone.getString(54).toString())
                                            }

                                            css.setText(getone.getString(21))



                                            protypesave=getone.getString(52)
                                            grosstot.setText(getone.getString(22))
                                            payemp.setChecked(getone.getString(14).toBoolean())
                                            checkcommisionvalidate=getone.getString(14)

                                            paybonus.setChecked(getone.getString(13).toBoolean())

                                            checkbonusvalidate=getone.getString(13)


                                            currency.setChecked(getone.getString(23).toBoolean())

                                            percentage.setChecked(getone.getString(25).toBoolean())
                                            per.setText(getone.getString(26))

                                            percentagevalvalidate=getone.getString(26)

                                            maxstock.setText(getone.getString(12))
                                            maxstockvalidate=getone.getString(12)

                                            minstock.setText(getone.getString(10))
                                            minstockvalidate=getone.getString(10)

                                            makeupitemstr=getone.getString(55)


                                            if(makeupitemstr=="FLOWERS"){
                                                servrelchk.visibility=View.GONE
                                                servrel.visibility=View.GONE
                                                pricerel.visibility=View.GONE
                                                lastrel.visibility=View.GONE
                                                rentalchk.visibility=View.INVISIBLE
                                                retques.visibility=View.INVISIBLE
                                            }

                                            scroll2_descrip.setText(getone.getString(27))
                                            des_boxvalidate=getone.getString(27)
                                            state.setText(getone.getString(24))


                                        }
                                        else{
                                            db.collection("productcategory")
                                                    .get()
                                                    .addOnCompleteListener {task->


                                                        if(task.result.isEmpty==false){
                                                            if (task.result != null){
                                                                maincateg.clear()
                                                                maincatIdpro.clear()
                                                                maincateg.add("Select")
                                                                maincatIdpro.add("")
                                                                for (document in task.result){
                                                                    println("document id : "+document.id)
                                                                    println("document data : "+document.data)
                                                                    val dd=document.data
                                                                    maincatIdpro.add(document.id)
                                                                    val c = dd["cat"].toString()
                                                                    maincateg.add(c)
                                                                    println(maincateg)
                                                                    cate.adapter=adp1
                                                                    /*  if (main.isNullOrEmpty()!=true){
                                                                          val spinnerPosition = adp1.getPosition(main.toString())
                                                                          cate.setSelection(spinnerPosition)
                                                                      }*/
                                                                }
                                                            }

                                                            else{

                                                            }
                                                        }
                                                        else
                                                        {
                                                            maincateg.add("Select")
                                                            cate.adapter=adp1
                                                        }

                                                    }


                                            db.collection("unit")
                                                    .get()
                                                    .addOnCompleteListener {task->
                                                        if(task.result.isEmpty==false){

                                                            if (task.result != null){
                                                                list.clear()
                                                                maincatIdpro.clear()
                                                                list.add("Select")
                                                                maincatIdpro.add("")
                                                                for (document in task.result){
                                                                    println("document id : "+document.id)
                                                                    println("document data : "+document.data)
                                                                    val dd=document.data
                                                                    maincatIdpro.add(document.id)
                                                                    val c = dd["cat"].toString()
                                                                    list.add(c)
                                                                    println(maincat)
                                                                    unitspinner.adapter=dataAdapter
                                                                    /*  if (main.isNullOrEmpty()!=true){
                                                                          val spinnerPosition = adp1.getPosition(main.toString())
                                                                          cate.setSelection(spinnerPosition)
                                                                      }*/
                                                                }
                                                            }
                                                        }
                                                        else{
                                                            list.add("Select")
                                                            unitspinner.adapter=dataAdapter
                                                        }
                                                    }


                                            db.collection("manufacturer")
                                                    .get()
                                                    .addOnCompleteListener {task->
                                                        if(task.result.isEmpty==false){
                                                            if (task.result != null){
                                                                subcateg.clear()
                                                                maincatIdpro.clear()
                                                                subcateg.add("Select")
                                                                maincatIdpro.add("")
                                                                for (document in task.result){
                                                                    println("document id : "+document.id)
                                                                    println("document data : "+document.data)
                                                                    val dd=document.data
                                                                    maincatIdpro.add(document.id)
                                                                    val c = dd["cat"].toString()
                                                                    subcateg.add(c)
                                                                    println(maincat)
                                                                    manu.adapter=adp2
                                                                    /*  if (main.isNullOrEmpty()!=true){
                                                                          val spinnerPosition = adp1.getPosition(main.toString())
                                                                          cate.setSelection(spinnerPosition)
                                                                      }*/
                                                                }
                                                            }
                                                        }
                                                        else
                                                        {
                                                            subcateg.add("Select")
                                                            manu.adapter=adp2
                                                        }
                                                    }
                                        }
                                    }
                                    else {
                                        println(idsmy.text.toString())
                                    }












        //}}




            disable.visibility=View.GONE



        }

        lists.add("Select")
        lists.add("Men")
        lists.add("Women")
        lists.add("Unisex")
        scroll2_gender.adapter = dataAdapterser
        if (gender.isNullOrEmpty() != true) {
            val spinnerPosition = dataAdapterser.getPosition(gender)
            scroll2_gender.setSelection(spinnerPosition)
        }


        disable.setOnClickListener {
            if(rentalchk.isChecked==true&&retailchk.isChecked==false) {
                val popup = PopupMenu(this@Attachments_Activity, disable)
                popup.menuInflater.inflate(R.menu.disable, popup.menu)
                val m1 = popup.menu.getItem(0)
                if (delete == "true" || delete.isNullOrEmpty()) {
                    if (save.visibility == View.VISIBLE) {
                        if (state.text == "Disabled"||state.text=="Disable") {
                            m1.title = "Enable"
                            popup.setOnMenuItemClickListener { item ->//Click disable title and change the status of the product as 'DISABLED'

                                if (net_status() == true) {
                                    val upid = id.text.toString()
                                    val sname = (textInputLayout.editText!!.text).toString()
                                    val sid = (textInputLayout2.editText!!.text).toString()
                                    val sdur = (textInputLayout3.editText!!.text).toString()
                                    val hsnT = (hsnT.text).toString()
                                    val hsndes = (hsndes.text).toString()
                                    val pr = (price.text).toString()
                                    val Tax = (Tax.isChecked.toString())
                                    val intax = (intax.text).toString()
                                    val cess = (cess.text).toString()
                                    val Ctax = (Ctax.text).toString()
                                    val Stax = (Stax.text).toString()
                                    val taxtot = (taxtot.text).toString()
                                    val css = (css.text).toString()
                                    val Gtot = (grosstot.text).toString()
                                    val payemp = (payemp.isChecked.toString())
                                    val paybonus = (paybonus.isChecked.toString())
                                    val currency = (currency.isChecked.toString())
                                    val percentage = (percentage.isChecked.toString())
                                    val per = (per.text).toString()
                                    val retdates = ""

                                    //val desc = (descrip.text).toString()

                                    val builder = android.app.AlertDialog.Builder(this@Attachments_Activity)
                                    with(builder) {
                                        setTitle("Confirm?")
                                        setMessage("Are you sure want to enable?")
                                        setPositiveButton("Yes") { dialog, whichButton ->
                                            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE);
                                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                            pDialogs!!.setTitleText("Enabling...");
                                            pDialogs!!.setCancelable(false);
                                            pDialogs!!.show();
                                            state.setText("Active")
                                            val status = (state.text.toString())
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("status", status)
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update(map)
                                                    .addOnSuccessListener {
                                                        val isInserted = myDb.updateData(upid, sname, sid, sdur, hsnT, hsndes, pr, Tax, intax, cess, Ctax,
                                                                Stax, taxtot, css, Gtot, payemp, paybonus, currency, percentage, per, gender, maincat, subcat,
                                                                des, fix, from, to, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                                img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                                img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, mctgkeys, sctgkeys, retdates,makeupitemstr)


                                                        pDialogs!!.dismiss()
                                                        Toast.makeText(applicationContext, "Enabled", Toast.LENGTH_LONG).show()
                                                        val data = Intent(applicationContext,Main_makeup::class.java)
                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                        startActivity(data)
                                                        finish()
                                                    }
                                        }
                                                .setNegativeButton("No") { dialog, whichButton ->
                                                    dialog.dismiss()
                                                }

                                        val dialog = builder.create()

                                        dialog.show()
                                    }
                                } else if (net_status() == false) {
                                    Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                                }


                                true
                            }
                            popup.show()
                        } else if (state.text == "Active"||state.text=="Active") {
                            m1.title = "Disable"
                            popup.setOnMenuItemClickListener { item -> //Click enable title and change the status of the product as 'Active'
                                if (net_status() == true) {
                                    val upid = id.text.toString()
                                    val sname = (textInputLayout.editText!!.text).toString()
                                    val sid = (textInputLayout2.editText!!.text).toString()
                                    val sdur = (textInputLayout3.editText!!.text).toString()
                                    val hsnT = (hsnT.text).toString()
                                    val hsndes = (hsndes.text).toString()
                                    val pr = (price.text).toString()
                                    val Tax = (Tax.isChecked.toString())
                                    val intax = (intax.text).toString()
                                    val cess = (cess.text).toString()
                                    val Ctax = (Ctax.text).toString()
                                    val Stax = (Stax.text).toString()
                                    val taxtot = (taxtot.text).toString()
                                    val css = (css.text).toString()
                                    val Gtot = (grosstot.text).toString()
                                    val payemp = (payemp.isChecked.toString())
                                    val paybonus = (paybonus.isChecked.toString())
                                    val currency = (currency.isChecked.toString())
                                    val percentage = (percentage.isChecked.toString())
                                    val per = (per.text).toString()
                                    val retdates = ""
                                    //val desc = (descrip.text).toString()

                                    val builder = android.app.AlertDialog.Builder(this@Attachments_Activity)
                                    with(builder) {
                                        setTitle("Confirm?")
                                        setMessage("Are you sure want to disable?")
                                        setPositiveButton("Yes") { dialog, whichButton ->
                                            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE);
                                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                            pDialogs!!.setTitleText("Disabling...");
                                            pDialogs!!.setCancelable(false);
                                            pDialogs!!.show();
                                            state.setText("Disabled")
                                            val status = (state.text.toString())
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("status", status)
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update(map)
                                                    .addOnSuccessListener {
                                                        val isInserted = myDb.updateData(upid, sname, sid, sdur, hsnT, hsndes, pr, Tax, intax, cess,
                                                                Ctax, Stax, taxtot, css, Gtot, payemp, paybonus, currency, percentage, per, gender, maincat,
                                                                subcat, des, fix, from, to, status, img1n, img2n, img3n,
                                                                img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                                                img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, mctgkeys, sctgkeys, retdates,makeupitemstr)


                                                        pDialogs!!.dismiss()
                                                        Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()
                                                        val data = Intent(applicationContext,Main_makeup::class.java)
                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                        startActivity(data)
                                                        finish()
                                                    }
                                        }
                                                .setNegativeButton("No") { dialog, whichButton ->


                                                    dialog.dismiss()
                                                }
                                        val dialog = builder.create()

                                        dialog.show()
                                    }

                                } else if (net_status() == false) {
                                    Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                                }



                                true
                            }
                            popup.show()
                        }
                    }
                } else if (delete == "false") {
                    popup("Disable or Enable")
                }
            }
            else if(rentalchk.isChecked==true&&retailchk.isChecked==true){
                val popup = PopupMenu(this@Attachments_Activity, disable)
                popup.menuInflater.inflate(R.menu.disable, popup.menu)
                val m1 = popup.menu.getItem(0)
                if (delete == "true" || delete.isNullOrEmpty()) {
                    if (save.visibility == View.VISIBLE) {
                        if (state.text == "Disabled"||state.text=="Disable") {
                            m1.title = "Enable"
                            popup.setOnMenuItemClickListener { item ->//Click disable title and change the status of the product as 'DISABLED'

                                if (net_status() == true) {
                                    val upid = id.text.toString()
                                    val snames = (textInputLayout.editText!!.text).toString()
                                    val sid = (textInputLayout2.editText!!.text).toString()
                                    val sdur = (textInputLayout3.editText!!.text).toString()
                                    val hsnTs = (hsnT.text).toString()
                                    val hsndess = (hsndes.text).toString()
                                    val prs = (price.text).toString()
                                    val Taxs = (Tax.isChecked.toString())
                                    val intaxs = (intax.text).toString()
                                    val cesss = (cess.text).toString()
                                    val Ctaxs = (Ctax.text).toString()
                                    val Staxs = (Stax.text).toString()
                                    val taxtots = (taxtot.text).toString()
                                    val csss = (css.text).toString()
                                    val Gtots = (grosstot.text).toString()
                                    val payemps = (payemp.isChecked.toString())
                                    val paybonuss = (paybonus.isChecked.toString())
                                    val currencys = (currency.isChecked.toString())
                                    val percentages = (percentage.isChecked.toString())
                                    val pers = (per.text).toString()
                                    val retdatess = ""

                                    //val desc = (descrip.text).toString()

                                    val builder = android.app.AlertDialog.Builder(this@Attachments_Activity)
                                    with(builder) {
                                        setTitle("Confirm?")
                                        setMessage("Are you sure want to enable?")
                                        setPositiveButton("Yes") { dialog, whichButton ->
                                            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE);
                                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                            pDialogs!!.setTitleText("Enabling...");
                                            pDialogs!!.setCancelable(false);
                                            pDialogs!!.show();
                                            state.setText("Active")
                                            val status = (state.text.toString())
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("status", status)
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update(map)
                                                    .addOnSuccessListener {
                                                        val isInserted = myDb.updateData(upid, snames, sid, sdur, hsnTs, hsndess, prs, Taxs, intaxs, cesss, Ctaxs,
                                                                Staxs, taxtots, csss, Gtots, payemps, paybonuss, currencys, percentages, pers, gender, maincat, subcat,
                                                                des, fix, from, to, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                                img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                                img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, mctgkeys, sctgkeys, retdatess,makeupitemstr)

                                                        var npid = id.text.toString()
                                                        var pid = (pid.text).toString()
                                                        var pname = (sname.text).toString()
                                                        var bcode = (bcodeid.text).toString()
                                                        var pdes = (hsndes.text).toString()
                                                        var orikys = branchky
                                                        var weight = (vol.text).toString()
                                                        var psac = (hsnT.text).toString()

                                                        if (stockhand.text.toString().isNotEmpty()) {
                                                            var stockonhand = (stockhand.text).toString()
                                                            stkhand = stockonhand
                                                        } else {

                                                            stkhand = "0"
                                                        }

                                                        var minstock = (minstock.text).toString()
                                                        var maxstock = (maxstock.text).toString()
                                                        var price = (price.text).toString()
                                                        var taxable =Tax.isChecked.toString()
                                                        var igst = (intax.text).toString()
                                                        var cgst = (Ctax.text).toString()
                                                        var sgst = (Stax.text).toString()
                                                        var cess = (cess.text).toString()
                                                        var taxtotal = (taxtot.text).toString()
                                                        var cessval = (css.text).toString()
                                                        var currency = currency.isChecked.toString()
                                                        var percentage = percentage.isChecked.toString()
                                                        var percentagevalue = (per.text).toString()
                                                        var product_dec = (scroll2_descrip.text).toString()
                                                        var mrP = (grosstot.text).toString()
                                                        var cate = cate.selectedItem.toString()
                                                        var manufacture = manu.selectedItem.toString()
                                                        var ut = unitspinner.selectedItem.toString()
                                                        var consold = paybonus.isChecked.toString()
                                                        var comm = payemp.isChecked.toString()
                                                        var statuss = (state.text).toString()


                                                        var ret = "false"
                                                        var bskbr = "false"
                                                        var returnables="false"
                                                        var retday=""

                                                        val img1n = img1n
                                                        val img2n = img2n
                                                        val img3n = img3n
                                                        val img4n = img4n
                                                        val img5n = img5n
                                                        val img1url = img1url
                                                        val img2url = img2url
                                                        val img3url = img3url
                                                        val img4url = img4url
                                                        val img5url = img5url

                                                        state.setText("Active")
                                                        var status = (state.text).toString()

                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("status", status)
                                                        db.collection("product").document(id.text.toString())
                                                                .update(map)
                                                                .addOnSuccessListener {
                                                                    val isInserted = myDb1.updatedata(npid, pid, pname, bcode, pdes, weight, psac, cate,
                                                                            manufacture, ut, minstock, price, maxstock, consold, comm, taxable, igst, cgst,
                                                                            sgst, cess, taxtotal, cessval, mrP, currency, status, percentage, percentagevalue,
                                                                            product_dec, stkhand, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                                            img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                                            img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys, ret, bskbr, protypesave, returnables, retday,makeupitemstr)

                                                                    if (isInserted == true) {
                                                                    } else {
                                                                    }
                                                                    try {
                                                                        pDialogs!!.dismiss()
                                                                    } catch (e: Exception) {

                                                                    }
                                                                }


                                                                    pDialogs!!.dismiss()
                                                        Toast.makeText(applicationContext, "Enabled", Toast.LENGTH_LONG).show()
                                                        val data = Intent(applicationContext,Main_makeup::class.java)
                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                        startActivity(data)
                                                        finish()
                                                    }
                                        }
                                                .setNegativeButton("No") { dialog, whichButton ->
                                                    dialog.dismiss()
                                                }

                                        val dialog = builder.create()

                                        dialog.show()
                                    }
                                } else if (net_status() == false) {
                                    Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                                }


                                true
                            }
                            popup.show()
                        } else if (state.text == "Active"||state.text=="Active") {
                            m1.title = "Disable"
                            popup.setOnMenuItemClickListener { item ->
                                if (net_status() == true) { //Click enable title and change the status of the product as 'Active'
                                    val upid = id.text.toString()
                                    val snames = (textInputLayout.editText!!.text).toString()
                                    val sid = (textInputLayout2.editText!!.text).toString()
                                    val sdur = (textInputLayout3.editText!!.text).toString()
                                    val hsnTs = (hsnT.text).toString()
                                    val hsndess = (hsndes.text).toString()
                                    val prs = (price.text).toString()
                                    val Taxs = (Tax.isChecked.toString())
                                    val intaxs = (intax.text).toString()
                                    val cesss = (cess.text).toString()
                                    val Ctaxs = (Ctax.text).toString()
                                    val Staxs = (Stax.text).toString()
                                    val taxtots = (taxtot.text).toString()
                                    val csss = (css.text).toString()
                                    val Gtots = (grosstot.text).toString()
                                    val payemps = (payemp.isChecked.toString())
                                    val paybonuss = (paybonus.isChecked.toString())
                                    val currencys = (currency.isChecked.toString())
                                    val percentages = (percentage.isChecked.toString())
                                    val pers = (per.text).toString()
                                    val retdatess = ""
                                    //val desc = (descrip.text).toString()

                                    val builder = android.app.AlertDialog.Builder(this@Attachments_Activity)
                                    with(builder) {
                                        setTitle("Confirm?")
                                        setMessage("Are you sure want to disable?")
                                        setPositiveButton("Yes") { dialog, whichButton ->
                                            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE);
                                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                            pDialogs!!.setTitleText("Disabling...");
                                            pDialogs!!.setCancelable(false);
                                            pDialogs!!.show();
                                            state.setText("Disabled")
                                            val status = (state.text.toString())
                                            val map = mutableMapOf<String, Any?>()
                                            map.put("status", status)
                                            db.collection("${branchky}_service").document(id.text.toString())
                                                    .update(map)
                                                    .addOnSuccessListener {
                                                        val isInserted = myDb.updateData(upid, snames, sid, sdur, hsnTs, hsndess, prs, Taxs, intaxs, cesss,
                                                                Ctaxs, Staxs, taxtots, csss, Gtots, payemps, paybonuss, currencys, percentages, pers, gender, maincat,
                                                                subcat, des, fix, from, to, status, img1n, img2n, img3n,
                                                                img4n, img5n, img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                                                img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, mctgkeys, sctgkeys, retdatess,makeupitemstr)

                                                        var npid = id.text.toString()
                                                        var pid = (pid.text).toString()
                                                        var pname = (sname.text).toString()
                                                        var bcode = (bcodeid.text).toString()
                                                        var pdes = (hsndes.text).toString()
                                                        var orikys = branchky
                                                        var weight = (vol.text).toString()
                                                        var psac = (hsnT.text).toString()

                                                        if (stockhand.text.toString().isNotEmpty()) {
                                                            var stockonhand = (stockhand.text).toString()
                                                            stkhand = stockonhand
                                                        } else {

                                                            stkhand = "0"
                                                        }

                                                        var minstock = (minstock.text).toString()
                                                        var maxstock = (maxstock.text).toString()
                                                        var price = (price.text).toString()
                                                        var taxable =Tax.isChecked.toString()
                                                        var igst = (intax.text).toString()
                                                        var cgst = (Ctax.text).toString()
                                                        var sgst = (Stax.text).toString()
                                                        var cess = (cess.text).toString()
                                                        var taxtotal = (taxtot.text).toString()
                                                        var cessval = (css.text).toString()
                                                        var currency = currency.isChecked.toString()
                                                        var percentage = percentage.isChecked.toString()
                                                        var percentagevalue = (per.text).toString()
                                                        var product_dec = (scroll2_descrip.text).toString()
                                                        var mrP = (grosstot.text).toString()
                                                        var cate = cate.selectedItem.toString()
                                                        var manufacture = manu.selectedItem.toString()
                                                        var ut = unitspinner.selectedItem.toString()
                                                        var consold = paybonus.isChecked.toString()
                                                        var comm = payemp.isChecked.toString()
                                                        var statuss = (state.text).toString()


                                                        var ret = "false"
                                                        var bskbr = "false"
                                                        var returnables="false"
                                                        var retday=""

                                                        val img1n = img1n
                                                        val img2n = img2n
                                                        val img3n = img3n
                                                        val img4n = img4n
                                                        val img5n = img5n
                                                        val img1url = img1url
                                                        val img2url = img2url
                                                        val img3url = img3url
                                                        val img4url = img4url
                                                        val img5url = img5url

                                                        state.setText("Disable")
                                                        var status = (state.text).toString()

                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("status", status)
                                                        db.collection("product").document(id.text.toString())
                                                                .update(map)
                                                                .addOnSuccessListener {
                                                                    val isInserted = myDb1.updatedata(npid, pid, pname, bcode, pdes, weight, psac, cate,
                                                                            manufacture, ut, minstock, price, maxstock, consold, comm, taxable, igst, cgst,
                                                                            sgst, cess, taxtotal, cessval, mrP, currency, status, percentage, percentagevalue,
                                                                            product_dec, stkhand, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                                            img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                                            img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys, ret, bskbr, protypesave, returnables, retday,makeupitemstr)

                                                                    if (isInserted == true) {
                                                                    } else {
                                                                    }
                                                                    try {
                                                                        pDialogs!!.dismiss()
                                                                    } catch (e: Exception) {

                                                                    }
                                                                }
                                                        pDialogs!!.dismiss()
                                                        Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()
                                                        val data = Intent(applicationContext,Main_makeup::class.java)
                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                                        startActivity(data)
                                                        finish()
                                                    }
                                        }
                                                .setNegativeButton("No") { dialog, whichButton ->


                                                    dialog.dismiss()
                                                }
                                        val dialog = builder.create()

                                        dialog.show()
                                    }

                                } else if (net_status() == false) {
                                    Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                                }



                                true
                            }
                            popup.show()
                        }
                    }
                } else if (delete == "false") {
                    popup("Disable or Enable")
                }
            }
            else if(rentalchk.isChecked==false&&retailchk.isChecked==true){
                val popup = PopupMenu(this@Attachments_Activity, disable)
                popup.menuInflater.inflate(R.menu.disable, popup.menu)
                val m1 = popup.menu.getItem(0)
                if (delete == "true" || delete.isNullOrEmpty()) {
                    if (save.visibility == View.VISIBLE) {
                        if (state.text == "Disabled"||state.text=="Disable") {

                            m1.title = "Enable"
                            popup.setOnMenuItemClickListener { item ->

                                if (net_status() == true) {
                                    var npid = id.text.toString()
                                    var pid = (pid.text).toString()
                                    var pname = (sname.text).toString()
                                    var bcode = (bcodeid.text).toString()
                                    var pdes = (hsndes.text).toString()
                                    var orikys = branchky
                                    var weight = (vol.text).toString()
                                    var psac = (hsnT.text).toString()

                                    if (stockhand.text.toString().isNotEmpty()) {
                                        var stockonhand = (stockhand.text).toString()
                                        stkhand = stockonhand
                                    } else {

                                        stkhand = "0"
                                    }

                                    var minstock = (minstock.text).toString()
                                    var maxstock = (maxstock.text).toString()
                                    var price = (price.text).toString()
                                    var taxable =Tax.isChecked.toString()
                                    var igst = (intax.text).toString()
                                    var cgst = (Ctax.text).toString()
                                    var sgst = (Stax.text).toString()
                                    var cess = (cess.text).toString()
                                    var taxtotal = (taxtot.text).toString()
                                    var cessval = (css.text).toString()
                                    var currency = currency.isChecked.toString()
                                    var percentage = percentage.isChecked.toString()
                                    var percentagevalue = (per.text).toString()
                                    var product_dec = (scroll2_descrip.text).toString()
                                    var mrP = (grosstot.text).toString()
                                    var cate = cate.selectedItem.toString()
                                    var manufacture = manu.selectedItem.toString()
                                    var ut = unitspinner.selectedItem.toString()
                                    var consold = paybonus.isChecked.toString()
                                    var comm = payemp.isChecked.toString()
                                    var statuss = (state.text).toString()


                                    var ret = "false"
                                    var bskbr = "false"
                                    var returnables="false"
                                    var retday=""

                                    val img1n = img1n
                                    val img2n = img2n
                                    val img3n = img3n
                                    val img4n = img4n
                                    val img5n = img5n
                                    val img1url = img1url
                                    val img2url = img2url
                                    val img3url = img3url
                                    val img4url = img4url
                                    val img5url = img5url

                                    //val desc = (descrip.text).toString()

                                    val builder = android.app.AlertDialog.Builder(this@Attachments_Activity)
                                    with(builder) {
                                        setTitle("Confirm?")
                                        setMessage("Are you sure want to enable?")
                                        setPositiveButton("Yes") { dialog, whichButton ->
                                            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE);
                                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                            pDialogs!!.setTitleText("Enabling...");
                                            pDialogs!!.setCancelable(false);
                                            pDialogs!!.show();
                                            state.setText("Active")
                                            var status = (state.text).toString()

                                            val map = mutableMapOf<String, Any?>()
                                            map.put("status", status)
                                            db.collection("product").document(id.text.toString())
                                                    .update(map)
                                                    .addOnSuccessListener {
                                                        val isInserted = myDb1.updatedata(npid, pid, pname, bcode, pdes, weight, psac, cate,
                                                                manufacture, ut, minstock, price, maxstock, consold, comm, taxable, igst, cgst,
                                                                sgst, cess, taxtotal, cessval, mrP, currency, status, percentage, percentagevalue,
                                                                product_dec, stkhand, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                                img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                                img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys, ret, bskbr, protypesave, returnables, retday,makeupitemstr)

                                                        if (isInserted == true) {
                                                        } else {
                                                        }
                                                        try {
                                                            pDialogs!!.dismiss()
                                                        } catch (e: Exception) {

                                                        }
                                                    }
                                            pDialogs!!.dismiss()
                                            Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()
                                            val data = Intent(applicationContext,Main_makeup::class.java)
                                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                            startActivity(data)
                                            finish()

                                        }
                                                .setNegativeButton("No") { dialog, whichButton ->
                                                    dialog.dismiss()
                                                }

                                        val dialog = builder.create()

                                        dialog.show()
                                    }
                                } else if (net_status() == false) {
                                    Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                                }


                                true
                            }
                            popup.show()
                        } else if (state.text == "Active"||state.text=="Active") {
                            m1.title = "Disable"
                            popup.setOnMenuItemClickListener { item ->
                                if (net_status() == true) {
                                    var npid = id.text.toString()
                                    var pid = (pid.text).toString()
                                    var pname = (sname.text).toString()
                                    var bcode = (bcodeid.text).toString()
                                    var pdes = (hsndes.text).toString()
                                    var orikys = branchky
                                    var weight = (vol.text).toString()
                                    var psac = (hsnT.text).toString()

                                    if (stockhand.text.toString().isNotEmpty()) {
                                        var stockonhand = (stockhand.text).toString()
                                        stkhand = stockonhand
                                    } else {

                                        stkhand = "0"
                                    }

                                    var minstock = (minstock.text).toString()
                                    var maxstock = (maxstock.text).toString()
                                    var price = (price.text).toString()
                                    var taxable =Tax.isChecked.toString()
                                    var igst = (intax.text).toString()
                                    var cgst = (Ctax.text).toString()
                                    var sgst = (Stax.text).toString()
                                    var cess = (cess.text).toString()
                                    var taxtotal = (taxtot.text).toString()
                                    var cessval = (css.text).toString()
                                    var currency = currency.isChecked.toString()
                                    var percentage = percentage.isChecked.toString()
                                    var percentagevalue = (per.text).toString()
                                    var product_dec = (scroll2_descrip.text).toString()
                                    var mrP = (grosstot.text).toString()
                                    var cate = cate.selectedItem.toString()
                                    var manufacture = manu.selectedItem.toString()
                                    var ut = unitspinner.selectedItem.toString()
                                    var consold = paybonus.isChecked.toString()
                                    var comm = payemp.isChecked.toString()
                                    var statuss = (state.text).toString()


                                    var ret = "false"
                                    var bskbr = "false"
                                    var returnables="false"
                                    var retday=""

                                    val img1n = img1n
                                    val img2n = img2n
                                    val img3n = img3n
                                    val img4n = img4n
                                    val img5n = img5n
                                    val img1url = img1url
                                    val img2url = img2url
                                    val img3url = img3url
                                    val img4url = img4url
                                    val img5url = img5url

                                    //val desc = (descrip.text).toString()

                                    val builder = android.app.AlertDialog.Builder(this@Attachments_Activity)
                                    with(builder) {
                                        setTitle("Confirm?")
                                        setMessage("Are you sure want to disable?")
                                        setPositiveButton("Yes") { dialog, whichButton ->
                                            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE);
                                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                            pDialogs!!.setTitleText("Disabling...");
                                            pDialogs!!.setCancelable(false);
                                            pDialogs!!.show();
                                            state.setText("Disable")
                                            var status = (state.text).toString()

                                            val map = mutableMapOf<String, Any?>()
                                            map.put("status", status)
                                            db.collection("product").document(id.text.toString())
                                                    .update(map)
                                                    .addOnSuccessListener {
                                                        val isInserted = myDb1.updatedata(npid, pid, pname, bcode, pdes, weight, psac, cate,
                                                                manufacture, ut, minstock, price, maxstock, consold, comm, taxable, igst, cgst,
                                                                sgst, cess, taxtotal, cessval, mrP, currency, status, percentage, percentagevalue,
                                                                product_dec, stkhand, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                                img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                                img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys, ret, bskbr, protypesave, returnables, retday,makeupitemstr)

                                                        if (isInserted == true) {
                                                        } else {
                                                        }
                                                        try {
                                                            pDialogs!!.dismiss()
                                                        } catch (e: Exception) {

                                                        }
                                                    }
                                            pDialogs!!.dismiss()
                                            Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()
                                            val data = Intent(applicationContext,Main_makeup::class.java)
                                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                            startActivity(data)
                                            finish()
                                                    }

                                                .setNegativeButton("No") { dialog, whichButton ->


                                                    dialog.dismiss()
                                                }
                                        val dialog = builder.create()

                                        dialog.show()
                                    }

                                } else if (net_status() == false) {
                                    Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                                }



                                true
                            }
                            popup.show()
                        }
                    }
                } else if (delete == "false") {
                    popup("Disable or Enable")
                }

            }
            else if(rentalchk.isChecked==false&&retailchk.isChecked==false){
                disable.visibility=View.GONE
            }
        }



        //--------------------------------SAVE ACTION---------------------------------//


        save.setOnClickListener {
            println("save clicked " + newid.text)
            if ((newid.text.isNotEmpty()) && (net_status() == true)) {
                if (scroll2_fixed_price.text.isEmpty() || scroll2_price_from.text.isEmpty() || scroll2_price_to.text.isEmpty()) {
                    if (scroll2_fixed.isChecked == true) {
                        if (scroll2_fixed_price.text.isEmpty()) {

                        }
                    }
                    if (scroll2_from.isChecked == true) {
                        if (scroll2_price_from.text.isEmpty()) {

                        }
                        if (scroll2_price_to.text.isEmpty()) {

                        }
                    }
                }
                if (sname.text.isEmpty() || price.text.isEmpty()) {
                    println("gender " + scroll2_gender.selectedItemPosition.toString())
                    if (scroll2_gender.selectedItemPosition == 0) {

                    }
                    if (scroll2_category.selectedItemPosition == 0) {

                    }
                    if (scroll2_sub_category.selectedItemPosition == 0) {

                    }
                    if (sname.text.isEmpty()) {
                        sname_error.visibility = View.VISIBLE


                    }
                    if (price.text.isEmpty()) {
                        price_error.visibility = View.VISIBLE

                    }
                     if(retailchk.isChecked==false&&rentalchk.isChecked==false){
                         retailerr.visibility=View.VISIBLE
                        Toast.makeText(applicationContext,"Please check retail or rental",Toast.LENGTH_SHORT).show()
                    }
                    println("main " + scroll2_category.selectedItemPosition.toString())
                    println("sub " + scroll2_sub_category.selectedItemPosition.toString())
                    Toast.makeText(this, "please fill required fields!", Toast.LENGTH_LONG).show()
                } else if (sname.text.isNotEmpty() && price.text.isNotEmpty()&&(retailchk.isChecked==true||rentalchk.isChecked==true)) {

                    if (scroll2_fixed_price.text.isEmpty() || scroll2_price_from.text.isEmpty() || scroll2_price_to.text.isEmpty()) {
                        if (scroll2_fixed.isChecked == true) {
                            if (scroll2_fixed_price.text.isEmpty()) {

                            }
                        }
                        if (scroll2_from.isChecked == true) {
                            if (scroll2_price_from.text.isEmpty()) {

                            }
                            if (scroll2_price_to.text.isEmpty()) {

                            }
                        }
                    }



                    if ((newid.text.isNotEmpty() && id.text.isEmpty())&&(net_status()==true)) {


                        try {
                            if(scroll2_price_to.text.toString().isNotEmpty()&&scroll2_price_from.text.toString().isNotEmpty()) {
                                if (scroll2_price_to.text.toString().toFloat() <= scroll2_price_from.text.toString().toFloat()) {
                                    poplow()
                                } else {
                                    save.isEnabled = false
                                    save_progress.visibility = View.VISIBLE


                                    if(retailchk.isChecked==true&&rentalchk.isChecked==true){
                                        pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                        pDialogs!!.setTitleText("Saving...")
                                        pDialogs!!.setCancelable(false)
                                        pDialogs!!.show();
                                        bothcome="true"
                                        onStarClicked1pro()
                                        onStarClicked1()

                                    }
                                    else if(retailchk.isChecked==false&&rentalchk.isChecked==true){
                                        pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                        pDialogs!!.setTitleText("Saving...")
                                        pDialogs!!.setCancelable(false)
                                        pDialogs!!.show();
                                        onStarClicked1()
                                    }
                                    else if(retailchk.isChecked==true&&rentalchk.isChecked==false){
                                        pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                        pDialogs!!.setTitleText("Saving...")
                                        pDialogs!!.setCancelable(false)
                                        pDialogs!!.show();
                                        onStarClicked1pro()

                                    }
                                    else if(retailchk.isChecked==false&&rentalchk.isChecked==false){
                                        Toast.makeText(applicationContext,"Please check retail or rental",Toast.LENGTH_SHORT).show()
                                    }

                                }
                            }
                            else{
                                save.isEnabled = false
                                save_progress.visibility = android.view.View.VISIBLE
                                if(retailchk.isChecked==true&&rentalchk.isChecked==true){
                                    pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                    pDialogs!!.setTitleText("Saving...")
                                    pDialogs!!.setCancelable(false)
                                    pDialogs!!.show();
                                    onStarClicked1pro()
                                    onStarClicked1()

                                }
                                else if(retailchk.isChecked==false&&rentalchk.isChecked==true){
                                    pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                    pDialogs!!.setTitleText("Saving...")
                                    pDialogs!!.setCancelable(false)
                                    pDialogs!!.show();
                                    onStarClicked1()
                                }
                                else if(retailchk.isChecked==true&&rentalchk.isChecked==false){
                                    pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                    pDialogs!!.setTitleText("Saving...")
                                    pDialogs!!.setCancelable(false)
                                    pDialogs!!.show();
                                    onStarClicked1pro()

                                }
                                else if(retailchk.isChecked==false&&rentalchk.isChecked==false){
                                    Toast.makeText(applicationContext,"Please check retail or rental",Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        catch (e:Exception){

                        }




                    } else {
                        Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()

                        println("scroll2_price_to.text" + scroll2_price_to.text)
                    }


                } else {
                    Toast.makeText(this@Attachments_Activity, "please fill required fields!", Toast.LENGTH_LONG).show()
                    println("textView1.text.isNotEmpty()&&textView6.text.isNotEmpty()&&scroll2_gender.selectedItemPosition!=0&&scroll2_category.selectedItemPosition!=0&&scroll2_sub_category.selectedItemPosition!=0" + sname.text + "  " + price.text + "  " + scroll2_gender.selectedItemPosition + "  " + scroll2_category.selectedItemPosition + "  " + scroll2_sub_category.selectedItemPosition)
                }
            } else if ((id.text.isNotEmpty()) && (net_status() == true)) {

                try {
                    if (scroll2_category.selectedItemPosition==0) {
                        subcatvaldup = ""

                    } else if ((scroll2_category.selectedItemPosition!=0)&&(scroll2_sub_category.selectedItemPosition!=0)) {
                        subcatvaldup = scroll2_sub_category.selectedItem.toString()
                    }
                }
                catch (e:Exception){

                }
                if(((img1url != f1edit) || (img2url != s1edit) || (img3url != t1edit) || (img4url != fo1edit) || (img5url != fif1edit))){
                    println("ONBACK URL1 EDIT NOT EQUAl"+img1url)
                    listenersave = "change"
                    commonlisteners = "change"
                }
                 if((retailchkalready=="true"&&retailchk.isChecked==false)||(rentalchkalready=="true"&&rentalchk.isChecked==false)){
                    listenersave = "change"
                    commonlisteners = "change"
                }

                if(rentalchk.isChecked==true&&retailchk.isChecked==true) {
                    if ((snamevalidate != sname.text.toString()) || (sdurvalidate != sdur.text.toString()) || (hsnTvalidate != hsnT.text.toString())
                            || (hsndesvalidate != hsndes.text.toString()) || (pricevalidate != price.text.toString()) || (intaxvalidate != intax.text.toString()) ||
                            (gendervalidate != scroll2_gender.selectedItem.toString()) || (maincatvalidate != scroll2_category.selectedItem.toString()) || (subcatvalidate != scroll2_sub_category.selectedItem.toString())
                            || (cessvalidate != cess.text.toString()) || (pervalidate != per.text.toString()) || (payempvalidate != payemp.isChecked.toString()) || (descvalidate != scroll2_descrip.text.toString()) ||
                            (paybonusvalidate != paybonus.isChecked.toString()) || (scroll2_fixed_pricevalidate != scroll2_fixed_price.text.toString())
                            || (scroll2_price_fromvalidate != scroll2_price_from.text.toString()) || (scroll2_price_tovalidate != scroll2_price_to.text.toString())) {

                        listenersave = "change"
                        println("ONBACK URL1 NOT EQUAL" + img1url)

                    }

                    if ((pnamevalidate != sname.text.toString()) || (volvalidate != vol.text.toString()) || (bcodeidvalidate != bcodeid.text.toString()) ||
                            (hscvalidate != hsnT.text.toString()) || (hscdesvalidate != hsndes.text.toString()) || (maincatvalidatepro != cate.selectedItem.toString()) ||
                            (subcatvalidatepro != manu.selectedItem.toString()) || (listvalidate != unitspinner.selectedItem.toString()) || (pricevalidate != price.text.toString())
                            || (taxcheckvalidate != Tax.isChecked.toString()) || (intgstvalidate != intax.text.toString()) || (cessvaluevalidate != cess.text.toString())
                            || (checkcommisionvalidate != payemp.isChecked.toString()) || (returnablevalidate != "false") || (percentagevalvalidate != per.text.toString()) || (maxstockvalidate != maxstock.text.toString())
                            || (minstockvalidate != minstock.text.toString()) || (des_boxvalidate != scroll2_descrip.text.toString()) || (stockhandvalidate != stockhand.text.toString())) {

                        commonlisteners = "change"


                    }
                }
                else if(retailchk.isChecked==true&&rentalchk.isChecked==false){
                    if ((pnamevalidate != sname.text.toString()) || (volvalidate != vol.text.toString()) || (bcodeidvalidate != bcodeid.text.toString()) ||
                            (hscvalidate != hsnT.text.toString()) || (hscdesvalidate != hsndes.text.toString()) || (maincatvalidatepro != cate.selectedItem.toString()) ||
                            (subcatvalidatepro != manu.selectedItem.toString()) || (listvalidate != unitspinner.selectedItem.toString()) || (pricevalidate != price.text.toString())
                            || (taxcheckvalidate != Tax.isChecked.toString()) || (intgstvalidate != intax.text.toString()) || (cessvaluevalidate != cess.text.toString())
                            || (checkcommisionvalidate != payemp.isChecked.toString()) || (returnablevalidate != "false") || (percentagevalvalidate != per.text.toString()) || (maxstockvalidate != maxstock.text.toString())
                            || (minstockvalidate != minstock.text.toString()) || (des_boxvalidate != scroll2_descrip.text.toString()) || (stockhandvalidate != stockhand.text.toString())) {

                        commonlisteners = "change"


                    }
                }
                else if(retailchk.isChecked==false&&rentalchk.isChecked==true){
                    if ((snamevalidate != sname.text.toString()) || (sdurvalidate != sdur.text.toString()) || (hsnTvalidate != hsnT.text.toString())
                            || (hsndesvalidate != hsndes.text.toString()) || (pricevalidate != price.text.toString()) || (intaxvalidate != intax.text.toString()) ||
                            (gendervalidate != scroll2_gender.selectedItem.toString()) || (maincatvalidate != scroll2_category.selectedItem.toString()) || (subcatvalidate != scroll2_sub_category.selectedItem.toString())
                            || (cessvalidate != cess.text.toString()) || (pervalidate != per.text.toString()) || (payempvalidate != payemp.isChecked.toString()) || (descvalidate != scroll2_descrip.text.toString()) ||
                            (paybonusvalidate != paybonus.isChecked.toString()) || (scroll2_fixed_pricevalidate != scroll2_fixed_price.text.toString())
                            || (scroll2_price_fromvalidate != scroll2_price_from.text.toString()) || (scroll2_price_tovalidate != scroll2_price_to.text.toString())) {

                        listenersave = "change"
                        println("ONBACK URL1 NOT EQUAL" + img1url)

                    }
                }







                println("UPDATE")




                if((id.text.isNotEmpty())&&(net_status()==true)&&((listenersave=="change")||( commonlisteners == "change"))){
                    println("SAVE CLICK LISTENER SAVE"+listenersave)
                    try {
                        if(scroll2_price_to.text.toString().isNotEmpty()&&scroll2_price_from.text.toString().isNotEmpty()) {
                            if (scroll2_price_to.text.toString().toFloat() <= scroll2_price_from.text.toString().toFloat()) {
                                poplow()
                            } else {
                                if(retailchk.isChecked==true&&rentalchk.isChecked==true){
                                    bothcome="true"
                                    savepopup()
                                    save()

                                }
                                else if(retailchk.isChecked==false&&rentalchk.isChecked==true){
                                    if(retailchkalready=="true"){
                                        save_progress.visibility=View.VISIBLE
                                        db.collection("product").document(id.text.toString())
                                                .delete()
                                                .addOnCompleteListener {
                                                    myDb1.deleteData(id.text.toString())
                                                    save()
                                                }
                                    }
                                    else{
                                        save()
                                    }

                                }
                                else if(retailchk.isChecked==true&&rentalchk.isChecked==false){
                                    if(rentalchkalready=="true"){
                                        save_progress.visibility=View.VISIBLE
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .delete()
                                                .addOnCompleteListener {
                                                    myDb.deleteData(id.text.toString())

                                                    savepopup()
                                                }
                                    }
                                    else{
                                        savepopup()

                                    }


                                }
                                else if(retailchk.isChecked==false&&rentalchk.isChecked==false){
                                    Toast.makeText(applicationContext,"Please check retail or rental",Toast.LENGTH_SHORT).show()
                                }

                            }
                        }
                        else{
                            if(retailchk.isChecked==true&&rentalchk.isChecked==true){
                                bothcome="true"
                                savepopup()
                                save()

                            }
                            else if(retailchk.isChecked==false&&rentalchk.isChecked==true){
                                if(retailchkalready=="true"){
                                    save_progress.visibility=View.VISIBLE
                                    db.collection("product").document(id.text.toString())
                                            .delete()
                                            .addOnCompleteListener {
                                                myDb1.deleteData(id.text.toString())
                                                save()
                                            }
                                }
                                else{
                                    save()
                                }

                            }
                            else if(retailchk.isChecked==true&&rentalchk.isChecked==false){

                                if(rentalchkalready=="true"){
                                    save_progress.visibility=View.VISIBLE
                                    db.collection("${branchky}_service").document(id.text.toString())
                                            .delete()
                                            .addOnCompleteListener {
                                                myDb.deleteData(id.text.toString())
                                                savepopup()
                                            }
                                }
                                else{
                                    savepopup()

                                }

                            }
                            else if(retailchk.isChecked==false&&rentalchk.isChecked==false){
                                Toast.makeText(applicationContext,"Please check retail or rental",Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                    catch (e:Exception){
                    }

                }
                else if((id.text.isNotEmpty())&&((listenersave.isEmpty())&&(commonlisteners.isEmpty()))){

                    Toast.makeText(this@Attachments_Activity, "Nothing happened for save", Toast.LENGTH_LONG).show()

                }


            } else {
                Toast.makeText(this@Attachments_Activity, "No internet connection", Toast.LENGTH_LONG).show()

            }

        }




        // If imagelinks are not empty then add image links to 'filemaps' array for slider view.
        //Image links from local storage or online db

        if (id.text.isNotEmpty()) {
            val getone = myDb.getOne(id.text.toString())
            if (getone.moveToNext()) {
                sl_title.setText(getone.getString(1).toString())
            }
        }
        if (img1url.isNullOrEmpty() == false || img2url.isNullOrEmpty() == false || img3url.isNullOrEmpty() == false || img4url.isNullOrEmpty() == false || img5url.isNullOrEmpty() == false) {


            scrollpro.visibility = View.VISIBLE

            scroll2_preview_service_image2.visibility = View.VISIBLE
            scroll2_slider2.visibility = View.VISIBLE
            camback.visibility = View.GONE
            cam.visibility = View.GONE
            scroll2_gallery.visibility = View.VISIBLE
            if (img1url.isNullOrEmpty() == false) {
                img1url = img1url.toString()

            }
            if (img2url.isNullOrEmpty() == false) {
                img2url = img2url.toString()

            }
            if (img3url.isNullOrEmpty() == false) {
                img3url = img3url.toString()

            }
            if (img4url.isNullOrEmpty() == false) {
                img4url = img4url.toString()

            }
            if (img5url.isNullOrEmpty() == false) {
                img5url = img5url.toString()

            }
            if (img1n.isNullOrEmpty() == false) {
                img1n = img1n.toString()
                img1nhigh=img1nhigh.toString()

                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img1nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img1url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img1url)
                }



            }
            if (img2n.isNullOrEmpty() == false) {
                img2n = img2n.toString()
                img2nhigh=img2nhigh.toString()
                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img2nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img2url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img2url)
                }
            }
            if (img3n.isNullOrEmpty() == false) {
                img3n = img3n.toString()
                img3nhigh=img3nhigh.toString()

                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img3nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img3url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img3url)
                }
            }
            if (img4n.isNullOrEmpty() == false) {
                img4n = img4n.toString()
                img4nhigh=img4nhigh.toString()

                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img4nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img4url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img4url)
                }
            }
            if (img5n.isNullOrEmpty() == false) {
                img5n = img5n.toString()

                img5nhigh=img5nhigh.toString()
                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img5nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(img5url)
                    }
                }
                catch (e:Exception){
                    file_maps.add(img5url)
                }
            }
        } else {
            scroll2_slider2.visibility = View.GONE
            scroll2_preview_service_image2.visibility = View.GONE
            scroll2_slider.visibility = View.VISIBLE
            scroll2_preview_service_image.visibility = View.VISIBLE

            camback.visibility = View.VISIBLE
            cam.visibility = View.VISIBLE
            scroll2_gallery.visibility = View.GONE
        }
        if (paybonus.isEnabled == true) {
            if (paybonus.isChecked == true) {
                percentage.isEnabled = true
                currency.isEnabled = true
                per.isEnabled = true
                currency.setTextColor(Color.parseColor("#546e7a"))
                percentage.setTextColor(Color.parseColor("#546e7a"))
                per.setTextColor(Color.parseColor("#546e7a"))
            } else {
                percentage.isEnabled = false
                per.isEnabled = false
                currency.isEnabled = false
                currency.setTextColor(Color.parseColor("#85546e7a"))
                percentage.setTextColor(Color.parseColor("#85546e7a"))
                per.setTextColor(Color.parseColor("#85546e7a"))
            }
        }
        paybonus.setOnCheckedChangeListener { button, state ->
            if (paybonus.isEnabled == true) {
                if (state == true) {
                    percentage.isEnabled = true
                    currency.isEnabled = true
                    per.isEnabled = true
                    currency.setTextColor(Color.parseColor("#546e7a"))
                    percentage.setTextColor(Color.parseColor("#546e7a"))
                    per.setTextColor(Color.parseColor("#546e7a"))
                } else {
                    percentage.isEnabled = false
                    per.isEnabled = false
                    currency.isEnabled = false
                    currency.setTextColor(Color.parseColor("#85546e7a"))
                    percentage.setTextColor(Color.parseColor("#d3d3d3"))
                    per.setTextColor(Color.parseColor("#d3d3d3"))
                }
            }
        }
        currency.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                percentage.isChecked = false
                percentage.setTextColor(Color.parseColor("#d3d3d3"))
                per.setText("")
            } else if (state == false) {
                percentage.isChecked = true
                percentage.setTextColor(Color.parseColor("#546e7a"))
                per.setText("")
            }
        }
        percentage.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                currency.isChecked = false
                currency.setTextColor(Color.parseColor("#85546e7a"))
                per.setText("")
            } else if (state == false) {
                currency.isChecked = true
                currency.setTextColor(Color.parseColor("#546e7a"))
                per.setText("")
            }
        }

        per.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                var pri: Float
                if (currency.isChecked == true) {
                    if (s.isNotEmpty()) {
                        pri = s.toString().toFloat()
                        if (price.text.toString().isNotEmpty()) {
                            if ((pri > price.text.toString().toFloat())) {
                                per.isEnabled = false
                                val builder = AlertDialog.Builder(this@Attachments_Activity)
                                with(builder) {
                                    setTitle("Exceed")
                                    setMessage("Given value is higher than price.")
                                    builder.setCancelable(false)

                                    setPositiveButton("Ok") { dialog, whichButton ->
                                        per.isEnabled = true
                                        per.setText("")
                                        dialog.dismiss()
                                    }
                                    val dialog = builder.create()
                                    dialog.show()
                                }
                            }
                        } else {
                            val builder = AlertDialog.Builder(this@Attachments_Activity)
                            with(builder) {
                                setTitle("Alert")
                                setMessage("please fill price field before currency")
                                builder.setCancelable(false)

                                setPositiveButton("Ok") { dialog, whichButton ->
                                    per.isEnabled = true
                                    per.setText("")
                                    dialog.dismiss()
                                }
                                val dialog = builder.create()
                                dialog.show()
                            }
                        }
                    }
                } else if (percentage.isChecked == true) {
                    if (s.isNotEmpty()) {
                        pri = s.toString().toFloat()


                        if ((pri > 100)) {
                            per.isEnabled = false
                            val builder = AlertDialog.Builder(this@Attachments_Activity)
                            with(builder) {
                                setTitle("Exceed")
                                setMessage("Given percentage value is greater than 100.")
                                builder.setCancelable(false)

                                setPositiveButton("Ok") { dialog, whichButton ->
                                    per.setText("")
                                    per.isEnabled = true
                                    dialog.dismiss()
                                }
                                val dialog = builder.create()
                                dialog.show()
                            }
                        }


                    }

                }

            }
        })

        back.setOnClickListener {
            back.isEnabled = false
            onBackPressed()
            //finish()
        }
        //Tax Checkbox

        if (id.text.toString().isNotEmpty() && editclick == "clicked") {
            if (Tax.isChecked == true) {
                intax.isEnabled = true
                cess.isEnabled = true
                Ctax.isEnabled = false
                Stax.isEnabled = false
            } else {
                intax.isEnabled = false
                intax.setText("")
                cess.isEnabled = false
                cess.setText("")
                Ctax.isEnabled = false
                Ctax.setText("")
                Stax.isEnabled = false
                Stax.setText("")
                grosstot.setText(price.text.toString())

            }
        } else if (id.text.toString().isEmpty()) {
            if (Tax.isChecked == true) {
                intax.isEnabled = true
                cess.isEnabled = true
                Ctax.isEnabled = false
                Stax.isEnabled = false
            } else {
                intax.isEnabled = false
                intax.setText("")
                cess.isEnabled = false
                cess.setText("")
                Ctax.isEnabled = false
                Ctax.setText("")
                Stax.isEnabled = false
                Stax.setText("")


            }
        }

        Tax.setOnCheckedChangeListener { compoundButton, b ->
            if (id.text.toString().isNotEmpty() && editclick == "clicked") {

                if (Tax.isChecked == true) {
                    intax.isEnabled = true
                    cess.isEnabled = true
                    Ctax.isEnabled = false
                    Stax.isEnabled = false
                } else {
                    intax.isEnabled = false
                    intax.setText("")
                    cess.isEnabled = false
                    cess.setText("")
                    Ctax.isEnabled = false
                    Ctax.setText("")
                    Stax.isEnabled = false
                    Stax.setText("")
                    grosstot.setText(price.text.toString())
                }
            } else if (id.text.toString().isEmpty()) {
                if (Tax.isChecked == true) {
                    intax.isEnabled = true
                    cess.isEnabled = true
                    Ctax.isEnabled = false
                    Stax.isEnabled = false
                } else {
                    intax.isEnabled = false
                    intax.setText("")
                    cess.isEnabled = false
                    cess.setText("")
                    Ctax.isEnabled = false
                    Ctax.setText("")
                    Stax.isEnabled = false
                    Stax.setText("")
                    grosstot.setText(price.text.toString())
                }
            }
        }
        //Navigate to multi images add activity - AddImages_Accessories


        scroll2_gallery.setOnClickListener {
            scroll2_slider.removeAllSliders()
            scroll2_gallery.isEnabled = false
            val b = Intent(applicationContext, AddImages_Accessories::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("add", add)
            b.putExtra("edit", edite)
            b.putExtra("delete", delete)
            b.putExtra("keys",branchky)
            b.putExtra("f1", img1url)
            b.putExtra("fn1", img1n)
            b.putExtra("s1", img2url)
            b.putExtra("sn1", img2n)
            b.putExtra("t1", img3url)
            b.putExtra("tn1", img3n)
            b.putExtra("fo1", img4url)
            b.putExtra("fon1", img4n)
            b.putExtra("fif1", img5url)
            b.putExtra("fifn1", img5n)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high", img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high", img5nhigh)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("listenersave", listenersave)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)

            startActivityForResult(b, 0)
            scroll2_gallery.isEnabled = true
        }





        //Navigate to multi images add activity - AddImages_Accessories



        camback.setOnClickListener {
            camback.isEnabled = false
            val b = Intent(applicationContext, AddImages_Accessories::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("add", add)
            b.putExtra("edit", edite)
            b.putExtra("delete", delete)
            b.putExtra("keys",branchky)
            b.putExtra("f1", img1url)
            b.putExtra("fn1", img1n)
            b.putExtra("s1", img2url)
            b.putExtra("sn1", img2n)
            b.putExtra("t1", img3url)
            b.putExtra("tn1", img3n)
            b.putExtra("fo1", img4url)
            b.putExtra("fon1", img4n)
            b.putExtra("fif1", img5url)
            b.putExtra("fifn1", img5n)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("listenersave", listenersave)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high", img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high", img5nhigh)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)



            startActivityForResult(b, 0)
            camback.isEnabled = true
        }

        //Navigate to multi images add activity - AddImages_Accessories


        cam.setOnClickListener {
            cam.isEnabled = false
            val b = Intent(applicationContext, AddImages_Accessories::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("add", add)
            b.putExtra("edit", edite)
            b.putExtra("delete", delete)
            b.putExtra("keys",branchky)
            b.putExtra("f1", img1url)
            b.putExtra("fn1", img1n)
            b.putExtra("s1", img2url)
            b.putExtra("sn1", img2n)
            b.putExtra("t1", img3url)
            b.putExtra("tn1", img3n)
            b.putExtra("fo1", img4url)
            b.putExtra("fon1", img4n)
            b.putExtra("fif1", img5url)
            b.putExtra("fifn1", img5n)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("listenersave", listenersave)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)


            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high", img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high", img5nhigh)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)

            startActivityForResult(b, 0)
            cam.isEnabled = true
        }




        sname.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


                scroll2_preview_service_name.setText(pr)
                sname_error.visibility=View.INVISIBLE


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })


        sname.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->




        });


        sdur.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->


            if (sname.text.isNotEmpty()) {


                val dd = myDb.retrieves(sname.text.toString())
                try {
                    while (dd.moveToNext()) {
                        val snames = dd.getString(1)

                        if ((snames == sname.text.toString()) && (id.text.isEmpty())) {

                            val builder = AlertDialog.Builder(this@Attachments_Activity)
                            with(builder) {
                                setTitle("Already exist")
                                setMessage("Service name already exist!")
                                // Dialog
                                setPositiveButton("Ok") { dialog, whichButton ->
                                    sname.setText("")
                                    dialog.dismiss()

                                }

                                val dialog = builder.create()
                                dialog.show()
                            }

                        }

                    }
                }
                catch (e:Exception){


                }

                if (sname.text.toString().isEmpty()) {

                }
            }


            if ((!hasFocus)&&(sdur.text.isNotEmpty())) {
                if ((!sdur.text.toString().endsWith("mins") && (sdur.text.toString().isNotEmpty()))) {
                    var jj = sdur.text.toString()
                    sdur.setText("$jj mins")
                }
                // code to execute when EditText loses focus
            }

        });


        //During price edittext changelitener which calculates the price with gst and cess values

        price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


                if (pr.isNullOrEmpty()) {
                    price_error.visibility = View.VISIBLE

                } else {
                    price_error.visibility = View.GONE
                }
                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (pr.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (intax.text.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = intax.text.toString().replace("%", "").toFloat()
                }
                if (cess.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                Ctax.setText("$ans" + "%")
                Stax.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                taxtot.setText((String.format("%.2f", ttot)))

                //cess total
                val cesstot = (pri * ces) / 100
                css.setText((String.format("%.2f", cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                grosstot.setText((String.format("%.2f", g)))


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if (price.text.toString().isEmpty()) {
                    listenersave = ""
                }
            }
        })

               //During Intagrated Tax  edittext changelitener which calculates the price with gst and cess values

        intax.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {

                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (price.text.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = price.text.toString().toFloat()
                }
                if (ig.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = ig.toString().replace("%", "").toFloat()
                }
                if (cess.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                Ctax.setText("$ans" + "%")
                Stax.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                taxtot.setText((String.format("%.2f", ttot)))

                //cess total
                val cesstot = (pri * ces) / 100
                css.setText((String.format("%.2f", cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                grosstot.setText((String.format("%.2f", g)))


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {

                if (intax.text.toString().isEmpty()) {
                    listenersave = ""
                }

            }
        })

        //During cess edittext changelitener which calculates the price with gst and cess values

        cess.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {

                var pri: Float;
                var igst: Float;
                var ces: Float;
                if (price.text.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = price.text.toString().toFloat()
                }
                if (intax.text.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = intax.text.toString().replace("%", "").toFloat()
                }
                if (cess.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                Ctax.setText("$ans" + "%")
                Stax.setText("$ans" + "%")

                //tax total
                val ttot = (pri * igst) / 100
                taxtot.setText((String.format("%.2f", ttot)))

                //cess total
                val cesstot = (pri * ces) / 100
                css.setText((String.format("%.2f", cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                grosstot.setText((String.format("%.2f", g)))


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if (cess.text.toString().isEmpty()) {
                    listenersave = ""
                }
            }
        })
        //scroll2_page items
        if (gender.isNullOrEmpty() == false) gender = gender.toString()
        if (maincat.isNullOrEmpty() == false) maincat = maincat.toString()
        if (subcat.isNullOrEmpty() == false) subcat = subcat.toString()
        if (des.isNullOrEmpty() == false) des = des.toString()
        if (fix.isNullOrEmpty() == false) fix = fix.toString()
        if (from.isNullOrEmpty() == false) from = from.toString()
        if (to.isNullOrEmpty() == false) to = to.toString()
        //sname addTextChangedListener
        textInputLayout.editText!!.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(p0: CharSequence?, start: Int, before: Int, count: Int) {

                if (id.text.isNotEmpty()) {

                }
            }

            override fun afterTextChanged(p0: Editable?) {

            }

            override fun beforeTextChanged(p0: CharSequence?, start: Int, before: Int, count: Int) {

            }
        })
        fix_check = intent.getBooleanExtra("fix_check", true).toString()
        from_check = intent.getBooleanExtra("from_check", false).toString()


        vol.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
/*
                if(id.text.isNotEmpty()){
                    cntvol+=1
                }


                if((cntvol>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"

                if((cntvol==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


            }

            override fun afterTextChanged(arg0: Editable) {
                if(vol.text.toString().isEmpty()){
                    commonlisteners=""
                }
            }

        })

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERMISSION_REQUEST)
        }


        bcodeid.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->

            if((bcodeid.length() == 0)&&(bcodeid.isFocused==true))  {
                val b = Intent(this@Attachments_Activity, ScanProductActivity::class.java)
                /*var npid = id.text.toString()
                var pids = (pid.text).toString()
                var pname = (pname.text).toString()
                var bcode = (bcodeid.text).toString()
                var pdes = (hscdes.text).toString()

                var weight = (vol.text).toString()
                var psac = (hsc.text).toString()
                if(stockhand.text.toString().isNotEmpty()) {
                    var stockonhand = (stockhand.text).toString()
                    stkhand=stockonhand
                }
                else{

                    stkhand="0"
                }


                var minstock = (minstock.text).toString()
                var maxstock = (maxstock.text).toString()
                var price = (price.text).toString()
                var taxable = taxcheck.isChecked.toString()
                var igst = (intgst.text).toString()
                var cgst = (centgst.text).toString()
                var sgst = (stategst.text).toString()
                var cess = (cess.text).toString()
                var taxtotal = (taxtot.text).toString()
                var cessval = (cessvalue.text).toString()
                var currency = currencyradio.isChecked.toString()
                var percentage = percenradio.isChecked.toString()
                var percentagevalue = (percentageval.text).toString()
                var product_dec = (des_box.text).toString()
                var mrP = (mrp.text).toString()
                var cate = cate.selectedItem.toString()
                var manufacture = manu.selectedItem.toString()
                var ut = unitspinner.selectedItem.toString()
                var consold = checkbonus.isChecked.toString()
                var comm = checkcommision.isChecked.toString()
                var status=(disable.text).toString()
                var idss=idsmy.text.toString()
                val img1n=fn1
                val img2n=sn1
                val img3n=tn1
                val img4n=fon1
                val img5n=fifn1
                val img1url=f1
                val img2url=s1
                val img3url=t1
                val img4url=fo1
                val img5url=fif1
                val orikys=branchky
                b.putExtra("npid",npid)
                b.putExtra("pids",pids)
                b.putExtra("pname",pname)
                b.putExtra("bcode",bcode)
                b.putExtra("pdes",pdes)
                b.putExtra("weight",weight)
                b.putExtra("psac",psac)
                b.putExtra("stkhand",stkhand)
                b.putExtra("minstock",minstock)
                b.putExtra("maxstock",maxstock)
                b.putExtra("price",price)
                b.putExtra("taxable",taxable)
                b.putExtra("igst",igst)
                b.putExtra("cgst",cgst)
                b.putExtra("sgst",sgst)
                b.putExtra("cess",cess)
                b.putExtra("taxtotal",taxtotal)
                b.putExtra("cessval",cessval)
                b.putExtra("currency",currency)
                b.putExtra("percentage",percentage)
                b.putExtra("percentagevalue",percentagevalue)
                b.putExtra("product_dec",product_dec)
                b.putExtra("mrP",mrP)
                b.putExtra("cate",cate)
                b.putExtra("manufacture",manufacture)
                b.putExtra("ut",ut)
                b.putExtra("consold",consold)
                b.putExtra("comm",comm)
                b.putExtra("status",status)
                b.putExtra("img1n",img1n)
                b.putExtra("img2n",img2n)
                b.putExtra("img3n",img3n)
                b.putExtra("img4n",img4n)
                b.putExtra("img5n",img5n)
                b.putExtra("img1url",img1url)
                b.putExtra("img2url",img2url)
                b.putExtra("img3url",img3url)
                b.putExtra("img4url",img4url)
                b.putExtra("img5url",img5url)
                b.putExtra("orikys",orikys)
                b.putExtra("idss",idss)*/

                startActivityForResult(b, 1)

            } else {


            }

        })
        bcodeid.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {
                if((bcodeid.length() == 0)&&(bcodeid.isFocused==true))
                {

                    val b = Intent(this@Attachments_Activity, ScanProductActivity::class.java)
                    /*var npid = id.text.toString()
                    var pids = (pid.text).toString()
                    var pname = (pname.text).toString()
                    var bcode = (bcodeid.text).toString()
                    var pdes = (hscdes.text).toString()

                    var weight = (vol.text).toString()
                    var psac = (hsc.text).toString()
                    if(stockhand.text.toString().isNotEmpty()) {
                        var stockonhand = (stockhand.text).toString()
                        stkhand=stockonhand
                    }
                    else{

                        stkhand="0"
                    }


                    var minstock = (minstock.text).toString()
                    var maxstock = (maxstock.text).toString()
                    var price = (price.text).toString()
                    var taxable = taxcheck.isChecked.toString()
                    var igst = (intgst.text).toString()
                    var cgst = (centgst.text).toString()
                    var sgst = (stategst.text).toString()
                    var cess = (cess.text).toString()
                    var taxtotal = (taxtot.text).toString()
                    var cessval = (cessvalue.text).toString()
                    var currency = currencyradio.isChecked.toString()
                    var percentage = percenradio.isChecked.toString()
                    var percentagevalue = (percentageval.text).toString()
                    var product_dec = (des_box.text).toString()
                    var mrP = (mrp.text).toString()
                    var cate = cate.selectedItem.toString()
                    var manufacture = manu.selectedItem.toString()
                    var ut = unitspinner.selectedItem.toString()
                    var consold = checkbonus.isChecked.toString()
                    var comm = checkcommision.isChecked.toString()
                    var status=(disable.text).toString()
                    var idss=idsmy.text.toString()
                    val img1n=fn1
                    val img2n=sn1
                    val img3n=tn1
                    val img4n=fon1
                    val img5n=fifn1
                    val img1url=f1
                    val img2url=s1
                    val img3url=t1
                    val img4url=fo1
                    val img5url=fif1
                    val orikys=branchky
                    b.putExtra("npid",npid)
                    b.putExtra("pids",pids)
                    b.putExtra("pname",pname)
                    b.putExtra("bcode",bcode)
                    b.putExtra("pdes",pdes)
                    b.putExtra("weight",weight)
                    b.putExtra("psac",psac)
                    b.putExtra("stkhand",stkhand)
                    b.putExtra("minstock",minstock)
                    b.putExtra("maxstock",maxstock)
                    b.putExtra("price",price)
                    b.putExtra("taxable",taxable)
                    b.putExtra("igst",igst)
                    b.putExtra("cgst",cgst)
                    b.putExtra("sgst",sgst)
                    b.putExtra("cess",cess)
                    b.putExtra("taxtotal",taxtotal)
                    b.putExtra("cessval",cessval)
                    b.putExtra("currency",currency)
                    b.putExtra("percentage",percentage)
                    b.putExtra("percentagevalue",percentagevalue)
                    b.putExtra("product_dec",product_dec)
                    b.putExtra("mrP",mrP)
                    b.putExtra("cate",cate)
                    b.putExtra("manufacture",manufacture)
                    b.putExtra("ut",ut)
                    b.putExtra("consold",consold)
                    b.putExtra("comm",comm)
                    b.putExtra("status",status)
                    b.putExtra("img1n",img1n)
                    b.putExtra("img2n",img2n)
                    b.putExtra("img3n",img3n)
                    b.putExtra("img4n",img4n)
                    b.putExtra("img5n",img5n)
                    b.putExtra("img1url",img1url)
                    b.putExtra("img2url",img2url)
                    b.putExtra("img3url",img3url)
                    b.putExtra("img4url",img4url)
                    b.putExtra("img5url",img5url)
                    b.putExtra("orikys",orikys)
                    b.putExtra("idss",idss)*/
                    startActivityForResult(b, 1)

                }
                /*   if(bcodeid.text.toString().isEmpty()){
                       commonlisteners=""
                   }
                   if(bcodeid.text.toString().isNotEmpty()){
                       commonlisteners="change"
                   }*/

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {

            }
        })

    }



    //loadim() func is used to load all image links to slider view

    fun loadim() {
        scrollpro.visibility = View.GONE
        if (file_maps.isNotEmpty()) {


            for (r in 0 until file_maps.size) {
                try {
                    val textSliderView = TextSliderView(this)
                    // initialize a SliderLayout
                    Log.d("file_maps", "r  " + file_maps[r])
                    textSliderView
                            //.description(name)
                            .image(file_maps[r])
                            .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                            .setOnSliderClickListener {

                                if(net_status()==true){


                                    val b = Intent(applicationContext, AddImages_Accessories::class.java)
                                    b.putExtra("id", id.text.toString())
                                    b.putExtra("add", add)
                                    b.putExtra("edit", edite)
                                    b.putExtra("delete", delete)
                                    b.putExtra("keys",branchky)
                                    b.putExtra("f1", img1url)
                                    b.putExtra("fn1", img1n)
                                    b.putExtra("s1", img2url)
                                    b.putExtra("sn1", img2n)
                                    b.putExtra("t1", img3url)
                                    b.putExtra("tn1", img3n)
                                    b.putExtra("fo1", img4url)
                                    b.putExtra("fon1", img4n)
                                    b.putExtra("fif1", img5url)
                                    b.putExtra("fifn1", img5n)

                                    b.putExtra("f1high", img1urlhigh)
                                    b.putExtra("fn1high", img1nhigh)
                                    b.putExtra("s1high", img2urlhigh)
                                    b.putExtra("sn1high", img2nhigh)
                                    b.putExtra("t1high", img3urlhigh)
                                    b.putExtra("tn1high", img3nhigh)
                                    b.putExtra("fo1high", img4urlhigh)
                                    b.putExtra("fon1high", img4nhigh)
                                    b.putExtra("fif1high", img5urlhigh)
                                    b.putExtra("fifn1high", img5nhigh)
                                    b.putExtra("f1edithigh", f1edithigh)
                                    b.putExtra("fn1edithigh", fn1edithigh)
                                    b.putExtra("s1edithigh", s1edithigh)
                                    b.putExtra("sn1edithigh", sn1edithigh)
                                    b.putExtra("t1edithigh", t1edithigh)
                                    b.putExtra("tn1edithigh", tn1edithigh)
                                    b.putExtra("fo1edithigh", fo1edithigh)
                                    b.putExtra("fon1edithigh", fon1edithigh)
                                    b.putExtra("fif1edithigh", fif1edithigh)
                                    b.putExtra("fifn1edithigh", fifn1edithigh)
                                    b.putExtra("f1edit", f1edit)
                                    b.putExtra("fn1edit", fn1edit)
                                    b.putExtra("s1edit", s1edit)
                                    b.putExtra("sn1edit", sn1edit)
                                    b.putExtra("t1edit", t1edit)
                                    b.putExtra("tn1edit", tn1edit)
                                    b.putExtra("fo1edit", fo1edit)
                                    b.putExtra("fon1edit", fon1edit)
                                    b.putExtra("fif1edit", fif1edit)
                                    b.putExtra("fifn1edit", fifn1edit)
                                    startActivityForResult(b, 0)
                                    scroll2_slider.isEnabled = true
                                }
                                else{
                                    Toast.makeText(applicationContext,"You're offline.",Toast.LENGTH_SHORT).show()
                                }
                            }
                    scroll2_slider2.addSlider(textSliderView)
                } catch (e: Exception) {

                }
            }
            scroll2_slider2.setPresetTransformer(SliderLayout.Transformer.Default)
            scroll2_slider2.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
            scroll2_slider2.setCustomAnimation(DescriptionAnimation())
            scroll2_slider2.setDuration(5000)

            //scroll2_preview_service_image2
            try {
                val newurl = URL(file_maps[0]).openStream()
                val img = BitmapFactory.decodeStream(newurl)
                scroll2_preview_service_image2.setImageBitmap(img)
            } catch (e: Exception) {

            }
        }
    }


    //Receive image links from multi images activity and load into slider.


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0) {

            if (resultCode == Activity.RESULT_OK) {

                scroll2_slider.removeAllSliders()
                scroll2_slider2.removeAllSliders()

                imcome = "yes"

                scroll2_preview_service_image2.visibility = View.GONE
                scroll2_slider2.visibility = View.GONE
                scroll2_slider3.visibility = View.GONE
                scroll2_slider.visibility = View.VISIBLE
                scroll2_preview_service_image.visibility = View.VISIBLE
                val f = data!!.getStringExtra("f");
                val fn = data!!.getStringExtra("fn");
                val s = data!!.getStringExtra("s");
                val sn = data!!.getStringExtra("sn");
                val t = data!!.getStringExtra("t");
                val tn = data!!.getStringExtra("tn");
                val fo = data!!.getStringExtra("fo");
                val fon = data!!.getStringExtra("fon");
                val fif = data!!.getStringExtra("fif");
                val fifn = data!!.getStringExtra("fifn");


                val fedit = data!!.getStringExtra("fedit")
                val fnedit = data!!.getStringExtra("fnedit")
                val sedit = data!!.getStringExtra("sedit")
                val snedit = data!!.getStringExtra("snedit")
                val tedit = data!!.getStringExtra("tedit")
                val tnedit = data!!.getStringExtra("tnedit")
                val foedit = data!!.getStringExtra("foedit")
                val fonedit = data!!.getStringExtra("fonedit")
                val fifedit = data!!.getStringExtra("fifedit")
                val fifnedit = data!!.getStringExtra("fifnedit");

                try {
                    mresultsarr = data!!.getStringArrayListExtra("mResult")
                } catch (e: Exception) {

                }



                try {
                    cacnm1 = data!!.getStringExtra("cacnm1")
                } catch (e: Exception) {

                }
                try {
                    listenersave = data!!.getStringExtra("listenersave")
                } catch (e: Exception) {

                }

                val fhigh = data!!.getStringExtra("fhigh");
                val fnhigh = data!!.getStringExtra("fnhigh");
                val shigh = data!!.getStringExtra("shigh");
                val snhigh = data!!.getStringExtra("snhigh");
                val thigh = data!!.getStringExtra("thigh");
                val tnhigh = data!!.getStringExtra("tnhigh");
                val fohigh = data!!.getStringExtra("fohigh");
                val fonhigh = data!!.getStringExtra("fonhigh");
                val fifhigh = data!!.getStringExtra("fifhigh");
                val fifnhigh = data!!.getStringExtra("fifnhigh");


                println("fhigh" + fhigh)
                println("shigh" + shigh)
                println("thigh" + thigh)
                println("fohigh" + fohigh)
                println("fifhigh" + fifhigh)


                println("fnhigh" + fnhigh)
                println("snhigh" + snhigh)
                println("tnhigh" + tnhigh)
                println("fonhigh" + fonhigh)
                println("fifnhigh" + fifnhigh)
                if (fhigh.isNotEmpty()) {


                    img1urlhigh = fhigh
                    img1nhigh = fnhigh
                } else {
                    img1urlhigh = ""
                    img1nhigh = ""
                }
                if (shigh.isNotEmpty()) {


                    img2urlhigh = shigh
                    img2nhigh = snhigh
                } else {
                    img2urlhigh = ""
                    img2nhigh = ""
                }
                if (thigh.isNotEmpty()) {


                    img3urlhigh = thigh
                    img3nhigh = tnhigh
                } else {
                    img3urlhigh = ""
                    img3nhigh = ""
                }
                if (fohigh.isNotEmpty()) {


                    img4urlhigh = fohigh
                    img4nhigh = fonhigh
                } else {
                    img4urlhigh = ""
                    img4nhigh = ""
                }
                if (fifhigh.isNotEmpty()) {


                    img5urlhigh = fifhigh
                    img5nhigh = fifnhigh
                } else {

                    img5urlhigh = ""
                    img5nhigh = ""
                }


                val fedithigh = data!!.getStringExtra("fedithigh")
                val fnedithigh = data!!.getStringExtra("fnedithigh")
                val sedithigh = data!!.getStringExtra("sedithigh")
                val snedithigh = data!!.getStringExtra("snedithigh")
                val tedithigh = data!!.getStringExtra("tedithigh")
                val tnedithigh = data!!.getStringExtra("tnedithigh")
                val foedithigh = data!!.getStringExtra("foedithigh")
                val fonedithigh = data!!.getStringExtra("fonedithigh")
                val fifedithigh = data!!.getStringExtra("fifedithigh")
                val fifnedithigh = data!!.getStringExtra("fifnedithigh");

                if (fedithigh.isNotEmpty()) {


                    f1edithigh = fedithigh
                    fn1edithigh = fnedithigh


                } else {


                    f1edithigh = ""
                    fn1edithigh = ""
                }
                if (sedithigh.isNotEmpty()) {


                    s1edithigh = sedithigh
                    sn1edithigh = snedithigh

                } else {


                    s1edithigh = ""
                    sn1edithigh = ""
                }
                if (tedithigh.isNotEmpty()) {

                    t1edithigh = tedithigh
                    tn1edithigh = tnedithigh

                } else {

                    t1edithigh = ""
                    tn1edithigh = ""
                }
                if (foedithigh.isNotEmpty()) {
                    fo1edithigh = foedithigh
                    fon1edithigh = fonedithigh

                } else {

                    fo1edithigh = ""
                    fon1edithigh = ""
                }
                if (fifedithigh.isNotEmpty()) {

                    fif1edithigh = fifedithigh
                    fifn1edithigh = fifnedithigh

                } else {

                    fif1edithigh = ""
                    fifn1edithigh = ""
                }





                if (fedit.isNotEmpty()) {


                    f1edit = fedit
                    fn1edit = fnedit


                } else {


                    f1edit = ""
                    fn1edit = ""
                }
                if (sedit.isNotEmpty()) {


                    s1edit = sedit
                    sn1edit = snedit

                } else {


                    s1edit = ""
                    sn1edit = ""
                }
                if (tedit.isNotEmpty()) {

                    t1edit = tedit
                    tn1edit = tnedit

                } else {

                    t1edit = ""
                    tn1edit = ""
                }
                if (foedit.isNotEmpty()) {
                    fo1edit = foedit
                    fon1edit = fonedit

                } else {

                    fo1edit = ""
                    fon1edit = ""
                }
                if (fifedit.isNotEmpty()) {

                    fif1edit = fifedit
                    fifn1edit = fifnedit

                } else {

                    fif1edit = ""
                    fifn1edit = ""
                }


                val bitmapArray = ArrayList<String>()
                bitmapArray.clear()
                scrollpro.visibility = View.VISIBLE
                if (f.isNotEmpty() || s.isNotEmpty() || t.isNotEmpty() || fo.isNotEmpty() || fif.isNotEmpty()) {
                    camback.visibility = View.GONE
                    cam.visibility = View.GONE
                    scroll2_gallery.visibility = View.VISIBLE
                } else {
                    camback.visibility = View.VISIBLE
                    cam.visibility = View.VISIBLE
                    scroll2_gallery.visibility = View.GONE
                }

                if (f.isNotEmpty()) {
                    img1url = f
                    img1n = fn
                    if(img1nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img1nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img1url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img1url)
                        }
                    }
                    else{
                        d.add(f);bitmapArray.add(f)
                    }






                } else {
                    img1url = ""
                    img1n = ""
                }
                if (s.isNotEmpty()) {
                    d.add(s);

                    img2url = s
                    img2n = sn


                    if(img2nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img2nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img2url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img2url)
                        }
                    }
                    else{
                        bitmapArray.add(s)
                    }






                } else {
                    img2url = ""
                    img2n = ""
                }
                if (t.isNotEmpty()) {
                    d.add(t);
                    img3url = t
                    img3n = tn
                    if(img3nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img3nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img3url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img3url)
                        }
                    }
                    else{
                        bitmapArray.add(t)
                    }




                } else {
                    img3url = ""
                    img3n = ""
                }
                if (fo.isNotEmpty()) {
                    d.add(fo);


                    img4url = fo
                    img4n = fon

                    if(img4nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img4nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img4url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img4url)
                        }
                    }
                    else{
                        bitmapArray.add(fo)
                    }







                } else {
                    img4url = ""
                    img4n = ""
                }
                if (fif.isNotEmpty()) {
                    d.add(fif);




                    img5url = fif
                    img5n = fifn



                    if(img5nhigh.isNotEmpty()){
                        try {

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);
                            if (!dir.exists())
                                dir.mkdirs()

                            val k = img5nhigh
                            val recacnm = k.removeSuffix(".jpg")
                            cacnm1 = recacnm
                            var y = recacnm + ".png"

                            val file = File(dir, y)
                            println("CONTENT URI" + file)
                            if (file.exists()) {
                                val contentUri = Uri.fromFile(File("$path/$y"))
                                bitmapArray.add(contentUri.toString())
                            } else {
                                bitmapArray.add(img5url)
                            }
                        }
                        catch (e:Exception){
                            bitmapArray.add(img5url)
                        }
                    }
                    else{
                        bitmapArray.add(fif)
                    }
                } else {
                    img5url = ""
                    img5n = ""
                }

                Handler().postDelayed(Runnable {

                    Log.d("tag", "  " + bitmapArray)
                    if (bitmapArray.isNotEmpty()) {
                        for (r in 0 until bitmapArray.size) {
                            scrollpro.visibility = View.GONE

                            val textSliderView = TextSliderView(this)
                            // initialize a SliderLayout
                            Log.d("khd", "r  " + bitmapArray[r])
                            textSliderView
                                    //.description(name)
                                    .image(bitmapArray[r])

                                    .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                                    .setOnSliderClickListener {
                                        if(net_status()==true){

                                            val b = Intent(applicationContext, AddImages_Accessories::class.java)
                                            b.putExtra("id", id.text.toString())
                                            b.putExtra("keys",branchky)
                                            b.putExtra("f1", img1url)
                                            b.putExtra("fn1", img1n)
                                            b.putExtra("s1", img2url)
                                            b.putExtra("sn1", img2n)
                                            b.putExtra("t1", img3url)
                                            b.putExtra("tn1", img3n)
                                            b.putExtra("fo1", img4url)
                                            b.putExtra("fon1", img4n)
                                            b.putExtra("fif1", img5url)
                                            b.putExtra("fifn1", img5n)
                                            b.putExtra("f1high", img1urlhigh)
                                            b.putExtra("fn1high", img1nhigh)
                                            b.putExtra("s1high", img2urlhigh)
                                            b.putExtra("sn1high", img2nhigh)
                                            b.putExtra("t1high", img3urlhigh)
                                            b.putExtra("tn1high", img3nhigh)
                                            b.putExtra("fo1high", img4urlhigh)
                                            b.putExtra("fon1high", img4nhigh)
                                            b.putExtra("fif1high", img5urlhigh)
                                            b.putExtra("fifn1high", img5nhigh)
                                            b.putExtra("mresult", mresultsarr)
                                            b.putExtra("listenersave", listenersave)
                                            b.putExtra("f1edithigh", f1edithigh)
                                            b.putExtra("fn1edithigh", fn1edithigh)
                                            b.putExtra("s1edithigh", s1edithigh)
                                            b.putExtra("sn1edithigh", sn1edithigh)
                                            b.putExtra("t1edithigh", t1edithigh)
                                            b.putExtra("tn1edithigh", tn1edithigh)
                                            b.putExtra("fo1edithigh", fo1edithigh)
                                            b.putExtra("fon1edithigh", fon1edithigh)
                                            b.putExtra("fif1edithigh", fif1edithigh)
                                            b.putExtra("fifn1edithigh", fifn1edithigh)

                                            b.putExtra("cacnm1", cacnm1)
                                            b.putExtra("f1edit", f1edit)
                                            b.putExtra("fn1edit", fn1edit)
                                            b.putExtra("s1edit", s1edit)
                                            b.putExtra("sn1edit", sn1edit)
                                            b.putExtra("t1edit", t1edit)
                                            b.putExtra("tn1edit", tn1edit)
                                            b.putExtra("fo1edit", fo1edit)
                                            b.putExtra("fon1edit", fon1edit)
                                            b.putExtra("fif1edit", fif1edit)
                                            b.putExtra("fifn1edit", fifn1edit)
                                            startActivityForResult(b, 0)
                                            scroll2_slider.isEnabled = true
                                        }
                                        else{
                                            Toast.makeText(applicationContext,"You're offline.",Toast.LENGTH_SHORT).show()
                                        }
                                    }

                            //add your extra information
                            /*textSliderView.bundle(Bundle())
                    textSliderView.bundle.clear()*/
                            //.putString("extra", bitmapArray[r])

                            scroll2_slider.addSlider(textSliderView)
                        }
                        scroll2_slider.setPresetTransformer(SliderLayout.Transformer.Default)
                        scroll2_slider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                        scroll2_slider.setCustomAnimation(DescriptionAnimation())
                        scroll2_slider.setDuration(5000)

                        //scroll2_preview_service_image
                        val newurl = URL(bitmapArray[0]).openStream()
                        val img = BitmapFactory.decodeStream(newurl)
                        scroll2_preview_service_image.setImageBitmap(img)
                    }
                }, 1000)
                //bitmapArray.addAll(data.get("bitmapArray"))
                //println(bitmapArray)
                Log.d(" ", "result " + f)
                Log.d(" ", "result " + s)
                Log.d(" ", "result " + t)
                Log.d(" ", "result " + fo)
                Log.d(" ", "result " + fif)
                /* this.runOnUiThread(Runnable() {
                    file_maps.clear()
                    d.addAll(d)
                    Log.d("map","  "+d)
                })*/
            }

            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
                val f = data!!.getStringExtra("f");
                val fn = data!!.getStringExtra("fn");
                val s = data!!.getStringExtra("s");
                val sn = data!!.getStringExtra("sn");
                val t = data!!.getStringExtra("t");
                val tn = data!!.getStringExtra("tn");
                val fo = data!!.getStringExtra("fo");
                val fon = data!!.getStringExtra("fon");
                val fif = data!!.getStringExtra("fif");
                val fifn = data!!.getStringExtra("fifn");

                if (f.isNotEmpty()) {


                    img1url = f
                    img1n = fn
                } else {
                    img1url = ""
                    img1n = ""
                }
                if (s.isNotEmpty()) {


                    img2url = s
                    img2n = sn
                } else {
                    img2url = ""
                    img2n = ""
                }
                if (t.isNotEmpty()) {


                    img3url = t
                    img3n = tn
                } else {
                    img3url = ""
                    img3n = ""
                }
                if (fo.isNotEmpty()) {


                    img4url = fo
                    img4n = fon
                } else {
                    img4url = ""
                    img4n = ""
                }
                if (fif.isNotEmpty()) {


                    img5url = fif
                    img5n = fifn
                } else {
                    img5url = ""
                    img5n = ""
                }


                val fedit = data!!.getStringExtra("fedit")
                val fnedit = data!!.getStringExtra("fnedit")
                val sedit = data!!.getStringExtra("sedit")
                val snedit = data!!.getStringExtra("snedit")
                val tedit = data!!.getStringExtra("tedit")
                val tnedit = data!!.getStringExtra("tnedit")
                val foedit = data!!.getStringExtra("foedit")
                val fonedit = data!!.getStringExtra("fonedit")
                val fifedit = data!!.getStringExtra("fifedit")
                val fifnedit = data!!.getStringExtra("fifnedit");

                try {
                    mresultsarr = data!!.getStringArrayListExtra("mResult")
                } catch (e: Exception) {

                }



                try {
                    cacnm1 = data!!.getStringExtra("cacnm1")
                } catch (e: Exception) {

                }
                try {
                    listenersave = data!!.getStringExtra("listenersave")
                } catch (e: Exception) {

                }

                val fhigh = data!!.getStringExtra("fhigh");
                val fnhigh = data!!.getStringExtra("fnhigh");
                val shigh = data!!.getStringExtra("shigh");
                val snhigh = data!!.getStringExtra("snhigh");
                val thigh = data!!.getStringExtra("thigh");
                val tnhigh = data!!.getStringExtra("tnhigh");
                val fohigh = data!!.getStringExtra("fohigh");
                val fonhigh = data!!.getStringExtra("fonhigh");
                val fifhigh = data!!.getStringExtra("fifhigh");
                val fifnhigh = data!!.getStringExtra("fifnhigh");


                println("fhigh" + fhigh)
                println("shigh" + shigh)
                println("thigh" + thigh)
                println("fohigh" + fohigh)
                println("fifhigh" + fifhigh)


                println("fnhigh" + fnhigh)
                println("snhigh" + snhigh)
                println("tnhigh" + tnhigh)
                println("fonhigh" + fonhigh)
                println("fifnhigh" + fifnhigh)
                if (fhigh.isNotEmpty()) {


                    img1urlhigh = fhigh
                    img1nhigh = fnhigh
                } else {
                    img1urlhigh = ""
                    img1nhigh = ""
                }
                if (shigh.isNotEmpty()) {


                    img2urlhigh = shigh
                    img2nhigh = snhigh
                } else {
                    img2urlhigh = ""
                    img2nhigh = ""
                }
                if (thigh.isNotEmpty()) {


                    img3urlhigh = thigh
                    img3nhigh = tnhigh
                } else {
                    img3urlhigh = ""
                    img3nhigh = ""
                }
                if (fohigh.isNotEmpty()) {


                    img4urlhigh = fohigh
                    img4nhigh = fonhigh
                } else {
                    img4urlhigh = ""
                    img4nhigh = ""
                }
                if (fifhigh.isNotEmpty()) {


                    img5urlhigh = fifhigh
                    img5nhigh = fifnhigh
                } else {

                    img5urlhigh = ""
                    img5nhigh = ""
                }


                val fedithigh = data!!.getStringExtra("fedithigh")
                val fnedithigh = data!!.getStringExtra("fnedithigh")
                val sedithigh = data!!.getStringExtra("sedithigh")
                val snedithigh = data!!.getStringExtra("snedithigh")
                val tedithigh = data!!.getStringExtra("tedithigh")
                val tnedithigh = data!!.getStringExtra("tnedithigh")
                val foedithigh = data!!.getStringExtra("foedithigh")
                val fonedithigh = data!!.getStringExtra("fonedithigh")
                val fifedithigh = data!!.getStringExtra("fifedithigh")
                val fifnedithigh = data!!.getStringExtra("fifnedithigh");

                if (fedithigh.isNotEmpty()) {


                    f1edithigh = fedithigh
                    fn1edithigh = fnedithigh


                } else {


                    f1edithigh = ""
                    fn1edithigh = ""
                }
                if (sedithigh.isNotEmpty()) {


                    s1edithigh = sedithigh
                    sn1edithigh = snedithigh

                } else {


                    s1edithigh = ""
                    sn1edithigh = ""
                }
                if (tedithigh.isNotEmpty()) {

                    t1edithigh = tedithigh
                    tn1edithigh = tnedithigh

                } else {

                    t1edithigh = ""
                    tn1edithigh = ""
                }
                if (foedithigh.isNotEmpty()) {
                    fo1edithigh = foedithigh
                    fon1edithigh = fonedithigh

                } else {

                    fo1edithigh = ""
                    fon1edithigh = ""
                }
                if (fifedithigh.isNotEmpty()) {

                    fif1edithigh = fifedithigh
                    fifn1edithigh = fifnedithigh

                } else {

                    fif1edithigh = ""
                    fifn1edithigh = ""
                }





                if (fedit.isNotEmpty()) {


                    f1edit = fedit
                    fn1edit = fnedit


                } else {


                    f1edit = ""
                    fn1edit = ""
                }
                if (sedit.isNotEmpty()) {


                    s1edit = sedit
                    sn1edit = snedit

                } else {


                    s1edit = ""
                    sn1edit = ""
                }
                if (tedit.isNotEmpty()) {

                    t1edit = tedit
                    tn1edit = tnedit

                } else {

                    t1edit = ""
                    tn1edit = ""
                }
                if (foedit.isNotEmpty()) {
                    fo1edit = foedit
                    fon1edit = fonedit

                } else {

                    fo1edit = ""
                    fon1edit = ""
                }
                if (fifedit.isNotEmpty()) {

                    fif1edit = fifedit
                    fifn1edit = fifnedit

                } else {

                    fif1edit = ""
                    fifn1edit = ""
                }

                Log.d("no ", "Result")



                imcome = "yes"
            }
        }
    }



    //Save makeup service
    private fun onStarClicked1() {

        if (net_status() == true) {




            data class Count(var number: Int)

            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference("service_id")
            myRef.runTransaction(object : Transaction.Handler {
                override fun doTransaction(mutableData: MutableData): Transaction.Result? {
                    var p = mutableData.value
                    if (p == null) {
                        p = 1
                    } else if (p == 0) {
                        // Unstar the post and remove self from stars
                        p = 1

                    } else {
                        // Star the post and add self to stars
                        p = Integer.parseInt(p.toString()) + 1
                    }
                    // Set value and report transaction success
                    mutableData.value = p
                    //mutableData.setValue(p.number)
                    return Transaction.success(mutableData)
                }

                override fun onComplete(databaseError: DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {
                    println(dataSnapshot)
                    println(dataSnapshot.value)
                    val id = dataSnapshot.value
                    textInputLayout2.editText!!.setText(id.toString())

                    service_insert(id.toString())
                    // Transaction completed
                    // Log.d("", "postTransaction:onComplete:" + databaseError)
                }
            })
        }
        else
        {
            Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
        }
    }

    //Save makeup product
    private fun onStarClicked1pro() {


        if(net_status()==true) {





            println("INSIDE ONSTARTCLICK")
            data class Count(var number: Int)

            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference("produtadd")
            myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                    var p = mutableData.value


                    if (p == null) {
                        p = 1
                    }

                    if (p == 0) {
                        // Unstar the post and remove self from stars
                        p = 1

                    } else {
                        // Star the post and add self to stars
                        p = Integer.parseInt(p.toString()) + 1
                    }

                    // Set value and report transaction success
                    mutableData.value = p
                    //mutableData.setValue(p.number)
                    return com.google.firebase.database.Transaction.success(mutableData)
                }

                override fun onComplete(
                        databaseError: DatabaseError?,
                        b: Boolean,
                        dataSnapshot: DataSnapshot
                ) {

                    println(dataSnapshot)
                    println(dataSnapshot.value)
                    val id = dataSnapshot.value


                    prod_insert(id.toString())


                    // Transaction completed
                    // Log.d("", "postTransaction:onComplete:" + databaseError)
                }
            })
        }
        else{
            Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

        }
    }
    fun service_insert(service_id: String) {


       /* pDialogs = SweetAlertDialog(this@ScrollActivity, SweetAlertDialog.PROGRESS_TYPE);
        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialogs!!.setTitleText("Saving...")
        pDialogs!!.setCancelable(false)
        pDialogs!!.show();*/

        val nid= newid.text.toString()
        val sname = (textInputLayout.editText!!.text).toString()
        val sid = "SRV"+service_id
        val sdur = (textInputLayout3.editText!!.text).toString()
        val hsnT = (hsnT.text).toString()
        val hsndes = (hsndes.text).toString()
        val pr = (price.text).toString()
        val Tax = (Tax.isChecked.toString())
        val intax = (intax.text).toString()
        val cess = (cess.text).toString()
        val Ctax = (Ctax.text).toString()
        val Stax = (Stax.text).toString()
        val taxtot = (taxtot.text).toString()
        val css = (css.text).toString()
        val Gtot = (grosstot.text).toString()
        val payemp = (payemp.isChecked.toString())
        val paybonus = (paybonus.isChecked.toString())
        val currency = (currency.isChecked.toString())
        val percentage = (percentage.isChecked.toString())
        val per = (per.text).toString()
        val gender = (scroll2_gender.selectedItem.toString())

        val retdates=redays.text.toString()


        try {
            if(scroll2_category.selectedItemPosition == 0) {

                maincat = ""
            } else {
                maincat = (scroll2_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }

        try {
            if (scroll2_sub_category.selectedItemPosition == 0) {

                subcat = ""
            } else {
                subcat = (scroll2_sub_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }
        val des = (scroll2_descrip.text.toString())
        val fix = (scroll2_fixed_price.text.toString())
        val from = (scroll2_price_from.text.toString())
        val to = (scroll2_price_to.text.toString())

        //val desc = (descrip.text).toString()
        val status = (state.text.toString())
        val data = s(snm = sname, sid = sid, dur = sdur, sac = hsnT, sacdesc = hsndes, pr = pr, tx = Tax, igst = intax, cess = cess,
                cgst = Ctax, sgst = Stax, ttot = taxtot, ctot = css, gtot = Gtot, ecomm = payemp, ebns = paybonus, cry = currency,
                ptg = percentage, bval = per, gdr = gender, mctg = maincat, sctg = subcat,mctgkey=mctgkeys,
                sctgkey=sctgkeys,desc = des, fp = fix, fpr = from, tpr = to,status = status, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url,
                img3url = img3url, img4url = img4url, img5url = img5url,img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh,img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh,retdate = retdates,makeupitem = makeupitemstr)
        //if ((did.text.toString()).isEmpty()) {
        save.isEnabled = false

        val isInserted = myDb.insertData(nid, sname, sid, sdur, hsnT, hsndes,
                pr, Tax, intax, cess, Ctax, Stax, taxtot, css, Gtot, payemp, paybonus,
                currency, percentage, per, gender, maincat, subcat, des, fix, from, to,
                status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,mctgkeys,sctgkeys,retdates,makeupitemstr)
        if (isInserted == true){

        }
        else{
        }

        println("SERVIE ADD")

        db = FirebaseFirestore.getInstance()
        db.collection("${branchky}_service").document(newid.text.toString())
                .set(data)
                .addOnSuccessListener {
                    Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()

                    /*pDialogs!!.dismiss()*/

                   /* if(frmmakeup.isEmpty()) {
                        val t = Intent(this@ScrollActivity, servicelistActivity::class.java)
                        startActivity(t)
                        finish()
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                    }*/
                    try{
                        pDialogs!!.dismiss()
                    }
                    catch (e:Exception)
                    {

                    }
                     if((frmmakeup.isNotEmpty()||frmmakeup=="makeup")&&(bothcome.isEmpty())){
                        val data = Intent(applicationContext,Main_makeup::class.java)

                        // Add the required data to be returned to the MainActivity


                        // Set the resultCode to Activity.RESULT_OK to
                        // indicate a success and attach the Intent
                        // which contains our result data
                         overridePendingTransition( R.anim.slide_in_right, R.anim.slide_out_right);

                         startActivity(data)

                        // With finish() we close the AnotherActivity to
                        // return to MainActivity
                        finish()

                        Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()



                    }



                }
                .addOnFailureListener {Exception->

                    /*pDialogs!!.dismiss()*/
                    Toast.makeText(this, "not saved "+Exception.toString(), Toast.LENGTH_LONG).show()

                }
    }


    fun prod_insert(id1:String)

    {




       /* pDialogs!!.setTitleText("Saving...")*/








        if (sname.length() == 0) {
            sname_error.visibility = View.VISIBLE

            sname_error.setText("Required field*")
        }
        if (price.length() == 0) {
            price_error.visibility = View.VISIBLE

            price_error.setText("Required field*")
        }
       /* if (retail.isChecked==false&&backbox.isChecked==false) {
            reterr.visibility = View.VISIBLE

            bkbxerr.visibility=View.VISIBLE


            Toast.makeText(applicationContext, "Please Check retail or backbar", Toast.LENGTH_SHORT).show()
        }*/
        var npid = idsmy.text.toString()
        var pid = "PRD" + id1
        var pname = (sname.text).toString()
        var bcode = (bcodeid.text).toString()
        var pdes = (hsndes.text).toString()

        var weight = (vol.text).toString()
        var psac = (hsnT.text).toString()

        if (stockhand.text.toString().isNotEmpty()) {

            var stockonhand = (stockhand.text).toString()
            stkhand = stockonhand

        } else {

            stkhand = "0"
        }



        protypesave="Wedding"


        var minstock = (minstock.text).toString()
        var maxstock = (maxstock.text).toString()
        var price = (price.text).toString()
        var taxable = Tax.isChecked.toString()
        var igst = (intax.text).toString()
        var cgst = (Ctax.text).toString()
        var sgst = (Stax.text).toString()
        var cess = (cess.text).toString()
        var taxtotal = (taxtot.text).toString()
        var cessval = (css.text).toString()
        var currency = currency.isChecked.toString()
        var percentage = percentage.isChecked.toString()
        var percentagevalue = (per.text).toString()
        var product_dec = (scroll2_descrip.text).toString()
        var mrP = (grosstot.text).toString()
        var cate = cate.selectedItem.toString()
        var manufacture = manu.selectedItem.toString()
        var ut = unitspinner.selectedItem.toString()
        var consold = paybonus.isChecked.toString()
        var comm = payemp.isChecked.toString()
        var status = (state.text).toString()
        val img1npro = img1n
        val img2npro = img2n
        val img3npro = img3n
        val img4npro = img4n
        val img5npro = img5n
        if (img1npro.isNotEmpty()) {
            val img1urlpro = img1url
            imgurls = img1urlpro
        }
        if (img1url.isEmpty()) {

        }

        var ret="false"
        var bkbr="false"
        var returnables="false"
        val retdate=redays.text.toString()



        val img2urlpro = img2url
        val img3urlpro = img3url
        val img4urlpro = img4url
        val img5urlpro = img5url
        var orikys = branchky
        val data = s1(p_id = pid, p_nm = pname, bc = bcode, desc = pdes, wg_vol = weight, hsn = psac, ctgy = cate,
                mfr = manufacture, ut = ut, min_stk = minstock, price = price, mx_stk = maxstock, cn_sold = consold,
                emp_com = comm, taxchk = taxable, igst = igst, cgst = cgst, sgst = sgst, cess = cess, taxtot = taxtotal,
                cesstot = cessval, mrp = mrP, curency = currency, status = status, percentage = percentage, retail = ret,backbar = bkbr, percentageval = percentagevalue,
                product_desc = product_dec, stock_hand = stkhand, img1n = img1npro, img2n = img2npro, img3n = img3npro, img4n = img4npro, img5n = img5npro, img1url = imgurls,
                img2url = img2urlpro, img3url = img3urlpro, img4url = img4urlpro, img5url = img5urlpro, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh,
                orikys = branchky,supp_key = suppky,supp_name = suppname,protype = protypesave,returnable = returnables,returnableday = retdate,makeupitem = makeupitemstr)
        val TAG = "some"
        /*    save_progress.visibility = android.view.View.VISIBLE*/



        save.isEnabled = false
        var db = FirebaseFirestore.getInstance()




        db.collection("product").document(idsmy.text.toString())
                .set(data)

                .addOnSuccessListener { documentReference ->
                    var kk = idsmy.text.toString()

                    prosave_key = prosave_key.plusElement(kk)

                    if (net_status() == true) {

                        val map = mutableMapOf<String, Any?>()
                        map.put("$branchky", stkhand)
                        db.collection("product").document(idsmy.text.toString())
                                .update(map)
                                .addOnCompleteListener {

                                }



                        println("AT THE TIME OF SAVE CESS" + cess)


                        val database = FirebaseDatabase.getInstance()

                        if (idsmy.text.toString().isNotEmpty()) {

                            for (i in 0 until brnchkeys.size) {
                                if (brnchkeys[i].toString() == branchky) {
                                    var ad = brnchkeys[i]

                                    val map = mutableMapOf<String, Any?>()
                                    map.put("$ad", stkhand)
                                    db.collection("product").document(idsmy.text.toString())
                                            .update(map)

                                    val myRef = database.getReference(idsmy.text.toString() + "_" + brnchkeys[i])

                                    myRef.setValue(stkhand)
                                } else {
                                    var ads = brnchkeys[i]
                                    val myRef = database.getReference(idsmy.text.toString() + "_" + brnchkeys[i])


                                    val map = mutableMapOf<String, Any?>()


                                    map.put("$ads", "0")
                                    db.collection("product").document(idsmy.text.toString())
                                            .update(map)

                                    myRef.setValue("0")
                                }
                            }


                        } else {

                            val myRef = database.getReference(id.text.toString() + "_" + branchky)

                            myRef.setValue(stkhand)
                        }

                        val isInserted = myDb1.insertData(npid, pid, pname, bcode, pdes, weight, psac, cate, manufacture, ut, minstock,
                                price, maxstock, consold, comm, taxable, igst, cgst, sgst, cess, taxtotal, cessval, mrP, currency, status,
                                percentage, percentagevalue, product_dec, stkhand, img1n, img2n, img3n, img4n, img5n, imgurls,
                                img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys,ret,bkbr,protypesave,returnables,retdate,makeupitemstr)






                        if (isInserted == true) {
                        } else {
                        }
                        /*   Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)*/
                        /*val kk=documentReference.id*/


                        Handler().postDelayed(Runnable {


                            /*if(suppcome.isNotEmpty()&&suppcome=="supplier"){

                                val data = Intent(applicationContext,SupplierSecondmain::class.java)

                                // Add the required data to be returned to the MainActivity
                                data.putExtra("proky", Arrays.toString(prosave_key))

                                // Set the resultCode to Activity.RESULT_OK to
                                // indicate a success and attach the Intent
                                // which contains our result data
                                setResult(Activity.RESULT_OK, data)

                                // With finish() we close the AnotherActivity to
                                // return to MainActivity
                                finish()

                                Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()


                                try{
                                    pDialogs!!.dismiss()
                                }
                                catch (e:Exception)
                                {

                                }

                            }*/
                            try{
                                pDialogs!!.dismiss()
                            }
                            catch (e:Exception)
                            {

                            }


                            //Back action
                            if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
                                val data = Intent(applicationContext,Main_makeup::class.java)

                                // Add the required data to be returned to the MainActivity


                                // Set the resultCode to Activity.RESULT_OK to
                                // indicate a success and attach the Intent
                                // which contains our result data
                                overridePendingTransition( R.anim.slide_in_right, R.anim.slide_out_right);

                                startActivity(data)

                                // With finish() we close the AnotherActivity to
                                // return to MainActivity
                                finish()

                                Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()



                            }

                           /* else if(suppcome.isEmpty()){
                                val o = Intent(this@MainActivityScroll, MainProductlistActivity::class.java)

                                o.putExtra("frm_main", "main")

                                o.putExtra("addpro", addpro)
                                o.putExtra("editpro", editepro)
                                o.putExtra("deletepro", deletepro)
                                o.putExtra("viewpro", viewpro)
                                o.putExtra("importpro", importpro)
                                o.putExtra("exportpro", exportpro)
                                o.putExtra("changestock", stockin_hand)
                                o.putExtra("skey", branchky)
                                startActivity(o)
                                finish()
                                Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()


                                try{
                                   *//* pDialogs!!.dismiss()*//*
                                }
                                catch (e:Exception)
                                {

                                }
                            }*/
                        },2500)


                    } else {
                        Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()
                        try{
                           /* pDialogs!!.dismiss()*/
                        }
                        catch (e:Exception)
                        {

                        }

                    }
                }
                .addOnFailureListener { e ->
                    println("COME FAILURE LISTENER")
                    Log.w(TAG, "Error adding document", e)
                    Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                    /* save_progress.visibility = android.view.View.GONE*/
                }



    }



    override fun onBackPressed() {

        listenersave = ""
        commonlisteners = ""
        println("LISTENER SAVE"+listenersave)

        println("VALUE OF IMG2NAME"+img2n)
        println("VALUE OF IMG2NAME EDIT"+sn1edit)

        println("VALUE OF IMG1NAME"+img1n)
        println("VALUE OF IMG1NAME EDIT"+fn1edit)

        println("VALUE OF IMG3NAME"+img3n)
        println("VALUE OF IMG3NAME EDIT"+tn1edit)

        println("VALUE OF IMG4NAME"+img4n)
        println("VALUE OF IMG4NAME EDIT"+fon1edit)

        println("VALUE OF IMG5NAME"+img5n)
        println("VALUE OF IMG5NAME EDIT"+fifn1edit)

        println("VALUE OF BONUS STRING"+snamevalidate)
        println("VALUE OF BONUS EDITTEXT"+sname.text.toString())






        if(((img1url != f1edit) || (img2url != s1edit) || (img3url != t1edit) || (img4url != fo1edit) || (img5url != fif1edit))){
            println("ONBACK URL1 EDIT NOT EQUAl"+img1url)
            listenersave = "change"
            commonlisteners = "change"
        }
        if((retailchkalready=="true"&&retailchk.isChecked==false)||(rentalchkalready=="true"&&rentalchk.isChecked==false)){
            listenersave = "change"
            commonlisteners = "change"
        }

if(rentalchk.isChecked==true&&retailchk.isChecked==true) {
    try {
        if ((snamevalidate != sname.text.toString()) ||(retdatedup!=redays.text.toString())||(returnval!=retques.isChecked.toString())|| (sdurvalidate != sdur.text.toString()) || (hsnTvalidate != hsnT.text.toString())
                || (hsndesvalidate != hsndes.text.toString()) || (pricevalidate != price.text.toString()) || (intaxvalidate != intax.text.toString()) ||
                (gendervalidate != scroll2_gender.selectedItem.toString()) || (maincatvalidate != scroll2_category.selectedItem.toString()) || (subcatvalidate != scroll2_sub_category.selectedItem.toString())
                || (cessvalidate != cess.text.toString()) || (pervalidate != per.text.toString()) || (payempvalidate != payemp.isChecked.toString()) || (descvalidate != scroll2_descrip.text.toString()) ||
                (paybonusvalidate != paybonus.isChecked.toString()) || (scroll2_fixed_pricevalidate != scroll2_fixed_price.text.toString())
                || (scroll2_price_fromvalidate != scroll2_price_from.text.toString()) || (scroll2_price_tovalidate != scroll2_price_to.text.toString())) {

            listenersave = "change"
            println("ONBACK URL1 NOT EQUAL" + img1url)

        }

        if ((pnamevalidate != sname.text.toString()) ||(retdatedup!=redays.text.toString())||(returnval!=retques.isChecked.toString())|| (volvalidate != vol.text.toString()) || (bcodeidvalidate != bcodeid.text.toString()) ||
                (hscvalidate != hsnT.text.toString()) || (hscdesvalidate != hsndes.text.toString()) || (maincatvalidatepro != cate.selectedItem.toString()) ||
                (subcatvalidatepro != manu.selectedItem.toString()) || (listvalidate != unitspinner.selectedItem.toString()) || (pricevalidate != price.text.toString())
                || (taxcheckvalidate != Tax.isChecked.toString()) || (intgstvalidate != intax.text.toString()) || (cessvaluevalidate != cess.text.toString())
                || (checkcommisionvalidate != payemp.isChecked.toString()) || (returnablevalidate != "false") || (percentagevalvalidate != per.text.toString()) || (maxstockvalidate != maxstock.text.toString())
                || (minstockvalidate != minstock.text.toString()) || (des_boxvalidate != scroll2_descrip.text.toString()) || (stockhandvalidate != stockhand.text.toString())) {

            commonlisteners = "change"


        }
    }
    catch (e:Exception){


    }
}
        else if(retailchk.isChecked==true&&rentalchk.isChecked==false){
    try {

    if ((pnamevalidate != sname.text.toString()) ||(retdatedup!=redays.text.toString())||(returnval!=retques.isChecked.toString())|| (volvalidate != vol.text.toString()) || (bcodeidvalidate != bcodeid.text.toString()) ||
            (hscvalidate != hsnT.text.toString()) || (hscdesvalidate != hsndes.text.toString()) || (maincatvalidatepro != cate.selectedItem.toString()) ||
            (subcatvalidatepro != manu.selectedItem.toString()) || (listvalidate != unitspinner.selectedItem.toString()) || (pricevalidate != price.text.toString())
            || (taxcheckvalidate != Tax.isChecked.toString()) || (intgstvalidate != intax.text.toString()) || (cessvaluevalidate != cess.text.toString())
            || (checkcommisionvalidate != payemp.isChecked.toString()) || (returnablevalidate != "false") || (percentagevalvalidate != per.text.toString()) || (maxstockvalidate != maxstock.text.toString())
            || (minstockvalidate != minstock.text.toString()) || (des_boxvalidate != scroll2_descrip.text.toString()) || (stockhandvalidate != stockhand.text.toString())) {

        commonlisteners = "change"
    }


    }
    catch (e:Exception){


    }
        }
        else if(retailchk.isChecked==false&&rentalchk.isChecked==true){
    try {

    if ((snamevalidate != sname.text.toString()) ||(retdatedup!=redays.text.toString())||(returnval!=retques.isChecked.toString())|| (sdurvalidate != sdur.text.toString()) || (hsnTvalidate != hsnT.text.toString())
            || (hsndesvalidate != hsndes.text.toString()) || (pricevalidate != price.text.toString()) || (intaxvalidate != intax.text.toString()) ||
            (gendervalidate != scroll2_gender.selectedItem.toString()) || (maincatvalidate != scroll2_category.selectedItem.toString()) || (subcatvalidate != scroll2_sub_category.selectedItem.toString())
            || (cessvalidate != cess.text.toString()) || (pervalidate != per.text.toString()) || (payempvalidate != payemp.isChecked.toString()) || (descvalidate != scroll2_descrip.text.toString()) ||
            (paybonusvalidate != paybonus.isChecked.toString()) || (scroll2_fixed_pricevalidate != scroll2_fixed_price.text.toString())
            || (scroll2_price_fromvalidate != scroll2_price_from.text.toString()) || (scroll2_price_tovalidate != scroll2_price_to.text.toString())) {

        listenersave = "change"
        println("ONBACK URL1 NOT EQUAL" + img1url)

    }
    }
    catch (e:Exception){


    }
        }
        else if(retailchk.isChecked==false&&rentalchk.isChecked==false&&sid.text.toString()=="Auto-generated"&&pid.text.toString()=="Auto-generated") {
    try {
        if ((snamevalidate != sname.text.toString())|| (retdatedup != redays.text.toString()) ||(returnval!=retques.isChecked.toString())|| (sdurvalidate != sdur.text.toString()) || (hsnTvalidate != hsnT.text.toString())
                || (hsndesvalidate != hsndes.text.toString()) || (pricevalidate != price.text.toString()) || (intaxvalidate != intax.text.toString()) ||
                (cessvalidate != cess.text.toString()) || (pervalidate != per.text.toString()) || (payempvalidate != payemp.isChecked.toString()) || (descvalidate != scroll2_descrip.text.toString()) ||
                (paybonusvalidate != paybonus.isChecked.toString()) || (scroll2_fixed_pricevalidate != scroll2_fixed_price.text.toString())
                || (scroll2_price_fromvalidate != scroll2_price_from.text.toString()) || (scroll2_price_tovalidate != scroll2_price_to.text.toString())) {

            listenersave = "change"
            println("ONBACK URL1 NOT EQUAL" + img1url)

        }

        if ((pnamevalidate != sname.text.toString()) || (retdatedup != redays.text.toString()) ||(returnval!=retques.isChecked.toString())||(volvalidate != vol.text.toString()) || (bcodeidvalidate != bcodeid.text.toString()) ||
                (hscvalidate != hsnT.text.toString()) || (hscdesvalidate != hsndes.text.toString()) ||(pricevalidate != price.text.toString())
                || (taxcheckvalidate != Tax.isChecked.toString()) || (intgstvalidate != intax.text.toString()) || (cessvaluevalidate != cess.text.toString())
                || (checkcommisionvalidate != payemp.isChecked.toString()) || (returnablevalidate != "false") || (percentagevalvalidate != per.text.toString()) || (maxstockvalidate != maxstock.text.toString())
                || (minstockvalidate != minstock.text.toString()) || (des_boxvalidate != scroll2_descrip.text.toString()) || (stockhandvalidate != stockhand.text.toString())) {

            commonlisteners = "change"


        }
    } catch (e: Exception) {


    }
}


        if (((img1url.isNotEmpty()) || (img2url.isNotEmpty()) || (img3url.isNotEmpty()) || (img4url.isNotEmpty()) || (img5url.isNotEmpty())||(listenersave == "change")||(commonlisteners == "change"))&&(sid.text.toString()=="Auto-generated")&&(pid.text.toString()=="Auto-generated")) {
            println("ONBACK URL1 EDIT NOT SID"+img1url)
            alert()
        }
        else if (((listenersave == "change")||(commonlisteners=="change"))&&(id.text.toString().isNotEmpty())) {
            println("ONBACK URL1 EDIT LIST ID"+img1url)
            alert()
        }
        else {
            if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                val data = Intent(applicationContext,Main_makeup::class.java)
                startActivity(data)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()

            }

        }

    }

    fun alert() {
        val builder = AlertDialog.Builder(this@Attachments_Activity)
        with(builder) {
            setTitle("Save?")
            setMessage("Do you want to save?")


            // Dialog

            setPositiveButton("Yes") { dialog, whichButton ->

                dialog.dismiss()

                try {
                    if (sname.text.isEmpty() || price.text.isEmpty()) {
                        println("gender " + scroll2_gender.selectedItemPosition.toString())
                        if (scroll2_gender.selectedItemPosition == 0) {

                        }
                        if (scroll2_category.selectedItemPosition == 0) {

                        }
                        if (scroll2_sub_category.selectedItemPosition == 0) {

                        }
                        if (sname.text.isEmpty()) {
                            sname_error.visibility = View.VISIBLE


                        }
                        if (price.text.isEmpty()) {
                            price_error.visibility = View.VISIBLE

                        }
                        if (retailchk.isChecked == false && rentalchk.isChecked == false) {
                            retailerr.visibility = View.VISIBLE
                            Toast.makeText(applicationContext, "Please check retail or rental", Toast.LENGTH_SHORT).show()
                        }
                        println("main " + scroll2_category.selectedItemPosition.toString())
                        println("sub " + scroll2_sub_category.selectedItemPosition.toString())
                        Toast.makeText(this@Attachments_Activity, "please fill required fields!", Toast.LENGTH_LONG).show()
                    } else {
                        if (scroll2_price_to.text.toString().isNotEmpty() && scroll2_price_from.text.toString().isNotEmpty()) {
                            if (scroll2_price_to.text.toString().toFloat() <= scroll2_price_from.text.toString().toFloat()) {
                                poplow()
                            } else {
                                if (retailchk.isChecked == true && rentalchk.isChecked == true) {
                                    bothcome = "true"
                                    savepopup()  ///Save as makeup product
                                    save()  ///Save as makeup Service

                                } else if (retailchk.isChecked == false && rentalchk.isChecked == true) {

                                    if (retailchkalready == "true") {
                                        db.collection("product").document(id.text.toString())
                                                .delete()
                                                .addOnCompleteListener {
                                                    myDb1.deleteData(id.text.toString())

                                                    save()  ///Save as makeup Service
                                                }
                                    } else {

                                        save()  ///Save as makeup Service
                                    }
                                } else if (retailchk.isChecked == true && rentalchk.isChecked == false) {

                                    if (rentalchkalready == "true") {
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .delete()
                                                .addOnCompleteListener {
                                                    myDb.deleteData(id.text.toString())
                                                    savepopup()///Save as makeup product

                                                }
                                    } else {
                                        savepopup()///Save as makeup product

                                    }

                                } else if (retailchk.isChecked == false && rentalchk.isChecked == false) {

                                }
                            }
                        } else {
                            if (retailchk.isChecked == true && rentalchk.isChecked == true) {
                                bothcome = "true"
                                savepopup()///Save as makeup product
                                save()///Save as makeup service

                            } else if (retailchk.isChecked == false && rentalchk.isChecked == true) {


                                if (retailchkalready == "true") {
                                    save_progress.visibility = View.VISIBLE
                                    db.collection("product").document(id.text.toString())
                                            .delete()
                                            .addOnCompleteListener {
                                                myDb1.deleteData(id.text.toString())
                                                save()  ///Save as makeup service
                                            }
                                } else {
                                    save()  ///Save as makeup service
                                }
                            } else if (retailchk.isChecked == true && rentalchk.isChecked == false) {

                                if (rentalchkalready == "true") {
                                    save_progress.visibility = View.VISIBLE
                                    db.collection("${branchky}_service").document(id.text.toString())
                                            .delete()
                                            .addOnCompleteListener {
                                                myDb.deleteData(id.text.toString())
                                                savepopup()  ///Save as makeup product
                                            }
                                } else {
                                    savepopup()  ///Save as makeup product

                                }

                            } else if (retailchk.isChecked == false && rentalchk.isChecked == false) {
                                Toast.makeText(applicationContext, "Please check retail or rental", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
                catch (e:Exception){

                }

            }
                    .setNegativeButton("No") { dialog, whichButton ->

                        println("f1edit value" + f1edit)
                        println("img1n value" + img1n)


                        if (newid.text.toString().isNotEmpty()) {

                            dialog.dismiss()

                            val progressDialog = ProgressDialog(this@Attachments_Activity);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);
                            println("true " + newid.text.toString())
                            val del = ArrayList<String>()
                            val storage = FirebaseStorage.getInstance()
                            val storageRef = storage.getReference()
                            if (img1n.isEmpty() && img2n.isEmpty() && img3n.isEmpty() && img4n.isEmpty() && img5n.isEmpty()) {
                                progressDialog.dismiss()
                                if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                    val data = Intent(applicationContext,Main_makeup::class.java)
                                    startActivity(data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()

                                }

                            }
                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);

                            if (img1n.isNotEmpty()) {
                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }

                                del.add(img1n)
                                del.add(img1nhigh)
                            }
                            if (img2n.isNotEmpty()) {
                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img2n)
                                del.add(img2nhigh)
                            }
                            if (img3n.isNotEmpty()) {
                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img3n)
                                del.add(img3nhigh)
                            }
                            if (img4n.isNotEmpty()) {
                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img4n)
                                del.add(img4nhigh)
                            }
                            if (img5n.isNotEmpty()) {
                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(img5n)
                                del.add(img5nhigh)
                            }
                            if ((del.size >= 0)&&(net_status()==true)) {
                                for (i in del) {
                                    val imagesRef = storageRef.child("service").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {
                                                if (i == del.get(del.size - 1)) {
                                                    progressDialog.dismiss()
                                                    if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                                        val data = Intent(applicationContext,Main_makeup::class.java)
                                                        startActivity(data)
                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                        finish()

                                                    }

                                                }
                                            }
                                            .addOnCompleteListener {
                                            }
                                }
                            }
                            else{
                                progressDialog.dismiss()
                                if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                    val data = Intent(applicationContext,Main_makeup::class.java)
                                    startActivity(data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()

                                }

                            }
                        } else if ((id.text.isNotEmpty())&&(net_status()==true)) {
                            val delname = ArrayList<String>()
                            val delnameedit = ArrayList<String>()
                            val delnamehigh = ArrayList<String>()
                            val delnameedithigh = ArrayList<String>()
                            val delurl = ArrayList<String>()
                            val delurledit = ArrayList<String>()
                            val delurledithigh = ArrayList<String>()
                            val deldbnm = ArrayList<String>()

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"

                            val dir = File(path);

                            if (img1n != fn1edit) {
                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img1n)
                                delnamehigh.add(img1nhigh)
                            }
                            if (img2n != sn1edit) {
                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img2n)
                                delnamehigh.add(img2nhigh)
                            }
                            if (img3n != tn1edit) {
                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img3n)
                                delnamehigh.add(img3nhigh)
                            }
                            if (img4n != fon1edit) {
                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img4n)
                                delnamehigh.add(img4nhigh)
                            }
                            if (img5n != fifn1edit) {
                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(img5n)
                                delnamehigh.add(img5nhigh)
                            }


                            println("DELE NAME" + delname)
                            println("DELE NAME HIGH" + delnamehigh)


                            delurl.add(f1edit)
                            delnameedit.add(fn1edit)

                            delurledithigh.add(f1edithigh)
                            delnameedithigh.add(fn1edithigh)

                            dialog.dismiss()

                            val progressDialog = ProgressDialog(this@Attachments_Activity);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);
                            deletedb()
                            if ((delname.size >= 0)&&(net_status()==true)) {
                                for (i in delname) {
                                    val storage = FirebaseStorage.getInstance()
                                    val storageRef = storage.getReference()

                                    val imagesRef = storageRef.child("service").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {

                                                if (i == delname.get(delname.size - 1)) {
                                                    for (i in delnamehigh) {
                                                        val imagesRef = storageRef.child("service").child(i)
                                                        imagesRef.delete()
                                                                .addOnSuccessListener {
                                                                    if (i == delnamehigh.get(delnamehigh.size - 1)) {

                                                                        progressDialog.dismiss()
                                                                        if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                                                            val data = Intent(applicationContext,Main_makeup::class.java)
                                                                            startActivity(data)
                                                                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                                            finish()

                                                                        }


                                                                    }

                                                                }
                                                    }
                                                }

                                            }
                                }


                            }
                            else{
                                progressDialog.dismiss()
                                if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                    val data = Intent(applicationContext,Main_makeup::class.java)
                                    startActivity(data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()

                                }

                            }
                        }
                        else{
                            Toast.makeText(applicationContext,"No internet Connection",Toast.LENGTH_SHORT).show()
                            if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){

                                val data = Intent(applicationContext,Main_makeup::class.java)
                                startActivity(data)
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                finish()

                            }

                        }
                    }

            val dialog = builder.create()

            dialog.show()
        }
    }



    //--------------    ///Delete images when updated images are not saved   -------------------------------///

    fun deletedb() {
        if(((img1n != fn1edit)||(img2n != sn1edit)||(img3n != tn1edit)|| (img4n != fon1edit)||(img5n != fifn1edit))&&(net_status()==true)) {
            if ((id.text.isNotEmpty()) && (img1n != fn1edit)) {
                db.collection("${branchky}_service").document(id.text.toString())
                        .update("img1url", f1edit)
                        .addOnSuccessListener {
                            db.collection("${branchky}_service").document(id.text.toString())
                                    .update("img1n", fn1edit)
                                    .addOnCompleteListener {
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .update("img1urlhigh", f1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("${branchky}_service").document(id.text.toString())
                                                            .update("img1nhigh", fn1edithigh)

                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (img2n != sn1edit)) {

                db.collection("${branchky}_service").document(id.text.toString())
                        .update("img2url", s1edit)
                        .addOnSuccessListener {
                            db.collection("${branchky}_service").document(id.text.toString())
                                    .update("img2n", sn1edit)
                                    .addOnCompleteListener {
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .update("img2urlhigh", s1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("${branchky}_service").document(id.text.toString())
                                                            .update("img2nhigh", sn1edithigh)


                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (img3n != tn1edit)) {
                db.collection("${branchky}_service").document(id.text.toString())
                        .update("img3url", t1edit)
                        .addOnSuccessListener {
                            db.collection("${branchky}_service").document(id.text.toString())
                                    .update("img3n", tn1edit)
                                    .addOnCompleteListener {
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .update("img3urlhigh", t1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("${branchky}_service").document(id.text.toString())
                                                            .update("img3nhigh", tn1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (img4n != fon1edit)) {
                db.collection("${branchky}_service").document(id.text.toString())
                        .update("img4url", fo1edit)
                        .addOnSuccessListener {
                            db.collection("${branchky}_service").document(id.text.toString())
                                    .update("img4n", fon1edit)
                                    .addOnCompleteListener {
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .update("img4urlhigh", fo1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("${branchky}_service").document(id.text.toString())
                                                            .update("img4nhigh", fon1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (img5n != fifn1edit)) {
                db.collection("${branchky}_service").document(id.text.toString())
                        .update("img5url", fif1edit)
                        .addOnSuccessListener {
                            db.collection("${branchky}_service").document(id.text.toString())
                                    .update("img5n", fifn1edit)
                                    .addOnCompleteListener {
                                        db.collection("${branchky}_service").document(id.text.toString())
                                                .update("img5urlhigh", fif1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("${branchky}_service").document(id.text.toString())
                                                            .update("img5nhigh", fifn1edithigh)

                                                }
                                    }

                        }
            }
        }
        else{
            if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
                val data = Intent(applicationContext,Main_makeup::class.java)

                // Add the required data to be returned to the MainActivity


                // Set the resultCode to Activity.RESULT_OK to
                // indicate a success and attach the Intent
                // which contains our result data
                overridePendingTransition( R.anim.slide_in_right, R.anim.slide_out_right);

                startActivity(data)

                // With finish() we close the AnotherActivity to
                // return to MainActivity
                finish()





            }
        }

    }




    //Existing makeup service update
    fun update() {
        /*    pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialogs!!.setTitleText("Saving...")
        pDialogs!!.setCancelable(false);
        pDialogs!!.show();*/

        pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE)
        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialogs!!.setTitleText("Saving...")
        pDialogs!!.setCancelable(false)
        pDialogs!!.show();
        println("id  " + id.text)
        val upid = id.text.toString()
        val sname = (textInputLayout.editText!!.text).toString()
        val sid = (textInputLayout2.editText!!.text).toString()
        val sdur = (textInputLayout3.editText!!.text).toString()
        val hsnT = (hsnT.text).toString()
        val hsndes = (hsndes.text).toString()
        val pr = (price.text).toString()
        val Tax = (Tax.isChecked.toString())
        val intax = (intax.text).toString()
        val cess = (cess.text).toString()
        val Ctax = (Ctax.text).toString()
        val Stax = (Stax.text).toString()
        val taxtot = (taxtot.text).toString()
        val css = (css.text).toString()
        val Gtot = (grosstot.text).toString()
        val payemp = (payemp.isChecked.toString())
        val paybonus = (paybonus.isChecked.toString())
        val currency = (currency.isChecked.toString())
        val percentage = (percentage.isChecked.toString())
        val per = (per.text).toString()
        val gender = (scroll2_gender.selectedItem.toString())
        if(redays.text.toString().isNotEmpty()){
            retdatedup=redays.text.toString()

        }

        try {
            if (scroll2_category.selectedItemPosition == 0) {

                maincat = ""
            } else {
                maincat = (scroll2_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }


        if (scroll2_descrip.text.isNotEmpty()) {
            des = scroll2_descrip.text.toString()

        }

        try {
            if (scroll2_sub_category.selectedItemPosition == 0) {

                subcat = ""
            } else {
                subcat = (scroll2_sub_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }

        if (scroll2_fixed.isChecked == true) {
            fix = scroll2_fixed_price.text.toString()
            from = ""
            to = ""
        } else if (scroll2_from.isChecked == true) {
            fix = ""
            from = scroll2_price_from.text.toString()
            to = scroll2_price_to.text.toString()
        }

        //val desc = (descrip.text).toString()
        val status = (state.text.toString())
        val data = s(snm = sname, sid = sid, dur = sdur, sac = hsnT, sacdesc = hsndes, pr = pr, tx = Tax, igst = intax, cess = cess,
                cgst = Ctax, sgst = Stax, ttot = taxtot, ctot = css, gtot = Gtot, ecomm = payemp, ebns = paybonus, cry = currency,
                ptg = percentage, bval = per, gdr = gender, mctg = maincat, sctg = subcat, mctgkey = mctgkeys,
                sctgkey = sctgkeys, desc = des, fp = fix, fpr = from, tpr = to, status = status, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url,
                img3url = img3url, img4url = img4url, img5url = img5url, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh, retdate = retdatedup, makeupitem = makeupitemstr)
        //if ((did.text.toString()).isEmpty()) {

        val fix_check = intent.getBooleanExtra("fix_check", false).toString()
        val form_check = intent.getBooleanExtra("form_check", false).toString()
        if (fix_check.equals("true")) {
            fixed_error = "true"

        }

        if (from.isEmpty()) {
            from_error = "true"

        }
        if (to.isEmpty()) {
            to_error = "true"

        }


        if (textInputLayout.editText!!.text.isEmpty() || price.text.isEmpty()) {
            if (textInputLayout.editText!!.text.isEmpty()) {
                sname_error.visibility = View.VISIBLE

            }
            if (price.text.isEmpty()) {
                price_error.visibility = View.VISIBLE

            }
            if (gender.isEmpty()) {
                gen_error = "true"
            }
            if (maincat.isEmpty()) {
                main_error = "true"
            }
            if (subcat.isEmpty()) {
                sub_error = "true"
            }
            Toast.makeText(this@Attachments_Activity, "please fill required fields!", Toast.LENGTH_LONG).show()

        } else if (textInputLayout.editText!!.text.isNotEmpty() && price.text.isNotEmpty()) {


            if (newid.text.isEmpty() && id.text.isNotEmpty()) {
                save.isEnabled = false
                save_progress.visibility = View.VISIBLE


                var dd = myDb.getOne(id.text.toString())
                if (dd.moveToNext()) {
                    db = FirebaseFirestore.getInstance()
                    db.collection("${branchky}_service").document(id.text.toString())
                            .set(data)
                            .addOnSuccessListener {
                                Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                save_progress.visibility = android.view.View.GONE
                                try {
                                    pDialogs!!.dismiss()
                                } catch (e: Exception) {

                                }
                                val isInserted = myDb.updateData(upid, sname, sid, sdur, hsnT, hsndes, pr, Tax,
                                        intax, cess, Ctax, Stax, taxtot, css, Gtot, payemp, paybonus, currency, percentage,
                                        per, gender, maincat, subcat, des, fix, from, to, status, img1n, img2n, img3n, img4n, img5n,
                                        img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                        img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, mctgkeys, sctgkeys, retdatedup, makeupitemstr)


                                if (isInserted == true) {

                                    save_progress.visibility = View.GONE
                                } else {
                                    Toast.makeText(this, "Data not updated", Toast.LENGTH_SHORT).show()
                                }

                                if ((frmmakeup.isNotEmpty() || frmmakeup == "makeup")&&(bothcome.isEmpty())) {
                                    val data = Intent(applicationContext, Main_makeup::class.java)

                                    // Add the required data to be returned to the MainActivity


                                    // Set the resultCode to Activity.RESULT_OK to
                                    // indicate a success and attach the Intent
                                    // which contains our result data
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);

                                    startActivity(data)

                                    // With finish() we close the AnotherActivity to
                                    // return to MainActivity
                                    finish()

                                    Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()


                                }

                            }
                            .addOnFailureListener {
                                Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                save_progress.visibility = android.view.View.GONE
                            }

                } else {
                    if (net_status() == true) {

                        newid.setText(id.text.toString())
                        onStarClicked1()



                    }


                }
            } else {
                Toast.makeText(this, "please fill required fields", Toast.LENGTH_LONG).show()
            }
        }
    }


    fun deletedbpro() {
        if(((img1n != fn1edit)||(img2n != sn1edit)||(img3n != tn1edit)|| (img4n != fon1edit)||(img5n != fifn1edit))&&(net_status()==true)) {
            if ((id.text.isNotEmpty()) && (img1n != fn1edit)) {
                db.collection("product").document(id.text.toString())
                        .update("img1url", f1edit)
                        .addOnSuccessListener {
                            db.collection("product").document(id.text.toString())
                                    .update("img1n", fn1edit)
                                    .addOnCompleteListener {
                                        db.collection("product").document(id.text.toString())
                                                .update("img1urlhigh", f1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("product").document(id.text.toString())
                                                            .update("img1nhigh", fn1edithigh)

                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (img2n != sn1edit)) {

                db.collection("product").document(id.text.toString())
                        .update("img2url", s1edit)
                        .addOnSuccessListener {
                            db.collection("product").document(id.text.toString())
                                    .update("img2n", sn1edit)
                                    .addOnCompleteListener {
                                        db.collection("product").document(id.text.toString())
                                                .update("img2urlhigh", s1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("product").document(id.text.toString())
                                                            .update("img2nhigh", sn1edithigh)


                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (img3n != tn1edit)) {
                db.collection("product").document(id.text.toString())
                        .update("img3url", t1edit)
                        .addOnSuccessListener {
                            db.collection("product").document(id.text.toString())
                                    .update("img3n", tn1edit)
                                    .addOnCompleteListener {
                                        db.collection("product").document(id.text.toString())
                                                .update("img3urlhigh", t1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("product").document(id.text.toString())
                                                            .update("img3nhigh", tn1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (img4n != fon1edit)) {
                db.collection("product").document(id.text.toString())
                        .update("img4url", fo1edit)
                        .addOnSuccessListener {
                            db.collection("product").document(id.text.toString())
                                    .update("img4n", fon1edit)
                                    .addOnCompleteListener {
                                        db.collection("product").document(id.text.toString())
                                                .update("img4urlhigh", fo1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("product").document(id.text.toString())
                                                            .update("img4nhigh", fon1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (img5n != fifn1edit)) {
                db.collection("product").document(id.text.toString())
                        .update("img5url", fif1edit)
                        .addOnSuccessListener {
                            db.collection("product").document(id.text.toString())
                                    .update("img5n", fifn1edit)
                                    .addOnCompleteListener {
                                        db.collection("product").document(id.text.toString())
                                                .update("img5urlhigh", fif1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("product").document(id.text.toString())
                                                            .update("img5nhigh", fifn1edithigh)

                                                }
                                    }

                        }
            }
        }
        else{
            if(frmmakeup.isNotEmpty()||frmmakeup=="makeup"){
                val data = Intent(applicationContext,Main_makeup::class.java)

                // Add the required data to be returned to the MainActivity


                // Set the resultCode to Activity.RESULT_OK to
                // indicate a success and attach the Intent
                // which contains our result data
                overridePendingTransition( R.anim.slide_in_right, R.anim.slide_out_right);
                startActivity(data)


                // With finish() we close the AnotherActivity to
                // return to MainActivity
                finish()

                Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()



            }
        }
    }

    fun savepopup() {  //Save popup

        if ((sname.text.toString().isEmpty()|| price.text.isEmpty())) {
            if (sname.text.toString().isEmpty()) {
                sname_error.visibility = View.VISIBLE

            }
            if (price.text.isEmpty()) {
                price_error.visibility = View.VISIBLE

            }

            Toast.makeText(applicationContext,"Please fill required fields",Toast.LENGTH_SHORT).show()

        }


        /*if (retail.isChecked==false&&backbox.isChecked==false) {
            reterr.visibility = View.VISIBLE

            bkbxerr.visibility=View.VISIBLE


            Toast.makeText(applicationContext, "Please Check retail or backbar", Toast.LENGTH_SHORT).show()
        }*/
        if ((id.text == "") && (sname.text.toString().isNotEmpty() && price.text.isNotEmpty())) {
            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE)
            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialogs!!.setTitleText("Saving...")
            pDialogs!!.setCancelable(false)
            pDialogs!!.show();
            println("INSIDE SAVE POPUP ONSTAR"+id.text.toString())
            onStarClicked1pro() ///New makeup product insert
        } else if ((id.text.isNotEmpty())&&(sname.text.toString().isNotEmpty() && price.text.isNotEmpty()) ) {
            pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE)
            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialogs!!.setTitleText("Saving...")
            pDialogs!!.setCancelable(false)
            pDialogs!!.show();
            var npid = id.text.toString()
            var pid = (pid.text).toString()
            var pname = (sname.text).toString()
            var bcode = (bcodeid.text).toString()
            var pdes = (hsndes.text).toString()
            var orikys = branchky
            var weight = (vol.text).toString()
            var psac = (hsnT.text).toString()

            if (stockhand.text.toString().isNotEmpty()) {
                var stockonhand = (stockhand.text).toString()
                stkhand = stockonhand
            } else {

                stkhand = "0"
            }

            protypesave = "Wedding"


            var minstock = (minstock.text).toString()
            var maxstock = (maxstock.text).toString()
            var price = (price.text).toString()
            var taxable = Tax.isChecked.toString()
            var igst = (intax.text).toString()
            var cgst = (Ctax.text).toString()
            var sgst = (Stax.text).toString()
            var cess = (cess.text).toString()
            var taxtotal = (taxtot.text).toString()
            var cessval = (css.text).toString()
            var currency = currency.isChecked.toString()
            var percentage = percentage.isChecked.toString()
            var percentagevalue = (per.text).toString()
            var product_dec = (scroll2_descrip.text).toString()
            var mrP = (grosstot.text).toString()
            var cate = cate.selectedItem.toString()
            var manufacture = manu.selectedItem.toString()
            var ut = unitspinner.selectedItem.toString()
            var consold = paybonus.isChecked.toString()
            var comm = payemp.isChecked.toString()
            var status = (state.text).toString()
            val img1npro = img1n
            val img2npro = img2n
            val img3npro = img3n
            val img4npro = img4n
            val img5npro = img5n

            if(redays.text.toString().isNotEmpty()){
                retdatedup=redays.text.toString()

            }
            var ret = "false"
            var bkbr = "false"
            var returnables = "false"


println("INSIDE SAVE POPUP"+id.text.toString())

            if (img1url.isEmpty()) {

            }
            if (img1url.isNotEmpty()) {

                val img1url = img1url
                imgurls = img1url
            }

            val img2urlpro = img2url
            val img3urlpro = img3url
            val img4urlpro = img4url
            val img5urlpro = img5url

            val data = s1(p_id = pid, p_nm = pname, bc = bcode, desc = pdes, wg_vol = weight, hsn = psac, ctgy = cate,
                    mfr = manufacture, ut = ut, min_stk = minstock, price = price, mx_stk = maxstock, cn_sold = consold,
                    emp_com = comm, taxchk = taxable, igst = igst, cgst = cgst, sgst = sgst, cess = cess, taxtot = taxtotal,
                    cesstot = cessval, mrp = mrP, curency = currency, status = status, percentage = percentage, retail = ret, backbar = bkbr, percentageval = percentagevalue, product_desc = product_dec,
                    stock_hand = stkhand, img1n = img1npro, img2n = img2npro, img3n = img3npro, img4n = img4npro, img5n = img5npro, img1url = imgurls, img2url = img2urlpro, img3url = img3urlpro,
                    img4url = img4urlpro, img5url = img5urlpro, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                    img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh, orikys = orikys, supp_key = suppky, supp_name = suppname, protype = protypesave, returnable = returnables, returnableday = retdatedup,makeupitem = makeupitemstr)



                /*  pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialogs!!.setTitleText("Saving...")
            pDialogs!!.setCancelable(false)
            pDialogs!!.show();*/




                                        var dd=myDb1.getOne(id.text.toString())
                                        if(dd.moveToNext()) {
                                            val db = FirebaseFirestore.getInstance()


                                            db.collection("product").document(id.text.toString())

                                                    .set(data)
                                                    .addOnSuccessListener {
                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("$branchky", stkhand)
                                                        db.collection("product").document(id.text.toString())
                                                                .update(map)
                                                                .addOnCompleteListener {
                                                                    val isInserted = myDb1.updatedata(npid, pid, pname, bcode, pdes, weight, psac, cate, manufacture, ut, minstock, price, maxstock,
                                                                            consold, comm, taxable, igst, cgst, sgst, cess, taxtotal, cessval, mrP, currency, status, percentage, percentagevalue, product_dec,
                                                                            stkhand, img1n, img2n, img3n, img4n, img5n, imgurls, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                                                            img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys, ret, bkbr, protypesave, returnables, retdatedup, makeupitemstr)

                                                                    if (isInserted == true) {
                                                                        Toast.makeText(this, "Saving...", Toast.LENGTH_SHORT).show()
                                                                    } else {
                                                                    }

                                            val database = FirebaseDatabase.getInstance()

                                            if (stockhand.text.toString().isNotEmpty()) {
                                                val service_access = SessionManagement(this)
                                                val user = service_access.userDetails

                                                // name
                                                val name = user[SessionManagement.KEY_NAME]
                                                brkey = name.toString()
                                                for (i in 0 until brnchkeys.size) {
                                                    if (brnchkeys[i].toString() == brkey) {
                                                        println("BRANCH KEY" + brkey)
                                                        println("BRANCH KEY ARRAY" + brnchkeys[i])

                                                        println("STOCK HAND" + stockhand.text.toString())
                                                        println("ID" + id.text.toString())

                                                        var ad = brnchkeys[i]

                                                        val map = mutableMapOf<String, Any?>()
                                                        map.put("$ad", stockhand.text.toString())
                                                        db.collection("product").document(id.text.toString())
                                                                .set(map, SetOptions.merge())


                                                    } else {

                                                        val database = FirebaseDatabase.getInstance()
                                                        val myRef = database.getReference(id.text.toString() + "_" + brnchkeys[i])

                                                        val messageListener = object : ValueEventListener {

                                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                if (dataSnapshot.exists()) {

                                                                    val message = dataSnapshot.value

                                                                    var ads = brnchkeys[i]

                                                                    val map = mutableMapOf<String, Any?>()

                                                                    map.put("$ads", message)
                                                                    db.collection("product").document(id.text.toString())
                                                                            .update(map)

                                                                }
                                                            }

                                                            override fun onCancelled(databaseError: DatabaseError) {
                                                                // Failed to read value
                                                            }
                                                        }

                                                        myRef!!.addValueEventListener(messageListener)


                                                    }

                                                }
                                            } else {

                                                stkhand = "0"
                                            }

                                            if (idsmy.text.toString().isNotEmpty()) {
                                                val myRef = database.getReference(idsmy.text.toString() + "_" + branchky)

                                                myRef.setValue(stockhand.text.toString())
                                            } else {
                                                val myRef = database.getReference(id.text.toString() + "_" + branchky)

                                                myRef.setValue(stockhand.text.toString())
                                            }




                                            if (idsmy.text.toString().isNotEmpty()) {
                                                val myRef = database.getReference(idsmy.text.toString() + "_" + branchky)

                                                myRef.setValue(stockhand.text.toString())
                                            } else {
                                                val myRef = database.getReference(id.text.toString() + "_" + branchky)

                                                myRef.setValue(stockhand.text.toString())
                                            }

                                        }
                                                .addOnSuccessListener {


                                                    Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()
                                                    try {
                                                        pDialogs!!.dismiss()
                                                    } catch (e: Exception) {

                                                    }
                                                    if((frmmakeup.isNotEmpty()||frmmakeup=="makeup")){
                                                        val data = Intent(applicationContext,Main_makeup::class.java)

                                                        // Add the required data to be returned to the MainActivity


                                                        // Set the resultCode to Activity.RESULT_OK to
                                                        // indicate a success and attach the Intent
                                                        // which contains our result data
                                                        overridePendingTransition( R.anim.slide_in_right, R.anim.slide_out_right);
                                                        startActivity(data)


                                                        // With finish() we close the AnotherActivity to
                                                        // return to MainActivity
                                                        finish()





                                                    }
                                                    /*   if(suppcome.isEmpty()){

                                                    val o=Intent(this@Attachments_Activity,MainProductlistActivity::class.java)

                                                    o.putExtra("frm_main","main")


                                                    o.putExtra("addpro",addpro)
                                                    o.putExtra("editpro",editepro)
                                                    o.putExtra("deletepro",deletepro)
                                                    o.putExtra("viewpro",viewpro)
                                                    o.putExtra("importpro",importpro)
                                                    o.putExtra("exportpro",exportpro)
                                                    o.putExtra("changestock", stockin_hand)
                                                    o.putExtra("skey",branchky)

                                                    startActivity(o)
                                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                    finish()
                                                }*/

                                                    /* else if(suppcome.isNotEmpty()&&suppcome=="supplier"){
                                                    val data = Intent(applicationContext,SupplierSecondmain::class.java)

                                                    // Add the required data to be returned to the MainActivity
                                                    data.putExtra("proky", Arrays.toString(prosave_key))

                                                    // Set the resultCode to Activity.RESULT_OK to
                                                    // indicate a success and attach the Intent
                                                    // which contains our result data
                                                    setResult(Activity.RESULT_OK, data)

                                                    // With finish() we close the AnotherActivity to
                                                    // return to MainActivity
                                                    finish()


                                                    Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()

                                                }*/

                                                }


                                    }

                                    .addOnFailureListener {
                                        Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show()
                                        try {
                                            /*pDialogs!!.dismiss()*/
                                        } catch (e: Exception) {

                                        }
                                    }

                                        }
                                        else {
                                            if(net_status()==true) {

                                                idsmy.setText(id.text.toString())
                                                onStarClicked1pro()

                                            }
                                            else{
                                                Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

                                            }


                                        }





                println("INSIDE ELESE OF ELSE SAVE POPUP")
              /*  if (idsmy.text.isEmpty()) {
                    Toast.makeText(applicationContext, "Please fill required fields", Toast.LENGTH_SHORT).show()
                }
            }*/
        }
    }



    //Save action

    fun save(){
        if (fix.isEmpty()||from.isEmpty() || to.isEmpty()){
            val fix_check=intent.getBooleanExtra("fix_check",false).toString()
            val form_check=intent.getBooleanExtra("form_check",false).toString()
            if (fix_check.equals("true")){

            }
            if (form_check.equals("true")){
                if (from.isEmpty()) {

                }
                if (to.isEmpty()){

                }
            }
        }
        if ((sname.text.toString().isEmpty()|| price.text.isEmpty())) {
            if (sname.text.toString().isEmpty()) {
                sname_error.visibility = View.VISIBLE

            }
            if (price.text.isEmpty()) {
                price_error.visibility = View.VISIBLE

            }
            if (gender.isEmpty()){
                gen_error="true"
            }
            if (maincat.isEmpty()){
                main_error="true"
            }
            if (subcat.isEmpty()){
                sub_error="true"
            }

        } else if (sname.text.toString().isNotEmpty() && price.text.isNotEmpty()) {

            if ((newid.text.isNotEmpty() && id.text.isEmpty())&&(net_status()==true)) {
                pDialogs = SweetAlertDialog(this@Attachments_Activity, SweetAlertDialog.PROGRESS_TYPE)
                pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialogs!!.setTitleText("Saving...")
                pDialogs!!.setCancelable(false)
                pDialogs!!.show();
                onStarClicked1()
            }
            else if((id.text.toString().isNotEmpty())&&(net_status()==true)){
                update()

            }
            else{
                Toast.makeText(this@Attachments_Activity, "No Internet connection", Toast.LENGTH_LONG).show()

            }

        }
        else {
            Toast.makeText(this@Attachments_Activity, "please fill required fields!", Toast.LENGTH_LONG).show()
            println("fix.isNotEmpty()fix.isEmpty()" + fix)
        }
    }


    //Preview prices from-to validation alert
    fun poplow() {
        if(scroll2_price_from.text.toString().isNotEmpty()&&scroll2_price_to.text.toString().isNotEmpty()) {
            if ((scroll2_price_from.text.toString().toFloat() >= scroll2_price_to.text.toString().toFloat())) {
                val builder = AlertDialog.Builder(this@Attachments_Activity)
                with(builder) {
                    setTitle("Price details not valid")
                    setMessage("Example: 500-1000")
                    setCancelable(false)
                    setPositiveButton("Ok") { dialog, state ->
                        dialog.dismiss()
                        scroll2_price_to.requestFocus()
                        scroll2_price_from.requestFocus()


                    }
                    val dialog = builder.create()
                    dialog.show()
                }


            }
        }

    }
    fun popup(st:String){
        SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                .setTitleText("Access Denied!")
                .setContentText("You dont have Access to $st")
                .setConfirmText("ok")
                .setConfirmClickListener(null)
                .show()
        /*val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()*/
    }
    fun net_status():Boolean{  // Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

    companion object {

         //Listens internet status whether net is on/off.


        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout?=null
        private var consermaindis: ConstraintLayout?=null
        private var retailchkdis:CheckBox?=null
        private var rentalchkdis:CheckBox?=null
        private var retquesdis:CheckBox?=null
        private var firstreldis: RelativeLayout?=null
        private var secreldis: RelativeLayout?=null
        private var texreldis: RelativeLayout?=null
        private var inreldis: RelativeLayout?=null
        private var catreldis: RelativeLayout?=null
        private var desreldis: RelativeLayout?=null
        private var pricereldis: RelativeLayout?=null
        private var lastreldis: RelativeLayout?=null
        private var scrollView2dis: ScrollView?=null

        private var scroll2_gallerydis: ImageButton?=null
        var makeupitemstr=String()
        private var editdis: ImageButton?=null
        private var constraintLayout3dis: ConstraintLayout?=null
        /*    private var relativeLayout2dis:RelativeLayout?=null

        private var lineardis:LinearLayout?=null
        private var cambackdis:ImageView?=null*/
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                  /// if connection is off then all views becomes disable

                relativeslayoutdis!!.visibility=View.VISIBLE
                constraintLayout3dis!!.visibility=View.VISIBLE
                scroll2_gallerydis!!.isEnabled=false


                retailchkdis!!.isEnabled=false
                rentalchkdis!!.isEnabled=false
                retquesdis!!.isEnabled=false
                /* firstreldis
                 secreldis!!.
                 texreldis!!.
                 inreldis!!.
                 catreldis!!.
                 desreldis!!.
                 pricereldis!!.
                 lastreldis!!.*/


                for (i  in 0 until consermaindis!!.getChildCount()) {
                    val child = consermaindis!!.getChildAt(i);
                    child.setEnabled(false);
                }









/*
                relativeLayout2dis!!.setBackgroundColor(Color.parseColor("#96ffffff"))

                lineardis!!.setBackgroundColor(Color.parseColor("#96ffffff"))
                cambackdis!!.setBackgroundColor(Color.parseColor("#96ffffff"))*/


                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }

            }
            else
            {
                                 /// if connection is off then all views becomes enabled

                constraintLayout3dis!!.visibility=View.GONE
                relativeslayoutdis!!.visibility=View.GONE

                if((editdis!!.visibility==View.GONE)) {

                    rentalchkdis!!.isEnabled = true
                    retquesdis!!.isEnabled = true
                    scroll2_gallerydis!!.isEnabled = true
                }
                if((editdis!!.visibility==View.GONE)&&(makeupitemstr!="Flowers"&&makeupitemstr!="FLOWERS")){

                    retailchkdis!!.isEnabled=true
                }


                for (i  in 0 until consermaindis!!.getChildCount()) {
                    val child = consermaindis!!.getChildAt(i);
                    child.setEnabled(true);
                }


                /* for (i in 0 until consermaindis!!.getChildCount()) {
                     val child = consermaindis!!.getChildAt(i);
                     child.setEnabled(true);
                 }

                 for (i in 0 until firstreldis!!.getChildCount()) {
                     val child = firstreldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }

                 for (i in 0 until secreldis!!.getChildCount()) {
                     val child = secreldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }
                 for (i in 0 until texreldis!!.getChildCount()) {
                     val child = texreldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }

                 for (i in 0 until inreldis!!.getChildCount()) {
                     val child = inreldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }
                 for (i in 0 until catreldis!!.getChildCount()) {
                     val child = catreldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }
                 for (i in 0 until desreldis!!.getChildCount()) {
                     val child = desreldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }
                 for (i in 0 until pricereldis!!.getChildCount()) {
                     val child = pricereldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }
                 for (i in 0 until lastreldis!!.getChildCount()) {
                     val child = lastreldis!!.getChildAt(i);
                     child.setEnabled(true);
                 }*/


/*}
                relativeLayout2dis!!.setBackgroundColor(Color.parseColor("#eceff1"))

                lineardis!!.setBackgroundColor(Color.parseColor("#32ffffff"))
                cambackdis!!.setBackgroundColor(Color.parseColor("#263238"))*/
            }
        }
    }
}
