package com.example.vinitas.inventory_app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.print.PdfView
import android.print.PrintAttributes
import android.print.PrintManager
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.app.NotificationCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import kotlinx.android.synthetic.main.activity_receive_pdf.*
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil

import dmax.dialog.SpotsDialog

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
@RequiresApi(Build.VERSION_CODES.LOLLIPOP)

class MainReceivePdf : AppCompatActivity() {

    private var addtrans: String = ""
    private var editetrans: String = ""
    private var deletetrans: String = ""
    private var viewtrans: String = ""
    private var transfertrans: String = ""
    private var exporttrans: String = ""
    private var sendtrans = String()


    private var addtransano: String = ""
    private var editetransano: String = ""
    private var deletetransano: String = ""
    private var viewtransano: String = ""
    private var transfertransano: String = ""
    private var exporttransano: String = ""
    private var sendtransano = String()

    private var viewrec: String = ""
    private var addrec: String = ""
    private var deleterec: String = ""
    private var editrec: String = ""
    private var transferrec: String = ""
    private var exportrec: String = ""
    private var sendstrec: String = ""


    var names = String()
    var addressnames = String()
    var datestk = String()
    var descstk = String()
    var idstk = String()
    var iddbs = String()
    var smlistidss = String()
    var idli = String()
    var tallysend = String()
    var igstdiv = String()
    var receiv = String()

    //VALUES FOR TAX DETAILS

    var igsted = String()
    var igtot = String()
    var cestot = String()
    var grosstot = String()
    var cgstt = String()
    var sgstt = String()
    var cesst = String()
    var bridds = String()
    var grosstt = String()
    var singrosstot = arrayOf<String>()

    var sendreq=String()
    var htmlDocument= String()

    var listlistener = String()
    var descriplistenersave = String()

    var pronameArray = arrayOf<String>()
    var hsnArray = arrayOf<String>()
    var manufacturerArray = arrayOf<String>()
    var barcodeArray = arrayOf<String>()
    var quantityArray = arrayOf<String>()
    var priceArray = arrayOf<String>()
    var totArray = arrayOf<String>()
    var cessArray = arrayOf<String>()
    var keyArray = arrayOf<String>()
    var igstArray = arrayOf<String>()
    var igsttotArray = arrayOf<String>()
    var cesstotalArray = arrayOf<String>()
    var tallyArray = arrayOf<String>()
    var receivedArray = arrayOf<String>()
    var receivedArraycpy = arrayOf<String>()

    var imageArray = arrayOf<String>()
    var oriproArray = arrayOf<String>()
    var recon = String()
    var reccnt = String()

    var downstatus = String()
    var tt = arrayOf<String>()

    var descriplistener = String()
    var reccntlistener = String()
    var recdatelistener = String()
    var reconlistener = String()


    internal var intentFilter: IntentFilter? = null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private var myWebView: WebView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receive_pdf)

        val webView = findViewById<WebView>(R.id.webview) as WebView

        myWebView = webView






        net_status()//Check net status

//Listens internet changing movements


        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@MainReceivePdf) > 0) {

        } else {

            Toast.makeText(applicationContext, "You are offline", Toast.LENGTH_SHORT).show()
        }


        //Define No connection view when inetrnet connection is off.

        relativeslayoutdis = findViewById(R.id.relativeslayout)
        constraintLayout3dis = findViewById(R.id.constraintLayout3)
        cont = findViewById<ConstraintLayout>(R.id.container)


        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi = intent.getStringExtra("viewtrans")
        val tran = intent.getStringExtra("transfertrans")
        val ex = intent.getStringExtra("exporttrans")
        sendtrans = intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER" + addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano = intent.getStringExtra("viewtransano")
        val tranano = intent.getStringExtra("transfertransano")
        val exano = intent.getStringExtra("exporttransano")
        sendtransano = intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec = intent.getStringExtra("viewrec")
        val tranrec = intent.getStringExtra("transferrec")
        val exrec = intent.getStringExtra("exportrec")
        val sendrec = intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }


        //Get details from (ScrollStkOneActivity)

        val bundle = intent.extras
        var frm = bundle!!.get("fromreceive").toString()


        var a = bundle.get("receivepnm") as Array<String>
        println(a)
        val dsy = bundle.get("receivephsn") as Array<String>
        val ly = bundle.get("receivepmanu") as Array<String>
        val fy = bundle.get("receivebarcode") as Array<String>
        val gy = bundle.get("receive_quan") as Array<String>
        val hy = bundle.get("receiveprice") as Array<String>
        val ky = bundle.get("receive_tot") as Array<String>
        val my = bundle.get("receive_cessup") as Array<String>
        val ny = bundle.get("receive_igst") as Array<String>
        val oy = bundle.get("receive_igsttotal") as Array<String>
        val py = bundle.get("receive_cesstotarray") as Array<String>
        val iddd = bundle.get("receive_idsofli") as Array<String>
        val tally = bundle.get("tallyarray") as Array<String>
        val received = bundle.get("receivedarray") as Array<String>
        val receivedcpy = bundle.get("receivedarraycpy") as Array<String>

        var oripro = bundle.get("oriproarray") as Array<String>

        try {
            val immy = bundle.get("image") as Array<String>
            tt = immy.clone()
        } catch (e: Exception) {

        }


        pronameArray = a.clone()
        hsnArray = dsy.clone()
        manufacturerArray = ly.clone()
        barcodeArray = fy.clone()
        quantityArray = gy.clone()
        priceArray = hy.clone()
        totArray = ky.clone()
        cessArray = my.clone()
        igstArray = ny.clone()
        igsttotArray = oy.clone()
        cesstotalArray = py.clone()
        keyArray = iddd.clone()
        tallyArray = tally.clone()
        receivedArray = received.clone()
        receivedArraycpy = receivedcpy.clone()

        oriproArray = oripro.clone()

        try {
            imageArray = tt.clone()
        } catch (e: Exception) {

        }


        /*  val namebr = intent.getStringExtra("otherst_branch")
          val datestrec = bundle.get("receive_sstkdate")
          val smlistid = intent.getStringExtra("otherst_smlistids")
          val locbr = intent.getStringExtra("otherst_address")
          val stockid = intent.getStringExtra("receive_ssstockid")
          val stockdesc = intent.getStringExtra("receive_ssstkdesc")
          val iddb = intent.getStringExtra("receive_idofdb")*/





        try {

            val stockid = intent.getStringExtra("receive_ssstockid")
            idstk = stockid


            val namebr = intent.getStringExtra("otherst_branch")

            names = namebr

            val locbr = intent.getStringExtra("otherst_address")
            addressnames = locbr
        } catch (e: Exception) {

        }


        try{
sendreq=intent.getStringExtra("sendreq")
        }
        catch (e:Exception){

        }


        try {
            val cess = intent.getStringExtra("cesstot")
            cesst = cess

            val cgst = intent.getStringExtra("cgsttot")
            cgstt = cgst

            val sgst = intent.getStringExtra("sgsttot")
            sgstt = sgst

            val grosst = intent.getStringExtra("grosstot")
            grosstt = grosst
            println("GROSS TOT" + grosstt)

            val stkrecon = intent.getStringExtra("stkrecon")
            recon = stkrecon

            val stkreccnt = intent.getStringExtra("stkreccnt")
            reccnt = stkreccnt

            println("Names" + names)
        } catch (e: Exception) {
            val grosst = intent.getStringExtra("grosstot")
            grosstt = grosst
            println("GROSS TOT" + grosstt)

            val stkrecon = intent.getStringExtra("stkrecon")
            recon = stkrecon

            val stkreccnt = intent.getStringExtra("stkreccnt")
            reccnt = stkreccnt
        }

        /*  val kybrnch = intent.getStringExtra("keybrnch")

        brkey = kybrnch*/



        try{
            descriplistener=intent.getStringExtra("descriplistener")
            reccntlistener=intent.getStringExtra("reccntlistener")
            recdatelistener=intent.getStringExtra("recdatelistener")
            reconlistener=intent.getStringExtra("reconlistener")
        }
        catch (e:Exception){

        }

        try{

        }
        catch (e:Exception){

        }


        try {
            listlistener = intent.getStringExtra("listlistener")

        } catch (e: Exception) {

        }
        try {
            descriplistenersave = intent.getStringExtra("descriplistenersave")
        } catch (e: Exception) {

        }




        try {
            val iddb = intent.getStringExtra("receive_idofdb")
            iddbs = iddb


            val branid = intent.getStringExtra("brid")
            bridds = branid


            val stockdesc = intent.getStringExtra("receive_ssstkdesc")
            descstk = stockdesc


            val datest = intent.getStringExtra("receive_sstkdate")
            datestk = datest
            println("address" + addressnames)
            println("ID" + idstk)
        } catch (e: Exception) {


            val stockdesc = intent.getStringExtra("receive_ssstkdesc")
            descstk = stockdesc


            val datest = intent.getStringExtra("receive_sstkdate")
            datestk = datest

        }





        //webView.loadDataWithBaseURL(null, htmlDocument, "text/HTML", "UTF-8", null)


        myWebView = webView


        addData()

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView,
                                                  url: String): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                //createWebPrintJob(view)

                if(sendreq=="send"){
                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Receive Stock"
                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    var f = idstk + "_receive stock"

                    var y = f + ".pdf"
                    val file = File(dir, y)


                    val progressDialog = ProgressDialog(this@MainReceivePdf)
                    progressDialog.setMessage("Please wait")
                    progressDialog.show()
                    try {
                        PdfView.createWebPrintJob(this@MainReceivePdf, webView, file, y, object : PdfView.Callback {

                            override fun success(path: String) {
                                progressDialog.dismiss()
                                val builder = android.app.AlertDialog.Builder(this@MainReceivePdf)
                                with(builder) {
                                    setTitle("Are you sure?")
                                    setMessage("Are you sure want to send?")
                                    setPositiveButton("Send") { dialog, whichButton ->
                                       sendMail(path)
                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            }

                            override fun failure() {
                                progressDialog.dismiss()

                            }
                        })
                    }
                    catch (e:Exception){
                        Toast.makeText(applicationContext,"Already exist",Toast.LENGTH_SHORT).show()
                    }


                }

                myWebView = null
            }
        }

        pdf.setOnClickListener {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer"
            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            var f = idstk + "_receive stock"

            var y = f + ".pdf"




            val file = File(dir, y)
            val progressDialog = ProgressDialog(this@MainReceivePdf)
            progressDialog.setMessage("Please wait")
            progressDialog.show()
            try {
                PdfView.createWebPrintJob(this@MainReceivePdf, webView, file, y, object : PdfView.Callback {

                    override fun success(path: String) {
                        progressDialog.dismiss()
                        val builder = android.app.AlertDialog.Builder(this@MainReceivePdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->
                                PdfView.openPdfFile(this@MainReceivePdf, path)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }

                    override fun failure() {
                        progressDialog.dismiss()

                    }
                })
            }
            catch (e:Exception){
                Toast.makeText(applicationContext,"Already exist",Toast.LENGTH_SHORT).show()
            }






            /*   val file = File(dir, y)
               val progressDialog = ProgressDialog(this@RequestActivityPdf)
               progressDialog.setMessage("Please wait")
               progressDialog.show()
               PdfView.createWebPrintJob(this@RequestActivityPdf, webView, file, y, object : PdfView.Callback {

                   override fun success(path: String) {
                       progressDialog.dismiss()
                       val builder = android.app.AlertDialog.Builder(this@RequestActivityPdf)
                       with(builder) {
                           setTitle("File downloaded")
                           setMessage("Do you want to open a file?")
                           setPositiveButton("Open") { dialog, whichButton ->
                               PdfView.openPdfFile(this@RequestActivityPdf, path)
                           }
                           setNegativeButton("Cancel") { dialog, whichButton ->
                               //showMessage("Close the game or anything!")
                               dialog.dismiss()
                           }

                           // Dialog
                           val dialog = builder.create()

                           dialog.show()
                       }
                   }

                   override fun failure() {
                       progressDialog.dismiss()

                   }
               })*/
            /*} else {

                val file = File(dir, y)
                val progressDialog = ProgressDialog(this@RequestActivityPdf)
                progressDialog.setMessage("Please wait")
                progressDialog.show()
                PdfView.createWebPrintJob(this@RequestActivityPdf, webView, file, y, object : PdfView.Callback {

                    override fun success(path: String) {
                        progressDialog.dismiss()
                        val builder = android.app.AlertDialog.Builder(this@RequestActivityPdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->
                                PdfView.openPdfFile(this@RequestActivityPdf, path)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }

                    }

                    override fun failure() {
                        progressDialog.dismiss()

                    }
                })
            }*/
        }

        back.setOnClickListener {

            //Back action

            val o= Intent(this@MainReceivePdf,ScrollStkOneActivity::class.java)

            o.putExtra("otheruprenm",a)
            o.putExtra("fromreceive","frmpdfreceive")
            o.putExtra("otherupremanu",ly)
            o.putExtra("otheruprekey",iddd)
            o.putExtra("otheruprehsn",dsy)
            o.putExtra("otherupreprice",hy)
            o.putExtra("otheruprequan",gy)
            o.putExtra("otheruprebc",fy)
            o.putExtra("otherupretotal",ky)
            o.putExtra("otheruprecess",my)
            o.putExtra("otherupreimmg",tt)
            o.putExtra("otheroriproid", oripro)

            o.putExtra("otherupbranch",names)
            o.putExtra("otherupaddress",addressnames)
            o.putExtra("otherupredate",datestk)
            o.putExtra("otherupredesc",descstk)
            o.putExtra("otheruprestkid",idstk)
            o.putExtra("otherupreiddb",iddbs)
            o.putExtra("recon",recon)
            o.putExtra("reccnt",reccnt)
            o.putExtra("otherupreiddofli",idli)
            o.putExtra("otherreigst",ny)
            o.putExtra("otherreigst_total",oy)
            o.putExtra("othertally",tally)
            o.putExtra("otherreceive",received)
            o.putExtra("otherreceivecpy",receivedcpy)
            o.putExtra("otherrecesstotal",py)
            o.putExtra("otherbrid",bridds)
            o.putExtra("listlistener",listlistener)
            o.putExtra("descriplistenersave",descriplistenersave)



            o.putExtra("viewtrans", viewtrans)
            o.putExtra("addtrans", addtrans)
            o.putExtra("edittrans", editetrans)
            o.putExtra("deletetrans", deletetrans)
            o.putExtra("transfertrans", transfertrans)
            o.putExtra("exporttrans", exporttrans)
            o.putExtra("sendtrans", sendtrans)


            o.putExtra("viewtransano", viewtransano)
            o.putExtra("addtransano", addtransano)
            o.putExtra("edittransano", editetransano)
            o.putExtra("deletetransano", deletetransano)
            o.putExtra("transfertransano", transfertransano)
            o.putExtra("exporttransano", exporttransano)
            o.putExtra("sendtransano", sendtransano)

            o.putExtra("viewrec", viewrec)
            o.putExtra("addrec", addrec)
            o.putExtra("deleterec", deleterec)
            o.putExtra("editrec", editrec)
            o.putExtra("transferrec", transferrec)
            o.putExtra("exportrec", exportrec)
            o.putExtra("sendstrec",sendstrec)

            o.putExtra("cgsttot",cgstt)
            o.putExtra("sgsttot", sgstt)
            o.putExtra("cesstot", cesst)
            o.putExtra("grosstot", grosstt)

            o.putExtra("descriplistener",descriplistener)
            o.putExtra("reccntlistener",reccntlistener)
            o.putExtra("recdatelistener",recdatelistener)
            o.putExtra("reconlistener",reconlistener)

            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }

    }

    fun net_status(): Boolean {       //Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected = false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this, "No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

    companion object {

        //Listens internet status whether net is on/off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout? = null


        private val log_str: String? = null


        fun addLogText(log: String?) {
            if (log == "NOT_CONNECT") {

                /// if connection is off then all views becomes disable

                constraintLayout3dis!!.visibility = View.VISIBLE
                relativeslayoutdis!!.visibility = View.VISIBLE

                for (i in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }


            } else {


                /// if connection is off then all views becomes enabled

                constraintLayout3dis!!.visibility = View.GONE

                relativeslayoutdis!!.visibility = View.GONE
                for (i in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }


            }
        }
    }


    /* pdf.setOnClickListener {


            //Create local path storage for this pdf

            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            var f = idstk + "_receive stock"

            var y = f + ".pdf"

            val file = File(dir, y)

            if (file.exists()) {  //If file already exist alert



                val builder = AlertDialog.Builder(this)
                with(builder) {
                    setTitle("File Already Exist")
                    setMessage("Do you want to overwrite the existing file?")





                    setPositiveButton("Yes") { dialog, whichButton -> //Overwrite the exist pdf



                        val dialo = SpotsDialog(context, "Downloading pdf...")

                        dialo.show();


                        val timer2 = Timer()
                        timer2.schedule(object : TimerTask() {
                            override fun run() {

                                createandDisplayPdf(idstk, datestk, names, addressnames, descstk, reccnt,recon, cesst, grosstt) //Pdf write fiunction

                                if (downstatus == "success") {
                                    val mBuilder = NotificationCompat.Builder(this@MainReceivePdf)
                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                    val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer")
                                    intent.setDataAndType(uri, "application/pdf")  //Open pdf with pdf reader

                                    val pendingIntent = PendingIntent.getActivity(this@MainReceivePdf, 0, intent, 0)
                                    mBuilder.setContentIntent(pendingIntent)


                                    val mNotifyManager = this@MainReceivePdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                                    //Notification alert

                                    mBuilder.setContentTitle(idstk + "_receive stock.pdf")
                                    mBuilder.setContentText("Downloaded")
                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                                    mBuilder.setProgress(100, 100, false)
                                    mNotifyManager.notify(0, mBuilder.build());
                                }

                                dialo.dismiss()

                                timer2.cancel() //this will cancel the timer of the system
                            }


                        }, 3000)

                        val handler = Handler()
                        handler.postDelayed({
                            println("INSIDE IF" + a)
                            if (file.exists()) {
                                val builder = AlertDialog.Builder(this@MainReceivePdf)
                                with(builder) {
                                    setTitle("File downloaded")
                                    setMessage("Do you want to open a file?")
                                    setPositiveButton("Open") { dialog, whichButton ->
                                        var f = idstk + "_receive stock"


                                        var y = f + ".pdf"
                                        viewPdf("Stock Transfer", y)
                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            } else {

                            }
                        }, 4000)

                    }

                    setNegativeButton("NO") { dialog, whichButton ->
                        //showMessage("Close the game or anything!")
                        dialog.dismiss()
                    }

                    // Dialog
                    val dialog = builder.create()

                    dialog.show()
                }


                *//* val u = findViewById<ScrollView>(R.id.ss) as ScrollView
        val zx=findViewById<HorizontalScrollView>(R.id.hh) as HorizontalScrollView
        val yx=findViewById<RelativeLayout>(R.id.relative) as RelativeLayout
        val cx=findViewById<TableLayout>(R.id.table) as TableLayout

        val totalHeight = cx.height+u.height
        val totalWidth = cx.width+u.width

        val b = getBitmapFromView(yx, totalHeight, totalWidth)
        *//**//*  val share = Intent(Intent.ACTION_SEND)
              share.type = "image/jpeg"*//**//*
            val bytes = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 100, bytes)

            val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
            try {
                f.createNewFile()
                val fo = FileOutputStream(f)
                fo.write(bytes.toByteArray())
                imageToPDF()

            } catch (e: IOException) {
                e.printStackTrace()
            }*//*


            } else {

                val dialo = SpotsDialog(this, "Downloading pdf...")

                dialo.show();


                val timer2 = Timer()
                timer2.schedule(object : TimerTask() {
                    override fun run() {

                        createandDisplayPdf(idstk, datestk, names, addressnames, descstk, reccnt,recon, cesst, grosstt)  //Pdf write fiunction
                        if (downstatus == "success") {
                            val mBuilder = NotificationCompat.Builder(this@MainReceivePdf)
                            val intent = Intent(Intent.ACTION_CHOOSER)
                            val uri = Uri.parse(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer")
                            intent.setDataAndType(uri, "application/pdf")   //Open pdf with pdf reader

                            val pendingIntent = PendingIntent.getActivity(this@MainReceivePdf, 0, intent, 0)
                            mBuilder.setContentIntent(pendingIntent)


                            val mNotifyManager = this@MainReceivePdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;



                            mBuilder.setContentTitle(idstk + "_receive stock.pdf")
                            mBuilder.setContentText("Downloaded")
                            mBuilder.setSmallIcon(R.drawable.ic_logo)
                            mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                            mBuilder.setProgress(100, 100, false)
                            mNotifyManager.notify(0, mBuilder.build());
                        }

                        dialo.dismiss()
                        var b = "null"

                        timer2.cancel() //this will cancel the timer of the system
                    }


                }, 3000)

                val handler = Handler()
                handler.postDelayed({
                    println("INSIDE IF" + a)
                    if (file.exists()) {
                        val builder = AlertDialog.Builder(this@MainReceivePdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->

                                var f = idstk + "_receive stock"


                                var y = f + ".pdf"
                                viewPdf("Stock Transfer", y)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    } else {

                    }

                }, 4000)
            }
        }*/


    override fun onBackPressed() {

        val bundle = intent.extras
        var frm = bundle!!.get("fromreceive").toString()


        var a = bundle.get("receivepnm") as Array<String>
        println(a)
        val dsy = bundle.get("receivephsn") as Array<String>
        val ly = bundle.get("receivepmanu") as Array<String>
        val fy = bundle.get("receivebarcode") as Array<String>
        val gy = bundle.get("receive_quan") as Array<String>
        val hy = bundle.get("receiveprice") as Array<String>
        val ky = bundle.get("receive_tot") as Array<String>
        val my = bundle.get("receive_cessup") as Array<String>
        val ny = bundle.get("receive_igst") as Array<String>
        val oy = bundle.get("receive_igsttotal") as Array<String>
        val py = bundle.get("receive_cesstotarray") as Array<String>
        val iddd = bundle.get("receive_idsofli") as Array<String>
        val tally = bundle.get("tallyarray") as Array<String>
        val received = bundle.get("receivedarray") as Array<String>
        val receivedcpy = bundle.get("receivedarraycpy") as Array<String>

        var oripro = bundle.get("oriproarray") as Array<String>

        try {
            val immy = bundle.get("image") as Array<String>
            tt = immy.clone()
        } catch (e: Exception) {

        }


        pronameArray = a.clone()
        hsnArray = dsy.clone()
        manufacturerArray = ly.clone()
        barcodeArray = fy.clone()
        quantityArray = gy.clone()
        priceArray = hy.clone()
        totArray = ky.clone()
        cessArray = my.clone()
        igstArray = ny.clone()
        igsttotArray = oy.clone()
        cesstotalArray = py.clone()
        keyArray = iddd.clone()
        tallyArray = tally.clone()
        receivedArray = received.clone()
        receivedArraycpy = receivedcpy.clone()

        oriproArray = oripro.clone()
        try {
            imageArray = tt.clone()
        } catch (e: Exception) {

        }
        val o = Intent(this@MainReceivePdf, ScrollStkOneActivity::class.java)
        o.putExtra("otheruprenm", a)
        o.putExtra("fromreceive", "frmpdfreceive")
        o.putExtra("otherupremanu", ly)
        o.putExtra("otheruprekey", iddd)
        o.putExtra("otheruprehsn", dsy)
        o.putExtra("otherupreprice", hy)
        o.putExtra("otheruprequan", gy)
        o.putExtra("otheruprebc", fy)
        o.putExtra("otherupretotal", ky)
        o.putExtra("otheruprecess", my)
        o.putExtra("otheroriproid", oripro)

        o.putExtra("otherupreimmg", tt)
        o.putExtra("otherupbranch", names)
        o.putExtra("otherupaddress", addressnames)
        o.putExtra("otherupredate", datestk)
        o.putExtra("otherupredesc", descstk)
        o.putExtra("otheruprestkid", idstk)
        o.putExtra("otherupreiddb", iddbs)
        o.putExtra("otherupreiddofli", idli)
        o.putExtra("recon", recon)
        o.putExtra("otherbrid", bridds)
        o.putExtra("reccnt", reccnt)
        o.putExtra("otherreigst", ny)
        o.putExtra("otherreigst_total", oy)
        o.putExtra("othertally", tally)
        o.putExtra("otherreceive", received)
        o.putExtra("otherreceivecpy", receivedcpy)

        o.putExtra("otherrecesstotal", py)

        o.putExtra("listlistener", listlistener)

        o.putExtra("descriplistenersave", descriplistenersave)

        o.putExtra("cgsttot", cgstt)
        o.putExtra("sgsttot", sgstt)
        o.putExtra("cesstot", cesst)
        o.putExtra("grosstot", grosstt)

        o.putExtra("descriplistener", descriplistener)
        o.putExtra("reccntlistener", reccntlistener)
        o.putExtra("recdatelistener", recdatelistener)
        o.putExtra("reconlistener", reconlistener)




        o.putExtra("viewtrans", viewtrans)
        o.putExtra("addtrans", addtrans)
        o.putExtra("edittrans", editetrans)
        o.putExtra("deletetrans", deletetrans)
        o.putExtra("transfertrans", transfertrans)
        o.putExtra("exporttrans", exporttrans)
        o.putExtra("sendtrans", sendtrans)


        o.putExtra("viewtransano", viewtransano)
        o.putExtra("addtransano", addtransano)
        o.putExtra("edittransano", editetransano)
        o.putExtra("deletetransano", deletetransano)
        o.putExtra("transfertransano", transfertransano)
        o.putExtra("exporttransano", exporttransano)
        o.putExtra("sendtransano", sendtransano)

        o.putExtra("viewrec", viewrec)
        o.putExtra("addrec", addrec)
        o.putExtra("deleterec", deleterec)
        o.putExtra("editrec", editrec)
        o.putExtra("transferrec", transferrec)
        o.putExtra("exportrec", exportrec)
        o.putExtra("sendstrec", sendstrec)



        startActivity(o)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
        finish()


    }

    /*@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun createWebPrintJob(webView: WebView) {

        val printManager = this
                .getSystemService(Context.PRINT_SERVICE) as PrintManager

        val printAdapter = webView.createPrintDocumentAdapter("MyDocument")

        val jobName = getString(R.string.app_name) + " Print Test"

        printManager.print(jobName, printAdapter,
                PrintAttributes.Builder().build())
    }*/


    private fun getTextView(id: Int, title: String, color: Int, typeface: Int, bgColor: Int): TextView {   //Document's fonts and design
        val tv = TextView(this)
        tv.id = id
        tv.text = title.toUpperCase()
        tv.setTextColor(color)
        tv.setPadding(20, 20, 20, 20)
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.DEFAULT, typeface)
        tv.setBackgroundColor(bgColor)
        tv.layoutParams = getLayoutParams()

        return tv
    }

    private fun getLayoutParams(): TableRow.LayoutParams {          //Table row layout design
        val params = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT)
        params.setMargins(2, 0, 0, 2)
        return params
    }

    private fun getTblLayoutParams(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT)
    }

    fun addHeaders() {              //TAble headers
        val tl = findViewById<TableLayout>(R.id.table)
        val tr = TableRow(this)
        tr.layoutParams = getLayoutParams()
        tr.addView(getTextView(0, "S.No", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD, ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Product name", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD, ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "HSN/SAC", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD, ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Price", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD, ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Quantity", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD, ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "          Tax         ", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD, ContextCompat.getColor(this, R.color.white)))

        tr.addView(getTextView(0, "Total", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD, ContextCompat.getColor(this, R.color.white)))
        tl.addView(tr, getTblLayoutParams())
    }

    var ee = 0.0F
    var cc = 0.0F
    var gros = 0.0F
    var ig = 0.0F
    var cg = 0.0F
    var sg = 0.0F
    var ces = 0.0F


    fun addData() {


        htmlDocument = "<html><body><h3>Vinitas Enterprises Pvt Ltd</h3><h4>" + "Receive Stock</h4>" +
                "<table class=Border>"+

                "<tr>"+
                "<td class=Border>S.No:</td>"+
                "<td class=Border>$idstk</td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Date:</td>"+
                "<td class=Border>$datestk</td>"+
                "</tr>"+

                "<tr>"+
                "<td class=Border>Branch Name: </td>"+
                "<td class=Border>$names </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Branch Address:</td>"+
                "<td class=Border>$addressnames </td>"+
                "</tr>"+

                "<tr>"+
                "<td class=Border>Description: </td>"+
                "<td class=Border> $descstk</td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Stock Received Count:</td>"+
                "<td class=Border> $reccnt </td>"+
                "</tr>"+

                "<tr>"+
                "<td class=Border>Stock Received On:</td>"+
                "<td class=Border> $recon</td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Stock Received Count:</td>"+
                "<td class=Border> $reccnt </td>"+
                "</tr>"+






                "<style>"+
                "table, th, td {"+
                "border: 1px solid black;"+
                "border-collapse: collapse;"+

                "}"+
                "th, td {"+
                "padding: 15px;"+
                "}"+
                "th {"+
                "text-align: left;"+
                "}"+
                "td.Hidden {"+
                    "visibility: hidden;"+
                "}"+

                "td.Border {"+
                "border:none;"+
                "width:60%;"+
                "padding:8px;"+
                "}"+


                "table.Border {"+
                "border:none;"+

                "}"+
                "</style>"+

                "<table style=\"width:100%\">"+
                "<tr>"+







                "<th>S.No</th>"+
                "<th>Product name</th>"+
                "<th>HSN/SAC Code</th>"+

                "<th>Price</th>"+
                "<th>Quantity</th>"+
                "<th>Tax</th>"+
                "<th>Total</th>"+
                "</tr>"//Fill datas on table

        val tl = findViewById<TableLayout>(R.id.table)
        for (i in 0 until priceArray.size) {
            val tr = TableRow(this)

            var pri = priceArray[i].toFloat()
            var quan = quantityArray[i].toFloat()
            var e = igsttotArray[i].toFloat()
            var f = cesstotalArray[i].toFloat()

            var jj = e + f

            var grtt = jj
            var grflo = grtt
            var gttt = grflo + (pri * quan)

            var grossrealtot = gttt + gros


            singrosstot = singrosstot.plusElement(grossrealtot.toString())









                htmlDocument=htmlDocument+
                        "<tr>"+
                        "<td>${i+1}</td>"+
                        "<td>${pronameArray[i]}</td>"+
                        "<td>${hsnArray[i]}</td>"+
                        "<td>${priceArray[i]}</td>"+
                        "<td>${quantityArray[i]}</td>"+
                        "<td>$grtt</td>"+
                        "<td>$gttt</td>"+
                        "</tr>"

                if(priceArray.size==i){

                }























          /*  tr.addView(getTextView(i + 1, (i + 1).toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, pronameArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, hsnArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, priceArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, quantityArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, grtt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, gttt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tl.addView(tr, getTblLayoutParams())*/
        }
        htmlDocument=htmlDocument+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>CGST TOTAL:</td>"+
                "<td>$cgstt</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>SGST TOTAL:</td>"+
                "<td>$sgstt</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>Cess TOTAL:</td>"+
                "<td>$cesst</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td> Gross TOTAL:</td>"+
                "<td>$grosstt</td>"+

                "</tr>"+"</body></html>"


        myWebView!!.loadDataWithBaseURL(null, htmlDocument, "text/HTML", "UTF-8", null)
       /* val t2 = findViewById<TableLayout>(R.id.table1)
        val t3 = findViewById<TableLayout>(R.id.table2)
        val tr2 = TableRow(this)
        val tr3 = TableRow(this)
        val tr4 = TableRow(this)
        val tr6 = TableRow(this)
        val tr5 = TableRow(this)

        val trval2 = TableRow(this)
        val trval3 = TableRow(this)
        val trval4 = TableRow(this)
        val trval5 = TableRow(this)
        val trval6 = TableRow(this)



        tr2.layoutParams = getLayoutParams()

        trval3.addView(getTextView(0, cgstt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval4.addView(getTextView(0, sgstt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval5.addView(getTextView(0, cesst, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval6.addView(getTextView(0, grosstt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        //tr2.addView(getTextView( 1,"IGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr3.addView(getTextView(1, "CGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr4.addView(getTextView(1, "SGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr5.addView(getTextView(1, "Cess TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr6.addView(getTextView(1, "Gross TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        //t2.addView(tr2, getTblLayoutParams())
        t2.addView(tr3, getTblLayoutParams())
        t2.addView(tr4, getTblLayoutParams())
        t2.addView(tr5, getTblLayoutParams())
        t2.addView(tr6, getTblLayoutParams())


        //t3.addView(trval2, getTblLayoutParams())
        t3.addView(trval3, getTblLayoutParams())
        t3.addView(trval4, getTblLayoutParams())
        t3.addView(trval5, getTblLayoutParams())
        t3.addView(trval6, getTblLayoutParams())*/
    }




    fun sendMail(path: String) {  //Send this purchase request to desired path.
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "Receive Stock Pdf")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Inventory")
        val file = File(path)
        val uri = FileProvider.getUriForFile(this@MainReceivePdf, "com.package.name.fileprovider", file)
        emailIntent.type ="application/pdf"


        emailIntent.putExtra(Intent.EXTRA_STREAM, uri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))

    }

}

    //Create,write,export pdf

    /*fun createandDisplayPdf(id: String, requestdt: String, reqname: String, reqphone: String, reqestidate: String, cgsttotal: String, sgsttotal: String, cesstotal: String, grosstot: String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()
            var f = idstk + "_receive stock"

            var y = f + ".pdf"

            val file = File(dir, y)
            val fOut = FileOutputStream(file)





            PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();
            val fntSize = 9.5f
            val fntSizeheading = 14.5f
            val fntSizesubheading = 12.5f

            val b = Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSizeheading, b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSizesubheading, b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED, fntSize);
            val h1 = Paragraph("Vinitas Enterprises Pvt Ltd", fontheading)
            val hs1 = Paragraph("Stock Transfer", fontsubheading)

            val a1 = Paragraph("Branch Name:                         " + reqname, font)
            val b1 = Paragraph("Branch Address:                     " + reqphone, font)
            val c1 = Paragraph("ST No:                                     " + id, font)
            val d1 = Paragraph("Date:                                       " + requestdt, font)
            val e1 = Paragraph("Description:                             " + reqestidate, font)
            val p13 = Paragraph("Stock Received Count:           " + cgsttotal, font)
            val p14 = Paragraph("Stock Received On:                " + sgsttotal, font)
            val p15 = Paragraph("CESS Total:                               " + cesstotal, font)
            val p7 = Paragraph("Gross Total:                               " + grosstot, font)
            val p8 = Paragraph("Product Details", fontsubheading)

            val pnm = Paragraph("Product Name")
            val pri = Paragraph("Price")

            val table = PdfPTable(floatArrayOf(2F,6F,5F, 5F, 4F,6F,4F))

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER)

            table.addCell("S.No")
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");

            table.addCell("Quantity");
            table.addCell("Taxes")
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for (j in 0 until cells.size) {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var ces=0.0F
            for (i in 0 until priceArray.size)
            {



                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)

                var grossrealtot=gttt+gros


                singrosstot=singrosstot.plusElement(grossrealtot.toString())




                table.addCell((i+1).toString())
                table.addCell(pronameArray[i])
                table.addCell(hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell(quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell(gttt.toString())
            }
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER)
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            *//* table.addCell("")

             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("IGST Total")
             table.addCell(igstto)*//*

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgstt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgstt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cesst)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstt)
            *//*val table =  PdfPTable(10);
        val  cell = PdfPCell(pnm);
       cell.colspan=1
       cell.setBorder(PdfPCell.NO_BORDER);
       cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        table.addCell(cell);
        val cellCaveat =  PdfPCell(pri);
        cellCaveat.setColspan(1);
        cellCaveat.setBorder(PdfPCell.NO_BORDER);
        table.addCell(cellCaveat);
       table.addCell(cellCaveat);
       doc.add(table)*//*


            //add paragraph to document
            doc.add(h1)
            doc.add(Chunk.NEWLINE);
            doc.add(hs1)
            doc.add(Chunk.NEWLINE);
            doc.add(c1)
            doc.add(Chunk.NEWLINE);
            doc.add(d1)
            doc.add(Chunk.NEWLINE);
            doc.add(a1)
            doc.add(Chunk.NEWLINE);
            doc.add(b1)
            doc.add(Chunk.NEWLINE);
            doc.add(e1)
            doc.add(Chunk.NEWLINE);
            doc.add(p13)
            doc.add(Chunk.NEWLINE);
            doc.add(p14)
            doc.add(Chunk.NEWLINE);
            doc.add(Chunk.NEWLINE);
            doc.add(p8)
            doc.add(Chunk.NEWLINE);
            doc.add(table)

            downstatus = "success"


        } catch (de: DocumentException) {
            downstatus = "not"
        } catch (e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        } finally {
            doc.close()
        }


    }

    fun viewPdf(folder: String, file: String) {          //Open created pdf document from local storage using pdf reader.
        try {


            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + folder, file)
            println("SD CARD URL" + pdfFile)
            val path = Uri.fromFile(pdfFile)

            // Setting the intent for pdf reader
            val pdfIntent = Intent(Intent.ACTION_VIEW)
            pdfIntent.setDataAndType(path, "application/pdf")
            pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

            try {
                startActivity(pdfIntent);
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }


        } catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW)
            val k = folder.replace("%20", "")
            val path = Environment.getExternalStorageDirectory().absolutePath + "/" + folder + "/" + file
            println("PATH" + path)
            val targetFile = File(path)
            println("TARGET PATH" + targetFile)
            val targetUri = Uri.fromFile(targetFile)


            try {
                val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider", targetFile)
                println("URI" + photoURI)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.setDataAndType(photoURI, "application/pdf")
                startActivity(intent);
                Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }

        }

    }
    fun net_status():Boolean{       //Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
    companion object {

        //Listens internet status whether net is on/off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                /// if connection is off then all views becomes disable

                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }



            }
            else
            {


                /// if connection is off then all views becomes enabled

                constraintLayout3dis!!.visibility=View.GONE

                relativeslayoutdis!!.visibility=View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }
}*/




