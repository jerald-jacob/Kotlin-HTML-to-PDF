package com.example.vinitas.inventory_app

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.TextInputEditText
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.baoyz.swipemenulistview.SwipeMenuCreator
import com.baoyz.swipemenulistview.SwipeMenuItem
import com.baoyz.swipemenulistview.SwipeMenuListView
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.squareup.picasso.Picasso
import com.vansuita.pickimage.bean.PickResult
import com.vansuita.pickimage.bundle.PickSetup
import com.vansuita.pickimage.dialog.PickImageDialog
import com.vansuita.pickimage.listeners.IPickResult
import kotlinx.android.synthetic.main.activity_service_category.*
import kotlinx.android.synthetic.main.sub_category.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URL
import java.util.*
import kotlin.collections.ArrayList

class Service_category : AppCompatActivity(), IPickResult {

    var key = ""
    val db = FirebaseFirestore.getInstance()
    var main_image = ByteArray(1)

    var sub_image = ByteArray(1)
    var pop = ""
    var imnamedup = ""
    var imurdup = ""
    var catnamedup = ""

    var catdup = ""
    var imgnamedup = ""
    var desdup = ""
    var subcurdup = ""


    var changed = ""
    var changedback = ""

    var subcatnmArraydup = ArrayList<String>()

    lateinit var popimage: Bitmap
    lateinit var sub_imguri: TextView
    lateinit var sub_imgname: TextView
    lateinit var imgbk: ImageButton
    lateinit var cam: ImageButton
    lateinit var img: ImageView
    lateinit var sc_sub_img: TextView
    lateinit var nm: TextInputEditText
    lateinit var des: EditText

    data class s(var cat: String, var ur: String, var imgname: String)
    data class sub(var main_id: String, var cat: String, var des: String, var ur: String, var imgname: String, var main_cat: String)

    var subcatidArray = ArrayList<String>()
    var subcatnmArray = ArrayList<String>()
    var subcatdesArray = ArrayList<String>()
    var subcaticoArray = ArrayList<String>()
    var subcatimgArray = ArrayList<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_service_category)

        net_status() // Checks the net status.

        sc_add_back.setOnClickListener {
            finish()
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
        }
        val getid = intent.getStringExtra("id")//"NljJ6p7yAmPewk6XSAXb"////"tFphXCmOhN1SH9t2rzwk"
        sc_add_get_id.setText(getid)


        //Click image and show it on popup and navigate to zoom activity

        sc_add_card.setOnClickListener {


            if(sc_add_edit.visibility==View.GONE) {

                if (imguri.text.toString().isNotEmpty() == true) {


                    var redrawb = sc_add_card.drawable

                    val alert = AlertDialog.Builder(this@Service_category)
                    val inflater = this.layoutInflater
                    /*with(alert) {
setTitle("Select Branch")
}*/
                    val dialog = alert.create()
                    dialog.setView(inflater.inflate(R.layout.viewpopup, null))
                    dialog.show()
                    val stkedt = dialog.findViewById<ImageView>(R.id.imgshow) as ImageView

                    stkedt.setImageDrawable(redrawb)
                    val bitmap = (redrawb as BitmapDrawable).getBitmap()
                    val baos = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                    val b = baos.toByteArray()

                    stkedt.setOnClickListener {
                        val k = Intent(this@Service_category, ZoomService::class.java)
                        k.putExtra("im", "image")
                        k.putExtra("drawb", imguri.text.toString())

                        dialog.dismiss()
                        startActivity(k)


                    }


                    val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                    val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                    okact.setOnClickListener {

                        PickImageDialog.build(PickSetup()).show(this)
                        dialog.dismiss()


                    }
                    cancelact.setOnClickListener {
                        dialog.dismiss()
                    }
                } else {
                    PickImageDialog.build(PickSetup()).show(this)
                }
            }
            else{

            }

        }



        if (sc_add_get_id.text.isEmpty()) {
            val k = db.collection("servicecategory").document().id
            key = k
            println(" if   " + key)
        } else if (sc_add_get_id.text.isNotEmpty()) {


            //Get service category from db

            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();
            key = sc_add_get_id.text.toString()
            sc_add_save.visibility = View.GONE
            sub_add.visibility=View.INVISIBLE
            sc_add_edit.visibility = View.VISIBLE
            sc_add_name.isEnabled = false
            sc_add_card.isEnabled = false
            sc_add_camera.isEnabled = false

            println("else if     " + key)
            db.collection("servicecategory").document(key)
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            if (task.result != null) {
                                Log.d("data", "is" + task.result.data)
                                sc_add_name.setText(task.result.get("cat").toString())

                                imguri.setText(task.result.get("ur").toString())
                                imgname.setText(task.result.get("imgname").toString())
                                catnamedup=task.result.get("cat").toString()
                                imnamedup = task.result.get("imgname").toString()
                                imurdup = task.result.get("ur").toString()

                                if (task.result.get("ur").toString().isNotEmpty()) {
                                    sc_add_cam_back.visibility = View.GONE
                                    sc_add_camera.visibility = View.GONE
                                    Picasso.with(this).load(imguri.text.toString()).into(sc_add_card)
                                }
                                //sc_add_card.setImageBitmap(img)
                            } else {
                                Log.d("data", "is not here")
                            }
                        } else {
                            Log.d("task is not success", "full" + task.exception)
                        }
                    }
                    .addOnSuccessListener {
                        db.collection("subcategory").whereEqualTo("main_id", key)
                                .get()
                                .addOnCompleteListener { task ->
                                    if (task.result != null) {
                                        if (task.result.isEmpty == false) {
                                            for (doc in task.result) {
                                                nocat.visibility = View.GONE
                                                val cat = doc.data.get("cat").toString()

                                                val imgname = doc.data.get("imgname").toString()
                                                val imgur = doc.data.get("ur").toString()
                                                val desc = doc.data.get("des").toString()

                                                subcatidArray.add(doc.id.toString())
                                                subcatnmArray.add(cat)
                                                subcatnmArraydup.add(cat)
                                                subcatdesArray.add(desc)
                                                subcaticoArray.add(imgur)
                                                subcatimgArray.add(imgname)



                                                println("subcatnmArray main list"+subcatnmArray)
                                                println("subcatnmArray main list dup"+subcatnmArraydup)

                                            }
                                            val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                            val listView = findViewById(R.id.sub_list) as ListView
                                            listView.adapter = adp
                                        } else {

                                        }
                                    } else {

                                    }
                                }
                                .addOnSuccessListener {
                                    pDialog.dismiss()
                                }
                    }

        }
        sc_add_edit.setOnClickListener {
            sc_add_save.visibility = View.VISIBLE
            sc_add_edit.visibility = View.GONE
            sub_add.visibility=View.VISIBLE
            sc_add_name.isEnabled = true
            sc_add_card.isEnabled = true
            sc_add_camera.isEnabled = true

        }


        //Save action

        sc_add_save.setOnClickListener {
            if (sc_add_name.text.isNotEmpty() == true) {
                if (((subcatnmArray.isNotEmpty() == true) && (subcatnmArraydup != subcatnmArray)) || (imnamedup != imgname.text.toString()) || (imurdup != imguri.text.toString()) || (catnamedup != sc_add_name.text.toString())) {
                    changed = "changes"
                }
                if (changed == "changes") {
                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialog.setTitleText("Saving...")
                    pDialog.setCancelable(false)
                    pDialog.show();
                    val cate = sc_add_name.text.toString()
                    val ur = imguri.text.toString()
                    val name = imgname.text.toString()
                    val data = s(cat = cate, ur = ur, imgname = name)
                    //if ((did.text.toString()).isEmpty()) {
                    //progress.visibility = View.VISIBLE
                    sc_add_save.isEnabled = false
                    println(data)
                    db.collection("servicecategory").document(key)
                            .set(data)
                            .addOnSuccessListener {
                                Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                pDialog.dismiss()
                                finish()
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                            }
                            .addOnFailureListener {
                                Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                            }
                }
                else {
                    Toast.makeText(this, "Nothing happened for save", Toast.LENGTH_LONG).show()
                }
            }else {
                Toast.makeText(this, "Nothing happened for save", Toast.LENGTH_LONG).show()
            }
        }
        sc_add_camera.setOnClickListener {
            if (imgname.text.isEmpty()) {
                PickImageDialog.build(PickSetup()).show(this@Service_category)
            } else {
                PickImageDialog.build(PickSetup()).show(this@Service_category)

            }
        }
        /*sc_add_card.setOnClickListener {

            if (imgname.text.isEmpty()) {
                PickImageDialog.build(PickSetup()).show(this@Service_category)
            }else{
                val alert=AlertDialog.Builder(this)
                val delete=Button(this)
                delete.setText("DELETE")
                alert.create()
                alert.setView(delete)
                delete.setOnClickListener {
                    val storage = FirebaseStorage.getInstance()
                    val storageRef = storage.getReference()
                    val imagesRef = storageRef.child("maincategory").child(imgname.text.toString())
                    imagesRef.delete()
                            .addOnSuccessListener {
                                imgname.setText("")
                                imguri.setText("")
                                PickImageDialog.build(PickSetup()).show(this@Service_category)
                            }
                }
            }
        }*/


//Sub category add popup

        sub_add.setOnClickListener {
            if (sc_add_name.text.isNotEmpty() == true) {
                val popup = AlertDialog.Builder(this, R.style.popup)
                val inflater = this.layoutInflater
                val dialog = popup.create()
                dialog.setCancelable(false)
                dialog.setView(inflater.inflate(R.layout.sub_category, null))
                dialog.show()
                pop = "pop"
                imgbk = dialog.findViewById<ImageButton>(R.id.sc_sub_add_cam_back) as ImageButton
                cam = dialog.findViewById<ImageButton>(R.id.sc_sub_add_camera) as ImageButton
                img = dialog.findViewById<ImageView>(R.id.sc_sub_add_card) as ImageView
                sub_imguri = dialog.findViewById<TextView>(R.id.sc_sub_imguri) as TextView
                sub_imgname = dialog.findViewById<TextView>(R.id.sc_sub_imgname) as TextView
                val error = dialog.findViewById<TextView>(R.id.textView6) as TextView
                nm = dialog.findViewById<TextInputEditText>(R.id.sc_sub_add_name) as TextInputEditText
                des = dialog.findViewById<EditText>(R.id.sc_sub_add_disc) as EditText
                val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                val ok = dialog.findViewById<Button>(R.id.ok) as Button
                nm.addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) {

                    }

                    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

                    }

                    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                        if (s.isNullOrEmpty()) {
                            error.visibility = View.VISIBLE
                        } else {
                            error.visibility = View.GONE
                        }
                    }

                })
                cam.setOnClickListener {
                    if (sub_imgname.text.isEmpty()) {
                        PickImageDialog.build(PickSetup()).show(this@Service_category)
                    } else {

                        PickImageDialog.build(PickSetup()).show(this@Service_category)

                    }
                    img.setOnClickListener {




                        if (sub_imguri.text.toString().isNotEmpty() == true) {


                            var redrawb = img.drawable

                            val alert = AlertDialog.Builder(this@Service_category)
                            val inflater = this.layoutInflater
                            /*with(alert) {
        setTitle("Select Branch")
        }*/
                            val dialog = alert.create()
                            dialog.setView(inflater.inflate(R.layout.viewpopup, null))
                            dialog.show()
                            val stkedt = dialog.findViewById<ImageView>(R.id.imgshow) as ImageView

                            stkedt.setImageDrawable(redrawb)
                            val bitmap = (redrawb as BitmapDrawable).getBitmap()
                            val baos = ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                            val b = baos.toByteArray()

                            stkedt.setOnClickListener {
                                val k = Intent(this@Service_category, ZoomService::class.java)
                                k.putExtra("im", "image")
                                k.putExtra("drawb", sub_imguri.text.toString())

                                dialog.dismiss()
                                startActivity(k)


                            }


                            val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                            val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                            okact.setOnClickListener {

                                PickImageDialog.build(PickSetup()).show(this)
                                dialog.dismiss()


                            }
                            cancelact.setOnClickListener {
                                dialog.dismiss()
                            }
                        } else {
                            PickImageDialog.build(PickSetup()).show(this)

                        }


                    }



                }






                cancel.setOnClickListener {
                    if (sub_imgname.text.isNotEmpty()) {
                        val alert = AlertDialog.Builder(this)
                        val infl = this.layoutInflater
                        val v = alert.create()
                        v.setCancelable(false)
                        v.setView(infl.inflate(R.layout.save_popup, null))
                        v.show()
                        val cance = v.findViewById<Button>(R.id.button4) as Button
                        val k = v.findViewById<Button>(R.id.button3) as Button
                        k.setOnClickListener {
                            if (nm.text.isNotEmpty()) {
                                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                pDialog.setTitleText("Saving...")
                                pDialog.setCancelable(false)
                                pDialog.show();
                                val data = sub(key, nm.text.toString(), des.text.toString(), sub_imguri.text.toString(),
                                        sub_imgname.text.toString(), sc_add_name.text.toString())
                                db.collection("subcategory")
                                        .add(data)
                                        .addOnSuccessListener { ref ->
                                            Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                            pop = ""
                                            subcatnmArray.add(nm.text.toString())
                                            subcatdesArray.add(des.text.toString())
                                            subcaticoArray.add(sub_imguri.text.toString())
                                            subcatimgArray.add(sub_imgname.text.toString())
                                            subcatidArray.add(ref.id.toString())
                                            v.dismiss()
                                            pDialog.dismiss()
                                            dialog.dismiss()
                                            nocat.visibility = View.GONE
                                            val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                            sub_list.adapter = adp
                                        }
                                        .addOnFailureListener {
                                            Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                        }
                            } else {
                                error.visibility = View.VISIBLE
                                v.dismiss()
                            }
                        }
                        cance.setOnClickListener {

                            val storage = FirebaseStorage.getInstance()
                            val storageRef = storage.getReference()
                            val imagesRef = storageRef.child("subcategory").child(sub_imgname.text.toString())
                            imagesRef.delete()
                                    .addOnSuccessListener {
                                        sub_imgname.setText("")
                                        sub_imguri.setText("")
                                        dialog.dismiss()
                                        /* val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                         sub_list.adapter = adp*/
                                        pop = ""
                                        //PickImageDialog.build(PickSetup()).show(this@Service_category)

                                        v.dismiss()
                                    }
                        }


                    } else {
                        dialog.dismiss()
                    /*    val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                        sub_list.adapter = adp*/
                        pop = ""
                    }
                }



                //insert sub category

                ok.setOnClickListener {

                    if (nm.text.isNotEmpty()) {
                        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                        pDialog.setTitleText("Saving...")
                        pDialog.setCancelable(false)
                        pDialog.show();
                        val data = sub(key, nm.text.toString(), des.text.toString(), sub_imguri.text.toString(),
                                sub_imgname.text.toString(), sc_add_name.text.toString())
                        db.collection("subcategory")
                                .add(data)
                                .addOnSuccessListener { ref ->
                                    Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                    pop = ""

                                    println("subcatnmArray"+subcatnmArray)

                                    subcatnmArray.add(nm.text.toString())
                                    subcatdesArray.add(des.text.toString())
                                    subcaticoArray.add(sub_imguri.text.toString())
                                    subcatimgArray.add(sub_imgname.text.toString())
                                    subcatidArray.add(ref.id.toString())
                                    pDialog.dismiss()
                                    dialog.dismiss()
                                    println("subcatnmArray bef list"+subcatnmArray)
                                    nocat.visibility = View.GONE
                                    val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                    sub_list.adapter = adp
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                }
                    } else {
                        error.visibility = View.VISIBLE
                        //Toast.makeText(this,"Nothing Saved",Toast.LENGTH_SHORT).show()
                        /*if (sub_imgname.text.isNotEmpty()) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("subcategory").child(sub_imgname.toString())
                        imagesRef.delete()
                                .addOnSuccessListener {
                                    sub_imgname.setText("")
                                    sub_imguri.setText("")
                                    dialog.hide()
                                    pop=""
                                    //PickImageDialog.build(PickSetup()).show(this@Service_category)
                                }

                    }else{
                        pop=""
                        dialog.hide()
                    }*/
                    }
                }
                /*dialog.setButton(Dialog.BUTTON_POSITIVE,"ok",DialogInterface.OnClickListener { dialogInterface, i ->

            })
            dialog.setButton(Dialog.BUTTON_NEGATIVE,"cancel",DialogInterface.OnClickListener { dialogInterface, i ->

            })*/
            } else {
                Toast.makeText(this, "please fill category name field", Toast.LENGTH_SHORT).show()
            }
        }


        //Sub category list click and update the details on popup

        sub_list.setOnItemClickListener { parent, view, i, id ->
            if (sc_add_edit.visibility == View.GONE) {
                if (sc_add_name.text.isNotEmpty() == true) {
                    val popup = AlertDialog.Builder(this, R.style.popup)
                    val inflater = this.layoutInflater
                    val dialog = popup.create()
                    dialog.setCancelable(false)
                    dialog.setView(inflater.inflate(R.layout.sub_category, null))
                    dialog.show()
                    pop = "pop"
                    imgbk = dialog.findViewById<ImageButton>(R.id.sc_sub_add_cam_back) as ImageButton
                    cam = dialog.findViewById<ImageButton>(R.id.sc_sub_add_camera) as ImageButton
                    img = dialog.findViewById<ImageView>(R.id.sc_sub_add_card) as ImageView
                    sub_imguri = dialog.findViewById<TextView>(R.id.sc_sub_imguri) as TextView
                    sub_imgname = dialog.findViewById<TextView>(R.id.sc_sub_imgname) as TextView
                    val error = dialog.findViewById<TextView>(R.id.textView6) as TextView
                    nm = dialog.findViewById<TextInputEditText>(R.id.sc_sub_add_name) as TextInputEditText
                    des = dialog.findViewById<EditText>(R.id.sc_sub_add_disc) as EditText
                    val cancel = dialog.findViewById<Button>(R.id.cancel) as Button
                    val ok = dialog.findViewById<Button>(R.id.ok) as Button
                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialog.setTitleText("Loading...")
                    pDialog.setCancelable(false)
                    pDialog.show();
                    db.collection("subcategory").document(subcatidArray.get(i).toString())
                            .get()
                            .addOnCompleteListener { task ->
                                if (task.result != null) {
                                    if (task.result.exists()) {
                                        //for (doc in task.result){
                                        val cat = task.result.data.get("cat").toString()
                                        val imgname = task.result.data.get("imgname").toString()
                                        val imgur = task.result.data.get("ur").toString()
                                        val desc = task.result.data.get("des").toString()

                                        catdup = task.result.data.get("cat").toString()
                                        imgnamedup = task.result.data.get("imgname").toString()
                                        desdup = task.result.data.get("des").toString()
                                        subcurdup = task.result.data.get("ur").toString()

                                        nm.setText(cat)
                                        des.setText(desc)
                                        sub_imgname.setText(imgname)
                                        sub_imguri.setText(imgur)
                                        if (imgur.isNotEmpty()) {
                                            imgbk.visibility = View.GONE
                                            cam.visibility=View.GONE
                                            Picasso.with(this).load(imgur).into(img)
                                        }
                                        pDialog.dismiss()
                                        /*subcatnmArray.add(cat)
                                    subcatdesArray.add(desc)
                                    subcaticoArray.add(imgur)
                                    subcatimgArray.add(imgname)
                                    subcatidArray.add(doc.id.toString())
                                    val adp=subcat_list(this,subcatnmArray, subcatdesArray, subcaticoArray,subcatidArray,subcatimgArray)
                                    sub_list.adapter=adp*/
                                        // }
                                    }
                                }
                            }

                    nm.addTextChangedListener(object : TextWatcher {
                        override fun afterTextChanged(s: Editable?) {

                        }

                        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

                        }

                        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {

                            if (s.isNullOrEmpty()) {
                                error.visibility = View.VISIBLE
                            } else {
                                error.visibility = View.GONE
                            }
                        }

                    })
                    cam.setOnClickListener {
                        if (sub_imgname.text.isEmpty()) {

                            PickImageDialog.build(PickSetup()).show(this@Service_category)
                        } else {

                            PickImageDialog.build(PickSetup()).show(this@Service_category)
                        }
                    }

                    img.setOnClickListener {




                        if (sub_imguri.text.toString().isNotEmpty() == true) {


                            var redrawb = img.drawable

                            val alert = AlertDialog.Builder(this@Service_category)
                            val inflater = this.layoutInflater
                            /*with(alert) {
        setTitle("Select Branch")
        }*/
                            val dialog = alert.create()
                            dialog.setView(inflater.inflate(R.layout.viewpopup, null))
                            dialog.show()
                            val stkedt = dialog.findViewById<ImageView>(R.id.imgshow) as ImageView

                            stkedt.setImageDrawable(redrawb)
                            val bitmap = (redrawb as BitmapDrawable).getBitmap()
                            val baos = ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
                            val b = baos.toByteArray()

                            stkedt.setOnClickListener {
                                val k = Intent(this@Service_category, ZoomService::class.java)
                                k.putExtra("im", "image")
                                k.putExtra("drawb", sub_imguri.text.toString())

                                dialog.dismiss()
                                startActivity(k)


                            }


                            val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                            val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                            okact.setOnClickListener {

                                PickImageDialog.build(PickSetup()).show(this)
                                dialog.dismiss()


                            }
                            cancelact.setOnClickListener {
                                dialog.dismiss()
                            }
                        } else {
                            PickImageDialog.build(PickSetup()).show(this)

                        }


                    }

                    //Cancel and close the popup

                    cancel.setOnClickListener {

                        if ((catdup != nm.text.toString()) || (desdup != des.text.toString()) || (subcurdup != sub_imguri.text.toString()) || (imgnamedup != sub_imgname.text.toString())) {
                            changed = "changes"
                        }

                        if (changed == "changes") {
                            val alert = AlertDialog.Builder(this)
                            val infl = this.layoutInflater
                            val v = alert.create()
                            v.setCancelable(false)
                            v.setView(infl.inflate(R.layout.save_popup, null))
                            v.show()
                            val cance = v.findViewById<Button>(R.id.button4) as Button
                            val k = v.findViewById<Button>(R.id.button3) as Button
                            k.setOnClickListener {
                                if (nm.text.isNotEmpty()) {
                                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                                    pDialog.setTitleText("Saving...")
                                    pDialog.setCancelable(false)
                                    pDialog.show();
                                    val data = sub(key, nm.text.toString(), des.text.toString(), sub_imguri.text.toString(), sub_imgname.text.toString(), sc_add_name.text.toString())
                                    db.collection("subcategory").document(subcatidArray.get(i))
                                            .set(data)
                                            .addOnSuccessListener { ref ->
                                                Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                                pop = ""
                                                subcatnmArray.set(i, nm.text.toString())
                                                subcatdesArray.set(i, des.text.toString())
                                                subcaticoArray.set(i, sub_imguri.text.toString())
                                                subcatimgArray.set(i, sub_imgname.text.toString())
                                                subcatidArray.set(i, subcatidArray.get(i))
                                                v.dismiss()
                                                pDialog.dismiss()
                                                dialog.hide()
                                                nocat.visibility = View.GONE
                                                val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                                sub_list.adapter = adp
                                            }
                                            .addOnFailureListener {
                                                Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                            }
                                } else {
                                    error.visibility = View.VISIBLE
                                    v.dismiss()
                                }
                            }
                            cance.setOnClickListener {
                                v.dismiss()
                                dialog.dismiss()
                                pop = ""
                            }

                        } else {
                            pop = ""
                            dialog.dismiss()
                        }
                    }


                    //Update the changes
                    ok.setOnClickListener {
                        if ((catdup != nm.text.toString()) || (desdup != des.text.toString()) || (subcurdup != sub_imguri.text.toString()) || (imgnamedup != sub_imgname.text.toString())) {
                            changed = "changes"
                        }
                        if ((nm.text.isNotEmpty()) && (changed == "changes")) {
                            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                            pDialog.setTitleText("Saving...")
                            pDialog.setCancelable(false)
                            pDialog.show();
                            val data = sub(key, nm.text.toString(), des.text.toString(), sub_imguri.text.toString(), sub_imgname.text.toString(), sc_add_name.text.toString())
                            db.collection("subcategory").document(subcatidArray.get(i))
                                    .set(data)
                                    .addOnSuccessListener { ref ->
                                        Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                        pop = ""
                                        subcatnmArray.set(i, nm.text.toString())
                                        subcatdesArray.set(i, des.text.toString())
                                        subcaticoArray.set(i, sub_imguri.text.toString())
                                        subcatimgArray.set(i, sub_imgname.text.toString())
                                        subcatidArray.set(i, subcatidArray.get(i))
                                        pDialog.dismiss()
                                        dialog.hide()
                                        nocat.visibility = View.GONE
                                        val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                        sub_list.adapter = adp
                                    }
                                    .addOnFailureListener {
                                        Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                    }
                        } else {

                            if (nm.text.isEmpty()) {
                                error.visibility = View.VISIBLE

                            } else {
                                pop = ""
                                dialog.hide()
                            }

                            //Toast.makeText(this,"Nothing Saved",Toast.LENGTH_SHORT).show()
                            /*if (sub_imgname.text.isNotEmpty()) {
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("subcategory").child(sub_imgname.toString())
                        imagesRef.delete()
                                .addOnSuccessListener {
                                    sub_imgname.setText("")
                                    sub_imguri.setText("")
                                    dialog.hide()
                                    pop=""
                                    //PickImageDialog.build(PickSetup()).show(this@Service_category)
                                }

                    }else{
                        pop=""
                        dialog.hide()
                    }*/
                        }
                    }
                    /*dialog.setButton(Dialog.BUTTON_POSITIVE,"ok",DialogInterface.OnClickListener { dialogInterface, i ->

            })
            dialog.setButton(Dialog.BUTTON_NEGATIVE,"cancel",DialogInterface.OnClickListener { dialogInterface, i ->

            })*/
                } else {
                    Toast.makeText(this, "please fill category name field", Toast.LENGTH_SHORT).show()
                }
            }
        }


        //val adp = subcat_list(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)

        /*var creator = SwipeMenuCreator { menu ->
            // create "delete" item
            val deleteItem = SwipeMenuItem(
                    applicationContext)
            // set item background
            deleteItem.background = ColorDrawable(resources.getColor(R.color.fab))
            // set item width
            deleteItem.width = 150
            // set a icon
            deleteItem.setIcon(R.drawable.ic_delete_white_24px)
            // add to menu
            menu.addMenuItem(deleteItem)
        }
        sub_list.setMenuCreator(creator);
        sub_list.setOnSwipeListener(object : SwipeMenuListView.OnSwipeListener {

            override fun onSwipeStart(position: Int) {
                //swipe start
                println("pos : " + position)
            }

            override fun onSwipeEnd(position: Int) {
                //swipe end
                println("pos : " + position)
            }
        })
        sub_list.setOnMenuItemClickListener(SwipeMenuListView.OnMenuItemClickListener { i, menu, index ->
            when (index) {
                0 -> {
                    //delete
                    //delete(item);
                    println("intex..........   :  " + index)
                    println("subcatnmArray.......... :" + subcatnmArray.get(i))
                    println("subcatdesArray.......... :" + subcatdesArray.get(i))
                    println("subcaticoArray.......... :" + subcaticoArray.get(i))
                    println("subcatidArray.......... :" + subcatidArray.get(i))
                    println("subcatimgArray.......... :" + subcatimgArray.get(i))
                    if (sc_add_edit.visibility == View.GONE) {
                        db.collection("subcategory").document(subcatidArray[i])
                                .delete()
                                .addOnCompleteListener {
                                    if (subcatimgArray.get(i).isNotEmpty()) {
                                        val storage = FirebaseStorage.getInstance()
                                        val storageRef = storage.getReference()
                                        val imagesRef = storageRef.child("subcategory").child(subcatimgArray.get(i).toString())
                                        imagesRef.delete()
                                                .addOnSuccessListener {
                                                    subcatnmArray.removeAt(i)
                                                    subcatdesArray.removeAt(i)
                                                    subcaticoArray.removeAt(i)
                                                    subcatidArray.removeAt(i)
                                                    subcatimgArray.removeAt(i)
                                                    val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                                    sub_list.adapter = adp
                                                }
                                    } else {
                                        subcatnmArray.removeAt(i)
                                        subcatdesArray.removeAt(i)
                                        subcaticoArray.removeAt(i)
                                        subcatidArray.removeAt(i)
                                        subcatimgArray.removeAt(i)
                                        val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                        sub_list.adapter = adp
                                    }
                                    if (subcatnmArray.isEmpty()) {
                                        nocat.visibility = View.VISIBLE
                                    } else {
                                        nocat.visibility = View.GONE
                                    }

                                }
                    }
                }
            }
            true
        })*/
        //swipe()

        var d = arrayListOf<String>()

        var dlt = arrayListOf<String>()
        val list_item = ArrayList<String>()
        val list_itemimg = ArrayList<String>()
        var imarr=arrayListOf<String>()

        var dpos=arrayListOf<Int>()



        //---------------DELETE ACTION---------------------//

        sub_list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        sub_list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = sub_list.getCheckedItemCount()

                d=subcatidArray

                imarr=subcatimgArray

                val l = d.get(position)

                val h=position



                val k=imarr.get(position)

                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")

                //list_item.add(id);
                if (checked) {


                    list_item.add(id.toString()) // Add to list when checked ==  true
                    dlt.add(l)
                    dpos.add(h)
                    list_itemimg.add(k)

                    println("IMG VALUE"+list_itemimg)


                    // Log.i(TAG,"itm "+dlt.get(position))
                } else {
                    list_item.remove(id.toString())

                    dlt.remove(l)
                    dpos.remove(h)
                    list_itemimg.remove(k)
                    println("IMG VALUE REMOVE"+list_itemimg)

                }

            }

            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB
                sc_add_toolbar.visibility = View.GONE
                mode.getMenuInflater().inflate(R.menu.list, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                val builder = AlertDialog.Builder(this@Service_category)
                with(builder) {
                    setTitle("Delete from subcategory?")
                    setMessage("Are you sure want to delete?")
                    setPositiveButton("Yes") { dialog, whichButton ->
                        val pDialog = SweetAlertDialog(this@Service_category, SweetAlertDialog.PROGRESS_TYPE)
                        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                        pDialog.setTitleText("Deleting...")
                        pDialog.setCancelable(false)
                        pDialog.show();
                        val deleteSize = dlt.size
                        Log.i("tsdfs","  "+dlt.size)
                        /*val cate = null
                        val data = s(cat = cate)*/
                        val m = 0

                        val itemId = item.getItemId()
                        if ((itemId == R.id.delete)&&(net_status()==true)) {

                            for(m in dpos){
                                subcatnmArray.removeAt(m)
                                subcatdesArray.removeAt(m)
                                subcaticoArray.removeAt(m)
                                subcatidArray.removeAt(m)
                                subcatimgArray.removeAt(m)
                            }


                            for (i in dlt) {
                                db.collection("subcategory").document(i)
                                        .delete()
                                        .addOnCompleteListener {

                                            for(j in list_itemimg){
                                                if (j.isNotEmpty()){
                                                    val storage = FirebaseStorage.getInstance()
                                                    val storageRef = storage.getReference()
                                                    val imagesRef = storageRef.child("subcategory").child(j)
                                                    imagesRef.delete()
                                                            .addOnSuccessListener {

                                                            }
                                                }
                                            }
                                           /* if (subcatimgArray.get().isNotEmpty()) {
                                                val storage = FirebaseStorage.getInstance()
                                                val storageRef = storage.getReference()
                                                val imagesRef = storageRef.child("subcategory").child(subcatimgArray.get(i).toString())
                                                imagesRef.delete()
                                                        .addOnSuccessListener {
                                                            subcatnmArray.removeAt(i)
                                                            subcatdesArray.removeAt(i)
                                                            subcaticoArray.removeAt(i)
                                                            subcatidArray.removeAt(i)
                                                            subcatimgArray.removeAt(i)
                                                            val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                                            sub_list.adapter = adp
                                                        }
                                            } else {
                                                subcatnmArray.removeAt(i)
                                                subcatdesArray.removeAt(i)
                                                subcaticoArray.removeAt(i)
                                                subcatidArray.removeAt(i)
                                                subcatimgArray.removeAt(i)
                                                val adp = subcat_lists(this, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                                sub_list.adapter = adp
                                            }*/
                                        }
                                        .addOnSuccessListener {
                                            dlt.clear()
                                            list_itemimg.clear()
                                            pDialog.dismiss()
                                            val adp = subcat_lists(this@Service_category, subcatnmArray, subcatdesArray, subcaticoArray, subcatidArray, subcatimgArray)
                                            sub_list.adapter = adp
                                            Toast.makeText(applicationContext, "" + deleteSize + " Item(s) deleted", Toast.LENGTH_SHORT).show()
                                            // save_progress.visibility = android.view.View.GONE

                                        }
                                        .addOnFailureListener {
                                            Toast.makeText(applicationContext, "not updated", Toast.LENGTH_LONG).show()
                                            //save_progress.visibility = android.view.View.GONE
                                        }
                            }
                        }
                        else if(net_status()==false){
                            Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_LONG).show()

                        }
                        /* checkedCount = 0*/
                        list_item.clear()
                        mode.finish()
                    }
                    setNegativeButton("No") { dialog, whichButton ->
                        //showMessage("Close the game or anything!")
                        dialog.dismiss()
                        list_item.clear()
                        mode.finish()
                    }

                    // Dialog
                    val dialog = builder.create()

                    dialog.show()
                }


                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                dlt.clear()
                sc_add_toolbar.visibility =View.VISIBLE
            }
        })

    }



    //Image pick result and save to db storage
    override fun onPickResult(r: PickResult) {

        if (pop == "") {
            if (r.error == null) {

                sc_add_card.setImageBitmap(r.bitmap)
                val storage = FirebaseStorage.getInstance()
                val storageRef = storage.getReference()
                val generator = Random()
                var n = 1000
                n = generator.nextInt(n)
                val d = System.currentTimeMillis() / 1000
                val s = d.toString() + "$n"
                val imname = "$key" + "_$s.jpg"
                val imagesRef = storageRef.child("maincategory").child(imname)
                sc_add_card.isDrawingCacheEnabled = true
                sc_add_card.buildDrawingCache()
                val bitmap = sc_add_card.drawingCache
                val baos = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Loading...")
                pDialog.setCancelable(false)
                pDialog.show();
                /* sc_add_cam_back.visibility= View.GONE
                sc_add_camera.visibility= View.GONE*/
                sc_add_cam_back.visibility = View.GONE
                sc_add_camera.visibility = View.GONE
                val data = baos.toByteArray()
                main_image = data
                val uploadTask = imagesRef.putBytes(data)
                uploadTask.addOnFailureListener(OnFailureListener {}).addOnSuccessListener(OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->
                    val ur = taskSnapshot.downloadUrl
                    imguri.text = ur.toString()
                    imgname.text = imname

                    if(imnamedup.isNotEmpty()){
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("maincategory").child(imnamedup)
                        imagesRef.delete()
                                .addOnSuccessListener {


                                    //PickImageDialog.build(PickSetup()).show(this@Service_category)
                                }

                    }

                    //Toast.makeText(applicationContext, "URL :" + Uri.PARCELABLE_WRITE_RETURN_VALUE, Toast.LENGTH_SHORT).show()
                    pDialog.dismiss();
                    /*val localFile: File = File.createTempFile("images21", "jpg")
                    // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                    val downloadUrl = taskSnapshot.downloadUrl*/

                })
                uploadTask.addOnProgressListener { taskSnapshot -> }.addOnPausedListener { println("Upload is paused") }
                //Image path
                r.getPath();
            } else {
                //Handle possible errors
                Toast.makeText(this, r.error.message, Toast.LENGTH_LONG).show()
            }
            // Reference to an image file in Firebase Storage
        } else {
            if (r.error == null) {
                popimage = r.bitmap
                img.setImageBitmap(r.bitmap)
                val storage = FirebaseStorage.getInstance()
                val storageRef = storage.getReference()
                val k = storage.getReference().downloadUrl
                println("k : " + k)
                val generator = Random()
                var n = 1000
                n = generator.nextInt(n)
                val d = System.currentTimeMillis() / 1000
                val s = d.toString() + "$n"
                val imname = "$key" + "_$s.jpg"
                val imagesRef = storageRef.child("subcategory").child(imname)
                img.isDrawingCacheEnabled = true
                img.buildDrawingCache()
                val bitmap = img.drawingCache
                val baos = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Loading...")
                pDialog.setCancelable(false)
                pDialog.show();
                imgbk.visibility = View.GONE
                cam.visibility=View.GONE
                /*cam.visibility=View.GONE*/
                //sc_add_cam_back.visibility = View.GONE
                val data = baos.toByteArray()
                sub_image = data
                val uploadTask = imagesRef.putBytes(data)
                uploadTask.addOnFailureListener(OnFailureListener {}).addOnSuccessListener(OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->
                    val ur = taskSnapshot.downloadUrl
                    sub_imguri.setText(ur.toString())
                    sub_imgname.setText(imname)


                    if(imgnamedup.isNotEmpty()){
                        val storage = FirebaseStorage.getInstance()
                        val storageRef = storage.getReference()
                        val imagesRef = storageRef.child("subcategory").child(imgnamedup)
                        imagesRef.delete()
                                .addOnSuccessListener {


                                    //PickImageDialog.build(PickSetup()).show(this@Service_category)
                                }

                    }


                    //Toast.makeText(applicationContext, "URL :" + Uri.PARCELABLE_WRITE_RETURN_VALUE, Toast.LENGTH_SHORT).show()
                    pDialog.dismiss();
                    /*val localFile: File = File.createTempFile("images21", "jpg")
                    // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                    val downloadUrl = taskSnapshot.downloadUrl*/

                })
                uploadTask.addOnProgressListener { taskSnapshot -> }.addOnPausedListener { println("Upload is paused") }
                //Image path
                r.getPath();
            } else {
                //Handle possible errors
                Toast.makeText(this, r.error.message, Toast.LENGTH_LONG).show()
            }
            // Reference to an image file in Firebase Storage
        }


    }



    //Back action

    override fun onBackPressed() {
        if (sc_add_get_id.text.isEmpty()) {
            if (((subcatnmArray.isNotEmpty() == true)&&(subcatnmArraydup != subcatnmArray)) || (imnamedup != imgname.text.toString()) ||
                    (imurdup != imguri.text.toString())||(catnamedup!=sc_add_name.text.toString())) {
                changedback="changes"
            }

            println("subcatnmArray"+subcatnmArray)
            println("subcatnmArraydup"+subcatnmArraydup)
            println("imnamedup"+imnamedup)
            println("imurdup"+imurdup)


            //If changes happened then save the changes and finish the activity

            if(changedback=="changes"){

                val alert = AlertDialog.Builder(this)
                val infl = this.layoutInflater
                val v = alert.create()
                v.setCancelable(false)
                v.setView(infl.inflate(R.layout.save_popup, null))
                v.show()
                val cancel = v.findViewById<Button>(R.id.button4) as Button
                val ok = v.findViewById<Button>(R.id.button3) as Button
                ok.setOnClickListener {
                    if (sc_add_name.text.isNotEmpty() == true) {
                        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                        pDialog.setTitleText("Saving...")
                        pDialog.setCancelable(false)
                        pDialog.show();
                        val cate = sc_add_name.text.toString()
                        val ur = imguri.text.toString()
                        val name = imgname.text.toString()
                        val data = s(cat = cate, ur = ur, imgname = name)
                        //if ((did.text.toString()).isEmpty()) {
                        //progress.visibility = View.VISIBLE
                        sc_add_save.isEnabled = false
                        println(data)
                        db.collection("servicecategory").document(key)
                                .set(data)
                                .addOnSuccessListener {
                                    Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                    v.hide()
                                    pDialog.dismiss()
                                    finish()
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                }
                    } else {
                        Toast.makeText(this, "please fill category name field", Toast.LENGTH_SHORT).show()
                    }
                }
                cancel.setOnClickListener {
                    v.hide()
                }
            } else {
                finish()
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

            }
        } else {

            if (sc_add_name.text.isNotEmpty() == true) {

                if (((subcatnmArray.isNotEmpty() == true)&&(subcatnmArraydup != subcatnmArray))|| (imnamedup != imgname.text.toString()) || (imurdup != imguri.text.toString())||(catnamedup!=sc_add_name.text.toString()))
                {
                    changedback="changes"
                }
                println("subcatnmArray"+subcatnmArray)
                println("subcatnmArraydup"+subcatnmArraydup)
                println("imnamedup"+imnamedup)
                println("imurdup"+imurdup)



                if(changedback=="changes"){

                    val alert = AlertDialog.Builder(this)
                    val infl = this.layoutInflater
                    val v = alert.create()
                    v.setCancelable(false)
                    v.setView(infl.inflate(R.layout.save_popup, null))
                    v.show()
                    val cance = v.findViewById<Button>(R.id.button4) as Button
                    val k = v.findViewById<Button>(R.id.button3) as Button
                    k.setOnClickListener {
                        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                        pDialog.setTitleText("Saving...")
                        pDialog.setCancelable(false)
                        pDialog.show();
                        val cate = sc_add_name.text.toString()
                        val ur = imguri.text.toString()
                        val name = imgname.text.toString()
                        val data = s(cat = cate, ur = ur, imgname = name)
                        //if ((did.text.toString()).isEmpty()) {
                        //progress.visibility = View.VISIBLE
                        sc_add_save.isEnabled = false
                        println(data)
                        db.collection("servicecategory").document(key)
                                .set(data)
                                .addOnSuccessListener {
                                    Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                    v.hide()
                                    pDialog.dismiss()
                                    finish()
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                }
                                .addOnFailureListener {
                                    Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                                }
                    }
                    cance.setOnClickListener {
                        v.hide()
                        finish()
                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                    }
                } else {
                    finish()
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                }


            } else {
                finish()
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

            }
        }
    }
        fun swipe() {

        }

        fun net_status(): Boolean { // Checks the net status.
            val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var connected = false
            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
                //we are connected to a network
                connected = true
            } else {
                Toast.makeText(this, "No internet connection", Toast.LENGTH_LONG).show()
                connected = false
            }
            return connected
        }

}
