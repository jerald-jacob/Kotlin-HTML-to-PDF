package com.example.vinitas.inventory_app

/**
 * Created by Vinitas on 22-12-2017.
 */
import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

import de.hdodenhof.circleimageview.CircleImageView

/**
 * Created by vinitas IT on 13-12-2017.
 */
class stk_two__list_adap(//to reference the Activity
        private val context: Activity, //to store the list of countries
        private val nameArray:   Array<String>, //to store the list of countries
        private val subnmArray:  Array<String>,
        private val bcArray:     Array<String>,
        private val sohArray:    Array<String>,
        private val mlArray:     Array<String>,
        private val priceArray:  Array<String>,
        private val productImArray: Array<Int>): ArrayAdapter<Any>(context, R.layout.act_stk_delhi_items, nameArray) {

    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.act_stk_delhi_items, null, true)

        //this code gets references to objects in the listview_row.xml file
        val nameTextField = rowView.findViewById<View>(R.id.pnm) as TextView
        val subnameTextField = rowView.findViewById<View>(R.id.psubnm) as TextView
        val bcnameTextField = rowView.findViewById<View>(R.id.bc) as TextView
        val sohnameTextField = rowView.findViewById<View>(R.id.soh) as TextView
        val pricenameTextField = rowView.findViewById<View>(R.id.price) as TextView
        val mlnameTextField = rowView.findViewById<View>(R.id.ml) as TextView
        val productim= rowView.findViewById<View>(R.id.primg) as CircleImageView


        //this code sets the values of the objects to values from the arrays
        nameTextField.text = nameArray[position]
        subnameTextField.text = subnmArray[position]
        bcnameTextField.text=bcArray[position]
        sohnameTextField.text=sohArray[position]
        pricenameTextField.text = mlArray[position]
        mlnameTextField.text = priceArray[position]
        productim.setImageResource(productImArray[position])


        //infoTextField.text = infoArray[position]


        return rowView
    }
}