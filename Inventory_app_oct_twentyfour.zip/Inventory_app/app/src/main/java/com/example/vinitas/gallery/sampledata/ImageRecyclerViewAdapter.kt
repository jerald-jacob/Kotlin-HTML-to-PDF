package com.example.vinitas.gallery.sampledata

import android.net.Uri
import android.widget.TextView
import com.facebook.drawee.view.SimpleDraweeView
import android.support.v7.widget.RecyclerView
import com.zfdang.multiple_images_selector.SelectorSettings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.example.vinitas.inventory_app.R
import com.zfdang.multiple_images_selector.OnImageRecyclerViewInteractionListener

import com.zfdang.multiple_images_selector.models.ImageItem;
import com.zfdang.multiple_images_selector.models.ImageListContent;
import com.zfdang.multiple_images_selector.utilities.DraweeUtils;
import com.zfdang.multiple_images_selector.utilities.FileUtils;
import java.io.File
import java.util.ArrayList


class ImageRecyclerViewAdapter(private val mValues: ArrayList<com.zfdang.multiple_images_selector.models.ImageItem>, private val mListener: OnImageRecyclerViewInteractionListener?) : RecyclerView.Adapter<ImageRecyclerViewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.recyclerview_image_item, parent, false)
        return ViewHolder(view)
    }



    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val imageItem = mValues[position]
        holder.mItem = imageItem

        val newURI: Uri
        if (!imageItem.isCamera) {
            // draw image first
            val imageFile = File(imageItem.path)
            if (imageFile.exists()) {
                newURI = Uri.fromFile(imageFile)
            } else {
                newURI = FileUtils.getUriByResId(R.drawable.default_image)
            }
            DraweeUtils.showThumb(newURI, holder.mDrawee!!)

            holder.mImageName!!.visibility = View.GONE
            holder.mChecked!!.setVisibility(View.VISIBLE)
            if (ImageListContent.isImageSelected(imageItem.path)) {
                holder.mMask!!.setVisibility(View.VISIBLE)
                holder.mChecked!!.setImageResource(R.drawable.image_selected)
            } else {
                holder.mMask!!.setVisibility(View.GONE)
                holder.mChecked!!.setImageResource(R.drawable.image_unselected)
            }
        } else {
            // camera icon, not normal image
            newURI = FileUtils.getUriByResId(R.drawable.ic_photo_camera_white_48dp)
            DraweeUtils.showThumb(newURI, holder.mDrawee!!)

            holder.mImageName!!.visibility = View.VISIBLE
            holder.mChecked!!.setVisibility(View.GONE)
            holder.mMask!!.setVisibility(View.GONE)
        }


        holder.mView.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                // Log.d(TAG, "onClick: " + holder.mItem.toString());
                if (!holder.mItem!!.isCamera) {
                    if (!ImageListContent.isImageSelected(imageItem.path)) {
                        // just select one new image, make sure total number is ok
                        if (ImageListContent.SELECTED_IMAGES.size < SelectorSettings.mMaxImageNumber) {
                            ImageListContent.toggleImageSelected(imageItem.path)
                            notifyItemChanged(position)
                        } else {
                            // set flag
                            ImageListContent.bReachMaxNumber = true
                        }
                    } else {
                        // deselect
                        ImageListContent.toggleImageSelected(imageItem.path)
                        notifyItemChanged(position)
                    }
                } else {
                    // do nothing here, listener will launch camera to capture image
                }
                mListener?.onImageItemInteraction(holder.mItem)
            }
        })
    }

    override fun getItemCount(): Int {
        return mValues.size
    }

    inner class ViewHolder(val mView: View) : RecyclerView.ViewHolder(mView) {
        val mDrawee: SimpleDraweeView?
        val mChecked: ImageView?
        val mMask: View?
        var mItem: ImageItem? = null
        var mImageName: TextView? = null

        init {
            mDrawee = mView.findViewById(R.id.image_drawee)
            assert(mDrawee != null)
            mMask = mView.findViewById(R.id.image_mask)
            assert(mMask != null)
            mChecked = mView.findViewById(R.id.image_checked) as ImageView
            assert(mChecked != null)
            mImageName = mView.findViewById(R.id.image_name)
            assert(mImageName != null)
        }

        override fun toString(): String {
            return super.toString()
        }
    }

    companion object {
        private val TAG = "ImageAdapter"
    }
}