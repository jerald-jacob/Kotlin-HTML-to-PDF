package com.example.vinitas.inventory_app

import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.*
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.popup.*
import kotlinx.android.synthetic.main.receive_list.*
import kotlinx.android.synthetic.main.scroll_branch_two.*
import java.text.DecimalFormat
import java.util.*

class Mainstk_branch_two : AppCompatActivity() {

    var db = FirebaseFirestore.getInstance()
    var groschk= String()
    var groschkdup= String()
    var names = String()
    var namesphones = String()
    var datestk=  String()
    var descstk= String()
    var idstk= String()
    var iddbs= String()
    var smlistidss= String()
    var idli= String()
    var brky= String()
    var tallyar= String()
    var orikys= String()
    var receivear= String()
    var editchange= String()
    var deletelistner=String()

    var descripdup=String()
    var stdatedup=String()
var fbinside=""
    var pval= String()
    var orignm=String()

    var pzsave:Int = 0
    var asave=arrayListOf<String>()
    var dsysave=arrayListOf<String>()
    var fysave=arrayListOf<String>()
    var gysave=arrayListOf<String>()
    var gysavecpy=arrayListOf<String>()
    var hysave=arrayListOf<String>()
    var kysave=arrayListOf<String>()
    var mysave=arrayListOf<String>()
    var nysave=arrayListOf<String>()
    var oysave=arrayListOf<String>()
    var pysave=arrayListOf<String>()
    var tallysave=arrayListOf<String>()
    var receivedsave=arrayListOf<String>()
    var proidsave=arrayListOf<String>()
    var proidcopysave=arrayListOf<String>()
    var idddsave= arrayListOf<String>()
    var lysave= arrayListOf<String>()
    var immysave= arrayListOf<String>()

    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""




    var proiddelete= arrayListOf<String>()
    var quantitydelete= arrayListOf<String>()




    var ids=arrayOf<String>()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scroll_branch_two)



        //Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Mainstk_branch_two) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }



        //Define No connection view and other views when inetrnet connection is off.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        req_updatedis=findViewById(R.id.update)
        userbackdis=findViewById(R.id.userback)
        purpridis=findViewById(R.id.stk_pri)
        cessdis=findViewById(R.id.cess_edt_trans)
        quan_receiveddis=findViewById(R.id.quan_transf_first)
        scrollView2dis=findViewById(R.id.scrollView2)





        net_status()       //Check internet status.


        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi = intent.getStringExtra("viewtrans")
        val tran = intent.getStringExtra("transfertrans")
        val ex = intent.getStringExtra("exporttrans")
        sendtrans = intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER" + addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano = intent.getStringExtra("viewtransano")
        val tranano = intent.getStringExtra("transfertransano")
        val exano = intent.getStringExtra("exporttransano")
        sendtransano = intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec = intent.getStringExtra("viewrec")
        val tranrec = intent.getStringExtra("transferrec")
        val exrec = intent.getStringExtra("exportrec")
        val sendrec = intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }


        val bundle = intent.extras
        var frm = bundle!!.get("from").toString()

        update.visibility = View.VISIBLE



        bcd_pid.isEnabled = false
        orddate.isEnabled = false
        prd_nm.isEnabled = false


        total.isEnabled = false

        cgst.isEnabled = false
        sgst.isEnabled = false


        edit.setOnClickListener {
            println("EDT PERMISSION" + editetrans)
            if (editetrans == "true") {

                edit.visibility = View.GONE
                update.visibility = View.VISIBLE

                bcd_pid.isEnabled = true
                orddate.isEnabled = true
                prd_nm.isEnabled = true
                stk_pri.isEnabled = true
                quan_transf_first.isEnabled = true
                total.isEnabled = true
                cess_edt_trans.isEnabled = true
                cgst.isEnabled = true
                sgst.isEnabled = true
            } else if (editetrans == "false") {
                popup("Update")
            }
        }



        //Get stock transfer details from (Mainstk_branch_one)


        var a = bundle.get("pnm") as ArrayList<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy = bundle.get("phsn") as ArrayList<String>
        val ly = bundle.get("pmanu") as ArrayList<String>
        val fy = bundle.get("barcode") as ArrayList<String>
        val gy = bundle.get("quan") as ArrayList<String>
        val gycpy = bundle.get("quanarraycpy") as ArrayList<String>


        val hy = bundle.get("price") as ArrayList<String>
        val ky = bundle.get("tot") as ArrayList<String>
        val my = bundle.get("cessup") as ArrayList<String>
        val ny = bundle.get("igst") as ArrayList<String>
        val oy = bundle.get("igsttotal") as ArrayList<String>
        val py = bundle.get("cesstotarray") as ArrayList<String>
        val iddd = bundle.get("idsofli") as ArrayList<String>
        val idtally = bundle.get("tallyarray") as ArrayList<String>
        val idrec = bundle.get("receivedarray") as ArrayList<String>
        val immy = bundle.get("image") as ArrayList<String>
        val proidsarr = bundle.get("proids") as ArrayList<String>
        val proidcpysarr = bundle.get("proidscpy") as ArrayList<String>





        try {
            val prodel = bundle.get("proiddelete") as ArrayList<String>

            if (prodel.isNotEmpty() == true) {
                proiddelete = prodel
            } else {

            }

            val quandel = bundle.get("quantitydelete") as ArrayList<String>

            if (quandel.isNotEmpty() == true) {
                quantitydelete = prodel
            } else {

            }
        } catch (e: Exception) {

        }


        ids = bundle.get("ids") as Array<String>




        asave = a
        dsysave = dsy
        fysave = fy
        gysave = gy
        hysave = hy
        kysave = ky
        mysave = my
        nysave = ny
        oysave = oy
        pysave = py
        tallysave = idtally
        receivedsave = idrec
        idddsave = iddd
        immysave = immy
        proidsave = proidsarr
        proidcopysave = proidcpysarr
        lysave = ly
        gysavecpy = gycpy

        val namebr = intent.getStringExtra("branch")
        val kybrnch = intent.getStringExtra("keybrnch")
        val oribrnky = intent.getStringExtra("originkeys")
        val datest = intent.getStringExtra("sstkdate")
        val smlistid = intent.getStringExtra("smlistids")
        val locbr = intent.getStringExtra("address")
        val stockid = intent.getStringExtra("ssstockid")
        val stockdesc = intent.getStringExtra("ssstkdesc")
        val iddb = intent.getStringExtra("idofdb")

        try{

            orignm=intent.getStringExtra("orignm")
        }
        catch (e:Exception){

        }

        deletelistner = intent.getStringExtra("deletelistner")


        try {
            descripdup = intent.getStringExtra("descripdup")
            stdatedup = intent.getStringExtra("stdatedup")
        } catch (e: Exception) {

        }


        val grochk = intent.getStringExtra("groschk")
        groschk = grochk
        groschkdup=grochk
        idoflist.setText(smlistid)
        bkey.setText(kybrnch)
        smlistidss = idoflist.text.toString()
        brky = bkey.text.toString()
        println("BRANCH KEY " + brky)

        idofre.setText(iddb)
        desc.setText(stockdesc)
        stkid.setText(stockid)
        date.setText(datest.toString())
        println("PRINT THE   DATEEEE  " + datest)
        comttname.setText(namebr)
        comphone.setText(locbr)
        names = comttname.text.toString()
        orikys = oribrnky

        datestk = date.text.toString()
        println("YOYO OO DATEEEE" + datestk)
        descstk = desc.text.toString()
        idstk = stkid.text.toString()
        iddbs = idofre.text.toString()
        println(iddbs)


        namesphones = comphone.text.toString()
        /*    val i=bundle.get("imageArray") as Array<String>*/

        /*   d.add(b.toString())*/
        val pz = bundle.get("pos") as Int

        pzsave = pz

        //total
        var totalof = ky[pz]
        total.setText(totalof)
        var halfpri = totalof.toFloat()
        gross_tot.setText((String.format("%.2f",totalof.toFloat())))
        var f = gross_tot.text.toString()
        var fgr = f.toFloat()


        //name edt text
        var prname = a[pz]
        prd_nm.setText(prname)


        //quantity
        var quant = gy[pz]
        var qu: Int
        qu = quant.toInt()

        quan_transf_first.setText(quant)

        //hsn code
        var prord = dsy[pz]
        orddate.setText(prord)
        //price
        var price = hy[pz]

            var pr: Float

            pr = halfpri / qu

            var praddzr=String()

            var prdiv = pr
            println("PRI VALUE" + prdiv)
            if((pr.toString().endsWith(".1"))||(pr.toString().endsWith(".2"))||(pr.toString().endsWith(".3"))||(pr.toString().endsWith(".4"))
                            ||(pr.toString().endsWith(".5"))||(pr.toString().endsWith(".6"))||(pr.toString().endsWith(".7"))||
                            (pr.toString().endsWith(".8")) ||(pr.toString().endsWith(".9"))){
                var przr=pr.toString()
                 praddzr=przr+"0"
            }
            else{
                praddzr=pr.toString()

            }

            var prsuf = pr.toString()

            if (prsuf.toString().endsWith(".0")) {
                var ff = prsuf.removeSuffix(".0")
                println("PRI REMOVE" + ff)
                stk_pri.setText(ff.toString())

                stk_pri.setText(ff.toString())
            } else {




                stk_pri.setText(praddzr.toString())


            }
        if((prsuf.toString().endsWith(".0")&&(hy[pz].endsWith(".00")))){
            var ff=prsuf.removeSuffix(".0")
            var kl=ff+".00"
            println("PRI REMOVE"+ff)


            stk_pri.setText(kl.toString())
        }
        else if(((prsuf.toString().endsWith(".0")&&(!hy[pz].endsWith(".00"))))){
            var ff=prsuf.removeSuffix(".0")
            var kl=ff+".00"
            println("PRI REMOVE"+ff)


            stk_pri.setText(ff.toString())
        }
        else{


            stk_pri.setText(praddzr.toString())
        }




        //barcode
        var bar = fy[pz]
        bcd_pid.setText(bar)


        //cess
        var cssof = my[pz]
        cess_edt_trans.setText(cssof)

        ///IGST
        var igstof = ny[pz]
        var gg=igstof.toFloat()/2
        cgst.setText(gg.toString())
       sgst.setText(gg.toString())

        //IGST TOTAL
        var igsttotof = oy[pz]

        var di = 2

        var g = igst_total.setText(igsttotof)
        var h = igst_total.text.toString()
        var ss = h.toFloat()
        var ii = ss / di
        cgst_tot.setText((String.format("%.2f",ii.toFloat())))
        sgst_tot.setText((String.format("%.2f",ii.toFloat())))


        //CESS TTAL
        var cesstotof = py[pz]
        cess_tot.setText((String.format("%.2f",cesstotof.toFloat())))
        var t = cess_tot.text.toString()
        var hd = t.toFloat()

        var ls = ss + hd + fgr
        gross_tot.setText((String.format("%.2f",ls)))


        var idof = iddd[pz]
        newid.setText(idof)
        idli = newid.text.toString()

        var tally = idtally[pz]
        tallyarr.setText(tally)
        tallyar = tallyarr.text.toString()

        var receive = idrec[pz]
        receivearr.setText(receive)
        receivear = receivearr.text.toString()


        var upnm = arrayListOf<String>()
        val p = intent.getStringArrayListExtra("liids")


        val b = intent.getStringExtra("id")
        idofre.setText(b)



        //Quantity textchangelistener
        quan_transf_first.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = pr.toString().toFloat()
                }
                var k = stk_pri.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                total.setText((String.format("%.2f",f.toFloat())))
                gross_tot.setText((String.format("%.2f",f.toFloat())))

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //Price textchangelistener
        stk_pri.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {

                total.setText("")
                gross_tot.setText("")
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 0.0F

                } else {
                    pri = pr.toString().toFloat()
                }
                var k = quan_transf_first.text.toString()
                var l = pri.toBigDecimal()
                val oi = k.toBigDecimal()
                val f = l.times(oi)
                total.setText((String.format("%.2f",f.toFloat())))
                gross_tot.setText((String.format("%.2f",f.toFloat())))

            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })


        //Get stock on hand value and put it to the variable 'pval'

        var path="${proidsave[pzsave]}_${orikys}"
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference(path)

        val messageListener = object : ValueEventListener {

            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {

                    val message = dataSnapshot.value


                    pval=message.toString()


                    println("P VALUE"+message)
                    fbinside="ins"





                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Failed to read value
            }
        }

        myRef!!.addValueEventListener(messageListener)
        update.setOnClickListener {
            if(quan_transf_first.text.toString().isEmpty()){
                quan_transf_first.setText("0")
            }




            println("PATHS"+path)




                        println("P VALUE"+p)

                        /*else if (rr.isNotEmpty()||cls.isEmpty()){
                            p = Integer.parseInt(p.toString()) + qnt.toInt()
                            if (p<0){
                                p=0
                            }
                        }*/



                    // Set value and report transaction success

                    // Star the post and add self to stars





                    //mutableData.setValue(p.number)



            //Update happens when the Quantity is less than or equal to stock on hand

            if((fbinside=="ins")&&(quan_transf_first.text.toString().toInt()<=pval.toInt())) {
                val o = Intent(this@Mainstk_branch_two, Mainstk_branch_one::class.java)
                o.putExtra("from", "update")
                var dx = prd_nm.text
                var ex = orddate.text
                var fx = stk_pri.text.toString()
                var gx = quan_transf_first.text
                var hx = bcd_pid.text
                var ix = total.text
                var jx = cess_edt_trans.text
                var kx = cgst.text.toString()
                var lx = igst_total.text
                var mx = cess_tot.text
                var tallx = tallyarr.text
                var receivex = receivearr.text


                a[pz] = dx.toString()
                dsy[pz] = ex.toString()
                fy[pz] = hx.toString()
                gy[pz] = gx.toString()
                hy[pz] = fx.toString()
                ky[pz] = ix.toString()
                my[pz] = jx.toString()
                ny[pz] = kx.toString()
                oy[pz] = lx.toString()
                py[pz] = mx.toString()
                idtally[pz] = tallx.toString()
                idrec[pz] = receivex.toString()

                o.putExtra("renm", a)
                o.putExtra("from", "update")
                o.putExtra("remanu", ly)
                o.putExtra("rekey", iddd)
                o.putExtra("rehsn", dsy)
                o.putExtra("reprice", hy)
                o.putExtra("requan", gy)
                o.putExtra("rebc", fy)
                o.putExtra("retotal", ky)
                o.putExtra("recess", my)
                o.putExtra("reigst", ny)
                o.putExtra("retally", idtally)
                o.putExtra("rereceived", idrec)
                o.putExtra("reigst_total", oy)
                o.putExtra("recesstotal", py)
                o.putExtra("reimmg", immy)
                o.putExtra("requancpy", gycpy)


                o.putExtra("deletelistner", deletelistner)

                o.putExtra("proiddelete", proiddelete)
                o.putExtra("quantitydelete", quantitydelete)


                o.putExtra("reproid", proidsarr)
                o.putExtra("reproidscpy", proidcpysarr)
                o.putExtra("branch", names)
                o.putExtra("address", namesphones)
                o.putExtra("redate", datestk)
                o.putExtra("redesc", descstk)
                o.putExtra("restkid", idstk)
                o.putExtra("reiddb", iddbs)
                o.putExtra("smlistidss", smlistidss)
                o.putExtra("groschk", groschk)
                o.putExtra("brnchky", brky)
                o.putExtra("oribrnky", orikys)
                o.putExtra("reiddofli", idli)


                o.putExtra("orignm", orignm)

                o.putExtra("viewtrans", viewtrans)
                o.putExtra("addtrans", addtrans)
                o.putExtra("edittrans", editetrans)
                o.putExtra("deletetrans", deletetrans)
                o.putExtra("transfertrans", transfertrans)
                o.putExtra("exporttrans", exporttrans)
                o.putExtra("sendtrans", sendtrans)


                o.putExtra("descripdup", descripdup)
                o.putExtra("stdatedup", stdatedup)
                o.putExtra("viewtransano", viewtransano)
                o.putExtra("addtransano", addtransano)
                o.putExtra("edittransano", editetransano)
                o.putExtra("deletetransano", deletetransano)
                o.putExtra("transfertransano", transfertransano)
                o.putExtra("exporttransano", exporttransano)
                o.putExtra("sendtransano", sendtransano)

                o.putExtra("viewrec", viewrec)
                o.putExtra("addrec", addrec)
                o.putExtra("deleterec", deleterec)
                o.putExtra("editrec", editrec)
                o.putExtra("transferrec", transferrec)
                o.putExtra("exportrec", exportrec)
                o.putExtra("sendstrec", sendstrec)

                o.putExtra("ids", ids)



                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                finish()
            }


            //Quantity exceeded alert popup

            else if((fbinside=="ins")&&(quan_transf_first.text.toString().toInt()>pval.toInt())){
                val dialog=AlertDialog.Builder(this@Mainstk_branch_two)
                with(dialog){
                    setTitle("Exceeded")
                    setMessage("Available quantity is $pval but you entered ${quan_transf_first.text.toString()}")
                    setCancelable(false)
                    setPositiveButton("Ok"){dialog,button ->
                        quan_transf_first.setText("")
                        dialog.dismiss()
                    }
                    val builders=dialog.create()
                    builders.show()
                }
            }


        }












        userback.setOnClickListener {
            onBackPressed()  //Back action


        }
    }


    fun popup(st:String){   //Access denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    override fun onBackPressed() {

        if(groschk!="list") {
            groschk = ""
            editchange = ""
        }
        println("PRICE  "+hysave[pzsave])
        println("RECEIVED PRICE  "+gysave[pzsave])

        var kk=hysave[pzsave]





        if((hysave[pzsave]!=stk_pri.text.toString())||(gysave[pzsave]!=quan_transf_first.text.toString())){
            groschk="edited"
            editchange="changed"
        }

        if (editchange.isEmpty()) {   //navigate to 'Mainstk_branch_one'

            groschk=groschkdup

            val o = Intent(this@Mainstk_branch_two, Mainstk_branch_one::class.java)


            o.putExtra("from", "update")
            o.putExtra("renm", asave)

            o.putExtra("remanu", lysave)
            o.putExtra("rekey", idddsave)
            o.putExtra("rehsn", dsysave)
            o.putExtra("reprice", hysave)
            o.putExtra("requan", gysave)
            o.putExtra("rebc", fysave)
            o.putExtra("retotal", kysave)
            o.putExtra("recess", mysave)
            o.putExtra("reigst", nysave)
            o.putExtra("retally", tallysave)
            o.putExtra("rereceived", receivedsave)
            o.putExtra("reigst_total", oysave)
            o.putExtra("recesstotal", pysave)
            o.putExtra("reimmg", immysave)
            o.putExtra("reproid", proidsave)
            o.putExtra("reproidscpy", proidcopysave)
            o.putExtra("requancpy", gysavecpy)
            o.putExtra("orignm",orignm)

            o.putExtra("descripdup",descripdup)
            o.putExtra("stdatedup",stdatedup)
            o.putExtra("proiddelete",proiddelete)
            o.putExtra("quantitydelete",quantitydelete)

            o.putExtra("branch", names)
            o.putExtra("address", namesphones)
            o.putExtra("redate", datestk)
            o.putExtra("redesc", descstk)
            o.putExtra("restkid", idstk)
            o.putExtra("reiddb", iddbs)
            o.putExtra("groschk",groschk)
            o.putExtra("smlistidss", smlistidss)
            o.putExtra("brnchky", brky)
            o.putExtra("oribrnky", orikys)
            o.putExtra("reiddofli", idli)


            o.putExtra("deletelistner",deletelistner)







            o.putExtra("ids",ids)

            o.putExtra("viewtrans", viewtrans)
            o.putExtra("addtrans", addtrans)
            o.putExtra("edittrans", editetrans)
            o.putExtra("deletetrans", deletetrans)
            o.putExtra("transfertrans", transfertrans)
            o.putExtra("exporttrans", exporttrans)
            o.putExtra("sendtrans", sendtrans)


            o.putExtra("viewtransano", viewtransano)
            o.putExtra("addtransano", addtransano)
            o.putExtra("edittransano", editetransano)
            o.putExtra("deletetransano", deletetransano)
            o.putExtra("transfertransano", transfertransano)
            o.putExtra("exporttransano", exporttransano)
            o.putExtra("sendtransano", sendtransano)

            o.putExtra("viewrec", viewrec)
            o.putExtra("addrec", addrec)
            o.putExtra("deleterec", deleterec)
            o.putExtra("editrec", editrec)
            o.putExtra("transferrec", transferrec)
            o.putExtra("exportrec", exportrec)
            o.putExtra("sendstrec",sendstrec)



            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()

        } else if (editchange == "changed") {
            savepopup()

        }
    }

        fun savepopup() {   //Save alert popup

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }



            val builder = AlertDialog.Builder(this@Mainstk_branch_two)
            with(builder) {
                setTitle("Save changes?")
                setMessage("Do you want to save?")

                setPositiveButton("Yes") { dialog, whichButton ->
                    println("YES")
                    if(quan_transf_first.text.toString().isEmpty()){
                        quan_transf_first.setText("0")
                    }




                    /*else if (rr.isNotEmpty()||cls.isEmpty()){
                        p = Integer.parseInt(p.toString()) + qnt.toInt()
                        if (p<0){
                            p=0
                        }
                    }*/



                    // Set value and report transaction success

                    // Star the post and add self to stars





                    //mutableData.setValue(p.number)


                    //Update happens when the Quantity is less than or equal to stock on hand


                    if((fbinside=="ins")&&(quan_transf_first.text.toString().toInt()<=pval.toInt())) {
                        val o = Intent(this@Mainstk_branch_two, Mainstk_branch_one::class.java)

                        var dx = prd_nm.text
                        var exs = orddate.text
                        var fx = stk_pri.text
                        var gx = quan_transf_first.text
                        var hx = bcd_pid.text
                        var ix = total.text
                        var jx = cess_edt_trans.text
                        var kx = cgst.text
                        var lx = igst_total.text
                        var mx = cess_tot.text
                        var tallx = tallyarr.text
                        var receivex = receivearr.text


                        asave[pzsave] = dx.toString()
                        dsysave[pzsave] = exs.toString()
                        fysave[pzsave] = hx.toString()
                        gysave[pzsave] = gx.toString()
                        hysave[pzsave] = fx.toString()
                        kysave[pzsave] = ix.toString()
                        mysave[pzsave] = jx.toString()
                        nysave[pzsave] = kx.toString()
                        oysave[pzsave] = lx.toString()
                        pysave[pzsave] = mx.toString()
                        tallysave[pzsave] = tallx.toString()
                        receivedsave[pzsave] = receivex.toString()

                        o.putExtra("from", "update")
                        o.putExtra("renm", asave)

                        o.putExtra("remanu", lysave)
                        o.putExtra("rekey", idddsave)
                        o.putExtra("rehsn", dsysave)
                        o.putExtra("reprice", hysave)
                        o.putExtra("requan", gysave)
                        o.putExtra("rebc", fysave)
                        o.putExtra("retotal", kysave)
                        o.putExtra("recess", mysave)
                        o.putExtra("reigst", nysave)
                        o.putExtra("retally", tallysave)
                        o.putExtra("rereceived", receivedsave)
                        o.putExtra("reigst_total", oysave)
                        o.putExtra("recesstotal", pysave)
                        o.putExtra("reimmg", immysave)
                        o.putExtra("reproid", proidsave)
                        o.putExtra("reproidscpy", proidcopysave)
                        o.putExtra("requancpy", gysavecpy)
                        o.putExtra("orignm",orignm)

                        o.putExtra("descripdup",descripdup)
                        o.putExtra("stdatedup",stdatedup)
                        o.putExtra("proiddelete",proiddelete)
                        o.putExtra("quantitydelete",quantitydelete)

                        o.putExtra("branch", names)
                        o.putExtra("address", namesphones)
                        o.putExtra("redate", datestk)
                        o.putExtra("redesc", descstk)
                        o.putExtra("restkid", idstk)
                        o.putExtra("reiddb", iddbs)
                        o.putExtra("groschk",groschk)
                        o.putExtra("smlistidss", smlistidss)
                        o.putExtra("brnchky", brky)
                        o.putExtra("oribrnky", orikys)
                        o.putExtra("reiddofli", idli)


                        o.putExtra("deletelistner",deletelistner)







                        o.putExtra("ids",ids)

                        o.putExtra("viewtrans", viewtrans)
                        o.putExtra("addtrans", addtrans)
                        o.putExtra("edittrans", editetrans)
                        o.putExtra("deletetrans", deletetrans)
                        o.putExtra("transfertrans", transfertrans)
                        o.putExtra("exporttrans", exporttrans)
                        o.putExtra("sendtrans", sendtrans)


                        o.putExtra("viewtransano", viewtransano)
                        o.putExtra("addtransano", addtransano)
                        o.putExtra("edittransano", editetransano)
                        o.putExtra("deletetransano", deletetransano)
                        o.putExtra("transfertransano", transfertransano)
                        o.putExtra("exporttransano", exporttransano)
                        o.putExtra("sendtransano", sendtransano)

                        o.putExtra("viewrec", viewrec)
                        o.putExtra("addrec", addrec)
                        o.putExtra("deleterec", deleterec)
                        o.putExtra("editrec", editrec)
                        o.putExtra("transferrec", transferrec)
                        o.putExtra("exportrec", exportrec)
                        o.putExtra("sendstrec",sendstrec)



                        startActivity(o)
                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                        finish()
                    }
                    else if((fbinside=="ins")&&(quan_transf_first.text.toString().toInt()>pval.toInt())){
                        val dialog=AlertDialog.Builder(this@Mainstk_branch_two)
                        with(dialog){
                            setTitle("Exceeded")
                            setMessage("Available quantity is $pval but you entered ${quan_transf_first.text.toString()}")
                            setCancelable(false)
                            setPositiveButton("Ok"){dialog,button ->
                                quan_transf_first.setText("")
                                dialog.dismiss()
                            }
                            val builders=dialog.create()
                            builders.show()
                        }
                    }


                }

                setNegativeButton("No") { dialog, whichButton ->
                    groschk=""
                    val o = Intent(this@Mainstk_branch_two, Mainstk_branch_one::class.java)


                    //showMessage("Close the game or anything!")
                    println("No")
                    o.putExtra("renm", asave)
                    o.putExtra("from", "update")
                    o.putExtra("remanu", lysave)
                    o.putExtra("rekey", idddsave)
                    o.putExtra("rehsn", dsysave)
                    o.putExtra("reprice", hysave)
                    o.putExtra("requan", gysave)
                    o.putExtra("rebc", fysave)
                    o.putExtra("retotal", kysave)
                    o.putExtra("recess", mysave)
                    o.putExtra("reigst", nysave)
                    o.putExtra("retally", tallysave)
                    o.putExtra("rereceived", receivedsave)
                    o.putExtra("reigst_total", oysave)
                    o.putExtra("recesstotal", pysave)
                    o.putExtra("reimmg", immysave)
                    o.putExtra("reproids", proidsave)
                    o.putExtra("requancpy", gysavecpy)
                    o.putExtra("reproidscpy", proidcopysave)
                    o.putExtra("branch", names)
                    o.putExtra("groschk",groschk)
                    o.putExtra("address", namesphones)
                    o.putExtra("redate", datestk)
                    o.putExtra("redesc", descstk)
                    o.putExtra("restkid", idstk)
                    o.putExtra("reiddb", iddbs)
                    o.putExtra("smlistidss", smlistidss)
                    o.putExtra("brnchky", brky)
                    o.putExtra("oribrnky", orikys)
                    o.putExtra("reiddofli", idli)


                    o.putExtra("orignm",orignm)


                    o.putExtra("ids",ids)

                    o.putExtra("deletelistner",deletelistner)

                    o.putExtra("proiddelete",proiddelete)
                    o.putExtra("quantitydelete",quantitydelete)






                   o.putExtra("viewtrans", viewtrans)
                   o.putExtra("addtrans", addtrans)
                   o.putExtra("edittrans", editetrans)
                   o.putExtra("deletetrans", deletetrans)
                   o.putExtra("transfertrans", transfertrans)
                   o.putExtra("exporttrans", exporttrans)
                   o.putExtra("sendtrans", sendtrans)


                   o.putExtra("viewtransano", viewtransano)
                   o.putExtra("addtransano", addtransano)
                   o.putExtra("edittransano", editetransano)
                   o.putExtra("deletetransano", deletetransano)
                   o.putExtra("transfertransano", transfertransano)
                   o.putExtra("exporttransano", exporttransano)
                   o.putExtra("sendtransano", sendtransano)

                   o.putExtra("viewrec", viewrec)
                   o.putExtra("addrec", addrec)
                   o.putExtra("deleterec", deleterec)
                   o.putExtra("editrec", editrec)
                   o.putExtra("transferrec", transferrec)
                   o.putExtra("exportrec", exportrec)
                   o.putExtra("sendstrec",sendstrec)


                    o.putExtra("descripdup",descripdup)
                    o.putExtra("stdatedup",stdatedup)

                    startActivity(o)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()
                    dialog.dismiss()
                }

                // Dialog
                val dialog = builder.create()
                dialog.show()

            }
        }

    companion object {

        //Listens internet status whether net is on/off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null

        private var purpridis: EditText?=null
        private var quan_receiveddis: EditText?=null
        private var req_updatedis: Button? = null

        private var userbackdis: ImageButton? = null
        private var scrollView2dis: ScrollView?=null
        private var editdis: ImageButton? =null
        private var taxtotdup=String()
        private var cessdis:EditText?=null

        private val log_str: String? = null

        @RequiresApi(Build.VERSION_CODES.M)
        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                /// if connection is off then all views becomes disable


                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                req_updatedis!!.isEnabled=false
                purpridis!!.isEnabled=false
                val color = 0x96ffffff;
                val  drawables =  ColorDrawable(color.toInt());
                scrollView2dis!!.foreground=drawables
                cessdis!!.isEnabled=false
                quan_receiveddis!!.isEnabled=false
                userbackdis!!.isEnabled=false


                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }


            }
            else
            {


                /// if connection is off then all views becomes enabled

                constraintLayout3dis!!.visibility=View.GONE
                req_updatedis!!.isEnabled=true

                userbackdis!!.isEnabled=true
                purpridis!!.isEnabled=true
                quan_receiveddis!!.isEnabled=true
                scrollView2dis!!.setBackgroundColor(Color.parseColor("#32ffffff"))
                scrollView2dis!!.foreground=null
                relativeslayoutdis!!.visibility=View.GONE





            }
        }
    }

    fun net_status():Boolean{        //Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}