package com.example.vinitas.inventory_app

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Handler
import android.support.multidex.MultiDex
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.view.View

import android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
import android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_splash.*

import com.example.vinitas.inventory_app.R.id.textView




class SplashActivity : AppCompatActivity() {
    private val SPLASH_TIME_OUT = 2000
    private var progressStatus = 0
    private val handler = Handler()
    internal lateinit var session: SessionManagement
    var a = String()
    val PERMISSION_REQUEST = 7

    override fun onCreate(savedInstanceState: Bundle?) {

        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)




        session = SessionManagement(applicationContext)
        Handler().postDelayed(Runnable /*
             * Showing splash screen with a timer. This will be useful when you
             * want to show case your app logo / company
             */

        {
            if(CheckingPermissionIsEnabledOrNot()) {
                if (session.isLoggedIn == false) {
                    val b= Intent(this,ScanActivity::class.java)
                    startActivity(b)
                    overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left)
                    finish()
                }else if(session.isLoggedIn==true){
                    val b= Intent(this,PinActivity::class.java)
                    startActivity(b)
                    overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left)

                    finish()
                }
                else {
                    val b = Intent(this, ScanActivity::class.java)
                    startActivity(b)
                    finish()
                }
            }else{
                //Calling method to enable permission.
                RequestMultiplePermission();
            }

            // This method will be executed once the timer is over
            // Start your app main activity


        }, SPLASH_TIME_OUT.toLong())
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {

            PERMISSION_REQUEST ->

                if (grantResults.size > 0) {

                    val CameraPermission = grantResults[0] == PackageManager.PERMISSION_GRANTED


                    if (CameraPermission) {

                        if (session.isLoggedIn == false) {
                            val b= Intent(this,ScanActivity::class.java)
                            startActivity(b)
                            overridePendingTransition( R.anim.slide_in_left, R.anim.slide_out_left)
                            finish()
                        }else{

                        }

                    } else {


                    }
                }
        }
    }

    fun CheckingPermissionIsEnabledOrNot(): Boolean {

        val FirstPermissionResult = ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val SecondPermissionResult = ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.READ_EXTERNAL_STORAGE)


        val FortPermissionResult = ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.INTERNET)
        val ForPermissionResult = ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.CAMERA)

        return FirstPermissionResult == PackageManager.PERMISSION_GRANTED &&
                SecondPermissionResult == PackageManager.PERMISSION_GRANTED &&

                FortPermissionResult == PackageManager.PERMISSION_GRANTED&&
                ForPermissionResult == PackageManager.PERMISSION_GRANTED
    }


    private fun RequestMultiplePermission() {
        ActivityCompat.requestPermissions(this@SplashActivity, arrayOf<String>(android.Manifest.permission.WRITE_EXTERNAL_STORAGE, android.Manifest.permission.READ_EXTERNAL_STORAGE,android.Manifest.permission.INTERNET,android.Manifest.permission.CAMERA), PERMISSION_REQUEST)

    }
}