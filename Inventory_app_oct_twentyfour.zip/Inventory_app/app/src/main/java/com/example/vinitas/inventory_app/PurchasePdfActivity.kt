package com.example.vinitas.inventory_app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.*
import android.print.PdfView
import android.print.PrintAttributes
import android.print.PrintManager
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.app.NotificationCompat
import android.support.v7.app.AppCompatActivity
import android.support.v4.content.ContextCompat
import android.support.v4.content.FileProvider
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil

import dmax.dialog.SpotsDialog
import kotlinx.android.synthetic.main.activity_purchase_pdf.*
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import java.util.Collections.replaceAll





@RequiresApi(Build.VERSION_CODES.LOLLIPOP)

class PurchasePdfActivity() : AppCompatActivity(){

    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    var ids = arrayOf<String>()


    var suppinv=""


   var orddatedup=String()
   var reqdatedup=String()
   var descripdup=String()

    var descriplistener=String()
    var listListener=String()

    var supplieridfr=String()

    var edclick=String()
    var htmlDocument= String()


    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""


    var sendpo=String()


    var brnchidss = String()

    var  pronameArray       = arrayListOf<String>()
    var  hsnArray           = arrayListOf<String>()
    var  manufacturerArray  = arrayListOf<String>()
    var  barcodeArray       = arrayListOf<String>()
    var  quantityArray      = arrayListOf<String>()
    var  priceArray         = arrayListOf<String>()
    var  totArray           = arrayListOf<String>()
    var  grosstotArray           = arrayListOf<String>()

    var  cessArray          = arrayListOf<String>()
    var  imageArray         = arrayListOf<String>()
    var  idproArray         = arrayListOf<String>()
    var  igstArray         = arrayListOf<String>()
    var  cgstArray         = arrayListOf<String>()
    var  sgstArray         = arrayListOf<String>()
    var  igsttotArray         = arrayListOf<String>()
    var  cesstotalArray         = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var receivedArraypri = arrayListOf<String>()
    var receivedArraytaxtot = arrayListOf<String>()
    var receivedArraytotal = arrayListOf<String>()
    var receivedArraygrosstotal = arrayListOf<String>()
    var receivedArraycesstotal = arrayListOf<String>()
    var tallyArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var singrosstot= arrayListOf<String>()

      var downstatus= String()
    var nms = String()
    var ph = String()
    var reqliid = String()
    var reprnms = String()
    var ponum = String()
    var recstatus = String()
    var reqdt = String()
    var desc = String()
    var orddate = String()
    var postatus = String()
    var recprice = String()
    var rectoal = String()
    var recquant = String()
    var reccesstot = String()
    var rectaxtot = String()
    var recgrosstot = String()
    var idli = String()
    var brky = String()
    var tallyar = String()
    var receivear = String()
    var suppname= String()
    var suppphone= String()
    var grossto = String()
    var igstto = String()
    var cgstto = String()
    var sgstto = String()
    var cessto = String()


    var grossori=String()

    var smill= String()

    var tt=arrayListOf<String>()
    var idofprott=arrayListOf<String>()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null



    private var myWebView: WebView? = null


    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    /*constructor(parcel: Parcel) : this() {
        pronameArray = parcel.createStringArray()
        hsnArray = parcel.createStringArray()
        manufacturerArray = parcel.createStringArray()
        barcodeArray = parcel.createStringArray()
        quantityArray = parcel.createStringArray()
        priceArray = parcel.createStringArray()
        totArray = parcel.createStringArray()
        cessArray = parcel.createStringArray()
        igstArray = parcel.createStringArray()
        cgstArray = parcel.createStringArray()
        sgstArray = parcel.createStringArray()
        igsttotArray = parcel.createStringArray()
        cesstotalArray = parcel.createStringArray()
        receivedArray = parcel.createStringArray()
        receivedArraypri = parcel.createStringArray()
        receivedArraytaxtot = parcel.createStringArray()
        receivedArraytotal = parcel.createStringArray()
        receivedArraygrosstotal = parcel.createStringArray()
        receivedArraycesstotal = parcel.createStringArray()
        tallyArray = parcel.createStringArray()
        keyArray = parcel.createStringArray()
        nms = parcel.readString()
        ph = parcel.readString()
        reqliid = parcel.readString()
        reprnms = parcel.readString()
        ponum = parcel.readString()
        recstatus = parcel.readString()
        reqdt = parcel.readString()
        desc = parcel.readString()
        orddate = parcel.readString()
        postatus = parcel.readString()
        recprice = parcel.readString()
        rectoal = parcel.readString()
        recquant = parcel.readString()
        reccesstot = parcel.readString()
        rectaxtot = parcel.readString()
        recgrosstot = parcel.readString()
        idli = parcel.readString()
        brky = parcel.readString()
        tallyar = parcel.readString()
        receivear = parcel.readString()
        suppname = parcel.readString()
        suppphone = parcel.readString()
        grossto = parcel.readString()
        smill = parcel.readString()
    }*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_purchase_pdf)

        net_status()//Check net status


        val webView = findViewById<WebView>(R.id.webviews) as WebView //Initaialize web view

        myWebView = webView//Assign web view globally

//Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@PurchasePdfActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }


        //Define No connection view when inetrnet connection is off.


        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.container)

        val bundle = intent.extras
        var frm = bundle!!.get("from_pur").toString()




        //Get details from (PurcathirdMainActivity)


        var a = bundle.get("pnm") as ArrayList<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy = bundle.get("phsn") as ArrayList<String>
        val ly = bundle.get("pmanu") as ArrayList<String>
        val fy = bundle.get("barcode") as ArrayList<String>
        val gy = bundle.get("quan") as ArrayList<String>
        val hy = bundle.get("price") as ArrayList<String>
        val ky = bundle.get("tot") as ArrayList<String>
        val kygro = bundle.get("grosstot") as ArrayList<String>

        val my = bundle.get("cessup") as ArrayList<String>
        val ny = bundle.get("igst") as ArrayList<String>
        val cy = bundle.get("cgst") as ArrayList<String>
        val sy = bundle.get("sgst") as ArrayList<String>
        val oy = bundle.get("igsttotal") as ArrayList<String>
        val py = bundle.get("cesstotarray") as ArrayList<String>
        val iddd = bundle.get("idsofli") as ArrayList<String>
        val idtally = bundle.get("tallyarray") as ArrayList<String>
        val idrec = bundle.get("receivedarray") as ArrayList<String>
        println("REEECCCCIIIEEEVVVVEEE" + idrec)
        val spri = bundle.get("received_price") as ArrayList<String>
        val stot = bundle.get("received_total") as ArrayList<String>
        val staxt = bundle.get("received_taxtot") as ArrayList<String>
        val scesstot = bundle.get("received_cesstot") as ArrayList<String>
        val sgross = bundle.get("received_grosstot") as ArrayList<String>

        val idsar = bundle.get("ids") as Array<String>
        ids=idsar.clone()


        try {
            val immy = bundle.get("image") as ArrayList<String>
            tt = immy
        } catch (e: Exception) {

        }



            val idpros = bundle.get("idpro") as ArrayList<String>
            idproArray = idpros


        try {


            val stat = intent.getStringExtra("postatus")
            postatus = stat
            println("PO STATUSSS" + postatus)
        }
        catch(e:Exception) {

        }


        try{

            edclick=intent.getStringExtra("edclick")

        }
        catch (e:Exception){

        }


        try{
            sendpo=intent.getStringExtra("sendpo")
        }
        catch (e:Exception){

        }

        try{

            supplieridfr=intent.getStringExtra("supplieridfr")
        }
        catch (e:Exception){

        }

        try{
            suppinv=intent.getStringExtra("suppinv")

        }
        catch (e:Exception){

        }


           try {
               val aa = intent.getStringExtra("nms")
               suppname = aa


               val b = intent.getStringExtra("ph")
               suppphone = b

               val lii = intent.getStringExtra("pono")
               ponum = lii
           }
           catch (e:Exception){

           }

try {
    orddatedup = intent.getStringExtra("orddatedup")
    reqdatedup = intent.getStringExtra("reqdatedup")
    descripdup = intent.getStringExtra("descripdup")
}
catch (e:Exception){

}
        try {
            descriplistener = intent.getStringExtra("descriplistener")
            listListener = intent.getStringExtra("listListener")

        }
        catch (e:Exception){

        }


try {
    val grosst = intent.getStringExtra("gross")
    grossto = grosst

    val igstt = intent.getStringExtra("igsts")
    igstto = igstt

    val cgstt = intent.getStringExtra("cgsts")
    cgstto = cgstt

    val sgstt = intent.getStringExtra("sgsts")
    sgstto = sgstt

    val cesst = intent.getStringExtra("cessts")
    cessto = cesst
}
catch(e:Exception){
    val igstt = intent.getStringExtra("igsts")
    igstto = igstt

    val cgstt = intent.getStringExtra("cgsts")
    cgstto = cgstt

    val sgstt = intent.getStringExtra("sgsts")
    sgstto = sgstt

    val cesst = intent.getStringExtra("cessts")
    cessto = cesst
}

            try {

                val f = intent.getStringExtra("reqdate")
                reqdt = f

                val ff = intent.getStringExtra("orddate")
                orddate = ff
            }
            catch (e:Exception){

            }

        try{

            grossori=intent.getStringExtra("grossori")

        }
        catch (e:Exception){

        }



        try {
                val bridd = intent.getStringExtra("brids")
                brnchidss = bridd

                val liis = intent.getStringExtra("reqliid")
                reqliid = liis
        }
        catch(e:Exception){

            val bridd = intent.getStringExtra("brids")
            brnchidss = bridd

            val liis = intent.getStringExtra("reqliid")
            reqliid = liis
        }

            try {
                val nm = intent.getStringExtra("reprnms")
                reprnms = nm

                val e = intent.getStringExtra("desc")
                desc = e
            }

            catch (e:Exception){

            }







        //Purchase order

        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")

        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }




        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr
        }
        if (expr != null) {
            exportpurreq = expr
        }






        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }

        //Supname

           /* if (suppname.isNotEmpty()) {
                suppliernm.setText(suppname)
            } else {
                suppliernm.setText("-")
            }


            //Supphone

            if (suppphone.isNotEmpty()) {
                supplierph.setText(suppphone)
            } else {
                supplierph.setText("-")
            }


            //Gross tot
            if (grossto.isNotEmpty()) {
                gross.setText(grossto)
            } else {
                gross.setText("-")
            }

            //IGST TOT
            if (igstto.isNotEmpty()) {
                igsttotal.setText(igstto)
            } else {
                igsttotal.setText("-")
            }

            //CGST TOT
            if (cgstto.isNotEmpty()) {
                cgsttotal.setText(cgstto)
            } else {
                cgsttotal.setText("-")
            }

            //SGST TOT
            if (sgstto.isNotEmpty()) {
                sgsttotal.setText(sgstto)
            } else {
                sgsttotal.setText("-")
            }

            //CESS TOT
            if (cessto.isNotEmpty()) {
                cesstotal.setText(cessto)
            } else {
                cesstotal.setText("-")
            }

            //DESCRIPTION
            if (desc.isNotEmpty()) {
                descr.setText(desc)
            } else {
                descr.setText("-")
            }

            //Invoice

            if (reqdt.isNotEmpty()) {
                reqdate.setText(reqdt)
            } else {
                reqdate.setText("-")
            }

            //Date
            if (orddate.isNotEmpty()) {
                date.setText(orddate)
            } else {
                date.setText("-")
            }

           *//* //Due date
            if (postatus.isNotEmpty()) {
                postat.setText(postatus)
            } else {
                postat.setText("NONE")
            }*//*

            //Voucher date
            if (ponum.isNotEmpty()) {
                pono.setText(ponum)
            } else {
                pono.setText("-")
            }*/

       /*  catch (e: Exception) {

        }*/



        pronameArray = a
        hsnArray = dsy
        manufacturerArray = ly
        barcodeArray = fy
        quantityArray = gy
        priceArray = hy
        totArray = ky
        grosstotArray = kygro

        receivedArray = idrec
        cessArray = my
        igstArray = ny
        cgstArray = cy
        sgstArray = sy
        igsttotArray = oy
        cesstotalArray = py
        tallyArray = idtally
        receivedArraypri = spri
        receivedArraytotal = stot
        receivedArraytaxtot = staxt
        receivedArraycesstotal = scesstot
        receivedArraygrosstotal = sgross
        imageArray = tt
        keyArray = iddd


        addData();


        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView,
                                                  url: String): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {

                if(sendpo=="send"){
                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order"
                val dir = File(path);
                if (!dir.exists())
                    dir.mkdirs()

                var f = ponum
                smill = orddate
                var c = suppname
                var y = f + ".pdf"





                val file = File(dir, y)
                val progressDialog = ProgressDialog(this@PurchasePdfActivity)
                progressDialog.setMessage("Please wait")
                progressDialog.show()
                try {
                    PdfView.createWebPrintJob(this@PurchasePdfActivity, webView, file, y, object : PdfView.Callback {

                        override fun success(path: String) {
                            progressDialog.dismiss()
                            val builder = android.app.AlertDialog.Builder(this@PurchasePdfActivity)
                            with(builder) {
                                setTitle("Are you sure?")
                                setMessage("Are you sure want to send?")
                                setPositiveButton("Send") { dialog, whichButton ->
                                  sendMail(path)
                                }
                                setNegativeButton("Cancel") { dialog, whichButton ->
                                    //showMessage("Close the game or anything!")
                                    dialog.dismiss()
                                }

                                // Dialog
                                val dialog = builder.create()

                                dialog.show()
                            }
                        }

                        override fun failure() {
                            progressDialog.dismiss()

                        }
                    })
                }
                catch (e:Exception){
                    Toast.makeText(applicationContext,"Already exist",Toast.LENGTH_SHORT).show()
                }
                }
                myWebView = null
            }
        }


        pdf.setOnClickListener {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order"
            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            var f = ponum
            smill = orddate
            var c = suppname
            var y = f + ".pdf"





            val file = File(dir, y)
            val progressDialog = ProgressDialog(this@PurchasePdfActivity)
            progressDialog.setMessage("Please wait")
            progressDialog.show()
            try {
                PdfView.createWebPrintJob(this@PurchasePdfActivity, webView, file, y, object : PdfView.Callback {

                    override fun success(path: String) {
                        progressDialog.dismiss()
                        val builder = android.app.AlertDialog.Builder(this@PurchasePdfActivity)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->
                                PdfView.openPdfFile(this@PurchasePdfActivity, path)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }

                    override fun failure() {
                        progressDialog.dismiss()

                    }
                })
            }
            catch (e:Exception){
                Toast.makeText(applicationContext,"Already exist",Toast.LENGTH_SHORT).show()
            }
        }

        /*pdf.setOnClickListener {

            //Create local path storage for this pdf


            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Purchase Order"

            val dir = File(path)
            if (!dir.exists())
                dir.mkdirs()
            var f = ponum
            smill = orddate
            var c = suppname
            var y = f + ".pdf"

            val file = File(dir, y)

            if (file.exists()) {         //If file already exist alert


                val builder = AlertDialog.Builder(this)
                with(builder) {
                    setTitle("File Already Exist")
                    setMessage("Do you want to overwrite the existing file?")





                    setPositiveButton("Yes") { dialog, whichButton ->    //Overwrite the exist pdf




                        val dialo = SpotsDialog(context, "Downloading pdf...")

                        dialo.show();

                        createandDisplayPdf(suppname, suppphone, ponum, orddate, desc, reqdt, postatus, igstto, cgstto, sgstto, cessto, grossto)  //Pdf write fiunction


                        val timer2 = Timer()
                        timer2.schedule(object : TimerTask() {
                            override fun run() {
                                if(downstatus=="success"){
                                    val mBuilder = NotificationCompat.Builder(this@PurchasePdfActivity)
                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                    val uri = Uri.parse(Environment.getExternalStorageDirectory().path
                                            + File.separator + "Purchase Order" + File.separator)
                                    intent.setDataAndType(uri, "application/pdf") //Open pdf with pdf reader

                                    val pendingIntent = PendingIntent.getActivity(this@PurchasePdfActivity, 0, intent, 0)
                                    mBuilder.setContentIntent(pendingIntent)


                                    val mNotifyManager = this@PurchasePdfActivity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                                    //Notification alert

                                    mBuilder.setContentTitle(ponum + ".pdf")
                                    mBuilder.setContentText("Downloaded")
                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                                    mBuilder.setProgress(100, 100, false)
                                    mNotifyManager.notify(0, mBuilder.build());
                                }
                                dialo.dismiss()


                                timer2.cancel() //this will cancel the timer of the system
                            }


                        }, 3000)

                        val handler = Handler()
                        handler.postDelayed({
                            println("INSIDE IF" + a)
                            if(file.exists()) {
                                val builder = AlertDialog.Builder(this@PurchasePdfActivity)
                                with(builder) {
                                    setTitle("File downloaded")
                                    setMessage("Do you want to open a file?")
                                    setPositiveButton("Open") { dialog, whichButton ->

                                    var f = ponum
                                var s = smill
                                var c = suppname
                                var y = f + ".pdf"
                                viewPdf("Purchase Order", y)
                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            }
                            else{

                            }
                        }, 4000)


            }


                setNegativeButton("NO") { dialog, whichButton ->
                    //showMessage("Close the game or anything!")
                    dialog.dismiss()
                }

                // Dialog
                val dialog = builder.create()

                dialog.show()
            }

        }

                    else {




                val dialo = SpotsDialog(this@PurchasePdfActivity, "Downloading pdf...")

                dialo.show();


                val timer2 = Timer()
                timer2.schedule(object : TimerTask() {
                    override fun run() {
                        createandDisplayPdf(suppname, suppphone, ponum, orddate, desc, reqdt, postatus, igstto, cgstto, sgstto, cessto, grossto)  //Pdf write fiunction
                        if(downstatus=="success"){
                            val mBuilder = NotificationCompat.Builder(this@PurchasePdfActivity)
                            val intent = Intent(Intent.ACTION_GET_CONTENT)
                            val uri = Uri.parse(Environment.getExternalStorageDirectory().path
                                    + File.separator + "Purchase Order" + File.separator)
                            intent.setDataAndType(uri, "application/pdf")  //Open pdf with pdf reader

                            val pendingIntent = PendingIntent.getActivity(this@PurchasePdfActivity, 0, intent, 0)
                            mBuilder.setContentIntent(pendingIntent)


                            val mNotifyManager = this@PurchasePdfActivity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;



                            mBuilder.setContentTitle(ponum + ".pdf")
                            mBuilder.setContentText("Downloaded")
                            mBuilder.setSmallIcon(R.drawable.ic_logo)
                            mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                            mBuilder.setProgress(100, 100, false)
                            mNotifyManager.notify(0, mBuilder.build());
                        }

                        dialo.dismiss()
                        var b = "null"

                        timer2.cancel() //this will cancel the timer of the system
                    }


                }, 3000)

                val handler = Handler()
                handler.postDelayed({
                    println("INSIDE IF" + a)
                    if (file.exists()) {
                        val builder = AlertDialog.Builder(this@PurchasePdfActivity)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->


                                var f = ponum
                                var s = smill
                                var c = suppname
                                var y = f + ".pdf"
                                viewPdf("Purchase Order", y)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    } else {

                    }

                }, 4000)


            }
        }*/


       back.setOnClickListener {
          onBackPressed()

       }



    }

    override fun onBackPressed() {

        //Back action

        val bundle = intent.extras
        var a = bundle.get("pnm") as ArrayList<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy = bundle.get("phsn") as ArrayList<String>
        val ly = bundle.get("pmanu") as ArrayList<String>
        val fy = bundle.get("barcode") as ArrayList<String>
        val gy = bundle.get("quan") as ArrayList<String>
        val hy = bundle.get("price") as ArrayList<String>
        val ky = bundle.get("tot") as ArrayList<String>
        val kygro = bundle.get("grosstot") as ArrayList<String>

        val my = bundle.get("cessup") as ArrayList<String>
        val ny = bundle.get("igst") as ArrayList<String>
        val cy = bundle.get("cgst") as ArrayList<String>
        val sy = bundle.get("sgst") as ArrayList<String>
        val oy = bundle.get("igsttotal") as ArrayList<String>
        val py = bundle.get("cesstotarray") as ArrayList<String>
        val iddd = bundle.get("idsofli") as ArrayList<String>
        val idtally = bundle.get("tallyarray") as ArrayList<String>
        val idrec = bundle.get("receivedarray") as ArrayList<String>
        println("REEECCCCIIIEEEVVVVEEE" + idrec)
        val spri = bundle.get("received_price") as ArrayList<String>
        val stot = bundle.get("received_total") as ArrayList<String>
        val staxt = bundle.get("received_taxtot") as ArrayList<String>
        val scesstot = bundle.get("received_cesstot") as ArrayList<String>
        val sgross = bundle.get("received_grosstot") as ArrayList<String>

        val idsar = bundle.get("ids") as Array<String>
        ids=idsar.clone()


        try {
            val immy = bundle.get("image") as ArrayList<String>
            tt = immy
        } catch (e: Exception) {

        }

        val idpros=bundle.get("idpro") as ArrayList<String>
        idproArray=idpros

        try {


            val stat = intent.getStringExtra("postatus")
            postatus = stat
            println("PO STATUSSS" + postatus)
        }
        catch(e:Exception) {

        }
        try{

            supplieridfr=intent.getStringExtra("supplieridfr")
        }
        catch (e:Exception){

        }



        try{

            edclick=intent.getStringExtra("edclick")

        }
        catch (e:Exception){

        }

        try{
            suppinv=intent.getStringExtra("suppinv")

        }
        catch (e:Exception){

        }


        try{
            sendpo=intent.getStringExtra("sendpo")
        }
        catch (e:Exception){

        }

        try {
            val aa = intent.getStringExtra("nms")
            suppname = aa


            val b = intent.getStringExtra("ph")
            suppphone = b

            val lii = intent.getStringExtra("pono")
            ponum = lii
        }
        catch (e:Exception){

        }

        try{

            grossori=intent.getStringExtra("grossori")

        }
        catch (e:Exception){

        }
        try {
            val grosst = intent.getStringExtra("gross")
            grossto = grosst

            val igstt = intent.getStringExtra("igsts")
            igstto = igstt

            val cgstt = intent.getStringExtra("cgsts")
            cgstto = cgstt

            val sgstt = intent.getStringExtra("sgsts")
            sgstto = sgstt

            val cesst = intent.getStringExtra("cessts")
            cessto = cesst
        }
        catch(e:Exception){
            val igstt = intent.getStringExtra("igsts")
            igstto = igstt

            val cgstt = intent.getStringExtra("cgsts")
            cgstto = cgstt

            val sgstt = intent.getStringExtra("sgsts")
            sgstto = sgstt

            val cesst = intent.getStringExtra("cessts")
            cessto = cesst
        }

        try {

            val f = intent.getStringExtra("reqdate")
            reqdt = f

            val ff = intent.getStringExtra("orddate")
            orddate = ff
        }
        catch (e:Exception){

        }



        try {
            val bridd = intent.getStringExtra("brids")
            brnchidss = bridd

            val liis = intent.getStringExtra("reqliid")
            reqliid = liis
        }
        catch(e:Exception){

        }

        try {
            val nm = intent.getStringExtra("reprnms")
            reprnms = nm

            val e = intent.getStringExtra("desc")
            desc = e
        }

        catch (e:Exception){

        }
        try {
            orddatedup = intent.getStringExtra("orddatedup")
            reqdatedup = intent.getStringExtra("reqdatedup")
            descripdup = intent.getStringExtra("descripdup")
        }
        catch (e:Exception){

        }
        try {
            descriplistener = intent.getStringExtra("descriplistener")
            listListener = intent.getStringExtra("listListener")

        }
        catch (e:Exception){

        }


        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")

        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }
        val o = Intent(this@PurchasePdfActivity, PurcathirdMainActivity::class.java)
        o.putExtra("from_pur", "from_pdf")
        o.putExtra("renm", a)
        o.putExtra("remanu", ly)
        o.putExtra("rekey", iddd)
        o.putExtra("rehsn", dsy)
        o.putExtra("reprice", hy)
        o.putExtra("requan", gy)
        o.putExtra("rebc", fy)
        o.putExtra("retotal", ky)
        o.putExtra("regrosstotal", kygro)
        o.putExtra("recess", my)
        o.putExtra("reigst", ny)
        o.putExtra("recgst", cy)
        o.putExtra("resgst", sy)
        o.putExtra("retally", idtally)
        o.putExtra("rereceived", idrec)
        o.putExtra("rereceived_pri", spri)
        o.putExtra("rereceived_tot", stot)
        o.putExtra("rereceived_taxtot", staxt)
        o.putExtra("rereceived_cesstot", scesstot)
        o.putExtra("rereceived_grosstot", sgross)
        o.putExtra("reigst_total", oy)
        o.putExtra("recesstotal", py)
        o.putExtra("reimmg", tt)
        o.putExtra("idpro", idproArray)
        o.putExtra("supplieridfr",supplieridfr)

        o.putExtra("suppinv",suppinv)

        o.putExtra("edclick",edclick)
        o.putExtra("orddatedup",orddatedup)
        o.putExtra("reqdatedup",reqdatedup)
        o.putExtra("descripdup",descripdup)

        o.putExtra("pono", ponum)
        o.putExtra("names", reprnms)
        o.putExtra("redesc", desc)
        o.putExtra("reorddate", orddate)
        o.putExtra("reestdt", reqdt)
        o.putExtra("restatus", postatus)
        o.putExtra("reids", reqliid)
        o.putExtra("titnm", suppname)
        o.putExtra("tiphone", suppphone)
        o.putExtra("brids", brnchidss)
        o.putExtra("regross", grossori)
        o.putExtra("reigsts", igstto)
        o.putExtra("recgsts", cgstto)
        o.putExtra("resgsts", sgstto)
        o.putExtra("recessts", cessto)
        o.putExtra("brids", brnchidss)
        o.putExtra("viewsuppin", viewsuppin)
        o.putExtra("addsuppin", addsuppin)
        o.putExtra("deletesuppin", deletesuppin)
        o.putExtra("editsuppin", editesuppin)
        o.putExtra("transfersuppin", transfersuppin)
        o.putExtra("exportsuppin", exportsuppin)
        o.putExtra("descriplistener",descriplistener)
        o.putExtra("listListener",listListener)

        o.putExtra("viewpurord", viewpurord)
        o.putExtra("addpurord", addpurord)
        o.putExtra("deletepurord", deletepurord)
        o.putExtra("editpurord", editepurord)
        o.putExtra("transferpurord", transferpurord)
        o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)

        o.putExtra("ids",ids)


        o.putExtra("viewpurreq", viewpurreq)
        o.putExtra("addpurreq", addpurreq)
        o.putExtra("deletepurreq", deletepurreq)
        o.putExtra("editpurreq", editepurreq)
        o.putExtra("transferpurreq", transferpurreq)
        o.putExtra("exportpurreq", exportpurreq)


        startActivity(o)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()
    }




    private fun getTextView(id: Int, title: String, color: Int, typeface: Int, bgColor: Int): TextView {   //Document's fonts and design
        val tv = TextView(this)
        tv.id = id
        tv.text = title.toUpperCase()
        tv.setTextColor(color)
        tv.setPadding(20, 20, 20, 20)
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.DEFAULT, typeface)
        tv.setBackgroundColor(bgColor)
        tv.layoutParams = getLayoutParams()

        return tv
    }

    private fun getLayoutParams(): TableRow.LayoutParams {          //Table row layout design
        val params = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT)
        params.setMargins(2, 0, 0, 2)
        return params
    }

    private fun getTblLayoutParams(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT)
    }

    fun addHeaders() {   //TAble headers
        val tl = findViewById<TableLayout>(R.id.table)
        val tr = TableRow(this)
        tr.layoutParams = getLayoutParams()
        tr.addView(getTextView(0, "S.No", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))

        tr.addView(getTextView(0, "Product name", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "HSN/SAC", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Price", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Quantity", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "          Tax         ", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Total", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tl.addView(tr, getTblLayoutParams())



    }
    var ee=0.0F
    var cc=0.0F
    var gros=0.0F
    var ig=0.0F
    var cg=0.0F
    var sg=0.0F
    var ces=0.0F


    fun addData() {                 //Fill datas on table








        htmlDocument = "<html><body><h3>Vinitas Enterprises Pvt Ltd</h3><h4>" + "Purchase order</h4>" +

                "<table class=Border>"+

                "<tr>"+
                "<td class=Border>PO No:  </td>"+
                "<td class=Border> $ponum </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Order Date: </td>"+
                "<td class=Border>$orddate </td>"+
                "</tr>"+


                "<tr>"+
                "<td class=Border>Description: </td>"+
                "<td class=Border> $desc </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Required By:</td>"+
                "<td class=Border>$reqdt</td>"+
                "</tr>"+



               /* "<h5>Purchase Details</h5>"+

                "<p>Requestor name:          $reqnm <p/>" +
                "<p>Requestor phone:       $reqph  <p/> "+
                "<p>Requestor Email:          $reqmail  <p/> "+
                "<p>Estimated date: $restimt  <p/> "+
                "<p></p>"+*/

                "<tr>"+
                "<td class=Border><b>Supplier Details</b></td>"+
                "<td class=Border></td>"+"</tr>"+
                "<tr>"+

                "<tr>"+
                "<td class=Border>Supplier Name: </td>"+
                "<td class=Border>$suppname</td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Supplier Phone: </td>"+
                "<td class=Border>$suppphone</td>"+
                "</tr>"+


                "<tr>"+
                "<td class=Border><b>Bill To:</b></td>"+
                "<td class=Border></td>"+"</tr>"+
                "<tr>"+


                "<table class=Border>"+
                "<tr>"+
                "<td class=Borders>Vinitas Enterprises pvt Ltd,\n" +
                "438,KK nagar , Opposite Mahatma School,\n" +
                "Madurai, Tamil nadu 625020.</td>"+ "</tr>"+


                "<style>"+
                "table, th, td {"+
                "border: 1px solid black;"+
                "border-collapse: collapse;"+
                "}"+
                "th, td {"+
                "padding: 15px;"+
                "}"+
                "th {"+
                "text-align: left;"+
                "}"+
                "td.Hidden {"+
                "visibility: hidden;"+
                "}"+
                "td.Border {"+
                "border:none;"+
                "width:60%;"+
                "padding:8px;"+
                "}"+
                "td.Borders {"+
                "border:none;"+
                "width:100%;"+

                "}"+

                "table.Border {"+
                "border:none;"+

                "}"+
                "</style>"+

                "<table style=\"width:100%\">"+
                "<tr>"+







                "<th>S.No</th>"+
                "<th>Product name</th>"+
                "<th>HSN/SAC Code</th>"+

                "<th>Price</th>"+
                "<th>Quantity</th>"+
                "<th>Tax</th>"+
                "<th>Total</th>"+
                "</tr>"

        val tl = findViewById<TableLayout>(R.id.table)
        for (i in 0 until priceArray.size) {
            val tr = TableRow(this)

            tr.layoutParams = getLayoutParams()
            var pri=priceArray[i].toFloat()
            var quan=receivedArray[i].toFloat()
            var e=igsttotArray[i].toFloat()
            var f=cesstotalArray[i].toFloat()

            var jj=e+f

            var grtt=jj
            var grflo=grtt
            var gttt=grflo+(pri*quan)

            var grossrealtot=gttt+gros

            singrosstot.add(grossrealtot.toString())


            htmlDocument=htmlDocument+
                    "<tr>"+
                    "<td>${i+1}</td>"+
                    "<td>${pronameArray[i]}</td>"+
                    "<td>${hsnArray[i]}</td>"+
                    "<td>${priceArray[i]}</td>"+
                    "<td>${receivedArray[i]}</td>"+
                    "<td>$grtt</td>"+
                    "<td>$gttt</td>"+
                    "</tr>"

            if(priceArray.size==i){

            }



          /*  tr.addView(getTextView(i + 1, (i+1).toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, pronameArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, hsnArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))

            tr.addView(getTextView(i +1, priceArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))

            tr.addView(getTextView(i +1, quantityArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, grtt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, gttt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tl.addView(tr, getTblLayoutParams())*/
        }


        htmlDocument=htmlDocument+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>IGST TOTAL:</td>"+
                "<td>$igstto</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>CGST TOTAL:</td>"+
                "<td>$cgstto</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>SGST TOTAL:</td>"+
                "<td>$sgstto</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>Cess TOTAL:</td>"+
                "<td>$cessto</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td> Gross TOTAL:</td>"+
                "<td>$grossto</td>"+

                "</tr>"+"</body></html>"


        myWebView!!.loadDataWithBaseURL(null, htmlDocument, "text/HTML", "UTF-8", null)

        /*val t2 = findViewById<TableLayout>(R.id.table1)
        val t3 = findViewById<TableLayout>(R.id.table2)
        val tr2 = TableRow(this)
        val tr3 = TableRow(this)
        val tr4 = TableRow(this)
        val tr6 = TableRow(this)
        val tr5 = TableRow(this)

        val trval2= TableRow(this)
        val trval3= TableRow(this)
        val trval4= TableRow(this)
        val trval5= TableRow(this)
        val trval6= TableRow(this)



        tr2.layoutParams = getLayoutParams()

        trval2.addView(getTextView( 0,igstto, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval3.addView(getTextView( 0,cgstto, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval4.addView(getTextView( 0,sgstto, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval5.addView(getTextView( 0,cessto, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval6.addView(getTextView( 0,grossto,ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        tr2.addView(getTextView( 1,"IGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr3.addView(getTextView( 1,"CGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr4.addView(getTextView( 1,"SGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr5.addView(getTextView( 1,"Cess TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr6.addView(getTextView( 1,"Gross TOTAL:",ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        t2.addView(tr2, getTblLayoutParams())
        t2.addView(tr3, getTblLayoutParams())
        t2.addView(tr4, getTblLayoutParams())
        t2.addView(tr5, getTblLayoutParams())
        t2.addView(tr6, getTblLayoutParams())


        t3.addView(trval2, getTblLayoutParams())
        t3.addView(trval3, getTblLayoutParams())
        t3.addView(trval4, getTblLayoutParams())
        t3.addView(trval5, getTblLayoutParams())
        t3.addView(trval6, getTblLayoutParams())*/

    }

   /* override fun onClick(v: View)
    {
        val id = v.id
        val tv = findViewById<TextView>(id)
        if (null != tv) {
            Log.i("onClick", "Clicked on row :: " + id)
            Toast.makeText(this, "Clicked on row :: " + id + ", Text :: " + tv.text, Toast.LENGTH_SHORT).show()
        }
    }*/


                    //-----------------Create,write,export pdf---------------------//


   /* fun createandDisplayPdf(nm:String,ph:String,vno:String,date:String,desc:String,ivdt:String,paydt:String,igstt:String,csgtt:String,sgstt:String,cesst:String,grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Purchase Order"

            val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs()
            var f=ponum
            smill=orddate
            var c=suppname
            var y=f+".pdf"

            val file = File(dir,y)
            val fOut =  FileOutputStream(file)




            PdfWriter.getInstance(doc,fOut)

            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSize1 = 10.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= Font.BOLD

            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b)
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b)
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize)

            val font1 = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize1,b)
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Purchase Order",fontsubheading)



            val p1 =  Paragraph("Supplier Name:         "+nm,font)

            val p2 =  Paragraph("Supplier Phone:         "+ph,font)
            val p3 =  Paragraph("PO No:                    "+vno,font)
            val p4 =  Paragraph("Order Date:                "+date,font)
            val p11 =  Paragraph("Description:                    "+desc,font)
            val p5 =  Paragraph("Required By:              "+ivdt,font)
            val supde= Paragraph("Supplier Details:                  ",fontsubheading)
            val billto= Paragraph("Bill to:                  ",fontsubheading)
            val offaddre= Paragraph("Vinitas Enterprises pvt Ltd," +
                                "No:438,KK Nagar,Opposite Mahatma School," +
                                 "Madurai,Tamil Nadu-635020",font)
           *//* val p6 =  Paragraph("PO Status:                  "+paydt,font)
            val p12 =  Paragraph("IGST Total:                  "+igstt,font)
            val p13 =  Paragraph("CGST Total:                  "+csgtt,font)
            val p14 =  Paragraph("SGST Total:                  "+sgstt,font)
            val p15 =  Paragraph("CESS Total:                  "+cesst,font)
            val p7 =  Paragraph("Gross Total:                 "+grosstot,font)*//*

            val p8=   Paragraph("Product Details",fontsubheading)

        *//*    val pnm= Paragraph("Product Name")
            val pri= Paragraph("Price")*//*
            val igstpdf= Paragraph("IGST TOTAL",font1)
            val cgstpdf= Paragraph("CGST TOTAL",font1)
            val sgstpdf= Paragraph("SGST TOTAL",font1)
            val cesspdf= Paragraph("Cess TOTAL",font1)
            val grosspdf= Paragraph("Gross TOTAL",font1)



            val table =  PdfPTable( floatArrayOf(2F,6F, 5F, 5F, 4F,6F, 4F ))

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER)

            table.addCell("S.No")

            table.addCell("Product Name")
            table.addCell("HSN/SAC")
            table.addCell("Price")

            table.addCell("Quantity")
            table.addCell("Taxes")
            table.addCell("Total")
            table.setHeaderRows(1)
            val cells = table.getRow(0).getCells()
            for(j in 0 until cells.size)
            {
                cells[j].setBackgroundColor(BaseColor.GRAY)
            }
            var ee=0.0F
            var cc=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var ces=0.0F
            for (i in 0 until priceArray.size)
            {

                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()

                var jj=e+f

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quan)

                var grossrealtot=gttt+gros


                *//*var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var div=2
                var e=igsttotArray[i]
                var eflo=e.toFloat()
                ee=ee+eflo
                ig= ee
                var csgsts=ig.toFloat()
                var csgttotalss=csgsts/div
                cg=csgttotalss
                sg=csgttotalss




                var f=cesstotalArray[i]
                var fflo=f.toFloat()
                cc=fflo+cc
                ces=cc
                var gg=ig.toFloat()
                var jj=ces.toFloat()
                var grtt=gg+jj+cc
                var grflo=grtt.toFloat()
                var gttt=grflo+(pri*quan)*//*



                table.addCell((i+1).toString())
                table.addCell(pronameArray[i])
                table.addCell(hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell(quantityArray[i])
                table.addCell(grtt.toString())

                table.addCell(gttt.toString())
            }
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER)
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            table.addCell("")

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("IGST Total")
            table.addCell(igstto)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgstto)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgstto)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cessto)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grossto)


            *//*val table1 =  PdfPTable( floatArrayOf(6F))

            table1.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);

            table1.setHeaderRows(1)
            val cells1 = table.getRow(0).getCells()


                table1.addCell("IGST Total"+igstto)
                table1.addCell("CGST Total"+cgstto)
                table1.addCell("SGST Total"+sgstto)
                table1.addCell( "Cess Total"+cessto)
                table1.addCell( "Gross Total"+grossto)*//*


      *//*      val table1 =  PdfPTable(2);
            val  cell = PdfPCell(igstpdf);
           cell.colspan=2
           cell.setBorder(PdfPCell.NO_BORDER);
           cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            table.addCell(cell);
            val cellCaveat =  PdfPCell(cgstpdf);
            cellCaveat.setColspan(1);
            cellCaveat.setBorder(PdfPCell.NO_BORDER);
            table1.addCell(cellCaveat);
           table1.addCell(cellCaveat);*//*






            //add paragraph to document
            doc.add(h1)
            doc.add( Chunk.NEWLINE )
            doc.add(hs1)
            doc.add( Chunk.NEWLINE )
            doc.add(p3);
            doc.add( Chunk.NEWLINE )
            doc.add(p4);
            doc.add( Chunk.NEWLINE )
            doc.add(p11);
            doc.add( Chunk.NEWLINE )
            doc.add(p5);
            doc.add( Chunk.NEWLINE )
            doc.add( Chunk.NEWLINE )
            doc.add(supde);
            doc.add( Chunk.NEWLINE );
            doc.add(p1);
            doc.add( Chunk.NEWLINE );
            doc.add(p2);
            doc.add( Chunk.NEWLINE );
            doc.add( Chunk.NEWLINE );
            doc.add(billto);
            doc.add( Chunk.NEWLINE );
            doc.add(offaddre);


     *//*       doc.add( Chunk.NEWLINE );
            doc.add(p6);
            doc.add( Chunk.NEWLINE );
            doc.add(p12);
            doc.add( Chunk.NEWLINE );
            doc.add(p13);
            doc.add( Chunk.NEWLINE );
            doc.add(p14);
            doc.add( Chunk.NEWLINE );
            doc.add(p15);
            doc.add( Chunk.NEWLINE );
            doc.add(p7)*//*

            doc.add( Chunk.NEWLINE );
            doc.add(p8);
            doc.add( Chunk.NEWLINE );
            doc.add(table)
            doc.add( Chunk.NEWLINE );

downstatus="success"

        } catch ( de: DocumentException) {
            downstatus="not"
        } catch ( e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        }
        finally {
            doc.close()
        }


    }*/

    // Method for opening a pdf file
    /*fun viewPdf(folder:String,file:String) {


        *//*  val pdfIntent = Intent(Intent.ACTION_VIEW)


            val newFilePath = folder.replace("%20", " ")
            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + newFilePath, file).toString()
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
                pdfIntent.setDataAndType(Uri.parse(pdfFile), "application/pdf");

            } else {
                val uri = Uri.parse(pdfFile);
                val file = File(uri.path);
                if (file.exists()) {
                    val uri = FileProvider.getUriForFile(this@PurchasePdfActivity, this.packageName + "com.example.vinitas.purchase_third.provider", file);
                    pdfIntent.setDataAndType(uri, "application/pdf");
                    pdfIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
            }
            pdfIntent.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);*//*


        *//*  println("SD CARD URL"+pdfFile)
        val path = Uri.fromFile(pdfFile)

        // Setting the intent for pdf reader

        pdfIntent.setDataAndType(path,"application/pdf")
        pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)*//*
        try {




            val pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + folder,file)
            println("SD CARD URL" + pdfFile)
            val path = Uri.fromFile(pdfFile)

            // Setting the intent for pdf reader
            val pdfIntent = Intent(Intent.ACTION_VIEW)
            pdfIntent.setDataAndType(path,"application/pdf")
            pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

            try {
                startActivity(pdfIntent);
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }


        }

        catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW)
            val k = folder.replace("%20", "")
            val path = Environment.getExternalStorageDirectory().absolutePath + "/" + folder + "/" + file
            println("PATH"+path)
            val targetFile = File(path)
            println("TARGET PATH"+targetFile)
            val targetUri = Uri.fromFile(targetFile)


            try {
                val photoURI = FileProvider.getUriForFile(applicationContext, "com.example.vinitas.purchase_third.provider",targetFile)
                println("URI"+photoURI)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                intent.setDataAndType(photoURI, "application/pdf")
                startActivity(intent);
                Toast.makeText(applicationContext, "path: " + path, Toast.LENGTH_SHORT).show()

            } catch (e: Exception) {
                Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show()
            }

        }
    }*/
   /* @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun createWebPrintJob(webView: WebView) {

        val printManager = this
                .getSystemService(Context.PRINT_SERVICE) as PrintManager

        val printAdapter = webView.createPrintDocumentAdapter("MyDocument")

        val jobName = getString(R.string.app_name) + " Print Test"

        printManager.print(jobName, printAdapter,
                PrintAttributes.Builder().build())
    }*/
    companion object {



        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {



                constraintLayout3dis!!.visibility=View.GONE

                relativeslayoutdis!!.visibility=View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }

    fun sendMail(path: String) {  //Send this purchase request to desired path.
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "Stock Transfer Pdf")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Inventory")
        val file = File(path)
        val uri = FileProvider.getUriForFile(this@PurchasePdfActivity, "com.package.name.fileprovider", file)
        emailIntent.type ="application/pdf"


        emailIntent.putExtra(Intent.EXTRA_STREAM, uri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))

    }


    fun net_status():Boolean{//Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }



}
