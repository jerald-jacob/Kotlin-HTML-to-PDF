package com.example.vinitas.inventory_app

import android.app.*
import android.content.Intent
import android.support.v4.content.WakefulBroadcastReceiver
import android.content.Context
import android.support.v4.app.NotificationCompat

import android.util.Log
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import android.app.PendingIntent
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.widget.Toast


/**
 * Created by Vinitas on 03/05/2018.
 */


class NotificationIntentService : IntentService(NotificationIntentService::class.java.simpleName) {
    var db = FirebaseFirestore.getInstance()
    internal lateinit var myDb: Databasehelper
    var a = arrayOf<String>()

    var orignm=String()
    var ids= String()
    var prArray= arrayListOf<String>()

    var idsar= arrayOf<String>()
    var tallystatus = String()
    internal lateinit var session: SessionManagement
    override fun onHandleIntent(intent: Intent?) {
        Log.d(javaClass.simpleName, "onHandleIntent, started handling a notification event")
        try {
            val action = intent!!.action
            if (ACTION_START == action) {
                processStartNotification()
            }
            if (ACTION_DELETE == action) {
                processDeleteNotification(intent)
            }
        } finally {
            WakefulBroadcastReceiver.completeWakefulIntent(intent!!)
        }




        val service_access =SessionManagement(this)



        val user = service_access.userDetails

        // name
        val name = user[SessionManagement.KEY_NAME]
        ids = name.toString()


    }

    private fun processDeleteNotification(intent: Intent) {
        // Log something?
    }




    // get user data from session


    private fun processStartNotification() {

        myDb = Databasehelper(this)

        var idsArray = arrayOf<String>()
        var nameArray = arrayOf<String>()
        var sunbnmArray = arrayOf<String>()//mfr
        var bcArray = arrayOf<String>()//bc
        var sohArray = arrayOf<String>()//stock_hand
        var mlArray = arrayOf<String>()//wg_vol
        var disArray = arrayOf<String>()//status
        var mhArray = arrayOf<String>()//mx_stk
        var priceArray = arrayOf<String>()//price
        var primgArray = arrayOf<String>()
        var pridArray = arrayOf<String>()
        val dd = myDb.getAllData()

        while (dd.moveToNext()) {
            pridArray = pridArray.plusElement(dd.getString(1))
            idsArray = idsArray.plusElement(dd.getString(0))
            a = idsArray
            val pname = dd.getString(2)
            val pvol = dd.getString(5)
            val pmfr = dd.getString(8)
            val pstkohhnd = dd.getString(28)
            val mxstk = dd.getString(12)
            val prices = dd.getString(11)
            val mrpp = dd.getString(22)
            val status = dd.getString(24)
            val barcode = dd.getString(3)
            nameArray = nameArray.plusElement(pname)
            sunbnmArray = sunbnmArray.plusElement(pmfr)
            bcArray = bcArray.plusElement(barcode)
            sohArray = sohArray.plusElement(pstkohhnd)
            mlArray = mlArray.plusElement(pvol + "ml")
            priceArray = priceArray.plusElement(mrpp)
            mhArray = mhArray.plusElement(mxstk)
            disArray = disArray.plusElement(status)
            val ur = dd.getString(34) //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"

            if (ur.isNotEmpty()) {
                primgArray = primgArray.plusElement(ur)
            } else {
                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
            }


            //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
            /* if (ur.isNotEmpty()) {

            icoArray = icoArray.plusElement(ur)
        }else{
            icoArray = icoArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
        }*/






            for (i in 0 until priceArray.count()) {
                var d = sohArray[i]

                println("DB STK HAND" + d)
                if (d == "0") {

                    println("INSIDE IF")
                    var tt = nameArray[i]


                    val mBuilder = NotificationCompat.Builder(this@NotificationIntentService)


                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                    val mNotifyManager = this@NotificationIntentService.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                    val resultIntent = Intent(this, MainProductlistActivity::class.java)
                    val stackBuilder = TaskStackBuilder.create(this)
                    stackBuilder.addParentStack(MainProductlistActivity::class.java)

// Adds the Intent that starts the Activity to the top of the stack
                    stackBuilder.addNextIntent(resultIntent)
                    val resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
                    mBuilder.setContentIntent(resultPendingIntent)

                    mBuilder.setDeleteIntent(NotificationEventReceiver.getDeleteIntent(this))

                    mBuilder.setContentText("Alert")
                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                    mBuilder.setContentTitle(tt + " has no number of stock")
                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)

                    mNotifyManager.notify(i, mBuilder.build());
                }
            }
        }


        /*  db.collection("Receive Stock").whereEqualTo("stk_brid", ids)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var stockidArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var tallyArray = arrayOf<String>()
                        var talliedArray = arrayOf<String>()





                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
                        if (value.isEmpty == false) {

                            for (document in value) {

                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                println(document.data)

                                var dt = document.data
                                var id = (document.id)
                                idss = idss.plusElement(id)
                                println(idss)

                                *//*  idss=idss.plusElement(path)
                                                  i=idss
                                                  println(id)
                                                  println(i)*//*

                                var name = (dt["stk_Desc"]).toString()
                                var date = (dt["stkdate"]).toString()
                                var tot = (dt["stk_total"]).toString()


                                var manufacturer = (dt["stkid"]).toString()
                                var brnm = (dt["stk_destination"]).toString()

                                var rec_on = (dt["Receive_date"]).toString()
                                var rec_count = (dt["Receive_count"]).toString()
                                var status = (dt["Status"]).toString()
                                tallystatus = status

                                db.collection("branch").document(brnm)
                                        .get()
                                        .addOnCompleteListener { task ->
                                            if (task.isSuccessful) {
                                                if (task.result != null) {
                                                    var document = task.result
                                                    orignm = document.id
                                                    Log.d("data", "is" + task.result.data)
                                                    var orig = document.get("nm").toString()
                                                    orignm = orig

                                                    println("VALUE OF ORIGIN IDDD " + orignm)
                                                } else {
                                                    Log.d("data", "is not here")
                                                }
                                            } else {
                                                Log.d("task is not success", "full" + task.exception)
                                            }
                                        }

                                nameArray = nameArray.plusElement(name)
                                dateArray = dateArray.plusElement("Dated" + date + ". Stock received on" + rec_on)
                                stockidArray = stockidArray.plusElement("Stock transfer No - " + manufacturer)
                                priceArray = priceArray.plusElement(tot)

                                idsar = idsar.plusElement(manufacturer)



                                println("TALLY ARRAY" + tallystatus)


                                if (tallystatus.equals("Not Tallied")) {
                                    tallyArray = tallyArray.plusElement("Not tallied")
                                    talliedArray = talliedArray.plusElement("")
                                } else if (tallystatus.equals("Tallied")) {
                                    tallyArray = tallyArray.plusElement("")
                                    talliedArray = talliedArray.plusElement("Tallied")
                                } else {
                                    tallyArray = tallyArray.plusElement("Not tallied")
                                    talliedArray = talliedArray.plusElement("")
                                }

                                *//*   talliedArray=talliedArray.plusElement("Tallied")*//**//*
                                tallyArray= tallyArray.plusElement("")*//*



                                if (status == "Not Tallied") {

                                    val mBuilder = NotificationCompat.Builder(this@NotificationIntentService)


                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                    val mNotifyManager = this@NotificationIntentService.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                                    val resultIntent = Intent(this, ReceiveActivity::class.java)
                                    val stackBuilder = TaskStackBuilder.create(this)
                                    stackBuilder.addParentStack(ReceiveActivity::class.java)

// Adds the Intent that starts the Activity to the top of the stack
                                    stackBuilder.addNextIntent(resultIntent)
                                    val resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
                                    mBuilder.setContentIntent(resultPendingIntent)
                                    mBuilder.setDeleteIntent(NotificationEventReceiver.getDeleteIntent(this))

                                    mBuilder.setContentText("Receive the stock")
                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                    mBuilder.setContentTitle("Please verify the stock sent from $orignm")
                                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)

                                    mNotifyManager.notify(1, mBuilder.build());
                                }


                            }


                        }
                    })


            *//*  val builder = NotificationCompat.Builder(this)
        builder.setContentTitle("Scheduled Notification")
                .setAutoCancel(true)
                .setColor(resources.getColor(R.color.colorAccent))
                .setContentText("This notification has been triggered by Notification service")
                .setSmallIcon(R.drawable.ic_launcher_background)

        val pendingIntent = PendingIntent.getActivity(this,
                NOTIFICATION_ID,
                Intent(this, MainProductlistActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT)
        builder.setContentIntent(pendingIntent)
        builder.setDeleteIntent(NotificationEventReceiver.getDeleteIntent(this))

        val manager = this.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, builder.build())*//*
        }*/


    }
    companion object {

        private val NOTIFICATION_ID = 1
        private val ACTION_START = "ACTION_START"
        private val ACTION_DELETE = "ACTION_DELETE"

        fun createIntentStartNotificationService(context: Context): Intent {
            val intent = Intent(context, NotificationIntentService::class.java)
            intent.action = ACTION_START
            return intent
        }

        fun createIntentDeleteNotification(context: Context): Intent {
            val intent = Intent(context, NotificationIntentService::class.java)
            intent.action = ACTION_DELETE
            return intent
        }
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {

            connected = false
        }
        return connected
    }
}