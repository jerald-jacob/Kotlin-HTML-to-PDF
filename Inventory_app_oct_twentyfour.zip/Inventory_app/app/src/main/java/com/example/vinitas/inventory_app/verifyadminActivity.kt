package com.example.vinitas.inventory_app

import android.os.Bundle
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BlurMaskFilter
import android.graphics.PorterDuff
import android.graphics.BlurMaskFilter.Blur
import android.graphics.Canvas
import android.graphics.Paint
import android.support.v7.app.AppCompatActivity
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_verifyadmin.*

class verifyadminActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_verifyadmin)
        /*val img = findViewById<ImageView>(R.id.logo3) as ImageView*/
       /* var img : ImageView
        img = findViewById(R.id.logo3)
        img.setImageBitmap(highlightImage(BitmapFactory.decodeResource(resources, R.drawable.ic_logo)))*/
        back2.setOnClickListener {
            finish()
        }
        verify.setOnClickListener {
            val b4 = Intent(applicationContext, setbranchActivity::class.java)
            startActivity(b4)
        }
    }

    fun highlightImage(src: Bitmap): Bitmap {
        // create new bitmap, which will be painted and becomes result image
        val bmOut = Bitmap.createBitmap(src.width + 96, src.height + 96, Bitmap.Config.ARGB_8888)
        // setup canvas for painting
        val canvas = Canvas(bmOut)
        // setup default color
        canvas.drawColor(0, PorterDuff.Mode.CLEAR)
        // create a blur paint for capturing alpha
        val ptBlur = Paint()
        ptBlur.maskFilter = BlurMaskFilter(15f, Blur.NORMAL)
        val offsetXY = IntArray(2)
        // capture alpha into a bitmap
        val bmAlpha = src.extractAlpha(ptBlur, offsetXY)
        // create a color paint
        val ptAlphaColor = Paint()
        ptAlphaColor.color = -0x1
        // paint color for captured alpha region (bitmap)
        canvas.drawBitmap(bmAlpha, offsetXY[0].toFloat(), offsetXY[1].toFloat(), ptAlphaColor)
        // free memory
        bmAlpha.recycle()

        // paint the image source
        canvas.drawBitmap(src, 0f, 0f, null)

        // return out final image
        return bmOut
    }
}