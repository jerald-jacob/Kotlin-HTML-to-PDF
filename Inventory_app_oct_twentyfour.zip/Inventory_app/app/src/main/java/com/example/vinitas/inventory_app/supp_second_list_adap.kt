package com.example.vinitas.inventory_app

/**
 * Created by Vinitas on 22-12-2017.
 */
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Environment
import android.support.constraint.ConstraintLayout
import android.support.design.widget.FloatingActionButton
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import com.squareup.picasso.Picasso

import de.hdodenhof.circleimageview.CircleImageView
import kotlinx.android.synthetic.main.fragment_list.*
import java.io.File

/**
 * Created by vinitas IT on 13-12-2017.
 */
class supp_second__list_adap(//to reference the Activity
        private val context: Activity,
        private val idsArray:   Array<String>,
        private val sprostatusArray:   Array<String>,//to store the list of countries
        private val nameArray:   Array<String>, //to store the list of countries
        private val subnmArray:  Array<String>,
        private val bcArray:     Array<String>,
        private val sohArray:    Array<String>,
        private val mlArray:     Array<String>,
        private val mohArray:     Array<String>,


        private val priceArray:  Array<String>,
        private val productImArray: Array<String>,
        private val imnmhigh: Array<String>,
        private val icohighArray: Array<String>): ArrayAdapter<Any>(context, R.layout.supp_second_list_items, nameArray) {


    private var mCurrentAnimator: Animator? = null

    private var mShortAnimationDuration: Int = 0
    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {

        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.supp_second_list_items, null, true)

        //this code gets references to objects in the listview_row.xml file
        val idssTextField = rowView.findViewById<View>(R.id.spfsid) as TextView
        val prostatusTextField = rowView.findViewById<View>(R.id.spstatus) as TextView
        val nameTextField = rowView.findViewById<View>(R.id.pnm) as TextView
        val subnameTextField = rowView.findViewById<View>(R.id.psubnm) as TextView
        val bcnameTextField = rowView.findViewById<View>(R.id.bc) as TextView
        val sohnameTextField = rowView.findViewById<View>(R.id.soh) as TextView
        val pricenameTextField = rowView.findViewById<View>(R.id.price) as TextView
        val maxstockTextField = rowView.findViewById<View>(R.id.moh) as TextView

        val hyphen=rowView.findViewById<View>(R.id.textView6) as TextView

        val mlnameTextField = rowView.findViewById<View>(R.id.ml) as TextView
        val productim= rowView.findViewById<View>(R.id.primg) as CircleImageView

        val texvewfr=rowView.findViewById<View>(R.id.textView4) as TextView
        val texvewthirfr=rowView.findViewById<View>(R.id.textView34) as TextView
        val texvewthree=rowView.findViewById<View>(R.id.textView3) as TextView
        val textvsix=rowView.findViewById<View>(R.id.textView6) as TextView
        val textveight=rowView.findViewById<View>(R.id.textView8) as TextView


        mShortAnimationDuration = context.resources.getInteger(
                android.R.integer.config_shortAnimTime);


        //this code sets the values of the objects to values from the arrays
        idssTextField.text=idsArray[position]
        prostatusTextField.text=sprostatusArray[position]
        nameTextField.text = nameArray[position]
        subnameTextField.text = subnmArray[position]
        bcnameTextField.text=bcArray[position]
        sohnameTextField.text=sohArray[position]
        pricenameTextField.text = mlArray[position]
        mlnameTextField.text = priceArray[position]
        maxstockTextField.text = mohArray[position]

        if(mohArray[position].isEmpty()&&(sohArray[position].isEmpty())){

            texvewfr.visibility=View.INVISIBLE
            texvewthirfr.visibility=View.INVISIBLE
            textveight.visibility=View.INVISIBLE
        }
        else if((sohArray[position].isEmpty())&&(mohArray[position].isNotEmpty())){

            sohnameTextField.setText("0")
        }



        try {

            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            val k = imnmhigh[position]
            val recacnm = k.removeSuffix(".jpg")

            var y = recacnm + ".png"

            val file = File(dir, y)
            println("CONTENT URI" + file)
            if (file.exists()) {
                val contentUri = Uri.fromFile(File("$path/$y"))
                try {
                    Picasso.with(context)
                            .load(contentUri)
                            .into(productim);
                }
                catch (e:Exception){

                }
            }
            else{
                try {
                    Picasso.with(context)
                            .load(productImArray[position])
                            .into(productim);
                }
                catch (e:Exception){

                }
            }
        }
        catch (e:Exception){
            try {
                Picasso.with(context)
                        .load(productImArray[position])
                        .into(productim);
            }
            catch (e:Exception){

            }
        }



        try {

            if (context.supp_prod_list.isClickable == false) {
                nameTextField.setTextColor(Color.parseColor("#d3d3d3"))
                subnameTextField.setTextColor(Color.parseColor("#d3d3d3"))
                bcnameTextField.setTextColor(Color.parseColor("#d3d3d3"))
                sohnameTextField.setTextColor(Color.parseColor("#d3d3d3"))
                pricenameTextField.setTextColor(Color.parseColor("#d3d3d3"))
                mlnameTextField.setTextColor(Color.parseColor("#d3d3d3"))
                maxstockTextField.setTextColor(Color.parseColor("#d3d3d3"))
                texvewfr.setTextColor(Color.parseColor("#d3d3d3"))
                texvewthirfr.setTextColor(Color.parseColor("#d3d3d3"))
                texvewthree.setTextColor(Color.parseColor("#d3d3d3"))
                textvsix.setTextColor(Color.parseColor("#d3d3d3"))
                textveight.setTextColor(Color.parseColor("#d3d3d3"))

            }
            if(context.supp_prod_list.isClickable == true){
                nameTextField.setTextColor(Color.parseColor("#000000"))
                subnameTextField.setTextColor(Color.parseColor("#666666"))
                bcnameTextField.setTextColor(Color.parseColor("#666666"))
                sohnameTextField.setTextColor(Color.parseColor("#808080"))
                maxstockTextField.setTextColor(Color.parseColor("#808080"))
                texvewfr.setTextColor(Color.parseColor("#808080"))
                textveight.setTextColor(Color.parseColor("#808080"))
                pricenameTextField.setTextColor(Color.parseColor("#666666"))
                mlnameTextField.setTextColor(Color.parseColor("#666666"))
                texvewthirfr.setTextColor(Color.parseColor("#666666"))
                texvewthree.setTextColor(Color.parseColor("#666666"))
                textvsix.setTextColor(Color.parseColor("#666666"))




            }
        }
        catch (e:Exception){

        }



        productim.setOnClickListener {position
            val kd = imnmhigh[position]
            println("IMAG NAME VIEW"+kd)

            val k=productim.drawable


            println("POSITION OF ICO"+position)

            val jk=context.findViewById<ListView>(R.id.supp_prod_list) as ListView

            jk.isEnabled=false
            jk.isClickable=false
            val jj=context.findViewById<FloatingActionButton>(R.id.sadd_fab) as FloatingActionButton
            jj.isClickable=false
            jj.isEnabled=false

            val kj=context.findViewById<ConstraintLayout>(R.id.constrain) as ConstraintLayout
            kj.setBackgroundColor(Color.parseColor("#43161616"))
            zoomImageFromThumb(productim,k,position)


        }


        if(mlnameTextField.text.isEmpty()){
            hyphen.visibility=View.INVISIBLE
        }
        if(mohArray[position].equals(""))
        {
            val kk1=rowView.findViewById<TextView>(R.id.textView34) as TextView
            val kk=rowView.findViewById<TextView>(R.id.textView8) as TextView

            kk.visibility=View.GONE
            kk1.visibility=View.GONE
        }
        if (prostatusTextField.text.equals("Disable")) {
            nameTextField.setTextColor(Color.LTGRAY)
            subnameTextField.setTextColor(Color.LTGRAY)
            bcnameTextField.setTextColor(Color.LTGRAY)
            sohnameTextField.setTextColor(Color.LTGRAY)
            pricenameTextField.setTextColor(Color.LTGRAY)
            mlnameTextField.setTextColor(Color.LTGRAY)
            maxstockTextField.setTextColor(Color.LTGRAY)
        }


        //infoTextField.text = infoArray[position]


        return rowView
    }
    private fun zoomImageFromThumb(thumbView: View, imageResId: Drawable, pos:Int) {
        // If there's an animation in progress, cancel it
        // immediately and proceed with this one.
        mCurrentAnimator?.cancel()

        // Load the high-resolution "zoomed-in" image.
        val expandedImageView = context.findViewById<View>(
                R.id.expanded_image) as ImageView
        val rel = context.findViewById<RelativeLayout>(
                R.id.relative) as RelativeLayout

        val jk=context.findViewById<ListView>(R.id.supp_prod_list) as ListView
        val jj=context.findViewById<FloatingActionButton>(R.id.sadd_fab) as FloatingActionButton
        /* val kj=context.findViewById<ConstraintLayout>(R.id.const) as ConstraintLayout*/

        val nm=context.findViewById<TextView>(R.id.nameser) as TextView

        val ico = context.findViewById<CircleImageView>(R.id.primg) as CircleImageView
        expandedImageView.setImageDrawable(imageResId)


        // Calculate the starting and ending bounds for the zoomed-in image.
        // This step involves lots of math. Yay, math.
        val startBounds = Rect()
        val finalBounds = Rect()
        val globalOffset = Point()

        // The start bounds are the global visible rectangle of the thumbnail,
        // and the final bounds are the global visible rectangle of the container
        // view. Also set the container view's offset as the origin for the
        // bounds, since that's the origin for the positioning animation
        // properties (X, Y).
        thumbView.getGlobalVisibleRect(startBounds)
        val kk = context.findViewById<View>(R.id.containersd)
        context.findViewById<View>(R.id.containersd)
                .getGlobalVisibleRect(finalBounds, globalOffset)
        startBounds.offset(-globalOffset.x, -globalOffset.y)
        finalBounds.offset(-globalOffset.x, -globalOffset.y)

        // Adjust the start bounds to be the same aspect ratio as the final
        // bounds using the "center crop" technique. This prevents undesirable
        // stretching during the animation. Also calculate the start scaling
        // factor (the end scaling factor is always 1.0).
        val startScale: Float
        if (finalBounds.width().toFloat() / finalBounds.height() > startBounds.width().toFloat() / startBounds.height()) {
            // Extend start bounds horizontally
            startScale = startBounds.height().toFloat() / finalBounds.height()
            val startWidth = startScale * finalBounds.width()
            val deltaWidth = (startWidth - startBounds.width()) / 2
            startBounds.left -= deltaWidth.toInt()
            startBounds.right += deltaWidth.toInt()
        } else {
            // Extend start bounds vertically
            startScale = startBounds.width().toFloat() / finalBounds.width()
            val startHeight = startScale * finalBounds.height()
            val deltaHeight = (startHeight - startBounds.height()) / 2
            startBounds.top -= deltaHeight.toInt()
            startBounds.bottom += deltaHeight.toInt()
        }

        // Hide the thumbnail and show the zoomed-in view. When the animation
        // begins, it will position the zoomed-in view in the place of the
        // thumbnail.
        thumbView.alpha = 1f
        expandedImageView.visibility = View.VISIBLE
        kk.visibility = View.VISIBLE
        rel.visibility=View.VISIBLE
        nm.visibility=View.VISIBLE

        nm.text=nameArray[pos]



        // Set the pivot point for SCALE_X and SCALE_Y transformations
        // to the top-left corner of the zoomed-in view (the default
        // is the center of the view).
        expandedImageView.pivotX = 0f
        expandedImageView.pivotY = 0f

        // Construct and run the parallel animation of the four translation and
        // scale properties (X, Y, SCALE_X, and SCALE_Y).
        val set = AnimatorSet()
        set
                .play(ObjectAnimator.ofFloat(expandedImageView, View.X,
                        startBounds.left.toFloat(), finalBounds.left.toFloat()))
                .with(ObjectAnimator.ofFloat(expandedImageView, View.Y,
                        startBounds.top.toFloat(), finalBounds.top.toFloat()))
                .with(ObjectAnimator.ofFloat(expandedImageView, View.SCALE_X,
                        startScale, 1f))
                .with(ObjectAnimator.ofFloat(expandedImageView,
                        View.SCALE_Y, startScale, 1f))
        set.setDuration(mShortAnimationDuration.toLong())
        set.interpolator = DecelerateInterpolator()
        set.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                mCurrentAnimator = null
            }

            override fun onAnimationCancel(animation: Animator) {
                mCurrentAnimator = null
            }
        })
        set.start()
        mCurrentAnimator = set

        // Upon clicking the zoomed-in image, it should zoom back down
        // to the original bounds and show the thumbnail instead of
        // the expanded image.
        val startScaleFinal = startScale



        // Animate the four positioning/sizing properties in parallel,
        // back to their original values.
        val kj = context.findViewById<ConstraintLayout>(R.id.constrain) as ConstraintLayout
        rel.setOnClickListener {


            kj.setBackgroundColor(Color.parseColor("#ffffff"))
            mCurrentAnimator?.cancel()
            val set = AnimatorSet()
            set.play(ObjectAnimator
                    .ofFloat(expandedImageView, View.X, startBounds.left.toFloat()))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.Y, startBounds.top.toFloat()))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.SCALE_X, startScale))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.SCALE_Y, startScale))
            set.setDuration(mShortAnimationDuration.toLong())
            set.interpolator = DecelerateInterpolator()
            set.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    thumbView.alpha = 1f
                    nm.visibility=View.GONE
                    expandedImageView.visibility = View.GONE
                    kk.visibility = View.GONE

                    rel.visibility = View.GONE
                    jk.isEnabled=true
                    jk.isClickable=true
                    ico.isEnabled=true
                    ico.isClickable=true
                    jj.isClickable=true
                    jj.isEnabled=true
                    mCurrentAnimator = null
                }

                override fun onAnimationCancel(animation: Animator) {
                    thumbView.alpha = 1f
                    expandedImageView.visibility = View.GONE
                    nm.visibility=View.GONE
                    kk.visibility = View.GONE
                    rel.visibility=View.GONE

                    jk.isEnabled=true
                    jk.isClickable=true
                    jj.isClickable=true
                    jj.isEnabled=true
                    mCurrentAnimator = null
                }
            })
            set.start()
            mCurrentAnimator = set
        }

        expandedImageView.setOnClickListener {pos

            val k = imnmhigh[pos]
            println("IMAG NAME VIEW"+k)
            expandedImageView.visibility = View.GONE
            kj.setBackgroundColor(Color.parseColor("#ffffff"))
            nm.visibility=View.GONE
            kk.visibility = View.GONE
            rel.visibility=View.GONE

            jk.isEnabled=true
            jk.isClickable=true
            jj.isClickable=true
            jj.isEnabled=true

            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_suppProduct"

            val dir = File(path);




            val recacnm = k.removeSuffix(".jpg")

            var y = recacnm + ".png"

            val file = File(dir, y)
            println("CONTENT URI GG" + file)
            if (file.exists()) {
                val contentUri = Uri.fromFile(File("$path/$y"))

                println("CONTENT URI" + contentUri)
                /*    var redrawb = image1.drawable
            val bitmap = (redrawb as BitmapDrawable).getBitmap()*/
                /*  val baos = ByteArrayOutputStream()
          bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
          val b = baos.toByteArray()*/
                if (contentUri != null) {
                    val shareIntent = Intent(context, ZoomProduct::class.java)
                    shareIntent.putExtra("im", "imageadap")
                    shareIntent.putExtra("drawb", contentUri.toString())
                    shareIntent.putExtra("nameser",nameArray[pos])
                    context.startActivity(shareIntent)
                }
            } else {
                val shareIntent = Intent(context, ZoomProduct::class.java)
                shareIntent.putExtra("im", "imageadap")
                shareIntent.putExtra("drawb", icohighArray[pos])
                shareIntent.putExtra("nameser",nameArray[pos])
                context.startActivity(shareIntent)
            }
        }




    }
}