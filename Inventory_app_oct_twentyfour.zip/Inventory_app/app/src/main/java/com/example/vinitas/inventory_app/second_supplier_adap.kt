package com.example.vinitas.purchase_third


import android.annotation.SuppressLint
import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.vinitas.inventory_app.R


/**
 * Created by vinitas IT on 13-12-2017.
 */
class second_suppl_list_adap(//to reference the Activity
        private val context: Activity, //to store the list of countries
        private val compronameArray: Array<String>, //to store the list of countries
        private val itemnmArray    : Array<String>,
        private val orderArray     : Array<String>,
        private val poArray        : Array<String>,
        private val mlArray        : Array<String>,
        private val priceArray     : Array<String>): ArrayAdapter<Any>(context, R.layout.act_purchasetlistsecond_items, compronameArray) {

    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.act_purchasetlistsecond_items, null, true)

        //this code gets references to objects in the listview_row.xml file
        val companynameTextField    =      rowView.findViewById<View>(R.id.companynm) as TextView
        val itemnameTextField       =      rowView.findViewById<View>(R.id.pur_item)  as TextView
        val ordernameTextField      =      rowView.findViewById<View>(R.id.order)     as TextView
        val ponameTextField         =      rowView.findViewById<View>(R.id.po)        as TextView
        val pricenameTextField      =      rowView.findViewById<View>(R.id.price)     as TextView
        val compnameTextField       =      rowView.findViewById<View>(R.id.complete)  as TextView



        //this code sets the values of the objects to values from the arrays
        companynameTextField.text = compronameArray[position]
        itemnameTextField.text    = itemnmArray[position]
        ordernameTextField.text   = orderArray[position]
        ponameTextField.text      = poArray[position]
        pricenameTextField.text   = mlArray[position]
        compnameTextField.text    = priceArray[position]



        //infoTextField.text = infoArray[position]


        return rowView
    }
}