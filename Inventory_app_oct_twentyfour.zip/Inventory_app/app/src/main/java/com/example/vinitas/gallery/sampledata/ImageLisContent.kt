package com.example.vinitas.gallery.sampledata

import com.zfdang.multiple_images_selector.SelectorSettings


object ImageListContent {
    // ImageRecyclerViewAdapter.OnClick will set it to true
    // Activity.OnImageInteraction will show the alert, and set it to false
    var bReachMaxNumber = false

    val IMAGES = ArrayList<ImageItem>()

    val SELECTED_IMAGES: ArrayList<String> = ArrayList()

    val cameraItem = ImageItem("", SelectorSettings.CAMERA_ITEM_PATH, 0)

    fun clear() {
        IMAGES.clear()
    }

    fun addItem(item: ImageItem) {
        IMAGES.add(item)
    }

    fun isImageSelected(filename: String): Boolean {
        return SELECTED_IMAGES.contains(filename)
    }

    fun toggleImageSelected(filename: String) {
        if (SELECTED_IMAGES.contains(filename)) {
            SELECTED_IMAGES.remove(filename)
        } else {
            SELECTED_IMAGES.add(filename)
        }
    }
}