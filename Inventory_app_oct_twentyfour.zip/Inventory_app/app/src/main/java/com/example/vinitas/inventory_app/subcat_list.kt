package com.example.vinitas.inventory_app

import android.app.Activity
import android.graphics.Bitmap
import android.os.StrictMode
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView

class subcat_lists(
        private val context: Activity, //to store the list of countries
        private val usArray: ArrayList<String>, //to store the list of countries
        private val tyArray: ArrayList<String>, //to store the animal images
        private val icoArray: ArrayList<String>,
        private val idArray: ArrayList<String>,
        private val nmArray: ArrayList<String>) : ArrayAdapter<String>(context, R.layout.subcat_list, usArray) {
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        val arr= ArrayList<Bitmap>()
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.subcat_list, null, true)

        //this code gets references to objects in the listview_row.xml file
        val us = rowView.findViewById<TextView>(R.id.textView2) as TextView
        val ty = rowView.findViewById<TextView>(R.id.textView3) as TextView
        val nm = rowView.findViewById<TextView>(R.id.textView4) as TextView
        val ky = rowView.findViewById<TextView>(R.id.textView5) as TextView

        val ico = rowView.findViewById<CircleImageView>(R.id.imageView) as CircleImageView

        //this code sets the values of the objects to values from the arrays
        us.text = usArray[position]
        ty.text = tyArray[position]
        nm.text = nmArray[position]
        ky.text = idArray[position]
        /*val newurl = URL(icoArray[position]).openStream()
        val img = BitmapFactory.decodeStream(newurl)*/
        //ico.setImageBitmap(icoArray[position])
        if (icoArray[position]!="") {
            Picasso.with(context)
                    .load(icoArray[position])
                    .into(ico);
        }
        /*status.text = state[position]
        ico.setOnClickListener {
            val alert = AlertDialog.Builder(context)
            val dialog = alert.create()
            val image=ImageView(context)
            Picasso.with(context)
                    .load(icoArray[position])
                    .into(image);
            //image.setImageBitmap(icoArray[position])
            dialog.setView(image)
            dialog.show()
        }*/

        //infoTextField.text = infoArray[position]
        //imageView.setImageResource(imageIDarray[position])
        return rowView

    }

    /*fun getResizedBitmap(bm: Bitmap, newHeight: Int, newWidth: Int): Bitmap {
        val width = bm.width
        val height = bm.height
        val scaleWidth = newWidth.toFloat() / width
        val scaleHeight = newHeight.toFloat() / height
        // CREATE A MATRIX FOR THE MANIPULATION
        val matrix = Matrix()
        // RESIZE THE BIT MAP
        matrix.postScale(scaleWidth, scaleHeight)

        // "RECREATE" THE NEW BITMAP
        return Bitmap.createBitmap(bm, 0, 0, width, height, matrix, false)
    }*/
}