package com.example.vinitas.gallery.sampledata

import android.net.Uri
import android.widget.TextView
import com.facebook.drawee.view.SimpleDraweeView
import android.support.v7.widget.RecyclerView
import java.nio.file.Files.size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.example.vinitas.inventory_app.R
import com.zfdang.multiple_images_selector.OnFolderRecyclerViewInteractionListener

import com.zfdang.multiple_images_selector.models.FolderItem;
import com.zfdang.multiple_images_selector.models.FolderListContent;
import com.zfdang.multiple_images_selector.utilities.DraweeUtils;
import java.io.File


class FolderRecyclerViewAdapter(private val mValues: List<FolderItem>, private val mListener: OnFolderRecyclerViewInteractionListener?) : RecyclerView.Adapter<FolderRecyclerViewAdapter.ViewHolder>() {
    private val TAG = "FolderAdapter"

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.popup_folder_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val folderItem = mValues[position]
        holder.mItem = folderItem
        holder.folderName.text = folderItem.name
        holder.folderPath.text = folderItem.path
        holder.folderSize.text = folderItem.numOfImages

        if (position == FolderListContent.selectedFolderIndex) {
            holder.folderIndicator.setVisibility(View.VISIBLE)
        } else {
            holder.folderIndicator.setVisibility(View.GONE)
        }

        DraweeUtils.showThumb(Uri.fromFile(File(folderItem.coverImagePath)), holder.folderCover)

        holder.mView.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View) {
                // Log.d(TAG, "onClick: " + holder.mItem.toString());
                // pass the selected result to FolderListContent
                val previousSelectedIndex = FolderListContent.selectedFolderIndex
                FolderListContent.setSelectedFolder(holder.mItem!!, position)
                // we should notify previous item and current time to change
                notifyItemChanged(previousSelectedIndex)
                notifyItemChanged(position)
                mListener?.onFolderItemInteraction(holder.mItem)
            }
        })
    }

    override fun getItemCount(): Int {

        return mValues.size
    }

    inner class ViewHolder(internal var mView: View) : RecyclerView.ViewHolder(mView) {
        internal var mItem: FolderItem? = null
        internal var folderCover: SimpleDraweeView
        internal var folderName: TextView
        internal var folderPath: TextView
        internal var folderSize: TextView
        internal var folderIndicator: ImageView

        init {
            folderCover = mView.findViewById(R.id.folder_cover_image)
            folderName = mView.findViewById(R.id.folder_name)
            folderPath = mView.findViewById(R.id.folder_path)
            folderSize = mView.findViewById(R.id.folder_size)
            folderIndicator = mView.findViewById(R.id.folder_selected_indicator) as ImageView
        }

        override fun toString(): String {
            return "ViewHolder{" +
                    "folderCover=" + folderCover +
                    ", mView=" + mView +
                    ", folderName=" + folderName +
                    ", folderPath=" + folderPath +
                    ", folderSize=" + folderSize +
                    ", folderIndicator=" + folderIndicator +
                    '}'.toString()
        }
    }
}