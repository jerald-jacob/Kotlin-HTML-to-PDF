package com.example.vinitas.inventory_app

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_to_another.*



class Anotherstate : AppCompatActivity() {
    val TAG = "some"
    var db = FirebaseFirestore.getInstance()
    var otherids= arrayOf<String>()

    var otherliids= arrayOf<String>()
    var otheraddress= arrayOf<String>()
    var otherbridd= arrayOf<String>()
    var other_nameArrayori= arrayOf<String>()
    var other_dateArrayori= arrayOf<String>()
    var other_priceArrayori= arrayOf<String>()
    var other_datearr=arrayOf<String>()
    var other_descrip=arrayOf<String>()
    var another_oriid= String()
    var another_orgval= String()
    var origid= String()
var a=arrayOf<String>()
    var esc= String()
    var upstr= String()
    var frms= String()
    var numberstr= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()
    var supkyval= String()
    var bsupkyval= String()
    var origisearch= arrayOf<String>()
    var orgcty= String()
    var orgst= String()



    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""






    var supkyarray= arrayOf<String>()
    var bsupkykyarray= arrayOf<String>()


    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_to_another)

        net_status()

        try {
            val bundle = intent.extras
            var frm = bundle!!.get("from_br").toString()
            frms=frm
        }
        catch (e:Exception){

        }
        var sd= String()
        var x= String()
        var reg= String()
        try {
            val p=intent.getStringExtra("another_bkey")
            another_oriid=p
        }
        catch(e:Exception){

        }

       /* db.collection("Branches").document(another_oriid)
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        if (task.result != null) {
                            var document=task.result
                            another_orgval=document.id
                            Log.d("data", "is" + task.result.data)
                            var orig = document.get("br_nm").toString()
                            another_orgval=orig

                            println("VALUE OF ORIGIN IDDD "+another_orgval)
                        } else {
                            Log.d("data", "is not here")
                        }
                    } else {
                        Log.d("task is not success", "full" + task.exception)
                    }
                }*/



        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")
        sendtrans=intent.getStringExtra("sendtrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        println("ADD TRANSFER"+addtrans)


        val adano = intent.getStringExtra("addtransano")
        val edano = intent.getStringExtra("edittransano")
        val delano = intent.getStringExtra("deletetransano")
        val viano=intent.getStringExtra("viewtransano")
        val tranano=intent.getStringExtra("transfertransano")
        val exano=intent.getStringExtra("exporttransano")
        sendtransano=intent.getStringExtra("sendtransano")
        if (adano != null) {
            addtransano = adano
        }
        if (edano != null) {
            editetransano = edano
        }
        if (delano != null) {
            deletetransano = delano
        }
        if (viano != null) {
            viewtransano = viano
        }
        if (tranano != null) {
            transfertransano = tranano
        }
        if (exano != null) {
            exporttransano = exano
        }


        val adrec = intent.getStringExtra("addrec")
        val edrec = intent.getStringExtra("editrec")
        val delrec = intent.getStringExtra("deleterec")
        val virec=intent.getStringExtra("viewrec")
        val tranrec=intent.getStringExtra("transferrec")
        val exrec=intent.getStringExtra("exportrec")
        val sendrec=intent.getStringExtra("sendstrec")

        if (adrec != null) {
            addrec = adrec
        }
        if (edrec != null) {
            editrec = edrec
        }
        if (delrec != null) {
            deleterec = delrec
        }
        if (virec != null) {
            viewrec = virec
        }
        if (tranrec != null) {
            transferrec = tranrec
        }
        if (exrec != null) {
            exportrec = exrec
        }
        if (sendrec != null) {
            sendstrec = sendrec
        }




        println("STATE ACTIVITY KEYSSS"+another_oriid)
        println("Another ADD STARTING"+addtransano)



        search.setOnClickListener {
            cardsearch.visibility= View.VISIBLE
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }



        dot.setOnClickListener({


            val popup = PopupMenu(this@Anotherstate, dot)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                if (item.title == "Logout") {
                    Toast.makeText(this@Anotherstate, "You are logged out", Toast.LENGTH_SHORT).show()
                    val f = Intent(this@Anotherstate, PinActivity::class.java)
                    startActivity(f)
                    finish()
                }
                true
            }

            popup.show()
        })


        try {


            db.collection("branch").document(another_oriid)
                    .get()
                    .addOnCompleteListener { task ->
                        try {
                            if (task.isSuccessful) {
                                if (task.result != null) {
                                    var document = task.result
                                    origid = document.id
                                    Log.d("data", "is" + task.result.data)
                                    var orig = document.get("nm").toString()
                                    var origcty = document.get("cty").toString()
                                    var origst = document.get("st").toString()

                                    another_orgval = orig
                                    orgcty=origcty

                                    println("VALUE OF ORIGIN IDDD " + another_orgval)
                                } else {
                                    Log.d("data", "is not here")
                                }
                            }
                            else
                         {
                            Log.d("task is not success", "full" + task.exception)
                        }
                        }
                        catch (e:Exception){
                            Toast.makeText(applicationContext,"Invalid branch",Toast.LENGTH_SHORT).show()
                        }
                        }

        }
        catch (e:Exception){
            Toast.makeText(applicationContext,"Invalid branch",Toast.LENGTH_SHORT).show()
        }

        fun gets() {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();
            db.collection("ST_Another_State")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                        var text       = arrayOf<String>()
                        var idss       = arrayOf<String>()
                        var nameArray  = arrayOf<String>()
                        var dateArray  = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var bridArray = arrayOf<String>()


                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }
if(value.isEmpty==false) {
    imageView10.visibility=View.GONE
    for (document in value) {

        Log.d("d", "key --- " + document.id + " => " + document.data)
        println(document.data)

        var dt = document.data
        var id = (document.id)



        idss = idss.plusElement(id)

        println(idss)

        /*  idss=idss.plusElement(path)
                          i=idss
                          println(id)
                          println(i)*/

        var name = (dt["otherstk_destination"]).toString()
        var address = (dt["otherstk_address"]).toString()
        var date = (dt["otherstkdate"]).toString()
        var tot = (dt["otherstk_total"]).toString()
        var descr = (dt["otherstk_Desc"]).toString()
        var manufacturer = (dt["otherstkid"]).toString()
        var brid = (dt["otherstk_brid"]).toString()
        text = text.plusElement(another_orgval)
        nameArray = nameArray.plusElement("Destination : " + name)
        dateArray = dateArray.plusElement(date + "," + manufacturer)
        priceArray = priceArray.plusElement(tot)
        otheraddress = otheraddress.plusElement(address)
        other_nameArrayori = other_nameArrayori.plusElement(name)
        other_dateArrayori = dateArray
        other_priceArrayori = priceArray
        other_datearr = other_datearr.plusElement(date)
        descriptionArray = descriptionArray.plusElement(descr)
        other_descrip = descriptionArray
        otherids = otherids.plusElement(manufacturer)
        otherliids = idss
        bridArray = bridArray.plusElement(brid)
        otherbridd = bridArray


    }
    pDialog.dismiss()
    val whatever = withstateAdapter(this, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
    val Tlist = findViewById<ListView>(R.id.Tlist) as ListView
    Tlist.adapter = whatever
    swipeContainer.setRefreshing(false);
}
                        else{
    imageView10.visibility=View.VISIBLE
    pDialog.dismiss()
                        }
                    })
        }


        swipeContainer.setOnRefreshListener {
            // Your code to refresh the list here.
            // Make sure you call swipeContainer.setRefreshing(false)
            // once the network request has completed successfully.
            gets()
        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.toolbar,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)




        if(frms=="brsave"){
            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }




            gets()
        }
        searchedit.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                progres.visibility=View.VISIBLE
                Tlist.visibility=View.GONE

                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                println("TYPED VALUED" + x)


                fun priget() {
                    if (s.length >= 3) {
                        noresfo.visibility=View.GONE
                        Tlist.visibility=View.VISIBLE
                        var text=arrayOf<String>()
                        var idss= arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray= arrayOf<String>()
                        var bridArray= arrayOf<String>()

                        db.collection("ST_Another_State").orderBy("otherstk_total").startAt(numberstr).endAt(esc)
                                .get()
                                .addOnCompleteListener { task ->
                                    println(task.result)
                                    if (task.isSuccessful) {
                                        if (task.result.isEmpty == false) {
                                            for (document in task.result) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var id = (document.id)
                                                idss = idss.plusElement(id)
                                                println(idss)

                                                /*  idss=idss.plusElement(path)
                                          i=idss
                                          println(id)
                                          println(i)*/

                                                var name = (dt["otherstk_destination"]).toString()
                                                var address = (dt["otherstk_address"]).toString()
                                                var date = (dt["otherstkdate"]).toString()
                                                var tot=(dt["otherstk_total"]).toString()
                                                var descr=(dt["otherstk_Desc"]).toString()
                                                var manufacturer = (dt["otherstkid"]).toString()
                                                var brid = (dt["otherstk_brid"]).toString()
                                                var orid = (dt["stk_origin"]).toString()

                                                try {
                                                    text = text.plusElement(another_orgval)
                                                }
                                                catch (e:Exception){

                                                }
                                                nameArray = nameArray.plusElement("Destination : " + name)
                                                dateArray = dateArray.plusElement(date + " ," + manufacturer)
                                                priceArray=priceArray.plusElement(tot)
                                                other_nameArrayori = other_nameArrayori.plusElement(name)
                                                otheraddress=otheraddress.plusElement(address)
                                                other_dateArrayori = dateArray
                                                other_priceArrayori = priceArray
                                                other_datearr=other_datearr.plusElement(date)
                                                descriptionArray=descriptionArray.plusElement(descr)
                                                other_descrip=descriptionArray
                                                otherids=otherids.plusElement(manufacturer)
                                                otherliids=idss
                                                bridArray=bridArray.plusElement(brid)
                                                otherbridd=bridArray
                                                origisearch=origisearch.plusElement(orid)



                                            }
                                            for (i in 0 until origisearch.count()) {
                                                var ail = origisearch[i]
                                                bsupkyval = ail
                                            }
                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + another_oriid)
                                            if (another_oriid == bsupkyval) {
                                                progres.visibility=View.GONE
                                                Tlist.visibility=View.VISIBLE
                                                println("SAVE KEYYYY" + another_oriid)
                                                val whatever = withstateAdapter(this@Anotherstate, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                                val Tlist = findViewById<ListView>(R.id.Tlist) as ListView
                                                Tlist.adapter = whatever
                                            } else {
                                                noresfo.visibility = View.VISIBLE
                                                Tlist.visibility = View.GONE
                                                progres.visibility=View.GONE
                                            }


                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            noresfo.visibility=View.VISIBLE
                                            Tlist.visibility=View.GONE
                                            progres.visibility=View.GONE
                                        }


                                    } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }
                                }

                    }
                }



                if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr=upstr
                    regtr="num"
                    priget()

                    //write code here for success
                }


                if(x!==reg) {
                    val upperString = x.toUpperCase()
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("STRINGSSSS" + upstr)
                }


                if ((s.length >= 4)&&(x!==reg)) {

                    var text=arrayOf<String>()
                    var idss= arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var dateArray = arrayOf<String>()
                    var priceArray = arrayOf<String>()
                    var descriptionArray= arrayOf<String>()
                    var bridArray= arrayOf<String>()

                    db.collection("ST_Another_State").orderBy("otherstkid").startAt(upstr).endAt(esc)
                            .get()
                            .addOnCompleteListener { task ->
                                println(task.result)
                                if (task.isSuccessful) {
                                    if (task.result.isEmpty == false) {
                                        for (document in task.result) {

                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                            println(document.data)

                                            var dt = document.data
                                            var id = (document.id)
                                            idss = idss.plusElement(id)
                                            println(idss)

                                            /*  idss=idss.plusElement(path)
                                              i=idss
                                              println(id)
                                              println(i)*/

                                            var name = (dt["otherstk_destination"]).toString()
                                            var address = (dt["otherstk_address"]).toString()

                                            var date = (dt["otherstkdate"]).toString()
                                            var tot=(dt["otherstk_total"]).toString()
                                            var descr=(dt["otherstk_Desc"]).toString()
                                            var manufacturer = (dt["otherstkid"]).toString()
                                            var brid = (dt["otherstk_brid"]).toString()
                                            var orid = (dt["otherstk_origin"]).toString()
                                            try {
                                                text = text.plusElement(another_orgval)
                                            }
                                            catch (e:Exception){

                                            }

                                            nameArray = nameArray.plusElement("Destination : " + name)
                                            dateArray = dateArray.plusElement(date + " ,"+ manufacturer)
                                            priceArray=priceArray.plusElement(tot)
                                            other_nameArrayori = other_nameArrayori.plusElement(name)
                                            otheraddress=otheraddress.plusElement(address)
                                            other_dateArrayori = dateArray
                                            other_priceArrayori = priceArray
                                            other_datearr=other_datearr.plusElement(date)
                                            descriptionArray=descriptionArray.plusElement(descr)
                                            other_descrip=descriptionArray
                                            otherids=otherids.plusElement(manufacturer)
                                            otherliids=idss
                                            bridArray=bridArray.plusElement(brid)
                                            otherbridd=bridArray
                                            origisearch=origisearch.plusElement(orid)



                                        }
                                        for (i in 0 until origisearch.count()) {
                                            var ail = origisearch[i]
                                            bsupkyval = ail
                                        }
                                        println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                        println("SAVE KEYYYY" + another_oriid)
                                        if (another_oriid == bsupkyval) {
                                            progres.visibility=View.GONE
                                            Tlist.visibility=View.VISIBLE
                                            println("SAVE KEYYYY" + another_oriid)
                                            val whatever = withstateAdapter(this@Anotherstate, text, nameArray, dateArray, priceArray, descriptionArray, idss, bridArray)
                                            val Tlist = findViewById<ListView>(R.id.Tlist) as ListView
                                            Tlist.adapter = whatever
                                        } else {
                                            noresfo.visibility = View.VISIBLE
                                            Tlist.visibility = View.GONE
                                            progres.visibility=View.GONE

                                        }


                                    } else {
                                        println("NO RECORDSSSS FOUNDD")
                                        noresfo.visibility=View.VISIBLE
                                        Tlist.visibility=View.GONE
                                        progres.visibility=View.GONE

                                    }


                                } else {
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }
                            }

                }








                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(searchedit.text.toString().isEmpty())
                {
                    Tlist.visibility=View.VISIBLE
                    noresfo.visibility=View.GONE

                    progres.visibility=View.GONE

                    gets()
                }
            }
        })

        /*var category = arrayListOf<String>()
        var d = arrayListOf<String>()
        var dlt = arrayListOf<String>()
        val list_item = ArrayList<String>()


        Tlist.choiceMode = ListView.CHOICE_MODE_MULTIPLE_MODAL;
       Tlist.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {
                //capture total checked items
                var checkedCount = Tlist.checkedItemCount
                val l = a[position]
                Log.i(TAG," "+l)
                //setting CAB title
                mode.setTitle(""+checkedCount + " Selected")
                Log.d(TAG," "+id)
                //list_item.add(id);
                if (checked) {
                    list_item.add(id.toString()) // Add to list when checked ==  true
                    dlt.add(l)
                    Log.i(TAG,"itm "+dlt.size)
                    //Log.i(TAG,"itm "+dlt.get(position))
                } else {
                    list_item.remove(id.toString())
                    dlt.remove(l)
                    Log.i(TAG,"itm "+dlt.size)
                    Log.d(TAG,"id  "+id)
                }

            }

            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB
                toolbar.visibility = View.GONE
                mode.getMenuInflater().inflate(R.menu.list, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {

                val deleteSize = dlt.size
                Log.i("tsdfs","  "+dlt.size)
                val cate = null

                val i = 0
                Log.d("dlt"," "+dlt.get(i))
                val itemId = item.getItemId()
                if ((itemId == R.id.delete)&&(deletetransano=="true")) {
                    progres.visibility=View.VISIBLE
                    for (i in dlt) {


                        db.collection("ST_Another_State").document(i)
                                .delete()
                                .addOnSuccessListener {

                                    dlt.clear()
                                    Toast.makeText(applicationContext, "" + deleteSize + " Items deleted", Toast.LENGTH_SHORT).show()
                                    gets()
                                    progres.visibility=View.GONE



                                    // save_progress.visibility = android.view.View.GONE

                                }
                                .addOnFailureListener {
                                    Toast.makeText(applicationContext, "not updated", Toast.LENGTH_LONG).show()
                                    //save_progress.visibility = android.view.View.GONE
                                }
                    }
                }
                else{
                    popup("delete")
                }
                if (itemId == R.id.selectAll){

                }

                list_item.clear()
                mode.finish()
                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {
                // refresh list after deletion
                toolbar.visibility =View.VISIBLE
            }
        })*/



        searback1.setOnClickListener {
            searchedit.setText("")
            cardsearch.visibility=View.GONE
            noresfo.visibility=View.GONE
            Tlist.visibility=View.VISIBLE

            progres.visibility=View.GONE
            gets()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }


       Tlist.setOnItemClickListener { parent, views, position, id ->

            val b = Intent(applicationContext, Main_stk_delhi::class.java)

            b.putExtra("fromstate", "startlist_otherst")
            b.putExtra("otherst_brnm", other_nameArrayori[position])
           b.putExtra("otherst_braddress", otheraddress[position])
            b.putExtra("otherst_date", other_datearr[position])
            b.putExtra("otherst_description", other_descrip[position])
            b.putExtra("otherst_Stockids", otherids[position])
            b.putExtra("otherst_listids", otherliids[position])
           b.putExtra("other_brids", otherbridd[position])
           b.putExtra("other_origiid", another_oriid)





           b.putExtra("viewtrans", viewtrans)
           b.putExtra("addtrans", addtrans)
           b.putExtra("edittrans", editetrans)
           b.putExtra("deletetrans", deletetrans)
           b.putExtra("transfertrans", transfertrans)
           b.putExtra("exporttrans", exporttrans)
           b.putExtra("sendtrans", sendtrans)


           b.putExtra("viewtransano", viewtransano)
           b.putExtra("addtransano", addtransano)
           b.putExtra("edittransano", editetransano)
           b.putExtra("deletetransano", deletetransano)
           b.putExtra("transfertransano", transfertransano)
           b.putExtra("exporttransano", exporttransano)
           b.putExtra("sendtransano", sendtransano)

           b.putExtra("viewrec", viewrec)
           b.putExtra("addrec", addrec)
           b.putExtra("deleterec", deleterec)
           b.putExtra("editrec", editrec)
           b.putExtra("transferrec", transferrec)
           b.putExtra("exportrec", exportrec)
           b.putExtra("sendstrec",sendstrec)





            startActivity(b)
           overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
           finish()
        }
        back.setOnClickListener {
            finish()
        }
        add1.setOnClickListener {
            if(addtransano=="true"){
            val b = Intent(applicationContext,AnotherSelectActivity::class.java)




                b.putExtra("viewtrans", viewtrans)
                b.putExtra("addtrans", addtrans)
                b.putExtra("edittrans", editetrans)
                b.putExtra("deletetrans", deletetrans)
                b.putExtra("transfertrans", transfertrans)
                b.putExtra("exporttrans", exporttrans)
                b.putExtra("sendtrans", sendtrans)


                b.putExtra("viewtransano", viewtransano)
                b.putExtra("addtransano", addtransano)
                b.putExtra("edittransano", editetransano)
                b.putExtra("deletetransano", deletetransano)
                b.putExtra("transfertransano", transfertransano)
                b.putExtra("exporttransano", exporttransano)
                b.putExtra("sendtransano", sendtransano)

                b.putExtra("viewrec", viewrec)
                b.putExtra("addrec", addrec)
                b.putExtra("deleterec", deleterec)
                b.putExtra("editrec", editrec)
                b.putExtra("transferrec", transferrec)
                b.putExtra("exportrec", exportrec)
                b.putExtra("sendstrec",sendstrec)



            b.putExtra("other_rbky",another_oriid)
            startActivity(b)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                finish()
            }
            else if(addtransano=="false"){
                popup("Add")
            }
        }

    }
    fun popup(st:String){
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    override fun onBackPressed()

    {

        if(cardsearch.visibility==View.VISIBLE){
            cardsearch.visibility=View.GONE
        }
        else{
            val b=Intent(this@Anotherstate,StockTransferActivity::class.java)
            b.putExtra("skey",another_oriid)




            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)



            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
