package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot


import kotlinx.android.synthetic.main.activity_purchase_request.*
import android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT
import com.example.vinitas.inventory_app.R.id.editText
import android.content.Context.INPUT_METHOD_SERVICE
import android.content.DialogInterface
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.constraint.ConstraintLayout
import android.support.v7.app.AlertDialog
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import cn.pedant.SweetAlert.SweetAlertDialog
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.widget.*
import com.applovin.sdk.AppLovinSdk
import com.example.vinitas.inventory_app.R.id.nores
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.Query


class PurchaseRequestActivity : AppCompatActivity() {
    val TAG = "some"
    var db = FirebaseFirestore.getInstance()
    var ids = arrayOf<String>()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    var liids = arrayOf<String>()
    var nameArrayori = arrayOf<String>()
    var supplierkeyori = arrayOf<String>()

    var phoneArrayori = arrayOf<String>()
    var dateArrayori = arrayOf<String>()
    var priceArrayori = arrayOf<String>()
    var bridArrayori = arrayOf<String>()
    var datearr = arrayOf<String>()
    var datesarr = arrayOf<String>()
    var name = arrayOf<String>()
    var descrip = arrayOf<String>()
    var status = arrayOf<String>()
    var status1 = arrayOf<String>()
    var broriky = String()
    var brorival = String()
    var stag = String()
    var s = String()
    var descr = String()

    var regexstr=String()

    var sd = String()
    var x = String()
    var reg = String()

    var datecome=String()

    var esc = String()
    var upstr = String()
    var numberstr = String()
    var regtr = String()
    var nmstr = String()
    var kyval = String()
    var supkyval = String()
    var bsupkyval = String()
    var origisearch = arrayOf<String>()
    var imarray = arrayOf<String>()
    var imglinks = String()

    private var addpurord: String = ""
    private var editepurord: String = ""
    private var deletepurord: String = ""
    private var viewpurord: String = ""
    private var transferpurord: String = ""
    private var exportpurord: String = ""
    private var sendpurpo = String()


    private var addsuppin: String = ""
    private var editesuppin: String = ""
    private var deletesuppin: String = ""
    private var viewsuppin: String = ""
    private var transfersuppin: String = ""
    private var exportsuppin: String = ""


    private var addpurreq: String = ""
    private var editepurreq: String = ""
    private var deletepurreq: String = ""
    private var viewpurreq: String = ""
    private var transferpurreq: String = ""
    private var exportpurreq: String = ""



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_purchase_request)


        net_status() //Check internet status.


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@PurchaseRequestActivity) > 0)
        {

        }
        else{

        }


        //Define No connection view when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.req_contain)

        addLogText(NetworkUtil.getConnectivityStatusString(this@PurchaseRequestActivity))


        search.setOnClickListener {                 //Image button search  action

            cardsearch.visibility = View.VISIBLE
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@PurchaseRequestActivity, R.anim.slide_to_right))
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }



        vert.setOnClickListener({       //Vert menu contains 'Logout' option.


            val popup = PopupMenu(this@PurchaseRequestActivity, vert)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                if (item.title == "Logout") {       //Navigate to pin activity
                    if(net_status()==true){
                    Toast.makeText(this@PurchaseRequestActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                    val f = Intent(this@PurchaseRequestActivity, PinActivity::class.java)
                    startActivity(f)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()
                    }
                    else if(net_status()==false){
                        Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
                    }
                }
                true
            }

            popup.show()
        })







                    //-------------------------SEARCH ACTION-----------------------------//

        searchedit.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                progressBar4.visibility = View.VISIBLE
                pur_reqlist.visibility = View.GONE
                if(searchedit.length()==1){
                    pur_reqlist.visibility=View.VISIBLE

                }
                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"

                val ps = "^[a-zA-Z ]+$"



                val datev = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$"
                println("TYPED VALUED" + x)

                if (x.trim().matches(datev.toRegex())) {
                    upstr = x
                    println("CAME INTO DATE NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    datecome="inside"
                    regtr = "num"
                    dateget()


                }



                fun dateget() {
                    println("d get date")
                    if ((s.length>=2)||(s.length>=2)) {
                        noresfo.visibility = View.GONE

                        var text = arrayOf<String>()
                        var suppkeyarr = arrayOf<String>()

                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var imArray1 = arrayOf<String>()

                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()


                        db.collection("${broriky}_Purchase Request").orderBy("req_date").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)
                                                var dt = document.data


                                                var brid = (dt["brid"]).toString()

                                                brorival = broriky

                                                if (brorival == brid) {

                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    iddd.setText(idss.toString())
                                                    println(idss)
                                                    var name = (dt["prod_nms"]).toString()


                                                    try {
                                                        var imlinks = (dt["imglinks"]).toString()
                                                        imglinks = imlinks
                                                        imarray = imarray.plusElement(imglinks)
                                                    } catch (e: Exception) {
                                                        imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                        imarray = imarray.plusElement(imglinks)
                                                    }


                                                    var phone = (dt["supplier_Phone"]).toString()
                                                    var date = (dt["req_date"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var dates = (dt["req_estimated"]).toString()
                                                    try {
                                                        imArray1 = imarray
                                                        var sta = (dt["status"]).toString()
                                                        stag = sta

                                                        if (sta == "Approved") {
                                                            descr = "Approved"
                                                            statusArray1 = statusArray1.plusElement(descr)
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray2pr=statusArray2pr.plusElement("")
                                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                                            status = statusArray1
                                                        } else {
                                                            descr = "Pending"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr=statusArray2pr.plusElement("")
                                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                                            status = statusArray
                                                        }
                                                    } catch (e: Exception) {
                                                        descr = "Pending"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")
                                                        status = statusArray
                                                    }
                                                    var manufacturer = (dt["req_id"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())

                                                    suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                    nameArray = nameArray.plusElement(name)
                                                    if(dates.isNotEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                    }
                                                    else if(dates.isEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date)

                                                    }
                                                    if(tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot)
                                                    }
                                                    else if(!tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot+".00")

                                                    }
                                                    nameArrayori = text
                                                    supplierkeyori=suppkeyarr
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)

                                                    descrip = descriptionArray
                                                    bridArrayori = bridArrayori.plusElement(brid)
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brid)
                                                    println("LOGIINNNN KEYYYY" + brorival)


                                                    pur_reqlist.visibility = View.VISIBLE
                                                    progressBar4.visibility = View.GONE
                                                    noresfo.visibility = View.GONE
                                                    println("If SAVE KEYYYY" + brorival)
                                                    val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                    wlist.adapter = whatever
                                                /*    swipeContainer.setRefreshing(false);*/

                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    pur_reqlist.visibility = View.GONE
                                                    progressBar4.visibility = View.GONE
                                                }


                                            }


                                        } else {
                                            println("NO RECORDSSSS FOUNDD")

                                            db.collection("${broriky}_Purchase Request").orderBy("req_estimated").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)

                                                                    var dt = document.data
                                                                    var brid = (dt["brid"]).toString()

                                                                    brorival = broriky

                                                                    if (brorival == brid) {


                                                                        var id = (document.id)
                                                                        idss = idss.plusElement(id)
                                                                        iddd.setText(idss.toString())
                                                                        println(idss)

                                                                        var name = (dt["prod_nms"]).toString()

                                                                        try {
                                                                            var imlinks = (dt["imglinks"]).toString()
                                                                            imglinks = imlinks
                                                                            imarray = imarray.plusElement(imglinks)
                                                                        } catch (e: Exception) {
                                                                            imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                                            imarray = imarray.plusElement(imglinks)
                                                                        }


                                                                        var phone = (dt["supplier_Phone"]).toString()
                                                                        var date = (dt["req_date"]).toString()
                                                                        var tot = (dt["gross_tot"]).toString()
                                                                        var dates = (dt["req_estimated"]).toString()
                                                                        try {
                                                                            imArray1 = imarray
                                                                            var sta = (dt["status"]).toString()
                                                                            stag = sta

                                                                            if (sta == "Approved") {
                                                                                descr = "Approved"
                                                                                statusArray1 = statusArray1.plusElement(descr)
                                                                                statusArray = statusArray.plusElement("")
                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                status = statusArray1
                                                                            } else {
                                                                                descr = "Pending"
                                                                                statusArray = statusArray.plusElement(descr)
                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                status = statusArray
                                                                            }
                                                                        } catch (e: Exception) {
                                                                            descr = "Pending"
                                                                            statusArray = statusArray.plusElement(descr)
                                                                            statusArray1 = statusArray1.plusElement("")
                                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                                            statusArray3cncl = statusArray3cncl.plusElement("")
                                                                            status = statusArray
                                                                        }
                                                                        var manufacturer = (dt["req_id"]).toString()
                                                                        text = text.plusElement((dt["supplier_name"]).toString())

                                                                        suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                                        nameArray = nameArray.plusElement(name)
                                                                        if (dates.isNotEmpty()) {
                                                                            dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                                        } else if (dates.isEmpty()) {
                                                                            dateArray = dateArray.plusElement("Ordered on " + date)

                                                                        }
                                                                        if (tot.contains(".")) {
                                                                            priceArray = priceArray.plusElement(tot)
                                                                        } else if (!tot.contains(".")) {
                                                                            priceArray = priceArray.plusElement(tot + ".00")

                                                                        }
                                                                        nameArrayori = text

                                                                        supplierkeyori=suppkeyarr
                                                                        dateArrayori = dateArray
                                                                        priceArrayori = priceArray
                                                                        datearr = datearr.plusElement(date)
                                                                        datesarr = datesarr.plusElement(dates)
                                                                        phoneArrayori = phoneArrayori.plusElement(phone)

                                                                        descriptionArray = descriptionArray.plusElement(manufacturer)

                                                                        descrip = descriptionArray
                                                                        bridArrayori = bridArrayori.plusElement(brid)
                                                                        ids = idss
                                                                        liids = idss
                                                                        println("Original KEYYYY" + brid)
                                                                        println("LOGIINNNN KEYYYY" + brorival)


                                                                        pur_reqlist.visibility = View.VISIBLE
                                                                        progressBar4.visibility = View.GONE
                                                                        noresfo.visibility = View.GONE
                                                                        println("If SAVE KEYYYY" + brorival)
                                                                        val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                        val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                                        wlist.adapter = whatever
                                                                        /*    swipeContainer.setRefreshing(false);*/

                                                                    } else {
                                                                        noresfo.visibility = View.VISIBLE
                                                                        pur_reqlist.visibility = View.GONE
                                                                        progressBar4.visibility = View.GONE
                                                                    }


                                                                }
                                                            }
                                                            else{
                                                                noresfo.visibility = View.VISIBLE
                                                                pur_reqlist.visibility = View.GONE
                                                                progressBar4.visibility = View.GONE
                                                            }

                                                    })
                                        }







                                })

                    }
                    else{
                        println("startlist error")
                        noresfo.visibility = View.VISIBLE
                        pur_reqlist.visibility = View.GONE
                        progressBar4.visibility = View.GONE
                    }
                }


                fun priget() {
                    println("d get pri")
                    if (s.length >= 2) {
                        noresfo.visibility = View.GONE

                        var text = arrayOf<String>()
                        var suppkeyarr = arrayOf<String>()

                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var imArray1 = arrayOf<String>()
                    var statusArray2pr = arrayOf<String>()
                    var statusArray3cncl = arrayOf<String>()

                        db.collection("${broriky}_Purchase Request").orderBy("gross_tot").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var brid = (dt["brid"]).toString()


                                                brorival = broriky

                                                if (brorival == brid) {

                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    iddd.setText(idss.toString())
                                                    println(idss)

                                                    var name = (dt["prod_nms"]).toString()
                                                    try {
                                                        var imlinks = (dt["imglinks"]).toString()
                                                        imglinks = imlinks
                                                        imarray = imarray.plusElement(imglinks)
                                                    } catch (e: Exception) {
                                                        imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                        imarray = imarray.plusElement(imglinks)
                                                    }


                                                    var phone = (dt["supplier_Phone"]).toString()
                                                    var date = (dt["req_date"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var dates = (dt["req_estimated"]).toString()
                                                    try {
                                                        imArray1 = imarray
                                                        var sta = (dt["status"]).toString()
                                                        stag = sta

                                                        if (sta == "Approved") {
                                                            descr = "Approved"
                                                            statusArray1 = statusArray1.plusElement(descr)
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray2pr=statusArray2pr.plusElement("")
                                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                                            status = statusArray1
                                                        } else {
                                                            descr = "Pending"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr=statusArray2pr.plusElement("")
                                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                                            status = statusArray
                                                        }
                                                    } catch (e: Exception) {
                                                        descr = "Pending"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")
                                                        status = statusArray
                                                    }
                                                    var manufacturer = (dt["req_id"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())

                                                    suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                    nameArray = nameArray.plusElement(name)
                                                    if(dates.isNotEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                    }
                                                    else if(dates.isEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date)

                                                    }
                                                    if(tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot)
                                                    }
                                                    else if(!tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot+".00")

                                                    }
                                                    nameArrayori = text
                                                    supplierkeyori=suppkeyarr
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)

                                                    descrip = descriptionArray
                                                    bridArrayori = bridArrayori.plusElement(brid)
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brid)
                                                    println("LOGIINNNN KEYYYY" + brorival)
                                                    pur_reqlist.visibility = View.VISIBLE
                                                    progressBar4.visibility = View.GONE
                                                    noresfo.visibility = View.GONE
                                                    println("If SAVE KEYYYY" + brorival)
                                                    val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                    wlist.adapter = whatever
                                                 /*   swipeContainer.setRefreshing(false);*/

                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    pur_reqlist.visibility = View.GONE
                                                    progressBar4.visibility = View.GONE
                                                }


                                            }


                                        } else {
                                           dateget()
                                        }



                                })

                    }
                }



                if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    regtr = "num"
                    priget()

                    //write code here for success
                }




                if ((x != reg)&&(!s.contains("/"))) {
                    val upperString = x.toUpperCase()
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("CAME INTO NUMBER upper string" + upstr)
                    println("STRINGSSSS" + upstr)

                }
                else if(s.contains("/")){
                    dateget()
                }






                //_____________________________NAME SEARCH__________________________________//


                fun nameget() {

                    println("d get name")
                    if ((s.length >= 3) && (x != reg)) {
                        noresfo.visibility = View.GONE
                        var text = arrayOf<String>()
                        var suppkeyarr = arrayOf<String>()

                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var imArray1 = arrayOf<String>()

                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()


                        db.collection("${broriky}_Purchase Request").orderBy("supplier_name").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var brid = (dt["brid"]).toString()


                                                brorival = broriky

                                                if (brorival == brid) {

                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    iddd.setText(idss.toString())
                                                    println(idss)

                                                    var name = (dt["prod_nms"]).toString()

                                                    try {
                                                        var imlinks = (dt["imglinks"]).toString()
                                                        imglinks = imlinks
                                                        imarray = imarray.plusElement(imglinks)
                                                    } catch (e: Exception) {
                                                        imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                        imarray = imarray.plusElement(imglinks)
                                                    }


                                                    var phone = (dt["supplier_Phone"]).toString()
                                                    var date = (dt["req_date"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var dates = (dt["req_estimated"]).toString()
                                                    try {
                                                        imArray1 = imarray
                                                        var sta = (dt["status"]).toString()
                                                        stag = sta

                                                        if (sta == "Approved") {
                                                            descr = "Approved"
                                                            statusArray1 = statusArray1.plusElement(descr)
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray2pr=statusArray2pr.plusElement("")
                                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                                            status = statusArray1
                                                        } else {
                                                            descr = "Pending"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr=statusArray2pr.plusElement("")
                                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                                            status = statusArray
                                                        }
                                                    } catch (e: Exception) {
                                                        descr = "Pending"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr=statusArray2pr.plusElement("")
                                                        statusArray3cncl=statusArray3cncl.plusElement("")
                                                        status = statusArray
                                                    }
                                                    var manufacturer = (dt["req_id"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())

                                                    suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                    nameArray = nameArray.plusElement(name)
                                                    if(dates.isNotEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                    }
                                                    else if(dates.isEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date)

                                                    }
                                                    if(tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot)
                                                    }
                                                    else if(!tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot+".00")

                                                    }
                                                    nameArrayori = text
                                                    supplierkeyori=suppkeyarr
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)

                                                    descrip = descriptionArray
                                                    bridArrayori = bridArrayori.plusElement(brid)
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brid)
                                                    println("LOGIINNNN KEYYYY" + brorival)


                                                    pur_reqlist.visibility = View.VISIBLE
                                                    progressBar4.visibility = View.GONE
                                                    println("If SAVE KEYYYY" + brorival)
                                                    val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                    wlist.adapter = whatever
                                           /*         swipeContainer.setRefreshing(false);*/

                                                } else {
                                                       noresfo.visibility = View.VISIBLE
                                                    pur_reqlist.visibility = View.GONE
                                                    progressBar4.visibility=View.GONE
                                                }

                                            }


                                        } else {


                                            db.collection("${broriky}_Purchase Request").orderBy("prod_nms").startAt(upstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)

                                                                    var dt = document.data
                                                                    var brid = (dt["brid"]).toString()



                                                                    if (brorival == brid) {

                                                                        var id = (document.id)
                                                                        idss = idss.plusElement(id)
                                                                        iddd.setText(idss.toString())
                                                                        println(idss)

                                                                        var name = (dt["prod_nms"]).toString()

                                                                        try {
                                                                            var imlinks = (dt["imglinks"]).toString()
                                                                            imglinks = imlinks
                                                                            imarray = imarray.plusElement(imglinks)
                                                                        } catch (e: Exception) {
                                                                            imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                                            imarray = imarray.plusElement(imglinks)
                                                                        }


                                                                        var phone = (dt["supplier_Phone"]).toString()
                                                                        var date = (dt["req_date"]).toString()
                                                                        var tot = (dt["gross_tot"]).toString()
                                                                        var dates = (dt["req_estimated"]).toString()
                                                                        try {
                                                                            imArray1 = imarray
                                                                            var sta = (dt["status"]).toString()
                                                                            stag = sta

                                                                            if (sta == "Approved") {
                                                                                descr = "Approved"
                                                                                statusArray1 = statusArray1.plusElement(descr)
                                                                                statusArray = statusArray.plusElement("")
                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                status = statusArray1
                                                                            } else {
                                                                                descr = "Pending"
                                                                                statusArray = statusArray.plusElement(descr)
                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                status = statusArray
                                                                            }
                                                                        } catch (e: Exception) {
                                                                            descr = "Pending"
                                                                            statusArray = statusArray.plusElement(descr)
                                                                            statusArray1 = statusArray1.plusElement("")
                                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                                            statusArray3cncl = statusArray3cncl.plusElement("")
                                                                            status = statusArray
                                                                        }
                                                                        var manufacturer = (dt["req_id"]).toString()
                                                                        text = text.plusElement((dt["supplier_name"]).toString())

                                                                        suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                                        nameArray = nameArray.plusElement(name)
                                                                        if(dates.isNotEmpty()){
                                                                            dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                                        }
                                                                        else if(dates.isEmpty()){
                                                                            dateArray = dateArray.plusElement("Ordered on " + date)

                                                                        }
                                                                        if(tot.contains(".")){
                                                                            priceArray = priceArray.plusElement(tot)
                                                                        }
                                                                        else if(!tot.contains(".")){
                                                                            priceArray = priceArray.plusElement(tot+".00")

                                                                        }
                                                                        nameArrayori = text
                                                                        supplierkeyori=suppkeyarr
                                                                        dateArrayori = dateArray
                                                                        priceArrayori = priceArray
                                                                        datearr = datearr.plusElement(date)
                                                                        datesarr = datesarr.plusElement(dates)
                                                                        phoneArrayori = phoneArrayori.plusElement(phone)

                                                                        descriptionArray = descriptionArray.plusElement(manufacturer)

                                                                        descrip = descriptionArray
                                                                        bridArrayori = bridArrayori.plusElement(brid)
                                                                        ids = idss
                                                                        liids = idss
                                                                        println("Original KEYYYY" + brid)
                                                                        println("LOGIINNNN KEYYYY" + brorival)
                                                                        brorival = broriky


                                                                        pur_reqlist.visibility = View.VISIBLE
                                                                        progressBar4.visibility = View.GONE
                                                                        println("If SAVE KEYYYY" + brorival)
                                                                        val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                        val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                                        wlist.adapter = whatever
                                                                        /*         swipeContainer.setRefreshing(false);*/

                                                                    } else {
                                                                        noresfo.visibility = View.VISIBLE
                                                                        pur_reqlist.visibility = View.GONE
                                                                        progressBar4.visibility = View.GONE
                                                                    }

                                                                }


                                                            } else {

                                                                db.collection("${broriky}_Purchase Request").orderBy("status").startAt(upstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {

                                                                                        Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                                        println(document.data)

                                                                                        var dt = document.data
                                                                                        var brid = (dt["brid"]).toString()


                                                                                        brorival = broriky

                                                                                        if (brorival == brid) {
                                                                                            var id = (document.id)
                                                                                            idss = idss.plusElement(id)
                                                                                            iddd.setText(idss.toString())
                                                                                            println(idss)

                                                                                            var name = (dt["prod_nms"]).toString()

                                                                                            try {
                                                                                                var imlinks = (dt["imglinks"]).toString()
                                                                                                imglinks = imlinks
                                                                                                imarray = imarray.plusElement(imglinks)
                                                                                            } catch (e: Exception) {
                                                                                                imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                                                                imarray = imarray.plusElement(imglinks)
                                                                                            }


                                                                                            var phone = (dt["supplier_Phone"]).toString()
                                                                                            var date = (dt["req_date"]).toString()
                                                                                            var tot = (dt["gross_tot"]).toString()
                                                                                            var dates = (dt["req_estimated"]).toString()
                                                                                            try {
                                                                                                imArray1 = imarray
                                                                                                var sta = (dt["status"]).toString()
                                                                                                stag = sta

                                                                                                if (sta == "Approved") {
                                                                                                    descr = "Approved"
                                                                                                    statusArray1 = statusArray1.plusElement(descr)
                                                                                                    statusArray = statusArray.plusElement("")
                                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                                    status = statusArray1
                                                                                                } else {
                                                                                                    descr = "Pending"
                                                                                                    statusArray = statusArray.plusElement(descr)
                                                                                                    statusArray1 = statusArray1.plusElement("")
                                                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                                    status = statusArray
                                                                                                }
                                                                                            } catch (e: Exception) {
                                                                                                descr = "Pending"
                                                                                                statusArray = statusArray.plusElement(descr)
                                                                                                statusArray1 = statusArray1.plusElement("")
                                                                                                statusArray2pr = statusArray2pr.plusElement("")
                                                                                                statusArray3cncl = statusArray3cncl.plusElement("")
                                                                                                status = statusArray
                                                                                            }
                                                                                            var manufacturer = (dt["req_id"]).toString()
                                                                                            text = text.plusElement((dt["supplier_name"]).toString())

                                                                                            suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                                                            nameArray = nameArray.plusElement(name)
                                                                                            if (dates.isNotEmpty()) {
                                                                                                dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                                                            } else if (dates.isEmpty()) {
                                                                                                dateArray = dateArray.plusElement("Ordered on " + date)

                                                                                            }
                                                                                            if (tot.contains(".")) {
                                                                                                priceArray = priceArray.plusElement(tot)
                                                                                            } else if (!tot.contains(".")) {
                                                                                                priceArray = priceArray.plusElement(tot + ".00")

                                                                                            }
                                                                                            nameArrayori = text
                                                                                            supplierkeyori=suppkeyarr
                                                                                            dateArrayori = dateArray
                                                                                            priceArrayori = priceArray
                                                                                            datearr = datearr.plusElement(date)
                                                                                            datesarr = datesarr.plusElement(dates)
                                                                                            phoneArrayori = phoneArrayori.plusElement(phone)

                                                                                            descriptionArray = descriptionArray.plusElement(manufacturer)

                                                                                            descrip = descriptionArray
                                                                                            bridArrayori = bridArrayori.plusElement(brid)
                                                                                            ids = idss
                                                                                            liids = idss
                                                                                            println("Original KEYYYY" + brid)
                                                                                            println("LOGIINNNN KEYYYY" + brorival)
                                                                                            pur_reqlist.visibility = View.VISIBLE
                                                                                            progressBar4.visibility = View.GONE
                                                                                            println("If SAVE KEYYYY" + brorival)
                                                                                            val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                                            val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                                                            wlist.adapter = whatever
                                                                                            /*         swipeContainer.setRefreshing(false);*/

                                                                                        } else {
                                                                                            noresfo.visibility = View.VISIBLE
                                                                                            pur_reqlist.visibility = View.GONE
                                                                                            progressBar4.visibility = View.GONE
                                                                                        }

                                                                                    }


                                                                                } else {
                                                                                    progressBar4.visibility = View.GONE

                                                                                    pur_reqlist.visibility = View.GONE
                                                                                    noresfo.visibility = View.VISIBLE
                                                                                }

                                                                        })

                                                            }



                                                    })
                                        }



                                })

                    }

                }
                if ((x.trim().matches(ps.toRegex())) && (x != reg)) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("CAME INTO NUMBER upper names" + upstr)
                    println("STRINGSSSS" + upstr)
                    nameget()
                }



                    if ((s.length >= 3) && (x != reg)&&((!s.contains("/")))) {
                        println("d get idss")
                        noresfo.visibility = View.GONE
                        var text = arrayOf<String>()
                        var suppkeyarr = arrayOf<String>()

                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var descriptionArray = arrayOf<String>()
                        var statusArray = arrayOf<String>()
                        var statusArray1 = arrayOf<String>()
                        var imArray1 = arrayOf<String>()
                        var statusArray2pr = arrayOf<String>()
                        var statusArray3cncl = arrayOf<String>()


                        db.collection("${broriky}_Purchase Request").orderBy("req_id").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data

                                                var brid = (dt["brid"]).toString()



                                                brorival = broriky



                                                if (brorival == brid) {

                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    iddd.setText(idss.toString())
                                                    println(idss)

                                                    var name = (dt["prod_nms"]).toString()

                                                    try {
                                                        var imlinks = (dt["imglinks"]).toString()
                                                        imglinks = imlinks
                                                        imarray = imarray.plusElement(imglinks)
                                                    } catch (e: Exception) {
                                                        imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                        imarray = imarray.plusElement(imglinks)
                                                    }


                                                    var phone = (dt["supplier_Phone"]).toString()
                                                    var date = (dt["req_date"]).toString()
                                                    var tot = (dt["gross_tot"]).toString()
                                                    var dates = (dt["req_estimated"]).toString()
                                                    try {
                                                        imArray1 = imarray
                                                        var sta = (dt["status"]).toString()
                                                        stag = sta

                                                        if (sta == "Approved") {
                                                            descr = "Approved"
                                                            statusArray1 = statusArray1.plusElement(descr)
                                                            statusArray = statusArray.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")
                                                            status = statusArray1
                                                        } else {
                                                            descr = "Pending"
                                                            statusArray = statusArray.plusElement(descr)
                                                            statusArray1 = statusArray1.plusElement("")
                                                            statusArray2pr = statusArray2pr.plusElement("")
                                                            statusArray3cncl = statusArray3cncl.plusElement("")
                                                            status = statusArray
                                                        }
                                                    } catch (e: Exception) {
                                                        descr = "Pending"
                                                        statusArray = statusArray.plusElement(descr)
                                                        statusArray1 = statusArray1.plusElement("")
                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                        statusArray3cncl = statusArray3cncl.plusElement("")
                                                        status = statusArray
                                                    }
                                                    var manufacturer = (dt["req_id"]).toString()
                                                    text = text.plusElement((dt["supplier_name"]).toString())

                                                    suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                    nameArray = nameArray.plusElement(name)
                                                    if(dates.isNotEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                    }
                                                    else if(dates.isEmpty()){
                                                        dateArray = dateArray.plusElement("Ordered on " + date)

                                                    }
                                                    if(tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot)
                                                    }
                                                    else if(!tot.contains(".")){
                                                        priceArray = priceArray.plusElement(tot+".00")

                                                    }
                                                    nameArrayori = text
                                                    supplierkeyori=suppkeyarr
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    datesarr = datesarr.plusElement(dates)
                                                    phoneArrayori = phoneArrayori.plusElement(phone)

                                                    descriptionArray = descriptionArray.plusElement(manufacturer)

                                                    descrip = descriptionArray
                                                    bridArrayori = bridArrayori.plusElement(brid)
                                                    ids = idss
                                                    liids = idss
                                                    println("Original KEYYYY" + brid)
                                                    println("LOGIINNNN KEYYYY" + brorival)


                                                    pur_reqlist.visibility = View.VISIBLE
                                                    progressBar4.visibility = View.GONE
                                                    noresfo.visibility = View.GONE
                                                    println("If SAVE KEYYYY" + brorival)
                                                    val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                    val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                    wlist.adapter = whatever


                                                } else {

                                                    pur_reqlist.visibility = View.GONE
                                                    progressBar4.visibility = View.GONE
                                                    noresfo.visibility = View.VISIBLE


                                                }

                                            }


                                        } else {

                                            nameget()


                                        }



                                })

                    }
                    else if(s.contains("/")){
                        dateget()
                    }






                return
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }

            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if (searchedit.text.toString().isEmpty()) {
                    noresfo.visibility = View.GONE
                    pur_reqlist.visibility = View.VISIBLE

                    progressBar4.visibility = View.GONE

                    act()
                }
            }
        })



   /*     swipeContainer.setOnRefreshListener {

            act()
        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/



        searback1.setOnClickListener {   //Image button search back action
            searchedit.setText("")
            cardsearch.visibility = View.GONE

            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@PurchaseRequestActivity, R.anim.slide_to_left))
            noresfo.visibility = View.GONE
            pur_reqlist.visibility = View.VISIBLE
            progressBar4.visibility = View.GONE
            act()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }


        val i = intent.extras
        var frm = i!!.get("from_ver")


        /*else if(frm=="verify") {
            try {
                val o = intent.getStringExtra("status")
                s = o
            } catch (e: Exception) {

            }
        }*/

        if (frm == "main") {

            val p = intent.getStringExtra("brkey")
            broriky = p





            //${broriky}_Purchase Request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("${broriky}_Purchase Request TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }
            println("LOGINN KEYYYY" + broriky)
            act()

        } else if (frm == "frmsave") {


            val pas = intent.getStringExtra("brky")
            broriky = pas



            //${broriky}_Purchase Request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("${broriky}_Purchase Request TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }
            act()


        } else if (frm == "verify") {

            //${broriky}_Purchase Request




            //${broriky}_Purchase Request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("${broriky}_Purchase Request TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }
            val pa = intent.getStringExtra("brky")
            broriky = pa
            act()

        } else if (frm == "frmaddact") {



            //${broriky}_Purchase Request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("${broriky}_Purchase Request TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }
            val pal = intent.getStringExtra("oriky")
            broriky = pal
            act()
        } else if (frm == "halfverify") {
            //${broriky}_Purchase Request




            //${broriky}_Purchase Request

            val adpr = intent.getStringExtra("addpurreq")
            val edpr = intent.getStringExtra("editpurreq")
            val delpr = intent.getStringExtra("deletepurreq")
            val vipr = intent.getStringExtra("viewpurreq")
            val tranpr = intent.getStringExtra("transferpurreq")
            val expr = intent.getStringExtra("exportpurreq")

            if (adpr != null) {
                addpurreq = adpr
            }
            if (edpr != null) {
                editepurreq = edpr
            }
            if (delpr != null) {
                deletepurreq = delpr
            }
            if (vipr != null) {
                viewpurreq = vipr
            }
            if (tranpr != null) {
                transferpurreq = tranpr


                println("${broriky}_Purchase Request TRANSFER NEXT" + transferpurreq)


            }
            if (expr != null) {
                exportpurreq = expr
            }


            //Purchase order

            val adord = intent.getStringExtra("addpurord")
            val edord = intent.getStringExtra("editpurord")
            val delord = intent.getStringExtra("deletepurord")
            val viord = intent.getStringExtra("viewpurord")
            val tranord = intent.getStringExtra("transferpurord")
            val exord = intent.getStringExtra("exportpurord")
            sendpurpo = intent.getStringExtra("sendpurord")
            if (adord != null) {
                addpurord = adord
            }
            if (edord != null) {
                editepurord = edord
            }
            if (delord != null) {
                deletepurord = delord
            }
            if (viord != null) {
                viewpurord = viord
            }
            if (tranord != null) {
                transferpurord = tranord
            }
            if (exord != null) {
                exportpurord = exord
            }


            //Supplier Invoice

            val adsuppin = intent.getStringExtra("addsuppin")
            val edsuppin = intent.getStringExtra("editsuppin")
            val delsuppin = intent.getStringExtra("deletesuppin")
            val visuppin = intent.getStringExtra("viewsuppin")
            val transuppin = intent.getStringExtra("transfersuppin")
            val exsuppin = intent.getStringExtra("exportsuppin")

            if (adsuppin != null) {
                addsuppin = adsuppin
            }
            if (edsuppin != null) {
                editesuppin = edsuppin
            }
            if (delsuppin != null) {
                deletesuppin = delsuppin
            }
            if (visuppin != null) {
                viewsuppin = visuppin
            }
            if (transuppin != null) {
                transfersuppin = transuppin
            }
            if (exsuppin != null) {
                exportsuppin = exsuppin
            }
            val pa = intent.getStringExtra("brky")
            broriky = pa
            act()
        }

        userback.setOnClickListener {

            onBackPressed()

        }

        /*     var path="Stock_Transfer/$i/Stock_products"
        println(path)
        db.collection(path)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                    println("hello")
                    var listidArray= arrayOf<String>()
                    if (e != null) {
                        Log.w("", "Listen failed.", e)
                        return@EventListener
                    }
                    for (document in value) {
                        var idli = (document.id)
                        listidArray.plusElement(idli)

                        liids=listidArray
                        println(liids)

                    }
                })*/




        //Navigate to purchase request details  activity (RequestAddActivity) for updating the purchase request.

        pur_reqlist.setOnItemClickListener { parent, views, position, id ->



            val b = Intent(applicationContext, RequestAddActivity::class.java)

            try {
                b.putExtra("from_req", "startlist_req")
                b.putExtra("spnm", nameArrayori[position])
                b.putExtra("suppkey",supplierkeyori[position])
                b.putExtra("spph", phoneArrayori[position])
                b.putExtra("date", datearr[position])
                b.putExtra("estidate", datesarr[position])
                b.putExtra("reqids", descrip[position])
                b.putExtra("listids", liids[position])
                b.putExtra("status", status[position])
                println("ONTIME STATUS VIEW SEND"+status[position])
                b.putExtra("brids", bridArrayori[position])

                try {
                    b.putExtra("imlink", imarray[position])
                } catch (e: Exception) {

                }
            }
            catch (e:Exception){
                try {
                    b.putExtra("from_req", "startlist_req")
                    b.putExtra("spnm", nameArrayori[5])
                    b.putExtra("suppkey",supplierkeyori[5])
                    b.putExtra("spph", phoneArrayori[5])
                    b.putExtra("date", datearr[5])
                    b.putExtra("estidate", datesarr[5])
                    b.putExtra("reqids", descrip[5])
                    b.putExtra("listids", liids[5])
                    b.putExtra("status", status[5])
                    b.putExtra("brids", bridArrayori[5])

                    try {
                        b.putExtra("imlink", imarray[5])
                    } catch (e: Exception) {

                    }
                }
                catch (e:Exception){

                }
            }

            b.putExtra("viewsuppin", viewsuppin)
            b.putExtra("addsuppin", addsuppin)
            b.putExtra("deletesuppin", deletesuppin)
            b.putExtra("editsuppin", editesuppin)
            b.putExtra("transfersuppin", transfersuppin)
            b.putExtra("exportsuppin", exportsuppin)


            b.putExtra("viewpurord", viewpurord)
            b.putExtra("addpurord", addpurord)
            b.putExtra("deletepurord", deletepurord)
            b.putExtra("editpurord", editepurord)
            b.putExtra("transferpurord", transferpurord)
            b.putExtra("exportpurord", exportpurord)
            b.putExtra("sendpurord", sendpurpo)




            b.putExtra("viewpurreq", viewpurreq)
            b.putExtra("addpurreq", addpurreq)
            b.putExtra("deletepurreq", deletepurreq)
            b.putExtra("editpurreq", editepurreq)
            b.putExtra("transferpurreq", transferpurreq)
            b.putExtra("exportpurreq", exportpurreq)


            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()
        }


        //Navigate to purchase request details  activity (RequestAddActivity) for make new purchase request.

        req_fab.setOnClickListener {
            if (addpurreq == "true") {
                val o = Intent(this@PurchaseRequestActivity, SupplierRequestActivity::class.java)
                o.putExtra("viewsuppin", viewsuppin)
                o.putExtra("addsuppin", addsuppin)
                o.putExtra("deletesuppin", deletesuppin)
                o.putExtra("editsuppin", editesuppin)
                o.putExtra("transfersuppin", transfersuppin)
                o.putExtra("exportsuppin", exportsuppin)


                o.putExtra("viewpurord", viewpurord)
                o.putExtra("addpurord", addpurord)
                o.putExtra("deletepurord", deletepurord)
                o.putExtra("editpurord", editepurord)
                o.putExtra("transferpurord", transferpurord)
                o.putExtra("exportpurord", exportpurord)
                o.putExtra("sendpurord", sendpurpo)




                o.putExtra("viewpurreq", viewpurreq)
                o.putExtra("addpurreq", addpurreq)
                o.putExtra("deletepurreq", deletepurreq)
                o.putExtra("editpurreq", editepurreq)
                o.putExtra("transferpurreq", transferpurreq)
                o.putExtra("exportpurreq", exportpurreq)


                o.putExtra("oribrky", broriky)
                startActivity(o)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                finish()
            } else if (addpurreq == "false") {
                popup("Add")
            }
        }
    }


    //--------------------Dateget search--------------//

    fun dateget() {

        println("numberstr dateget"+numberstr)
        if ((s.length>=3)||(s.length>=3)) {
            noresfo.visibility = View.GONE

            var text = arrayOf<String>()
            var suppkeyarr = arrayOf<String>()

            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var descriptionArray = arrayOf<String>()
            var statusArray = arrayOf<String>()
            var statusArray1 = arrayOf<String>()
            var imArray1 = arrayOf<String>()
           var statusArray2pr=arrayOf<String>()
           var statusArray3cncl=arrayOf<String>()


            db.collection("${broriky}_Purchase Request").orderBy("req_date").startAt(numberstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)
                                    var dt = document.data
                                    var brid = (dt["brid"]).toString()


                                    brorival = broriky

                                    if (brorival == brid) {

                                        var id = (document.id)
                                        idss = idss.plusElement(id)
                                        iddd.setText(idss.toString())
                                        println(idss)

                                        var name = (dt["prod_nms"]).toString()
                                        try {
                                            var imlinks = (dt["imglinks"]).toString()
                                            imglinks = imlinks
                                            imarray = imarray.plusElement(imglinks)
                                        } catch (e: Exception) {
                                            imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                            imarray = imarray.plusElement(imglinks)
                                        }


                                        var phone = (dt["supplier_Phone"]).toString()
                                        var date = (dt["req_date"]).toString()
                                        var tot = (dt["gross_tot"]).toString()
                                        var dates = (dt["req_estimated"]).toString()
                                        try {
                                            imArray1 = imArray1.plusElement("")
                                            var sta = (dt["status"]).toString()
                                            stag = sta

                                            if (sta == "Approved") {
                                                descr = "Approved"
                                                statusArray1 = statusArray1.plusElement(descr)
                                                statusArray = statusArray.plusElement("")
                                                statusArray2pr=statusArray2pr.plusElement("")
                                                statusArray3cncl=statusArray3cncl.plusElement("")
                                                status = statusArray1
                                            } else {
                                                descr = "Pending"
                                                statusArray = statusArray.plusElement(descr)
                                                statusArray1 = statusArray1.plusElement("")
                                                statusArray2pr=statusArray2pr.plusElement("")
                                                statusArray3cncl=statusArray3cncl.plusElement("")
                                                status = statusArray
                                            }
                                        } catch (e: Exception) {
                                            descr = "Pending"
                                            statusArray = statusArray.plusElement(descr)
                                            statusArray1 = statusArray1.plusElement("")
                                            statusArray2pr=statusArray2pr.plusElement("")
                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                            status = statusArray
                                        }
                                        var manufacturer = (dt["req_id"]).toString()
                                        text = text.plusElement((dt["supplier_name"]).toString())

                                        suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                        nameArray = nameArray.plusElement(name)
                                        if(dates.isNotEmpty()){
                                            dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                        }
                                        else if(dates.isEmpty()){
                                            dateArray = dateArray.plusElement("Ordered on " + date)

                                        }
                                        if(tot.contains(".")){
                                            priceArray = priceArray.plusElement(tot)
                                        }
                                        else if(!tot.contains(".")){
                                            priceArray = priceArray.plusElement(tot+".00")

                                        }
                                        nameArrayori = text
                                        supplierkeyori=suppkeyarr
                                        dateArrayori = dateArray
                                        priceArrayori = priceArray
                                        datearr = datearr.plusElement(date)
                                        datesarr = datesarr.plusElement(dates)
                                        phoneArrayori = phoneArrayori.plusElement(phone)

                                        descriptionArray = descriptionArray.plusElement(manufacturer)

                                        descrip = descriptionArray
                                        bridArrayori = bridArrayori.plusElement(brid)
                                        ids = idss
                                        liids = idss
                                        println("Original KEYYYY" + brid)
                                        println("LOGIINNNN KEYYYY" + brorival)


                                        pur_reqlist.visibility = View.VISIBLE
                                        progressBar4.visibility = View.GONE
                                        noresfo.visibility=View.GONE
                                        println("If SAVE KEYYYY" + brorival)
                                        val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                        val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                        wlist.adapter = whatever
                                        /*swipeContainer.setRefreshing(false);*/

                                    } else {
                                        noresfo.visibility = View.VISIBLE
                                        pur_reqlist.visibility = View.GONE
                                        progressBar4.visibility = View.GONE
                                    }


                                }


                            }
                                else {
                                    println("NO RECORDSSSS FOUNDD")

                                    db.collection("${broriky}_Purchase Request").orderBy("req_estimated").startAt(numberstr).endAt(esc)
                                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                if (e != null) {
                                                }
                                                if (value.isEmpty == false) {
                                                    for (document in value) {

                                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                                            println(document.data)
                                                            var dt = document.data
                                                            var brid = (dt["brid"]).toString()



                                                            if (brorival == brid) {
                                                                var id = (document.id)
                                                                idss = idss.plusElement(id)
                                                                iddd.setText(idss.toString())
                                                                println(idss)

                                                                var name = (dt["prod_nms"]).toString()
                                                                try {
                                                                    var imlinks = (dt["imglinks"]).toString()
                                                                    imglinks = imlinks
                                                                    imarray = imarray.plusElement(imglinks)
                                                                } catch (e: Exception) {
                                                                    imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                                                    imarray = imarray.plusElement(imglinks)
                                                                }


                                                                var phone = (dt["supplier_Phone"]).toString()
                                                                var date = (dt["req_date"]).toString()
                                                                var tot = (dt["gross_tot"]).toString()
                                                                var dates = (dt["req_estimated"]).toString()
                                                                try {
                                                                    imArray1 = imarray
                                                                    var sta = (dt["status"]).toString()
                                                                    stag = sta

                                                                    if (sta == "Approved") {
                                                                        descr = "Approved"
                                                                        statusArray1 = statusArray1.plusElement(descr)
                                                                        statusArray = statusArray.plusElement("")
                                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                                        statusArray3cncl = statusArray3cncl.plusElement("")
                                                                        status = statusArray1
                                                                    } else {
                                                                        descr = "Pending"
                                                                        statusArray = statusArray.plusElement(descr)
                                                                        statusArray1 = statusArray1.plusElement("")
                                                                        statusArray2pr = statusArray2pr.plusElement("")
                                                                        statusArray3cncl = statusArray3cncl.plusElement("")
                                                                        status = statusArray
                                                                    }
                                                                } catch (e: Exception) {
                                                                    descr = "Pending"
                                                                    statusArray = statusArray.plusElement(descr)
                                                                    statusArray1 = statusArray1.plusElement("")
                                                                    statusArray2pr = statusArray2pr.plusElement("")
                                                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                                                    status = statusArray
                                                                }
                                                                var manufacturer = (dt["req_id"]).toString()
                                                                text = text.plusElement((dt["supplier_name"]).toString())

                                                                suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                                                nameArray = nameArray.plusElement(name)
                                                                if (dates.isNotEmpty()) {
                                                                    dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                                                } else if (dates.isEmpty()) {
                                                                    dateArray = dateArray.plusElement("Ordered on " + date)

                                                                }
                                                                if (tot.contains(".")) {
                                                                    priceArray = priceArray.plusElement(tot)
                                                                } else if (!tot.contains(".")) {
                                                                    priceArray = priceArray.plusElement(tot + ".00")

                                                                }
                                                                nameArrayori = text
                                                                supplierkeyori=suppkeyarr
                                                                dateArrayori = dateArray
                                                                priceArrayori = priceArray
                                                                datearr = datearr.plusElement(date)
                                                                datesarr = datesarr.plusElement(dates)
                                                                phoneArrayori = phoneArrayori.plusElement(phone)

                                                                descriptionArray = descriptionArray.plusElement(manufacturer)

                                                                descrip = descriptionArray
                                                                bridArrayori = bridArrayori.plusElement(brid)
                                                                ids = idss
                                                                liids = idss
                                                                println("Original KEYYYY" + brid)
                                                                println("LOGIINNNN KEYYYY" + brorival)
                                                                brorival = broriky
                                                                pur_reqlist.visibility = View.VISIBLE
                                                                progressBar4.visibility = View.GONE
                                                                noresfo.visibility = View.GONE
                                                                println("If SAVE KEYYYY" + brorival)
                                                                val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                                                                val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                                                wlist.adapter = whatever
                                                                /*    swipeContainer.setRefreshing(false);*/

                                                            } else {
                                                                noresfo.visibility = View.VISIBLE
                                                                pur_reqlist.visibility = View.GONE
                                                                progressBar4.visibility = View.GONE
                                                            }


                                                        }
                                                    }
                                                    else{
                                                        noresfo.visibility = View.VISIBLE
                                                        pur_reqlist.visibility = View.GONE
                                                        progressBar4.visibility = View.GONE
                                                    }

                                            })

                            }



                    })

        }
        else{
            println("startlist error")
            noresfo.visibility = View.VISIBLE
            pur_reqlist.visibility = View.GONE
            progressBar4.visibility = View.GONE
        }
    }


    fun idget() {
        println("d get idget")
        if ((s.length >= 3) && (x != reg)) {

            var text = arrayOf<String>()
            var suppkeyarr = arrayOf<String>()

            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var descriptionArray = arrayOf<String>()
            var statusArray = arrayOf<String>()
            var statusArray1 = arrayOf<String>()
            var imArray1 = arrayOf<String>()
            var statusArray2pr=arrayOf<String>()
            var statusArray3cncl=arrayOf<String>()
            db.collection("${broriky}_Purchase Request").orderBy("req_id").startAt(upstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)

                                    var dt = document.data
                                    var id = (document.id)
                                    idss = idss.plusElement(id)
                                    iddd.setText(idss.toString())
                                    println(idss)

                                    var name = (dt["prod_nms"]).toString()
                                    var brid = (dt["brid"]).toString()
                                    try {
                                        var imlinks = (dt["imglinks"]).toString()
                                        imglinks = imlinks
                                        imarray = imarray.plusElement(imglinks)
                                    } catch (e: Exception) {
                                        imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                                        imarray = imarray.plusElement(imglinks)
                                    }


                                    var phone = (dt["supplier_Phone"]).toString()
                                    var date = (dt["req_date"]).toString()
                                    var tot = (dt["gross_tot"]).toString()
                                    var dates = (dt["req_estimated"]).toString()
                                    try {
                                        imArray1 = imArray1.plusElement("")
                                        var sta = (dt["status"]).toString()
                                        stag = sta

                                        if (sta == "Approved") {
                                            descr = "Approved"
                                            statusArray1 = statusArray1.plusElement(descr)
                                            statusArray = statusArray.plusElement("")
                                             statusArray2pr=statusArray2pr.plusElement("")
                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                            status = statusArray1
                                        } else {
                                            descr = "Pending"
                                            statusArray = statusArray.plusElement(descr)
                                            statusArray1 = statusArray1.plusElement("")
                                            statusArray2pr=statusArray2pr.plusElement("")
                                            statusArray3cncl=statusArray3cncl.plusElement("")
                                            status = statusArray
                                        }
                                    } catch (e: Exception) {
                                        descr = "Pending"
                                        statusArray = statusArray.plusElement(descr)
                                        statusArray1 = statusArray1.plusElement("")
                                        statusArray2pr=statusArray2pr.plusElement("")
                                        statusArray3cncl=statusArray3cncl.plusElement("")
                                        status = statusArray
                                    }
                                    var manufacturer = (dt["req_id"]).toString()
                                    text = text.plusElement((dt["supplier_name"]).toString())
                                    suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                                    nameArray = nameArray.plusElement(name)
                                    if(dates.isNotEmpty()){
                                        dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                                    }
                                    else if(dates.isEmpty()){
                                        dateArray = dateArray.plusElement("Ordered on " + date)

                                    }
                                    if(tot.contains(".")){
                                        priceArray = priceArray.plusElement(tot)
                                    }
                                    else if(!tot.contains(".")){
                                        priceArray = priceArray.plusElement(tot+".00")

                                    }
                                    nameArrayori = text
                                    supplierkeyori=suppkeyarr
                                    dateArrayori = dateArray
                                    priceArrayori = priceArray
                                    datearr = datearr.plusElement(date)
                                    datesarr = datesarr.plusElement(dates)
                                    phoneArrayori = phoneArrayori.plusElement(phone)

                                    descriptionArray = descriptionArray.plusElement(manufacturer)

                                    descrip = descriptionArray
                                    bridArrayori = bridArrayori.plusElement(brid)
                                    ids = idss
                                    liids = idss
                                    println("Original KEYYYY" + brid)
                                    println("LOGIINNNN KEYYYY" + brorival)
                                    brorival = broriky

                                    if (brorival == brid) {
                                        pur_reqlist.visibility = View.VISIBLE
                                        progressBar4.visibility = View.GONE
                                        println("If SAVE KEYYYY" + brorival)
                                        val whatever = req_search_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1,statusArray2pr,statusArray3cncl)
                                        val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                                        wlist.adapter = whatever
                                 /*       swipeContainer.setRefreshing(false);*/

                                    } else {
                                        noresfo.visibility = View.VISIBLE
                                        pur_reqlist.visibility = View.GONE
                                        progressBar4.visibility = View.GONE

                                    }

                                }


                            } else {
                                println("NO RECORDSSSS FOUNDD")
                                dateget()


                                noresfo.visibility = View.VISIBLE
                                pur_reqlist.visibility = View.GONE
                                progressBar4.visibility = View.GONE
                            }



                    })

        }
        else{
            noresfo.visibility = View.VISIBLE
            pur_reqlist.visibility = View.GONE
            progressBar4.visibility = View.GONE
        }


    }

    fun popup(st: String) {
        val pop = AlertDialog.Builder(this)
        pop.create()
        val title = TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50, 20, 20, 20)
        title.textSize = 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }


    //------------------------------Back action------------------------//
    override fun onBackPressed() {

        if (cardsearch.visibility == View.VISIBLE) {

            cardsearch.visibility = View.GONE
            noresfo.visibility=View.INVISIBLE
            pur_reqlist.visibility=View.VISIBLE
            progressBar4.visibility=View.GONE
            searchedit.setText("")
            act()


        } else {
            val k = Intent(this, MainPurchasefirstActivity::class.java)

            k.putExtra("skey", broriky)
            k.putExtra("viewsuppin", viewsuppin)
            k.putExtra("addsuppin", addsuppin)
            k.putExtra("deletesuppin", deletesuppin)
            k.putExtra("editsuppin", editesuppin)
            k.putExtra("transfersuppin", transfersuppin)
            k.putExtra("exportsuppin", exportsuppin)


            k.putExtra("viewpurord", viewpurord)
            k.putExtra("addpurord", addpurord)
            k.putExtra("deletepurord", deletepurord)
            k.putExtra("editpurord", editepurord)
            k.putExtra("transferpurord", transferpurord)
            k.putExtra("exportpurord", exportpurord)
            k.putExtra("sendpurord", sendpurpo)




            k.putExtra("viewpurreq", viewpurreq)
            k.putExtra("addpurreq", addpurreq)
            k.putExtra("deletepurreq", deletepurreq)
            k.putExtra("editpurreq", editepurreq)
            k.putExtra("transferpurreq", transferpurreq)
            k.putExtra("exportpurreq", exportpurreq)




            startActivity(k)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
    }




    //-----------------------------Get and list the purchase request details from db--------------//

    fun act() {
        progressBar45.visibility=View.VISIBLE
        brorival = broriky
        println("OR KEYS DUDE"+brorival)

        db.collection("${broriky}_Purchase Request").whereEqualTo("brid", brorival)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                    if (e != null) {
                        Log.w("", "Listen failed.", e)
                        return@EventListener
                    }
                    if (value.isEmpty == false) {

try {
    db.collection("${broriky}_Purchase Request").orderBy("req_id", Query.Direction.DESCENDING).whereEqualTo("brid", brorival).limit(15)
            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                var text = arrayOf<String>()
                var suppkeyarr = arrayOf<String>()

                var idss = arrayOf<String>()
                var nameArray = arrayOf<String>()
                var dateArray = arrayOf<String>()
                var priceArray = arrayOf<String>()
                var descriptionArray = arrayOf<String>()
                var statusArray = arrayOf<String>()
                var statusArray1 = arrayOf<String>()
                var imArray1 = arrayOf<String>()

                var statusArray2pr = arrayOf<String>()
                var statusArray3cncl = arrayOf<String>()



                if (e != null) {
                    Log.w("", "Listen failed.", e)
                    return@EventListener
                }
                if (value.isEmpty == false) {
                    imageView10.visibility = View.GONE
                    for (document in value) {

                        println("ELSE ")

                        Log.d("d", "key --- " + document.id + " => " + document.data)
                        println(document.data)

                        var dt = document.data
                        var id = (document.id)
                        idss = idss.plusElement(id)
                        iddd.setText(idss.toString())
                        println(idss)

                        var name = (dt["prod_nms"]).toString()
                        var brid = (dt["brid"]).toString()
                        try {
                            var imlinks = (dt["imglinks"]).toString()
                            imglinks = imlinks
                            imarray = imarray.plusElement(imglinks)
                        } catch (e: Exception) {
                            imglinks = "https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/WmvM0.png?alt=media&token=30068b17-1289-4f00-9b7f-d7e0246cf53a"
                            imarray = imarray.plusElement(imglinks)
                        }

                        var phone = (dt["supplier_Phone"]).toString()
                        var date = (dt["req_date"]).toString()
                        var tot = (dt["gross_tot"]).toString()



                        var dates = (dt["req_estimated"]).toString()
                        try {
                            imArray1 = imarray
                            var sta = (dt["status"]).toString()
                            stag = sta

                            if (sta.isNotEmpty()) {

                                println("STA NOT EMPTY" + sta)
                                if (sta == "Approved") {
                                    descr = "Approved"
                                    statusArray1 = statusArray1.plusElement(descr)
                                    statusArray = statusArray.plusElement("")
                                    statusArray2pr = statusArray2pr.plusElement("")
                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                    status = status.plusElement(descr)
                                } else {
                                    descr = "Pending"
                                    statusArray = statusArray.plusElement(descr)
                                    statusArray1 = statusArray1.plusElement("")
                                    statusArray2pr = statusArray2pr.plusElement("")
                                    statusArray3cncl = statusArray3cncl.plusElement("")
                                    status = status.plusElement(descr)
                                }

                            } else {
                                println("STA  EMPTY" + sta)
                                descr = "Pending"
                                statusArray = statusArray.plusElement(descr)
                                statusArray1 = statusArray1.plusElement("")
                                statusArray2pr = statusArray2pr.plusElement("")
                                statusArray3cncl = statusArray3cncl.plusElement("")
                                status = status.plusElement(descr)
                                println("ONTIME STATUS VIEW ELSE" + status)
                            }
                        } catch (e: Exception) {
                            descr = "Pending"
                            statusArray = statusArray.plusElement(descr)
                            statusArray1 = statusArray1.plusElement("")
                            statusArray2pr = statusArray2pr.plusElement("")
                            statusArray3cncl = statusArray3cncl.plusElement("")
                            status = status.plusElement(descr)
                            println("ONTIME STATUS VIEW CATCH" + status)
                        }
                        var manufacturer = (dt["req_id"]).toString()
                        text = text.plusElement((dt["supplier_name"]).toString())
                        suppkeyarr = suppkeyarr.plusElement((dt["supplier_Key"]).toString())

                        nameArray = nameArray.plusElement(name)

                        if(dates.isNotEmpty()){
                            dateArray = dateArray.plusElement("Ordered on " + date + ", Required on " + dates)

                        }
                        else if(dates.isEmpty()){
                            dateArray = dateArray.plusElement("Ordered on " + date)

                        }


                        if(tot.contains(".")){
                            priceArray = priceArray.plusElement(tot)
                        }
                        else if(!tot.contains(".")){
                            priceArray = priceArray.plusElement(tot+".00")

                        }

                        nameArrayori = text
                        supplierkeyori=suppkeyarr
                        dateArrayori = dateArray
                        priceArrayori = priceArray
                        datearr = datearr.plusElement(date)
                        datesarr = datesarr.plusElement(dates)
                        phoneArrayori = phoneArrayori.plusElement(phone)

                        descriptionArray = descriptionArray.plusElement(manufacturer)

                        descrip = descriptionArray
                        bridArrayori = bridArrayori.plusElement(brid)
                        ids = idss
                        liids = idss
                        println("Original KEYYYY" + brid)
                        println("LOGIINNNN KEYYYY" + brorival)
                        brorival = broriky


                    }


                    /*  if(brorival==brid) {*/
                    println("If SAVE KEYYYY" + brorival)

                    nameArray = nameArray.plusElement("")
                    imArray1 = imArray1.plusElement("")
                    idss = idss.plusElement("")
                    text = text.plusElement("")
                    dateArray = dateArray.plusElement("")
                    descriptionArray = descriptionArray.plusElement("")
                    priceArray = priceArray.plusElement("NA")
                    statusArray = statusArray.plusElement("")
                    statusArray1 = statusArray1.plusElement("")
                    statusArray2pr = statusArray2pr.plusElement("")
                    statusArray3cncl = statusArray3cncl.plusElement("")

                    progressBar45.visibility=View.GONE
                    val whatever = purchase_list_adap(this@PurchaseRequestActivity, imArray1, idss, text, nameArray, dateArray, descriptionArray, priceArray, statusArray, statusArray1, statusArray2pr, statusArray3cncl)
                    val wlist = findViewById<ListView>(R.id.pur_reqlist) as ListView
                    wlist.adapter = whatever
                    /*       swipeContainer.setRefreshing(false);*/
                } else {

                    progressBar45.visibility=View.GONE
                    imageView10.visibility = View.VISIBLE
                }

                /*  }*/
                /* else
                        {

                        }*/

            })
}
catch (e:Exception){
    Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
}
                    } else {
                        println("INSIDE ELSE")
                        imageView10.visibility = View.VISIBLE
                        progressBar45.visibility=View.GONE
                    }
                })

    }

    companion object {

 //Listens internet status whether net is on/off.

        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                 /// if connection is off then all views becomes disable

                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                                 /// if connection is off then all views becomes enabled

                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }
    fun net_status():Boolean{        //Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
