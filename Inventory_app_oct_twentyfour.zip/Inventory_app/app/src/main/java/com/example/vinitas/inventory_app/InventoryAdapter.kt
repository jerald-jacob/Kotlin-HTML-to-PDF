package com.example.vinitas.inventory_app

import android.app.Activity
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView

class InventoryAdapter(//to reference the Activity
private val context: Activity, //to store the list of countries
private val nameArray: Array<String>, //to store the list of countries
private val infoArray: Array<String>, //to store the animal images
private val imageIDarray: Array<Int>) : ArrayAdapter<Any>(context, R.layout.activity_inventory_adapter, nameArray) {

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.activity_inventory_adapter, null, true)

        //this code gets references to objects in the listview_row.xml file


        val imageView = rowView.findViewById<View>(R.id.imageView) as ImageView

        //this code sets the values of the objects to values from the arrays
        //nameTextField.text = nameArray[position]
        //infoTextField.text = infoArray[position]
        imageView.setImageResource(imageIDarray[position])

        return rowView

    }
}