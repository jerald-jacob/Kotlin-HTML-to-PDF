package com.example.vinitas.inventory_app

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.v7.app.AlertDialog
import android.view.View
import android.view.ViewTreeObserver
import android.widget.ImageView
import android.widget.Toast
import com.squareup.picasso.Picasso
import dmax.dialog.SpotsDialog
import kotlinx.android.synthetic.main.activity_zoom_service.*
import java.io.File
import java.io.FileOutputStream
import java.util.*

class ZoomService : AppCompatActivity() {

    var frms= Any()
    var wid:Float=0F
    var hei:Float=0F

    private val imageView: ImageView? = null

    private var strURL = String()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_zoom_service)
        var froms= String()


        val bundle = intent.extras
        try {
            var frm = bundle!!.get("im").toString()
            froms=frm
        }
        catch(e:Exception){

        }


        var zoomLayout = findViewById<View>(R.id.zoom_layout) as ZoomLayout

    /*    zoom_layout.setOnTouchListener(object : View.OnTouchListener{

            override fun onTouch(v:View ,event: MotionEvent ): Boolean {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    if (actionBar.isShowing()) {

                    } else {




                    }
                    return true;
                } else return false;
            }
        });*/


  /*      zoom_layout.setOnTouchListener { view, motionEvent ->
            if(userback.visibility==View.VISIBLE) {
                userback.visibility = View.GONE
                imageButton.visibility = View.GONE
                comttname.visibility=View.GONE
                true
            }
            else{
                userback.visibility = View.VISIBLE
                imageButton.visibility = View.VISIBLE
                comttname.visibility = View.VISIBLE
                true
            }
        }*/




        val vto = zoomLayout.getViewTreeObserver()
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                zoomLayout.getViewTreeObserver().removeOnGlobalLayoutListener(this)
                val width = zoomLayout.getMeasuredWidth()
                val height = zoomLayout.getMeasuredHeight()
                wid=width.toFloat()
                hei=height.toFloat()
                zoomLayout.setContentSize(width.toFloat(), height.toFloat())
                println("WIDTH"+wid)
                println("HEIGHT"+height)


            }

        })











        if(froms=="image") {

            progressBar13.visibility=View.VISIBLE



            val b = intent.getStringExtra("drawb")
            println("B CACHE PATHB CACHE PATH"+b)

           Picasso.with(this)
                   .load(b)
                   .into(imgview)
            progressBar13.visibility=View.GONE




        /*    val extras = intent.extras
            val b = intent.getParcelableExtra<Bitmap>("drawb")
            val k = intent.getStringExtra("url")
            imgview.setImageBitmap(b)
            try {
                Picasso.with(this)
                        .load(k)
                        .into(imgview)
            }
            catch (e:Exception){

            }*/
            /*val bmp = BitmapFactory.decodeByteArray(b, 0, b!!.size)*/




       /*     val bmp = BitmapFactory.decodeByteArray(b, 0, b!!.size)*/
          /*  val bmp = BitmapFactory.decodeByteArray(b, 0, b!!.size)
            val drawable = BitmapDrawable(resources, bmp)*/


        }

        else if(froms=="imageadap"){

             progressBar13.visibility=View.VISIBLE
            val b = intent.getStringExtra("drawb")
            val nameser=intent.getStringExtra("nameser")
            comttname.setText(nameser)
            println("B CACHE PATHB CACHE PATH ADAp"+b)

            try {
                Picasso.with(this)
                        .load(b)
                        .into(imgview)
            progressBar13.visibility=View.GONE


            }
            catch (e:Exception){
                Picasso.with(this)
                        .load("https://firebasestorage.googleapis.com/v0/b/alfahybrid-546c6.appspot.com/o/noimage1.png?alt=media&token=99759642-fad8-4d2d-8f8f-cc0d71e9e063")
                        .into(imgview)
                progressBar13.visibility=View.GONE

            }
        }



        imageButton.setOnClickListener {


            if (net_status() == true) {

                var smill=System.currentTimeMillis().toString()
                var y="Bill_$smill"+".jpg"
                val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Invoice Bill"
                val dir =  File(path);
                if(!dir.exists())
                    dir.mkdirs();
                val file = File(dir,y);

                val dialo =  SpotsDialog(this,"Downloading image...");

                dialo.show();

                val timer2 = Timer()
                timer2.schedule(object : TimerTask() {
                    override fun run() {


                        val time = System.currentTimeMillis()
                        val drawable = imgview.drawable
                        val bitmap = (drawable as BitmapDrawable).bitmap


                        try {



                            val fOut =  FileOutputStream(file);

                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
                            fOut.flush();
                            fOut.close();
                            dialo.dismiss()
                            val savedImageURI = Uri.parse(file.absolutePath)

                            // Display the saved image to ImageView


                            // Display saved image uri to TextView
                            Toast.makeText(applicationContext, "Image Saved to:\n$savedImageURI", Toast.LENGTH_LONG).show()

                        } catch (e:Exception) {


                        }



                    }
                }, 3000)

                val handler = Handler()
                handler.postDelayed({

                    if(file.exists()) {
                        val builder = AlertDialog.Builder(this@ZoomService)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->


                                var s = smill

                                var y = "Bill_$s"+".jpg"
                                viewPdf("Invoice Bill", y)

                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }
                    else{

                    }
                }, 4000)
            }
            else{
                Toast.makeText(applicationContext, "Please check your connection", Toast.LENGTH_LONG).show()

            }


        }




        userback.setOnClickListener {
            onBackPressed()
        }

    }




    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }



    fun viewPdf(folder:String,file:String) {

        val pdfFile =  File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+folder,file)
        println("SD CARD URL"+pdfFile)
        val path = Uri.fromFile(pdfFile);

        // Setting the intent for pdf reader
        val pdfIntent = Intent(Intent.ACTION_VIEW)
        pdfIntent.setDataAndType(path, "image/jpeg")
        pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

        try {
            startActivity(pdfIntent);
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(applicationContext, "Can't open imge", Toast.LENGTH_SHORT).show();
        }
    }





}
