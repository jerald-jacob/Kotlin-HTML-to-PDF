package com.example.vinitas.inventory_app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView

/**
 * Created by vinitas stock on 03-01-2018.
 */
class withstateAdapter(
        private val context: Activity,
        private val ori: Array<String>,
        private val desti: Array<String>,
        private val descrip: Array<String>,
        private val amo: Array<String>,
        private val description: Array<String>,
          private val listids: Array<String>,
        private val brids: Array<String>) : ArrayAdapter<Any>(context, R.layout.withstate_list, ori) {
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.withstate_list, null, true)

        //this code gets references to objects in the listview_row.xml file
        val origin = rowView.findViewById<TextView>(R.id.origin) as TextView
        val destination = rowView.findViewById<TextView>(R.id.desti) as TextView
        val desc = rowView.findViewById<TextView>(R.id.desc) as TextView
        val amount = rowView.findViewById<TextView>(R.id.textView8) as TextView
        val descriptext = rowView.findViewById<TextView>(R.id.descriptiontext) as TextView
        val listidtext = rowView.findViewById<TextView>(R.id.liids) as TextView
        val bridtext = rowView.findViewById<TextView>(R.id.brid) as TextView


        //this code sets the values of the objects to values from the arrays
        origin.text = ori[position]
        destination.text = desti[position]
        desc.text = descrip[position]
        amount.text = amo[position]
        descriptext.text=description[position]
        listidtext.text=listids[position]
        bridtext.text=brids[position]




        //infoTextField.text = infoArray[position]
        //imageView.setImageResource(imageIDarray[position])

        return rowView

    }
}