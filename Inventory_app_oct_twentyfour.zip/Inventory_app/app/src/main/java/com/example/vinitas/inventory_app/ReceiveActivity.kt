package com.example.vinitas.inventory_app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.app.NotificationCompat
import android.support.v4.content.ContextCompat
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.QuerySnapshot

import kotlinx.android.synthetic.main.activity_receive.*
import java.text.SimpleDateFormat
import java.util.*

class ReceiveActivity : AppCompatActivity() {


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    internal lateinit var session: SessionManagement
    val TAG = "some"
    var db = FirebaseFirestore.getInstance()
    var ids= arrayOf<String>()

    var brids= String()
    var tallys= String()
    var brname=arrayOf<String>()
    var braddress=arrayOf<String>()

    var liids= arrayOf<String>()
    var nameArrayori= arrayOf<String>()
    var dateArrayori= arrayOf<String>()
    var stockidArrayori= arrayOf<String>()
    var priceArrayori= arrayOf<String>()
    var rec_onori= arrayOf<String>()
    var rec_oncount= arrayOf<String>()
    var fromr= String()
    var esc= String()
    var s = String()
    var upstr= String()
    var numberstr= String()
    var oriid= String()
    var orgval= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()
    var supkyval= String()
    var bsupkyval= String()
    var origisearch= arrayOf<String>()

    var origid= String()

    var orignm=String()

    var supkyarray= arrayOf<String>()
    var bsupkykyarray= arrayOf<String>()

    var descrip=arrayOf<String>()
    var tallyori=arrayOf<String>()


    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""


    var sd= String()
    var x= String()
    var reg= String()
    var tallystatus = String()
    var datearr = arrayOf<String>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_receive)


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@ReceiveActivity) > 0)
        {

        }
        else{

        }



        //Define No connection view when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.containrec)

        addLogText(NetworkUtil.getConnectivityStatusString(this@ReceiveActivity))

        net_status()        //Check internet status


try {
    val bundleq = intent.extras
    var frm = bundleq!!.get("from_rec").toString()
    fromr=frm
}
catch (e:Exception){

}




        rsearch.setOnClickListener {    //Image button search  action
            cardsearch.visibility= View.VISIBLE
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@ReceiveActivity,R.anim.slide_to_right))
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }



        rback.setOnClickListener {
           onBackPressed()
        }


        imageButton2.setOnClickListener({       //Vert menu contains 'Logout' option.


            val popup = PopupMenu(this@ReceiveActivity, imageButton2)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                if (item.title == "Logout") {    //Navigate to pin activity

                    if(net_status()==true) {
                        Toast.makeText(this@ReceiveActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                        val f = Intent(this@ReceiveActivity, PinActivity::class.java)
                        startActivity(f)
                        finish()
                    }
                    else{
                        Toast.makeText(applicationContext, "You're offline", Toast.LENGTH_SHORT).show()

                    }
                }
                true
            }

            popup.show()
        })


        session = SessionManagement(applicationContext)



        var bundle = intent.getStringExtra("from")
        var bundl = intent.getStringExtra("tally")


        /*if(bundle=="Main"){*/


        var currentdate = String()

        val c = Calendar.getInstance()
        System.out.println("Current time =&gt; " + c.time)

        val df = SimpleDateFormat("dd/MM/yyyy")
        val formattedDate = df.format(c.time)
        currentdate = formattedDate

        session.checkLogin()

        // get user data from session
        val user = session.userDetails

        // name
        val namesss = user[SessionManagement.KEY_NAME]
        brids=namesss.toString()


        try {

            println("RECEIVE ID" + brids)
            origid = brids
            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }



        }
        catch (e:Exception){

        }

        println("STATE ACTIVITY KEYSSS"+oriid)
        println("ADD STARTING"+addrec)






        db.collection("${brids}_Receive Stock").whereEqualTo("stk_brid", brids)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->




                    if(value.isEmpty==false) {
                        db.collection("branch").document(brids)
                                .get()
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        if (task.result != null) {
                                            var document=task.result
                                            origid=document.id
                                            Log.d("data", "is" + task.result.data)
                                            var orig = document.get("nm").toString()
                                            orgval=orig

                                            println("VALUE OF ORIGIN IDDD "+orgval)
                                        } else {
                                            Log.d("data", "is not here")
                                        }
                                    } else {
                                        Log.d("task is not success", "full" + task.exception)
                                    }

                                }

                        gets()
                    }
                    else{
                        imageView10.visibility=View.VISIBLE
                    }
                })




    /*    swipeContainer.setOnRefreshListener {

            db.collection("Receive Stock").whereEqualTo("stk_brid", brids)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if(value.isEmpty==false) {
                            gets()
                        }
                        else{
                            imageView10.visibility=View.VISIBLE
                        }
                    })

        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.tool,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/



        /* if(bundl==tal.text.toString()){
            val name = intent.getStringExtra("tally")
            tallys=name
             println("TALLY ARRAYYYYY"+tallys)
             var currentdate= String()

             val c = Calendar.getInstance()
             System.out.println("Current time =&gt; " + c.time)

             val df = SimpleDateFormat("dd/MM/yyyy")
             val formattedDate = df.format(c.time)
             currentdate=formattedDate

             brids="vTUHrlFR0QwpJaeKhkzM"

             db.collection("Receive Stock").whereEqualTo("stk_brid",brids)
                     .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                         var text=arrayOf<String>()
                         var idss= arrayOf<String>()
                         var nameArray = arrayOf<String>()
                         var stockidArray = arrayOf<String>()
                         var dateArray = arrayOf<String>()
                         var priceArray = arrayOf<String>()
                         var  tallyArray= arrayOf<String>()
                         var  talliedArray= arrayOf<String>()





                         if (e != null) {
                             Log.w("", "Listen failed.", e)
                             return@EventListener
                         }

                         for (document in value) {

                             Log.d("d", "key --- " + document.id + " => " + document.data)
                             println(document.data)

                             var dt = document.data
                             var id = (document.id)
                             idss=idss.plusElement(id)
                             println(idss)

                             *//*  idss=idss.plusElement(path)
                               i=idss
                               println(id)
                               println(i)*//*

                             var name = (dt["stk_Desc"]).toString()
                             var date = (dt["stkdate"]).toString()
                             var tot=(dt["stk_total"]).toString()

                             var manufacturer = (dt["stkid"]).toString()
                             var rec_on = (dt["Receive_date"]).toString()
                             var brnm = (dt["stk_destination"]).toString()
                             var rec_count = (dt["Receive_count"]).toString()
                             text = text.plusElement("K.K.Nagar - 1001,Madurai")
                             nameArray = nameArray.plusElement(name)
                             dateArray = dateArray.plusElement("Dated" + date + ". Stock received on" + rec_on)
                             stockidArray=stockidArray.plusElement("Stock transfer No - ST100"+manufacturer)
                             priceArray=priceArray.plusElement(tot)
                             nameArrayori = nameArrayori.plusElement(name)
                             rec_oncount=rec_oncount.plusElement(rec_count)
                             dateArrayori = dateArray
                             priceArrayori = priceArray
                             datearr=datearr.plusElement(date)
                             tallyori=talliedArray
                             rec_onori=rec_onori.plusElement(rec_on)
                             descrip= tallyArray
                             stockidArrayori=stockidArray
                             ids=ids.plusElement(manufacturer)
                             liids=idss
                             brname=brname.plusElement(brnm)

                            if(tallys.equals("Not tallied")) {
                                tallyArray = tallyArray.plusElement("Not tallied")
                                talliedArray = talliedArray.plusElement("")
                            }
                             else
                            {
                                tallyArray = tallyArray.plusElement("")
                                talliedArray = talliedArray.plusElement("Tallied")
                            }
                             *//*   talliedArray=talliedArray.plusElement("Tallied")*//**//*
                                tallyArray= tallyArray.plusElement("")*//*






                         }
                         val whatever = receiveAdapter(this,idss,text,nameArray,dateArray,stockidArray,tallyArray,talliedArray,priceArray)
                         val rlist = findViewById<ListView>(R.id.rlist) as ListView
                         rlist.adapter = whatever


                     })
        }*/



    /*    db.collection("Branches")
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                    if (e != null) {
                        Log.w("", "Listen failed.", e)
                        return@EventListener
                    }

                    for (document in value) {

                        Log.d("d", "key --- " + document.id + " => " + document.data)
                        println(document.data)

                        var dt = document.data
                        var id = (document.id)
                        brids=id
                        println(brids)


                    }
                })*/






        if(fromr=="recsave"){
            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi=intent.getStringExtra("viewtrans")
            val tran=intent.getStringExtra("transfertrans")
            val ex=intent.getStringExtra("exporttrans")
            sendtrans=intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER"+addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano=intent.getStringExtra("viewtransano")
            val tranano=intent.getStringExtra("transfertransano")
            val exano=intent.getStringExtra("exporttransano")
            sendtransano=intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec=intent.getStringExtra("viewrec")
            val tranrec=intent.getStringExtra("transferrec")
            val exrec=intent.getStringExtra("exportrec")
            val sendrec=intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }




        }


        //----------------------------Search------------------------------------//

        searchedit.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                progressBar7.visibility=View.VISIBLE
                rlist.visibility=View.GONE

                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                val ps = "^[a-zA-Z ]+$"


                val datev = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$"

                println("TYPED VALUED" + x)

                if (x.trim().matches(datev.toRegex())) {
                    upstr = x
                    println("CAME INTO DATE NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr

                    regtr = "num"
                    dateget()


                }
                fun dateget() {
                    if ((s.length>=2)||(s.length>=2)) {
                        noresfo.visibility = View.GONE
                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var stockidArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var tallyArray = arrayOf<String>()
                        var talliedArray = arrayOf<String>()

                        db.collection("${brids}_Receive Stock").orderBy("stkdate").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var orid = (dt["stk_brid"]).toString()


                                                if (brids == orid) {


                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    println(idss)

                                                    /*  idss=idss.plusElement(path)
                                                          i=idss
                                                          println(id)
                                                          println(i)*/

                                                    var name = (dt["stk_Desc"]).toString()
                                                    var date = (dt["stkdate"]).toString()
                                                    var tot = (dt["stk_total"]).toString()


                                                    var manufacturer = (dt["stkid"]).toString()
                                                    var brnm = (dt["stk_destination"]).toString()
                                                    var braddr=(dt["stk_address"]).toString()

                                                    var rec_on = (dt["Receive_date"]).toString()
                                                    var rec_count = (dt["Receive_count"]).toString()
                                                    var status = (dt["Status"]).toString()
                                                    tallystatus = status
                                                    var orinm=(dt["stk_originname"]).toString()
                                                    orignm=orinm
                                                    text = text.plusElement("Origin: " + orignm)

                                                    text = text.plusElement("Origin: "+orgval)
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                                                    stockidArray = stockidArray.plusElement("Stock transfer No - "+manufacturer)
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = nameArrayori.plusElement(name)
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    tallyori = talliedArray
                                                    rec_onori = rec_onori.plusElement(rec_on)
                                                    rec_oncount = rec_oncount.plusElement(rec_count)

                                                    descrip = tallyArray
                                                    stockidArrayori = stockidArray
                                                    ids = ids.plusElement(manufacturer)
                                                    liids = idss
                                                    brname = brname.plusElement(brnm)
braddress=braddress.plusElement(braddr)

                                                    if (tallystatus.equals("Not Tallied")) {
                                                        tallyArray = tallyArray.plusElement("Not Tallied")
                                                        talliedArray = talliedArray.plusElement("")
                                                    } else {
                                                        tallyArray = tallyArray.plusElement("")
                                                        talliedArray = talliedArray.plusElement("Tallied")
                                                    }
                                                    origisearch = origisearch.plusElement(orid)


                                                    rlist.visibility=View.VISIBLE
                                                    progressBar7.visibility=View.GONE
                                                    noresfo.visibility = View.GONE
                                                    println("SAVE KEYYYY" + brids)
                                                    val whatever = receiveAdapter(this@ReceiveActivity, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                                                    val rlist = findViewById<ListView>(R.id.rlist) as ListView
                                                    rlist.adapter = whatever
                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    rlist.visibility = View.GONE
                                                    progressBar7.visibility=View.GONE

                                                }

                                            }

                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + brids)



                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            noresfo.visibility=View.VISIBLE
                                            rlist.visibility=View.GONE
                                            progressBar7.visibility=View.GONE
                                        }


                                    /*} else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                    }

                fun priget() {
                    if (s.length >= 2) {
                        noresfo.visibility=View.GONE


                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var stockidArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var tallyArray = arrayOf<String>()
                        var talliedArray = arrayOf<String>()

                        db.collection("${brids}_Receive Stock").orderBy("stk_total").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var orid = (dt["stk_brid"]).toString()

                                                if (brids == orid) {
                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    println(idss)

                                                    /*  idss=idss.plusElement(path)
                                                          i=idss
                                                          println(id)
                                                          println(i)*/

                                                    var name = (dt["stk_Desc"]).toString()
                                                    var date = (dt["stkdate"]).toString()
                                                    var tot = (dt["stk_total"]).toString()


                                                    var manufacturer = (dt["stkid"]).toString()
                                                    var brnm = (dt["stk_destination"]).toString()

                                                    var braddr=(dt["stk_address"]).toString()




                                                    var rec_on = (dt["Receive_date"]).toString()
                                                    var rec_count = (dt["Receive_count"]).toString()
                                                    var status = (dt["Status"]).toString()
                                                    tallystatus = status
                                                    var orinm=(dt["stk_originname"]).toString()
                                                    orignm=orinm
                                                    text = text.plusElement("Origin: " + orignm)

                                                    text = text.plusElement("Origin: "+orgval)
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                                                    stockidArray = stockidArray.plusElement("Stock transfer No - "+manufacturer)
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = nameArrayori.plusElement(name)
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    tallyori = talliedArray
                                                    rec_onori = rec_onori.plusElement(rec_on)
                                                    rec_oncount = rec_oncount.plusElement(rec_count)

                                                    descrip = tallyArray
                                                    stockidArrayori = stockidArray
                                                    ids = ids.plusElement(manufacturer)
                                                    liids = idss
                                                    brname = brname.plusElement(brnm)
                                                    braddress=braddress.plusElement(braddr)

                                                    if (tallystatus.equals("Not Tallied")) {
                                                        tallyArray = tallyArray.plusElement("Not Tallied")
                                                        talliedArray = talliedArray.plusElement("")
                                                    } else {
                                                        tallyArray = tallyArray.plusElement("")
                                                        talliedArray = talliedArray.plusElement("Tallied")
                                                    }
                                                    origisearch = origisearch.plusElement(orid)
                                                    rlist.visibility=View.VISIBLE
                                                    progressBar7.visibility=View.GONE
                                                    noresfo.visibility = View.GONE
                                                    println("SAVE KEYYYY" + brids)
                                                    val whatever = receiveAdapter(this@ReceiveActivity, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                                                    val rlist = findViewById<ListView>(R.id.rlist) as ListView
                                                    rlist.adapter = whatever
                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    rlist.visibility = View.GONE
                                                    progressBar7.visibility=View.GONE

                                                }


                                            }

                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + brids)



                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            dateget()
                                        }


                                   /* } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                }



                if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER" + upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr = upstr
                    regtr = "num"
                    priget()

                    //write code here for success
                }
                if ((x != reg)&&(!s.contains("/"))) {
                    val upperString = x.toUpperCase()
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("CAME INTO NUMBER upper string" + upstr)
                    println("STRINGSSSS" + upstr)

                }
                else if(s.contains("/")){
                    dateget()
                }
                fun nameget() {

                    println("d get name")
                    if ((s.length >= 3) && (x != reg)) {
                        noresfo.visibility=View.GONE


                        var text = arrayOf<String>()
                        var idss = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        var stockidArray = arrayOf<String>()
                        var dateArray = arrayOf<String>()
                        var priceArray = arrayOf<String>()
                        var tallyArray = arrayOf<String>()
                        var talliedArray = arrayOf<String>()

                        db.collection("${brids}_Receive Stock").orderBy("stk_originname").startAt(upstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)

                                                var dt = document.data
                                                var orid = (dt["stk_brid"]).toString()

                                                if (brids == orid) {
                                                    var id = (document.id)
                                                    idss = idss.plusElement(id)
                                                    println(idss)

                                                    /*  idss=idss.plusElement(path)
                                                          i=idss
                                                          println(id)
                                                          println(i)*/

                                                    var name = (dt["stk_Desc"]).toString()
                                                    var date = (dt["stkdate"]).toString()
                                                    var tot = (dt["stk_total"]).toString()


                                                    var manufacturer = (dt["stkid"]).toString()
                                                    var brnm = (dt["stk_destination"]).toString()
                                                                                                        var braddr=(dt["stk_address"]).toString()


                                                    var rec_on = (dt["Receive_date"]).toString()
                                                    var rec_count = (dt["Receive_count"]).toString()
                                                    var status = (dt["Status"]).toString()
                                                    tallystatus = status
                                                    var orinm=(dt["stk_originname"]).toString()
                                                    orignm=orinm
                                                    text = text.plusElement("Origin: " + orignm)

                                                    text = text.plusElement("Origin: "+orgval)
                                                    nameArray = nameArray.plusElement(name)
                                                    dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                                                    stockidArray = stockidArray.plusElement("Stock transfer No - "+manufacturer)
                                                    priceArray = priceArray.plusElement(tot)
                                                    nameArrayori = nameArrayori.plusElement(name)
                                                    dateArrayori = dateArray
                                                    priceArrayori = priceArray
                                                    datearr = datearr.plusElement(date)
                                                    tallyori = talliedArray
                                                    rec_onori = rec_onori.plusElement(rec_on)
                                                    rec_oncount = rec_oncount.plusElement(rec_count)

                                                    descrip = tallyArray
                                                    stockidArrayori = stockidArray
                                                    ids = ids.plusElement(manufacturer)
                                                    liids = idss
                                                    brname = brname.plusElement(brnm)

                                                    braddress=braddress.plusElement(braddr)

                                                    if (tallystatus.equals("Not Tallied")) {
                                                        tallyArray = tallyArray.plusElement("Not Tallied")
                                                        talliedArray = talliedArray.plusElement("")
                                                    } else {
                                                        tallyArray = tallyArray.plusElement("")
                                                        talliedArray = talliedArray.plusElement("Tallied")
                                                    }
                                                    origisearch = origisearch.plusElement(orid)
                                                    rlist.visibility=View.VISIBLE
                                                    progressBar7.visibility=View.GONE
                                                    noresfo.visibility = View.GONE
                                                    println("SAVE KEYYYY" + brids)
                                                    val whatever = receiveAdapter(this@ReceiveActivity, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                                                    val rlist = findViewById<ListView>(R.id.rlist) as ListView
                                                    rlist.adapter = whatever
                                                } else {
                                                    noresfo.visibility = View.VISIBLE
                                                    rlist.visibility = View.GONE
                                                    progressBar7.visibility=View.GONE

                                                }


                                            }

                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + brids)



                                        } else {



                                            db.collection("${brids}_Receive Stock").orderBy("stk_Desc").startAt(upstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {

                                                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                    println(document.data)

                                                                    var dt = document.data
                                                                    var orid = (dt["stk_brid"]).toString()

                                                                    if (brids == orid) {
                                                                        var id = (document.id)
                                                                        idss = idss.plusElement(id)
                                                                        println(idss)

                                                                        /*  idss=idss.plusElement(path)
                                                                              i=idss
                                                                              println(id)
                                                                              println(i)*/

                                                                        var name = (dt["stk_Desc"]).toString()
                                                                        var date = (dt["stkdate"]).toString()
                                                                        var tot = (dt["stk_total"]).toString()


                                                                        var manufacturer = (dt["stkid"]).toString()
                                                                        var brnm = (dt["stk_destination"]).toString()
                                                                                                                            var braddr=(dt["stk_address"]).toString()


                                                                        var rec_on = (dt["Receive_date"]).toString()
                                                                        var rec_count = (dt["Receive_count"]).toString()
                                                                        var status = (dt["Status"]).toString()
                                                                        tallystatus = status
                                                                        var orinm = (dt["stk_originname"]).toString()
                                                                        orignm = orinm
                                                                        text = text.plusElement("Origin: " + orignm)

                                                                        text = text.plusElement("Origin: " + orgval)
                                                                        nameArray = nameArray.plusElement(name)
                                                                        dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                                                                        stockidArray = stockidArray.plusElement("Stock transfer No - " + manufacturer)
                                                                        priceArray = priceArray.plusElement(tot)
                                                                        nameArrayori = nameArrayori.plusElement(name)
                                                                        dateArrayori = dateArray
                                                                        priceArrayori = priceArray
                                                                        datearr = datearr.plusElement(date)
                                                                        tallyori = talliedArray
                                                                        rec_onori = rec_onori.plusElement(rec_on)
                                                                        rec_oncount = rec_oncount.plusElement(rec_count)

                                                                        descrip = tallyArray
                                                                        stockidArrayori = stockidArray
                                                                        ids = ids.plusElement(manufacturer)
                                                                        liids = idss
                                                                        brname = brname.plusElement(brnm)
                                                    braddress=braddress.plusElement(braddr)


                                                                        if (tallystatus.equals("Not Tallied")) {
                                                                            tallyArray = tallyArray.plusElement("Not Tallied")
                                                                            talliedArray = talliedArray.plusElement("")
                                                                        } else {
                                                                            tallyArray = tallyArray.plusElement("")
                                                                            talliedArray = talliedArray.plusElement("Tallied")
                                                                        }
                                                                        origisearch = origisearch.plusElement(orid)
                                                                        rlist.visibility = View.VISIBLE
                                                                        progressBar7.visibility = View.GONE
                                                                        noresfo.visibility = View.GONE
                                                                        println("SAVE KEYYYY" + brids)
                                                                        val whatever = receiveAdapter(this@ReceiveActivity, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                                                                        val rlist = findViewById<ListView>(R.id.rlist) as ListView
                                                                        rlist.adapter = whatever
                                                                    } else {
                                                                        noresfo.visibility = View.VISIBLE
                                                                        rlist.visibility = View.GONE
                                                                        progressBar7.visibility = View.GONE

                                                                    }


                                                                }

                                                                println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                                                println("SAVE KEYYYY" + brids)



                                                            }
                                                            else{
                                                                db.collection("${brids}_Receive Stock").orderBy("Status").startAt(upstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {

                                                                                        Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                                        println(document.data)

                                                                                        var dt = document.data
                                                                                        var orid = (dt["stk_brid"]).toString()

                                                                                        if (brids == orid) {

                                                                                            var id = (document.id)
                                                                                            idss = idss.plusElement(id)
                                                                                            println(idss)

                                                                                            /*  idss=idss.plusElement(path)
                                                                                                  i=idss
                                                                                                  println(id)
                                                                                                  println(i)*/

                                                                                            var name = (dt["stk_Desc"]).toString()
                                                                                            var date = (dt["stkdate"]).toString()
                                                                                            var tot = (dt["stk_total"]).toString()


                                                                                            var manufacturer = (dt["stkid"]).toString()
                                                                                            var brnm = (dt["stk_destination"]).toString()
                                                                                                                                                var braddr=(dt["stk_address"]).toString()


                                                                                            var rec_on = (dt["Receive_date"]).toString()
                                                                                            var rec_count = (dt["Receive_count"]).toString()
                                                                                            var status = (dt["Status"]).toString()
                                                                                            tallystatus = status
                                                                                            var orinm = (dt["stk_originname"]).toString()
                                                                                            orignm = orinm
                                                                                            text = text.plusElement("Origin: " + orignm)

                                                                                            text = text.plusElement("Origin: " + orgval)
                                                                                            nameArray = nameArray.plusElement(name)
                                                                                            dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                                                                                            stockidArray = stockidArray.plusElement("Stock transfer No - " + manufacturer)
                                                                                            priceArray = priceArray.plusElement(tot)
                                                                                            nameArrayori = nameArrayori.plusElement(name)
                                                                                            dateArrayori = dateArray
                                                                                            priceArrayori = priceArray
                                                                                            datearr = datearr.plusElement(date)
                                                                                            tallyori = talliedArray
                                                                                            rec_onori = rec_onori.plusElement(rec_on)
                                                                                            rec_oncount = rec_oncount.plusElement(rec_count)

                                                                                            descrip = tallyArray
                                                                                            stockidArrayori = stockidArray
                                                                                            ids = ids.plusElement(manufacturer)
                                                                                            liids = idss
                                                                                            brname = brname.plusElement(brnm)
                                                                                            braddress=braddress.plusElement(braddr)


                                                                                            if (tallystatus.equals("Not Tallied")) {
                                                                                                tallyArray = tallyArray.plusElement("Not Tallied")
                                                                                                talliedArray = talliedArray.plusElement("")
                                                                                            } else {
                                                                                                tallyArray = tallyArray.plusElement("")
                                                                                                talliedArray = talliedArray.plusElement("Tallied")
                                                                                            }
                                                                                            origisearch = origisearch.plusElement(orid)
                                                                                            rlist.visibility = View.VISIBLE
                                                                                            progressBar7.visibility = View.GONE
                                                                                            noresfo.visibility = View.GONE
                                                                                            println("SAVE KEYYYY" + brids)
                                                                                            val whatever = receiveAdapter(this@ReceiveActivity, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                                                                                            val rlist = findViewById<ListView>(R.id.rlist) as ListView
                                                                                            rlist.adapter = whatever
                                                                                        } else {
                                                                                            noresfo.visibility = View.VISIBLE
                                                                                            rlist.visibility = View.GONE
                                                                                            progressBar7.visibility = View.GONE

                                                                                        }


                                                                                    }

                                                                                    println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                                                                    println("SAVE KEYYYY" + brids)



                                                                                }
                                                                                else{
                                                                                    noresfo.visibility=View.VISIBLE
                                                                                    rlist.visibility=View.GONE
                                                                                    progressBar7.visibility=View.GONE
                                                                                }

                                                                        })


                                                                println("NO RECORDSSSS FOUNDD")

                                                            }

                                                    })



                                        }


                                   /* } else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }*/
                                })

                    }
                }

                if ((x.trim().matches(ps.toRegex())) && (x != reg)) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString
                    /*nmstr = upstr*/
                    var escp = upperString + '\uf8ff'
                    esc = escp
                    println("CAPPPSSSS" + upperString)
                    println("CAME INTO NUMBER upper names" + upstr)
                    println("STRINGSSSS" + upstr)
                    nameget()
                }


                if ((s.length >= 3) && (x != reg)&&((!s.contains("/")))) {
                    noresfo.visibility = View.GONE
                    var text = arrayOf<String>()
                    var idss = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var stockidArray = arrayOf<String>()
                    var dateArray = arrayOf<String>()
                    var priceArray = arrayOf<String>()
                    var tallyArray = arrayOf<String>()
                    var talliedArray = arrayOf<String>()

                    db.collection("${brids}_Receive Stock").orderBy("stkid").startAt(upstr).endAt(esc)
                            .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                if (e != null) {
                                }
                                if (value.isEmpty == false) {
                                    for (document in value) {

                                            var dt = document.data

                                            var orid = (dt["stk_brid"]).toString()

                                            if (brids == orid)
                                            {
                                                var id = (document.id)
                                                idss = idss.plusElement(id)
                                                println(idss)

                                                /*  idss=idss.plusElement(path)
                                                      i=idss
                                                      println(id)
                                                      println(i)*/

                                                var name = (dt["stk_Desc"]).toString()
                                                var date = (dt["stkdate"]).toString()
                                                var tot = (dt["stk_total"]).toString()


                                                var manufacturer = (dt["stkid"]).toString()
                                                var brnm = (dt["stk_destination"]).toString()
                                                    var braddr=(dt["stk_address"]).toString()

                                                var rec_on = (dt["Receive_date"]).toString()
                                                var rec_count = (dt["Receive_count"]).toString()
                                                var status = (dt["Status"]).toString()
                                                tallystatus = status
                                                var orinm=(dt["stk_originname"]).toString()
                                                orignm=orinm
                                                text = text.plusElement("Origin: " + orignm)

                                                text = text.plusElement("Origin: "+orgval)
                                                nameArray = nameArray.plusElement(name)
                                                dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                                                stockidArray = stockidArray.plusElement("Stock transfer No - "+manufacturer)
                                                priceArray = priceArray.plusElement(tot)
                                                nameArrayori = nameArrayori.plusElement(name)
                                                dateArrayori = dateArray
                                                priceArrayori = priceArray
                                                datearr = datearr.plusElement(date)
                                                tallyori = talliedArray
                                                rec_onori = rec_onori.plusElement(rec_on)
                                                rec_oncount = rec_oncount.plusElement(rec_count)

                                                descrip = tallyArray
                                                stockidArrayori = stockidArray
                                                ids = ids.plusElement(manufacturer)
                                                liids = idss
                                                brname = brname.plusElement(brnm)
                                                    braddress=braddress.plusElement(braddr)


                                                if (tallystatus.equals("Not Tallied")) {
                                                    tallyArray = tallyArray.plusElement("Not tallied")
                                                    talliedArray = talliedArray.plusElement("")
                                                } else {
                                                    tallyArray = tallyArray.plusElement("")
                                                    talliedArray = talliedArray.plusElement("Tallied")
                                                }
                                                origisearch = origisearch.plusElement(orid)
                                                rlist.visibility=View.VISIBLE
                                                progressBar7.visibility=View.GONE
                                                noresfo.visibility = View.GONE
                                                println("SAVE KEYYYY" + brids)
                                                val whatever = receiveAdapter(this@ReceiveActivity, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                                                val rlist = findViewById<ListView>(R.id.rlist) as ListView
                                                rlist.adapter = whatever
                                            }
                                            else

                                            {
                                                noresfo.visibility = View.VISIBLE
                                                progressBar7.visibility = View.GONE
                                                rlist.visibility = View.GONE

                                            }




                                        }

                                        println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                        println("SAVE KEYYYY" + origid)






                                    } else {
                                        println("NO RECORDSSSS FOUNDD")
                                        nameget()

                                    }


                                /*} else {
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }*/
                            })

                }
                else if(s.contains("/")){
                    dateget()
                }








                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(searchedit.text.toString().isEmpty())
                {
                    rlist.visibility=View.VISIBLE
                    noresfo.visibility=View.GONE
                    progressBar7.visibility=View.GONE


                    if(imageView10.visibility==View.GONE){
                        gets()
                    }
                }
            }
        })



        searback1.setOnClickListener {
            searchedit.setText("")
            cardsearch.visibility=View.GONE

             cardsearch.startAnimation(AnimationUtils.loadAnimation(this@ReceiveActivity,R.anim.slide_to_left))
            noresfo.visibility=View.GONE
            rlist.visibility=View.VISIBLE
            progressBar7.visibility=View.GONE

            gets()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }










                        rback.setOnClickListener {
            onBackPressed()
        }



        rlist.setOnItemClickListener { parent, views, position, id ->

            val b = Intent(applicationContext, ScrollStkOneActivity::class.java)

            b.putExtra("fromreceive", "receivelist")
            b.putExtra("brnm", brname[position])
            b.putExtra("braddress", braddress[position])

            b.putExtra("date", datearr[position])
            b.putExtra("description", nameArrayori[position])
            b.putExtra("receive", rec_onori[position])
            b.putExtra("receive_cnt", rec_oncount[position])

            b.putExtra("Stockids", ids[position])
            b.putExtra("listids", liids[position])
            b.putExtra("brid",brids)





            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)


            startActivity(b)
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
            finish()

        }

    }
    override fun onBackPressed()

    {

        if(cardsearch.visibility==View.VISIBLE){
            cardsearch.visibility=View.GONE

            if(imageView10.visibility==View.GONE){
                gets()
            }
            else{
                val b=Intent(this@ReceiveActivity,StockTransferActivity::class.java)
                b.putExtra("skey",brids)




                b.putExtra("viewtrans", viewtrans)
                b.putExtra("addtrans", addtrans)
                b.putExtra("edittrans", editetrans)
                b.putExtra("deletetrans", deletetrans)
                b.putExtra("transfertrans", transfertrans)
                b.putExtra("exporttrans", exporttrans)
                b.putExtra("sendtrans", sendtrans)


                b.putExtra("viewtransano", viewtransano)
                b.putExtra("addtransano", addtransano)
                b.putExtra("edittransano", editetransano)
                b.putExtra("deletetransano", deletetransano)
                b.putExtra("transfertransano", transfertransano)
                b.putExtra("exporttransano", exporttransano)
                b.putExtra("sendtransano", sendtransano)

                b.putExtra("viewrec", viewrec)
                b.putExtra("addrec", addrec)
                b.putExtra("deleterec", deleterec)
                b.putExtra("editrec", editrec)
                b.putExtra("transferrec", transferrec)
                b.putExtra("exportrec", exportrec)
                b.putExtra("sendstrec",sendstrec)



                startActivity(b)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                finish()
            }


        }
        else{
            val b=Intent(this@ReceiveActivity,StockTransferActivity::class.java)
            b.putExtra("skey",brids)




            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("sendtrans", sendtrans)


            b.putExtra("viewtransano", viewtransano)
            b.putExtra("addtransano", addtransano)
            b.putExtra("edittransano", editetransano)
            b.putExtra("deletetransano", deletetransano)
            b.putExtra("transfertransano", transfertransano)
            b.putExtra("exporttransano", exporttransano)
            b.putExtra("sendtransano", sendtransano)

            b.putExtra("viewrec", viewrec)
            b.putExtra("addrec", addrec)
            b.putExtra("deleterec", deleterec)
            b.putExtra("editrec", editrec)
            b.putExtra("transferrec", transferrec)
            b.putExtra("exportrec", exportrec)
            b.putExtra("sendstrec",sendstrec)



            startActivity(b)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

            finish()
        }
    }





    //---------------------------------- gets() is used to get and list the receive stock details frokm db------------------------------//

    fun gets() {


        progressBar7.visibility=View.VISIBLE

        println("KEY"+brids)



        db.collection("${brids}_Receive Stock").whereEqualTo("stk_brid", brids).orderBy("stkid",Query.Direction.DESCENDING)
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->


                    var text = arrayOf<String>()
                    var idss = arrayOf<String>()
                    var nameArray = arrayOf<String>()
                    var stockidArray = arrayOf<String>()
                    var dateArray = arrayOf<String>()
                    var priceArray = arrayOf<String>()
                    var tallyArray = arrayOf<String>()
                    var talliedArray = arrayOf<String>()

var brnmsArray= arrayOf<String>()



                    if (e != null) {
                        Log.w("", "Listen failed.", e)
                        return@EventListener
                    }
                    if(value.isEmpty==false) {
                        imageView10.visibility=View.GONE
                        for (document in value) {

                            Log.d("d", "key --- " + document.id + " => " + document.data)
                            println(document.data)

                            var dt = document.data
                            var id = (document.id)
                            idss = idss.plusElement(id)
                            println(idss)

                            /*  idss=idss.plusElement(path)
                                                  i=idss
                                                  println(id)
                                                  println(i)*/

                            var name = (dt["stk_Desc"]).toString()
                            var date = (dt["stkdate"]).toString()
                            var tot = (dt["stk_total"]).toString()


                            var manufacturer = (dt["stkid"]).toString()
                            var brnm = (dt["stk_destination"]).toString()
                                                    var braddr=(dt["stk_address"]).toString()

                            var brnmori = (dt["stk_origin"]).toString()

                            var rec_on = (dt["Receive_date"]).toString()
                            var rec_count = (dt["Receive_count"]).toString()


                            var status = (dt["Status"]).toString()
                            tallystatus = status

                            var orinm=(dt["stk_originname"]).toString()
                            orignm=orinm

                            println("ORI VAl"+orignm)




                            text = text.plusElement("Origin: " + orignm)

                            nameArray = nameArray.plusElement(name)
                            dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                            stockidArray = stockidArray.plusElement("Stock transfer No - " + manufacturer)
                            priceArray = priceArray.plusElement(tot)
                            nameArrayori = nameArrayori.plusElement(name)
                            dateArrayori = dateArray
                            priceArrayori = priceArray
                            datearr = datearr.plusElement(date)
                            tallyori = talliedArray
                            rec_onori = rec_onori.plusElement(rec_on)
                            rec_oncount = rec_oncount.plusElement(rec_count)

                            descrip = tallyArray
                            stockidArrayori = stockidArray
                            ids = ids.plusElement(manufacturer)
                            liids = idss
                            brname = brname.plusElement(brnm)
                                                    braddress=braddress.plusElement(braddr)

                            println("TALLY ARRAY" + tallystatus)


                            if (tallystatus.equals("Not Tallied")) {
                                tallyArray = tallyArray.plusElement("Not tallied")
                                talliedArray = talliedArray.plusElement("")
                            }  else if (tallystatus.equals("Tallied")) {
                                tallyArray = tallyArray.plusElement("")
                                talliedArray = talliedArray.plusElement("Tallied")
                            }
                            else{
                                tallyArray = tallyArray.plusElement("Not tallied")
                                talliedArray = talliedArray.plusElement("")
                            }

                         /*   if(status=="Not Tallied") {

                                val mBuilder = NotificationCompat.Builder(this@ReceiveActivity)


                                val intent = Intent(Intent.ACTION_GET_CONTENT)
                                val mNotifyManager = this@ReceiveActivity.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;

                                val resultIntent = Intent(this, ReceiveActivity::class.java)
                                val stackBuilder = TaskStackBuilder.create(this)
                                stackBuilder.addParentStack(ReceiveActivity::class.java)

// Adds the Intent that starts the Activity to the top of the stack
                                stackBuilder.addNextIntent(resultIntent)
                                val resultPendingIntent = stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT)
                                mBuilder.setContentIntent(resultPendingIntent)
                                mBuilder.setDeleteIntent(NotificationEventReceiver.getDeleteIntent(this))

                                mBuilder.setContentText("Receive the stock")
                                mBuilder.setSmallIcon(R.drawable.ic_logo)
                                mBuilder.setContentTitle("Please verify the stock sent from $orignm")
                                mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)

                                mNotifyManager.notify(1, mBuilder.build());
                            }*/

                            /*   talliedArray=talliedArray.plusElement("Tallied")*//*
                                tallyArray= tallyArray.plusElement("")*/

                           /* swipeContainer.setRefreshing(false);*/
                        }

                        val whatever = receiveAdapter(this, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                        val rlist = findViewById<ListView>(R.id.rlist) as ListView
                        rlist.adapter = whatever

                        progressBar7.visibility=View.GONE
                    }
                    else{

                        progressBar7.visibility=View.GONE
                        imageView10.visibility=View.VISIBLE
                    }
                })

    }

    fun dateget() {
        if ((s.length>=2)||(s.length>=2)) {
            noresfo.visibility = View.GONE
            var text = arrayOf<String>()
            var idss = arrayOf<String>()
            var nameArray = arrayOf<String>()
            var stockidArray = arrayOf<String>()
            var dateArray = arrayOf<String>()
            var priceArray = arrayOf<String>()
            var tallyArray = arrayOf<String>()
            var talliedArray = arrayOf<String>()

            db.collection("${brids}_Receive Stock").orderBy("stkdate").startAt(numberstr).endAt(esc)
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        if (e != null) {
                        }
                        if (value.isEmpty == false) {
                            for (document in value) {

                                    Log.d("d", "key --- " + document.id + " => " + document.data)
                                    println(document.data)

                                    var dt = document.data
                                    var orid = (dt["stk_brid"]).toString()
                                    if (brids == orid) {
                                        var id = (document.id)
                                        idss = idss.plusElement(id)
                                        println(idss)

                                        /*  idss=idss.plusElement(path)
                                              i=idss
                                              println(id)
                                              println(i)*/

                                        var name = (dt["stk_Desc"]).toString()
                                        var date = (dt["stkdate"]).toString()
                                        var tot = (dt["stk_total"]).toString()


                                        var manufacturer = (dt["stkid"]).toString()
                                        var brnm = (dt["stk_destination"]).toString()
                                                    var braddr=(dt["stk_address"]).toString()

                                        var rec_on = (dt["Receive_date"]).toString()
                                        var rec_count = (dt["Receive_count"]).toString()
                                        var status = (dt["Status"]).toString()
                                        tallystatus = status
                                        var orinm=(dt["stk_originname"]).toString()
                                        orignm=orinm
                                        text = text.plusElement("Origin: " + orignm)

                                        text = text.plusElement("Origin: "+orgval)
                                        nameArray = nameArray.plusElement(name)
                                        dateArray = dateArray.plusElement("Dated " + date + ". Stock received on " + rec_on)
                                        stockidArray = stockidArray.plusElement("Stock transfer No - "+manufacturer)
                                        priceArray = priceArray.plusElement(tot)
                                        nameArrayori = nameArrayori.plusElement(name)
                                        dateArrayori = dateArray
                                        priceArrayori = priceArray
                                        datearr = datearr.plusElement(date)
                                        tallyori = talliedArray
                                        rec_onori = rec_onori.plusElement(rec_on)
                                        rec_oncount = rec_oncount.plusElement(rec_count)

                                        descrip = tallyArray
                                        stockidArrayori = stockidArray
                                        ids = ids.plusElement(manufacturer)
                                        liids = idss
                                        brname = brname.plusElement(brnm)
                                                    braddress=braddress.plusElement(braddr)


                                        if (tallystatus.equals("Not Tallied")) {
                                            tallyArray = tallyArray.plusElement("Not Tallied")
                                            talliedArray = talliedArray.plusElement("")
                                        } else {
                                            tallyArray = tallyArray.plusElement("")
                                            talliedArray = talliedArray.plusElement("Tallied")
                                        }
                                        origisearch = origisearch.plusElement(orid)
                                        rlist.visibility=View.VISIBLE
                                        progressBar7.visibility=View.GONE

                                        println("SAVE KEYYYY" + origid)
                                        val whatever = receiveAdapter(this@ReceiveActivity, idss, text, nameArray, dateArray, stockidArray, tallyArray, talliedArray, priceArray)
                                        val rlist = findViewById<ListView>(R.id.rlist) as ListView
                                        rlist.adapter = whatever
                                    } else {
                                        noresfo.visibility = View.VISIBLE
                                        rlist.visibility = View.GONE
                                        progressBar7.visibility=View.GONE

                                    }



                                }

                                println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                println("SAVE KEYYYY" + brids)



                            } else {
                                println("NO RECORDSSSS FOUNDD")
                                noresfo.visibility=View.VISIBLE
                                rlist.visibility=View.GONE
                                progressBar7.visibility=View.GONE
                            }


                      /*  } else {
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }*/
                    })

        }
    }
    companion object {

        //Listens inetrnet status whether net is on/off. .

        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                    /// if connection is off then all views becomes disable

                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE



                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {

                 /// if connection is off then all views becomes enabled


                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }

    fun net_status():Boolean{            //Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
