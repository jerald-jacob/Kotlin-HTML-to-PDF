package com.example.vinitas.gallery.sampledata

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.support.v7.widget.LinearLayoutManager
import android.view.View


class DividerItemDecoration(context: Context, orientation: Int, dividerDrawableRes: Int) : RecyclerView.ItemDecoration() {

    private var mOrientation: Int = 0

    val ATTRS = intArrayOf(android.R.attr.listDivider)
    private var mDivider: Drawable? = null
    private var mHeight: Int = 0
    private var mWidth: Int = 0

    init {
        if (dividerDrawableRes == 0) {
            val a = context.obtainStyledAttributes(ATTRS)
            mDivider = a.getDrawable(0)
            a.recycle()
            mHeight = mDivider!!.intrinsicHeight
            mWidth = mDivider!!.intrinsicWidth
        } else {
            mDivider = context.getResources().getDrawable(dividerDrawableRes)
            mHeight = DIVIDER_HEIGHT
            mWidth = DIVIDER_WIDTH
        }
        setOrientation(orientation)
    }

    fun setOrientation(orientation: Int) {
        if (orientation != HORIZONTAL_LIST && orientation != VERTICAL_LIST) {
            throw IllegalArgumentException("invalid orientation")
        }
        mOrientation = orientation
    }

    override fun onDrawOver(c: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        if (mOrientation == VERTICAL_LIST) {
            drawVertical(c, parent)
        } else {
            drawHorizontal(c, parent)
        }
    }

    fun drawVertical(c: Canvas, parent: RecyclerView) {
        val left = parent.paddingLeft
        val right = parent.width - parent.paddingRight

        val childCount = parent.childCount
        for (i in 0 until childCount) {
            val child = parent.getChildAt(i)
            val params = child
                    .layoutParams as RecyclerView.LayoutParams
            val top = child.bottom + params.bottomMargin
            val bottom = top + mHeight
            mDivider!!.setBounds(left, top, right, bottom)
            mDivider!!.draw(c)
        }
    }

    fun drawHorizontal(c: Canvas, parent: RecyclerView) {
        val top = parent.paddingTop
        val bottom = parent.height - parent.paddingBottom

        val childCount = parent.childCount
        for (i in 0 until childCount) {
            val child = parent.getChildAt(i)
            val params = child
                    .layoutParams as RecyclerView.LayoutParams
            val left = child.right + params.rightMargin
            val right = left + mHeight
            mDivider!!.setBounds(left, top, right, bottom)
            mDivider!!.draw(c)
        }
    }

    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        if (mOrientation == VERTICAL_LIST) {
            outRect.set(0, 0, 0, mHeight)
        } else {
            outRect.set(0, 0, mWidth, 0)
        }
    }

    companion object {

        val HORIZONTAL_LIST = LinearLayoutManager.HORIZONTAL
        val VERTICAL_LIST = LinearLayoutManager.VERTICAL
        private val DIVIDER_HEIGHT = 6
        private val DIVIDER_WIDTH = 6
    }
}