package com.example.vinitas.inventory_app

/**
 * Created by Vinitas on 22-12-2017.
 */
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Environment
import android.support.constraint.ConstraintLayout
import android.support.design.widget.FloatingActionButton
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.Window

import com.example.vinitas.inventory_app.R
import com.squareup.picasso.Picasso
import de.hdodenhof.circleimageview.CircleImageView
import android.view.Window.FEATURE_NO_TITLE
import android.view.animation.DecelerateInterpolator
import android.widget.*
import java.io.File


/**
 * Created by vinitas IT on 13-12-2017.
 */
class supp_first_list_adap(//to reference the Activity
        private val context: Activity,
        //to store the list of countries
        private val idsArray:   Array<String>,
        private val supstatusArray:   Array<String>,
        private val suppcnameArray:   Array<String>, //to store the list of countries
        private val supplocArray:  Array<String>,
        private val suppnumArray:     Array<String>,

        private val productImArray: Array<String>,
        private val imnmhigh: Array<String>,
        private val icohighArray: Array<String>): ArrayAdapter<Any>(context, R.layout.supp_first_list_items, suppcnameArray) {


    private var mCurrentAnimator: Animator? = null

    private var mShortAnimationDuration: Int = 0

    @SuppressLint("ViewHolder", "ResourceAsColor")

    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.supp_first_list_items, null, true)

        //this code gets references to objects in the listview_row.xml file
        val idsfTextField = rowView.findViewById<View>(R.id.spfid) as TextView
        val suppstatusField = rowView.findViewById<View>(R.id.spfstatus) as TextView
        val nameTextField = rowView.findViewById<View>(R.id.pcnm) as TextView
        val locationnameTextField = rowView.findViewById<View>(R.id.cloc) as TextView
        val bcnameTextField = rowView.findViewById<View>(R.id.cnum) as TextView

        val productim= rowView.findViewById<View>(R.id.scimg) as CircleImageView


        mShortAnimationDuration = context.resources.getInteger(
                android.R.integer.config_shortAnimTime);
        //this code sets the values of the objects to values from the arrays
        idsfTextField.text = idsArray[position]
        suppstatusField.text=supstatusArray[position]
        nameTextField.text = suppcnameArray[position]
        locationnameTextField.text =  supplocArray[position]
        bcnameTextField.text=suppnumArray[position]

        try {

            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            val k = imnmhigh[position]
            val recacnm = k.removeSuffix(".jpg")

            var y = recacnm + ".png"

            val file = File(dir, y)
            println("CONTENT URI" + file)
            if (file.exists()) {
                val contentUri = Uri.fromFile(File("$path/$y"))
                try {
                    Picasso.with(context)
                            .load(contentUri)
                            .into(productim);
                }
                catch (e:Exception){

                }
            }
            else{
                try {
                    Picasso.with(context)
                            .load(productImArray[position])
                            .into(productim);
                }
                catch (e:Exception){

                }
            }
        }
        catch (e:Exception){
            try {
                Picasso.with(context)
                        .load(productImArray[position])
                        .into(productim);
            }
            catch (e:Exception){

            }
        }





        /*        Log.i("Click", "TextView clicked on row " + position)

                val alert = AlertDialog.Builder(context)
                val inflater = context.layoutInflater
                *//*with(alert) {
                setTitle("Select Branch")
                }*//*
                val dialog = alert.create()
                dialog.setView(inflater.inflate(R.layout.popup, null))
                dialog.show()


                val popdp=dialog.findViewById<ImageView>(R.id.popdp) as ImageView
                val a=productim.drawable
                popdp.scaleType
                popdp.setImageDrawable(a)*/
                productim.setOnClickListener {position
                    val kd = imnmhigh[position]
                    println("IMAG NAME VIEW"+kd)

                    val k=productim.drawable


                    println("POSITION OF ICO"+position)

                    val jk=context.findViewById<ListView>(R.id.supp_list_ven) as ListView

                    jk.isEnabled=false
                    jk.isClickable=false
                    val jj=context.findViewById<FloatingActionButton>(R.id.d_fab) as FloatingActionButton
                    jj.isClickable=false
                    jj.isEnabled=false

                    val kj=context.findViewById<ConstraintLayout>(R.id.constr) as ConstraintLayout
                    kj.setBackgroundColor(Color.parseColor("#43161616"))
                    zoomImageFromThumb(productim,k,position)


                }



                /*    productim.isDrawingCacheEnabled = false
                productim.buildDrawingCache()
                val bitmap = productim.drawingCache
                val baos = ByteArrayOutputStream()
               bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)


                val a=Bitmap.createScaledBitmap(bitmap,800,800,false)
                popdp.setImageBitmap(a)*/




        if ( suppstatusField.text.equals("Disable")){
            nameTextField.setTextColor(Color.LTGRAY )
            nameTextField.setTextColor(Color.LTGRAY )
            bcnameTextField.setTextColor(Color.LTGRAY )
            locationnameTextField.setTextColor(Color.LTGRAY)


            //parseColor("#")
            //rowView.setLayerType(View.LAYER_TYPE_SOFTWARE, null)

        }


        //infoTextField.text = infoArray[position]


        return rowView
    }
    private fun zoomImageFromThumb(thumbView: View, imageResId: Drawable, pos:Int) {
        // If there's an animation in progress, cancel it
        // immediately and proceed with this one.
        mCurrentAnimator?.cancel()

        // Load the high-resolution "zoomed-in" image.
        val expandedImageView = context.findViewById<View>(
                R.id.expanded_image) as ImageView
        val rel = context.findViewById<RelativeLayout>(
                R.id.relative) as RelativeLayout

        val jk=context.findViewById<ListView>(R.id.supp_list_ven) as ListView
        val jj=context.findViewById<FloatingActionButton>(R.id.d_fab) as FloatingActionButton
       /* val kj=context.findViewById<ConstraintLayout>(R.id.const) as ConstraintLayout*/

        val nm=context.findViewById<TextView>(R.id.nameser) as TextView

        val ico = context.findViewById<CircleImageView>(R.id.scimg) as CircleImageView
        expandedImageView.setImageDrawable(imageResId)


        // Calculate the starting and ending bounds for the zoomed-in image.
        // This step involves lots of math. Yay, math.
        val startBounds = Rect()
        val finalBounds = Rect()
        val globalOffset = Point()

        // The start bounds are the global visible rectangle of the thumbnail,
        // and the final bounds are the global visible rectangle of the container
        // view. Also set the container view's offset as the origin for the
        // bounds, since that's the origin for the positioning animation
        // properties (X, Y).
        thumbView.getGlobalVisibleRect(startBounds)
        val kk = context.findViewById<View>(R.id.containersd)
        context.findViewById<View>(R.id.containersd)
                .getGlobalVisibleRect(finalBounds, globalOffset)
        startBounds.offset(-globalOffset.x, -globalOffset.y)
        finalBounds.offset(-globalOffset.x, -globalOffset.y)

        // Adjust the start bounds to be the same aspect ratio as the final
        // bounds using the "center crop" technique. This prevents undesirable
        // stretching during the animation. Also calculate the start scaling
        // factor (the end scaling factor is always 1.0).
        val startScale: Float
        if (finalBounds.width().toFloat() / finalBounds.height() > startBounds.width().toFloat() / startBounds.height()) {
            // Extend start bounds horizontally
            startScale = startBounds.height().toFloat() / finalBounds.height()
            val startWidth = startScale * finalBounds.width()
            val deltaWidth = (startWidth - startBounds.width()) / 2
            startBounds.left -= deltaWidth.toInt()
            startBounds.right += deltaWidth.toInt()
        } else {
            // Extend start bounds vertically
            startScale = startBounds.width().toFloat() / finalBounds.width()
            val startHeight = startScale * finalBounds.height()
            val deltaHeight = (startHeight - startBounds.height()) / 2
            startBounds.top -= deltaHeight.toInt()
            startBounds.bottom += deltaHeight.toInt()
        }

        // Hide the thumbnail and show the zoomed-in view. When the animation
        // begins, it will position the zoomed-in view in the place of the
        // thumbnail.
        thumbView.alpha = 1f
        expandedImageView.visibility = View.VISIBLE
        kk.visibility = View.VISIBLE
        rel.visibility=View.VISIBLE
        nm.visibility=View.VISIBLE

        nm.text=suppcnameArray[pos]



        // Set the pivot point for SCALE_X and SCALE_Y transformations
        // to the top-left corner of the zoomed-in view (the default
        // is the center of the view).
        expandedImageView.pivotX = 0f
        expandedImageView.pivotY = 0f

        // Construct and run the parallel animation of the four translation and
        // scale properties (X, Y, SCALE_X, and SCALE_Y).
        val set = AnimatorSet()
        set
                .play(ObjectAnimator.ofFloat(expandedImageView, View.X,
                        startBounds.left.toFloat(), finalBounds.left.toFloat()))
                .with(ObjectAnimator.ofFloat(expandedImageView, View.Y,
                        startBounds.top.toFloat(), finalBounds.top.toFloat()))
                .with(ObjectAnimator.ofFloat(expandedImageView, View.SCALE_X,
                        startScale, 1f))
                .with(ObjectAnimator.ofFloat(expandedImageView,
                        View.SCALE_Y, startScale, 1f))
        set.setDuration(mShortAnimationDuration.toLong())
        set.interpolator = DecelerateInterpolator()
        set.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                mCurrentAnimator = null
            }

            override fun onAnimationCancel(animation: Animator) {
                mCurrentAnimator = null
            }
        })
        set.start()
        mCurrentAnimator = set

        // Upon clicking the zoomed-in image, it should zoom back down
        // to the original bounds and show the thumbnail instead of
        // the expanded image.
        val startScaleFinal = startScale



        // Animate the four positioning/sizing properties in parallel,
        // back to their original values.
        val kj = context.findViewById<ConstraintLayout>(R.id.constr) as ConstraintLayout
        rel.setOnClickListener {


            kj.setBackgroundColor(Color.parseColor("#ffffff"))
            mCurrentAnimator?.cancel()
            val set = AnimatorSet()
            set.play(ObjectAnimator
                    .ofFloat(expandedImageView, View.X, startBounds.left.toFloat()))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.Y, startBounds.top.toFloat()))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.SCALE_X, startScale))
                    .with(ObjectAnimator
                            .ofFloat(expandedImageView,
                                    View.SCALE_Y, startScale))
            set.setDuration(mShortAnimationDuration.toLong())
            set.interpolator = DecelerateInterpolator()
            set.addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    thumbView.alpha = 1f
                    nm.visibility=View.GONE
                    expandedImageView.visibility = View.GONE
                    kk.visibility = View.GONE

                    rel.visibility = View.GONE
                    jk.isEnabled=true
                    jk.isClickable=true
                    ico.isEnabled=true
                    ico.isClickable=true
                    jj.isClickable=true
                    jj.isEnabled=true
                    mCurrentAnimator = null
                }

                override fun onAnimationCancel(animation: Animator) {
                    thumbView.alpha = 1f
                    expandedImageView.visibility = View.GONE
                    nm.visibility=View.GONE
                    kk.visibility = View.GONE
                    rel.visibility=View.GONE

                    jk.isEnabled=true
                    jk.isClickable=true
                    jj.isClickable=true
                    jj.isEnabled=true
                    mCurrentAnimator = null
                }
            })
            set.start()
            mCurrentAnimator = set
        }

        expandedImageView.setOnClickListener {pos

            val k = imnmhigh[pos]
            println("IMAG NAME VIEW"+k)
            expandedImageView.visibility = View.GONE
            kj.setBackgroundColor(Color.parseColor("#ffffff"))
            nm.visibility=View.GONE
            kk.visibility = View.GONE
            rel.visibility=View.GONE

            jk.isEnabled=true
            jk.isClickable=true
            jj.isClickable=true
            jj.isEnabled=true

            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Supplier"

            val dir = File(path);




            val recacnm = k.removeSuffix(".jpg")

            var y = recacnm + ".png"

            val file = File(dir, y)
            println("CONTENT URI GG" + file)
            if (file.exists()) {
                val contentUri = Uri.fromFile(File("$path/$y"))

                println("CONTENT URI" + contentUri)
                /*    var redrawb = image1.drawable
            val bitmap = (redrawb as BitmapDrawable).getBitmap()*/
                /*  val baos = ByteArrayOutputStream()
          bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
          val b = baos.toByteArray()*/
                if (contentUri != null) {
                    val shareIntent = Intent(context, ZoomSupplier::class.java)
                    shareIntent.putExtra("im", "imageadap")
                    shareIntent.putExtra("drawb", contentUri.toString())
                    shareIntent.putExtra("nameser",suppcnameArray[pos])
                    context.startActivity(shareIntent)
                }
            } else {
                val shareIntent = Intent(context, ZoomSupplier::class.java)
                shareIntent.putExtra("im", "imageadap")
                shareIntent.putExtra("drawb", icohighArray[pos])
                shareIntent.putExtra("nameser",suppcnameArray[pos])
                context.startActivity(shareIntent)
            }
        }




    }

}