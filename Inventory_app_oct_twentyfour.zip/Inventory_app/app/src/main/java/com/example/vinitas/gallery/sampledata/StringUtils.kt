package com.example.vinitas.gallery.sampledata

object StringUtils {
    fun getLastPathSegment(content: String?): String {
        if (content == null || content.length == 0) {
            return ""
        }
        val segments = content.split("/".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        return if (segments.size > 0) {
            segments[segments.size - 1]
        } else ""
    }

}