package com.example.vinitas.inventory_app;

/**
 * Created by vinitas stock on 13-02-2018.
 */

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import java.util.HashMap;

public class SessionManagement {
    // Shared Preferences
    SharedPreferences pref;

    // Editor for Shared preferences
    Editor editor;

    // Context
    Context _context;

    // Shared pref mode
    int PRIVATE_MODE = 0;

    // Sharedpref file name
    private static final String PREF_NAME = "vadeInventory";

    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";

    // User name (make variable public to access from outside)
    public static final String KEY_NAME = "name";
    public static final String KEY_STATE = "st";
    public static final String KEY_PIN = "pin";
    public static final String KEY_brnm = "brnm";

    public static final String employeeky = "empky";

    // Email address (make variable public to access from outside)

    //service
    public static final String sview="s-view";
    public static final String sedit="s-edit";
    public static final String sadd="s-add";
    public static final String sdelete="s-delete";
    public static final String simport="s-import";
    public static final String s_export="s-export";


    public static final String pview="p-view";
    public static final String  padd="p-add";
    public static final String pdelete="p-delete";
    public static final String  pedit="p-edit";
   public static final  String pimport="p-import";
    public static final String  pexport="p-export";
   public static final  String pstockin_hand="p-stockin_hand";


    public static final String suppview="sup-view";
    public static final String  suppadd="sup-add";
    public static final String suppdelete="sup-delete";
    public static final String  suppedit="sup-edit";
    public static final  String suppimport="sup-import";
    public static final String  suppexport="sup-export";

    public static final String viewpreq="purreq-view";
    public static final String  addpreq="purreq-add";
    public static final String deletepreq="purreq-delete";
    public static final String  editpreq="purreq-edit";
    public static final  String transferpreq="purreq-save";
    public static final String  exportpreq="purreq-export";

    public static final String viewpord="purord-view";
    public static final String  addpord="purord-add";
    public static final String deletepord="purord-delete";
    public static final String  editpord="purord-edit";
    public static final  String transferpord="purord-save";
    public static final String  exportpord="purord-export";
    public static final String  sendpord="purord-sndpo";


    public static final String viewsupin="supin-view";
    public static final String  addsupin="supin-add";
    public static final String deletesupin="supin-delete";
    public static final String  editsupin="supin-edit";
    public static final  String transfersupin="supin-save";
    public static final String  exportsupin="supin-export";

    public static final String viewtransf="trans-view";
    public static final String  addtransf="trans-add";
    public static final String deletetransf="trans-delete";
    public static final String  edittransf="trans-edit";
    public static final  String transfertransf="trans-save";
    public static final String  exporttransf="trans-export";
    public static final String  sendtransf="trans-send";


    public static final String viewtransfano="transano-view";
    public static final String  addtransfano="transano-add";
    public static final String deletetransfano="transano-delete";
    public static final String  edittransfano="transano-edit";
    public static final  String transfertransfano="transano-import";
    public static final String  exporttransfano="transano-export";
    public static final String  sendtransfano="transano-send";

    public static final String viewreceive="rec-view";
    public static final String  addreceive="rec-add";
    public static final String deletereceive="rec-delete";
    public static final String  editreceive="rec-edit";
    public static final  String transferreceive="rec-save";
    public static final String  exportreceive="rec-export";
    public static final String  sendstreceive="rec-send";

    public static final String  viewstklvl="stklvl-view";























    // Constructor
    public SessionManagement(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    /**
     * Create login session
     * */
    public void createLoginSession(String name,String pin,String state,String brnm){
        // Storing login value as TRUE
        editor.putBoolean(IS_LOGIN, true);

        // Storing name in pref
        editor.putString(KEY_NAME, name);
        editor.putString(KEY_STATE, state);
        editor.putString(KEY_PIN, pin);
        editor.putString(KEY_brnm, brnm);




        // Storing email in pref


        // commit changes
        editor.commit();
    }


    //Service Access
    public void putService_Access(String sv,String se,String sa,String sd,String im,String ex){
        editor.putString(sview,sv);
        editor.putString(sedit,se);
        editor.putString(sadd,sa);
        editor.putString(sdelete,sd);
        editor.putString(simport,im);
        editor.putString(s_export,ex);
        editor.commit();

    }


    //Product Access

    public void putProduct_Access(String pv,String pe,String pa,String pd,String pim,String pex,String pstkhnd){
        editor.putString(pview,pv);
        editor.putString(padd,pe);
        editor.putString(pdelete,pa);
        editor.putString(pedit,pd);
        editor.putString(pimport,pim);
        editor.putString(pexport,pex);
        editor.putString(pstockin_hand,pstkhnd);
        editor.commit();

    }

    //Supplier Access

    public void putSupplier_Access(String suppv,String suppe,String suppa,String suppd,String suppim,String suppex){
        editor.putString(suppview,suppv);
        editor.putString(suppadd,suppe);
        editor.putString(suppdelete,suppa);
        editor.putString(suppedit,suppd);
        editor.putString(suppimport,suppim);
        editor.putString(suppexport,suppex);

        editor.commit();

    }

    //Purchase request Access
    public void putPurreq_Access(String reqv,String reqadd,String reqdelete,String reqedit,String reqsave,String reqexport){
        editor.putString(viewpreq,reqv);
        editor.putString(addpreq,reqadd);
        editor.putString(deletepreq,reqdelete);
        editor.putString(editpreq,reqedit);
        editor.putString(transferpreq,reqsave);
        editor.putString(exportpreq,reqexport);

        editor.commit();

    }
    //Purchase Order Access
    public void putPurord_Access(String ordv,String ordadd,String orddelete,String ordedit,String ordsave,String ordexport,String ordsndpo){
        editor.putString(viewpord,ordv);
        editor.putString(addpord,ordadd);
        editor.putString(deletepord,orddelete);
        editor.putString(editpord,ordedit);
        editor.putString(transferpord,ordsave);
        editor.putString(exportpord,ordexport);
        editor.putString(sendpord,ordsndpo);
        editor.commit();

    }
    //Supplier invoice Access
    public void putSuppinvoice_Access(String supinv,String supinadd,String supindelete,String supinedit,String supinsave,String supinexport){
        editor.putString(viewsupin,supinv);
        editor.putString(addsupin,supinadd);
        editor.putString(deletesupin,supindelete);
        editor.putString(editsupin,supinedit);
        editor.putString(transfersupin,supinsave);
        editor.putString(exportsupin,supinexport);

        editor.commit();

    }

    //Stock transfer Access

    public void putStatetransfer_Access(String transfinv,String transfadd,String transfdelete,String transfedit,String transfsave,String transfexport,String transfsendpo){
        editor.putString(viewtransf,transfinv);
        editor.putString(addtransf,transfadd);
        editor.putString(deletetransf,transfdelete);
        editor.putString(edittransf,transfedit);
        editor.putString(transfertransf,transfsave);
        editor.putString(exporttransf,transfexport);
        editor.putString(sendtransf,transfsendpo);


        editor.commit();

    }

    public void putStatetransferano_Access(String transfanoinv,String transfanoadd,String transfanodelete,String transfanoedit,String transfanosave,String transfanoexport,String transfanosendpo){
        editor.putString(viewtransfano,transfanoinv);
        editor.putString(addtransfano,transfanoadd);
        editor.putString(deletetransfano,transfanodelete);
        editor.putString(edittransfano,transfanoedit);
        editor.putString(transfertransfano,transfanosave);
        editor.putString(exporttransfano,transfanoexport);
        editor.putString(sendtransfano,transfanosendpo);


        editor.commit();

    }

    //Receive stock Access

    public void putReceive_Access(String receivev,String receiveadd,String receivedelete,String receiveedit,String receivesave,String receiveexport,String receivesendpo){
        editor.putString(viewreceive,receivev);
        editor.putString(addreceive,receiveadd);
        editor.putString(deletereceive,receivedelete);
        editor.putString(editreceive,receiveedit);
        editor.putString(transferreceive,receivesave);
        editor.putString(exportreceive,receiveexport);
        editor.putString(sendstreceive,receivesendpo);


        editor.commit();

    }

    //Stock levels Access
    public void putStklvl_Access(String receivev){
        editor.putString(viewstklvl,receivev);



        editor.commit();

    }
    public void emplky(String empky){
        editor.putString(employeeky,empky);



        editor.commit();

    }
    /**
     * Check login method wil check user login status
     * If false it will redirect user to login page
     * Else won't do anything
     * */
    public void checkLogin(){
        // Check login status
        if(!this.isLoggedIn()){
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent(_context, yourbranchActivity.class);
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            // Add new Flag to start new Activity
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Staring Login Activity
            _context.startActivity(i);
        }

    }


    /*public void checkLogin(){
        // Check login status
        if(!this.isLoggedIn()){
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent(_context, yourbranchActivity.class);
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            // Add new Flag to start new Activity
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Staring Login Activity
            _context.startActivity(i);
        }

    }*/


    /**
     * Get stored session data
     * */
    public HashMap<String, String> getUserDetails(){
        HashMap<String, String> user = new HashMap<String, String>();
        // user name
        user.put(KEY_NAME, pref.getString(KEY_NAME, null));
        user.put(KEY_STATE, pref.getString(KEY_STATE, null));
        user.put(KEY_PIN, pref.getString(KEY_PIN, null));
        user.put(KEY_brnm, pref.getString(KEY_brnm, null));

        //service
        user.put(sview,pref.getString(sview,null));
        user.put(sedit,pref.getString(sedit,null));
        user.put(sadd,pref.getString(sadd,null));
        user.put(sdelete,pref.getString(sdelete,null));
        user.put(simport,pref.getString(simport,null));
        user.put(s_export,pref.getString(s_export,null));

        //product
        user.put(pview,pref.getString(pview,null));
        user.put(padd,pref.getString(padd,null));
        user.put(pdelete,pref.getString(pdelete,null));
        user.put(pedit,pref.getString(pedit,null));
        user.put(pimport,pref.getString(pimport,null));
        user.put(pexport,pref.getString(pexport,null));
        user.put(pstockin_hand,pref.getString(pstockin_hand,null));

        //Supplier
        user.put(suppview,pref.getString(suppview,null));
        user.put(suppadd,pref.getString(suppadd,null));
        user.put(suppdelete,pref.getString(suppdelete,null));
        user.put(suppedit,pref.getString(suppedit,null));
        user.put(suppimport,pref.getString(suppimport,null));
        user.put(suppexport,pref.getString(suppexport,null));

        //Purchase request
        user.put(viewpreq,pref.getString(viewpreq,null));
        user.put(addpreq,pref.getString(addpreq,null));
        user.put(deletepreq,pref.getString(deletepreq,null));
        user.put(editpreq,pref.getString(editpreq,null));
        user.put(transferpreq,pref.getString(transferpreq,null));
        user.put(exportpreq,pref.getString(exportpreq,null));

        //Purchase order
        user.put(viewpord,pref.getString(viewpord,null));
        user.put(addpord,pref.getString(addpord,null));
        user.put(deletepord,pref.getString(deletepord,null));
        user.put(editpord,pref.getString(editpord,null));
        user.put(transferpord,pref.getString(transferpord,null));
        user.put(exportpord,pref.getString(exportpord,null));
        user.put(sendpord,pref.getString(sendpord,null));

        //Supplier Invoice
        user.put(viewsupin,pref.getString(viewsupin,null));
        user.put(addsupin,pref.getString(addsupin,null));
        user.put(deletesupin,pref.getString(deletesupin,null));
        user.put(editsupin,pref.getString(editsupin,null));
        user.put(transfersupin,pref.getString(transfersupin,null));
        user.put(exportsupin,pref.getString(exportsupin,null));

        //Stock transfer
        user.put(viewtransf,pref.getString(viewtransf,null));
        user.put(addtransf,pref.getString(addtransf,null));
        user.put(deletetransf,pref.getString(deletetransf,null));
        user.put(edittransf,pref.getString(edittransf,null));
        user.put(transfertransf,pref.getString(transfertransf,null));
        user.put(exporttransf,pref.getString(exporttransf,null));
        user.put(sendtransf,pref.getString(sendtransf,null));

        user.put(viewtransfano,pref.getString(viewtransfano,null));
        user.put(addtransfano,pref.getString(addtransfano,null));
        user.put(deletetransfano,pref.getString(deletetransfano,null));
        user.put(edittransfano,pref.getString(edittransfano,null));
        user.put(transfertransfano,pref.getString(transfertransfano,null));
        user.put(exporttransfano,pref.getString(exporttransfano,null));
        user.put(sendtransfano,pref.getString(sendtransfano,null));

        //Receive
        user.put(viewreceive,pref.getString(viewreceive,null));
        user.put(addreceive,pref.getString(addreceive,null));
        user.put(deletereceive,pref.getString(deletereceive,null));
        user.put(editreceive,pref.getString(editreceive,null));
        user.put(transferreceive,pref.getString(transferreceive,null));
        user.put(exportreceive,pref.getString(exportreceive,null));

        user.put(viewstklvl,pref.getString(viewstklvl,null));

        user.put(employeeky,pref.getString(employeeky,null));




        return user;
    }

    /**
     * Clear session details
     * */
    public void logoutUser(){

        editor.putBoolean(IS_LOGIN, false);
        editor.commit();
        // Clearing all data from Shared Preferences
   /*     editor.clear();
        editor.commit();

        // After logout redirect user to Loing Activity
        Intent i = new Intent(_context, MainActivity.class);
        // Closing all the Activities
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // Add new Flag to start new Activity
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        // Staring Login Activity

        _context.startActivity(i);*/

    }

    /**
     * Quick check for login
     * **/
    // Get Login State
    public boolean isLoggedIn(){
        return pref.getBoolean(IS_LOGIN, false);
    }


}