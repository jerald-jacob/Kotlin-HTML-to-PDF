package com.example.vinitas.gallery.sampledata

object SelectorSettings {
    /**
     * max number of images to be selected
     */
    val SELECTOR_MAX_IMAGE_NUMBER = "selector_max_image_number"
    var mMaxImageNumber = 9

    /**
     * show camera
     */
    val SELECTOR_SHOW_CAMERA = "selector_show_camera"
    var isShowCamera = true
    val CAMERA_ITEM_PATH = "/CAMERA/CAMERA"


    /**
     * initial selected images, full path of images
     */
    val SELECTOR_INITIAL_SELECTED_LIST = "selector_initial_selected_list"
    var resultList: ArrayList<String> = ArrayList()

    // results
    val SELECTOR_RESULTS = "selector_results"

    // it can be used to filter very small images (mainly icons)
    var mMinImageSize = 50000
    val SELECTOR_MIN_IMAGE_SIZE = "selector_min_image_size"
}