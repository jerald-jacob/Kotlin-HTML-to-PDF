package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.view.View
import android.widget.RelativeLayout
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_stocklevels.*

class stocklevelsActivity : AppCompatActivity() {
    private  var viewstklvls=String()
    var brids=String()
    var db = FirebaseFirestore.getInstance()
    var brnchkeys=arrayListOf<String>()

    var maincatId = ArrayList<String>()
    var brnmsarr=ArrayList<String>()
    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stocklevels)



        //Listens internet changing movements
        //Define No connection view and other views when inetrnet connection is off.

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@stocklevelsActivity) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()
        }



     relativeslayoutdis =findViewById(R.id.relativeslayout)
     constraintLayout3dis =findViewById(R.id.constraintLayout3)
     cont =findViewById<ConstraintLayout>(R.id.container)

        net_status()//Check internet status.

        val bundle = intent.extras
        var frm = bundle!!.get("from_stock").toString()

if(frm=="mystock") {
    viewstklvls = intent.getStringExtra("viewstklvl")

    val jf = intent.getStringExtra("bkey")

    brids = jf
}


        else if(frm=="main") {
    viewstklvls = intent.getStringExtra("viewstklvl")

    val j = intent.getStringExtra("skey")

    brids = j
}
        /*val window = this.getWindow()

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)*/

// finally change the color
        /*window.setStatusBarColor(ContextCompat.getColor(this, android.R.color.black))*/
        userback.setOnClickListener {
            onBackPressed()
        }


        //Select ' My branch' option to navigate 'MybranchActivity'
        my.setOnClickListener {

            val b = Intent(applicationContext, MybranchActivity::class.java)
            b.putExtra("viewstklvl",viewstklvls)
            b.putExtra("bkey",brids)
            startActivity(b)
            finish()
            overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)


        }


        //Select 'All Branches' option to get all branches names and ids and put them to array and navigate to  'AllbranchesActivity'
        all.setOnClickListener {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();
            db.collection("branch")
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.result.isEmpty == false) {
                            if (task.result != null) {

                                maincatId.clear()

                                maincatId.add("")
                                brnchkeys.add("")
                                brnmsarr.add("Select Branch")
                                for (document in task.result) {

                                    var brid = document.id
                                    var dt = document.data
                                    var brnms = dt["nm"].toString()
                                    maincatId.add(document.id)

                                    brnmsarr.add(brnms)
                                    brnchkeys.add(brid)


                                }
                            }
                        }
                    }
                    .addOnSuccessListener {
                        pDialog.dismiss()
                        val b = Intent(applicationContext, AllbranchesActivity::class.java)
                        b.putExtra("frm","main")
                        b.putExtra("viewstklvl",viewstklvls)
                        b.putExtra("bkey",brids)
                        b.putExtra("brnmsarr",brnmsarr)
                        b.putExtra("brnchkeys",brnchkeys)
                        b.putExtra("maincatId",maincatId)

                        startActivity(b)
                        finish()
                        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                    }

        }
    }
    companion object {

 //Listens internet status whether net is on/off.


        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null


        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                                                 /// if connection is off then all views becomes disable


                constraintLayout3dis!!.visibility= View.VISIBLE
                relativeslayoutdis!!.visibility= View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {

                                 /// if connection is off then all views becomes enabled


                constraintLayout3dis!!.visibility= View.GONE

                relativeslayoutdis!!.visibility= View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }

    override fun onBackPressed() {
        finish()
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
    }

    fun net_status():Boolean{  //Check internet status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}
