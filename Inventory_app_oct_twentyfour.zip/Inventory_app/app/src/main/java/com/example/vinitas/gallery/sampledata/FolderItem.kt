package com.example.vinitas.gallery.sampledata

import java.nio.file.Files.size
import com.zfdang.multiple_images_selector.models.ImageItem


class FolderItem(var name: String, var path: String, var coverImagePath: String) {
    var mImages: ArrayList<ImageItem> = ArrayList()

    val numOfImages: String
        get() = String.format("%d", mImages.size)

    fun addImageItem(imageItem: ImageItem) {
        this.mImages.add(imageItem)
    }

    override fun toString(): String {
        return "FolderItem{" +
                "coverImagePath='" + coverImagePath + '\''.toString() +
                ", name='" + name + '\''.toString() +
                ", path='" + path + '\''.toString() +
                ", numOfImages=" + mImages.size +
                '}'.toString()
    }
}