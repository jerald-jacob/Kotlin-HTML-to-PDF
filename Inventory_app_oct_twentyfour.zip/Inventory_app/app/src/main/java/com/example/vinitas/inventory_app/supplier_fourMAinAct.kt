package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewTreeObserver
import android.widget.ScrollView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.supplier_four.*
import java.text.DecimalFormat
import java.util.*
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.util.DisplayMetrics
import android.util.Log
import android.opengl.ETC1.getHeight
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil


class Supplier_fourMainActivity : AppCompatActivity(){








    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""


    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    var vounodup=String()
    var invoicedatedup=String()
    var payduedatedup=String()
    var suppdescripdup=String()



    var reqliid = String()
    var reprnms = String()
    var pono = String()
    var recstatus = String()
    var recprice = String()
    var cess = String()
    var tot = String()
    var taxtot = String()
    var pri = String()
    var gtot = String()
    var idkey = String()
    var reckey = String()
    var nwkey = String()

    var paidsta=String()
    var stadupspin=String()

    var j=0
var datest= String()

    var idli = String()
    var imurl = String()
    var reqdt = String()
    var desc = String()
    var orddate = String()
    var postatus = String()

    var edclick= String()
    var desclistn= String()

    var frmvali= String()
    var brnchid= String()



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.supplier_four)

        //Listens internet changing movements


        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Supplier_fourMainActivity) > 0)
        {

        }
        else{

        }

        //Define No connection view when inetrnet connection is off.

        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        relativeslayoutdis=findViewById(R.id.relativeslayout)


        val layout = findViewById(R.id.scrollView2) as ScrollView
        val observer = layout.viewTreeObserver
        observer.addOnGlobalLayoutListener {


            val viewHeight = layout.getMeasuredHeight()
            val contentHeight = layout.getChildAt(0).getHeight()

            println("CONTAINR HEIGHT"+viewHeight)
            println("DEVICE HEIGHT"+contentHeight)



            //arrow mark displays for scrollabe screens.
            if (viewHeight - contentHeight < 0) {
                // scrollable
                img_arrow.visibility=View.VISIBLE

            }





          /*  j=layout.height
            val displayMetrics = DisplayMetrics()
            windowManager.defaultDisplay.getMetrics(displayMetrics)
            val height = displayMetrics.heightPixels








            if(height<j){

            }*/
        }
         // click arrow to scroll down automattically

        img_arrow.setOnClickListener {

            layout.scrollTo(0, layout.getBottom());

        }




        //Get supplier invoice details from (Supplier_third_MainAct)


        val bundle = intent.extras
        var frm = bundle!!.get("from_suppin").toString()















        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }



        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr
        }
        if (expr != null) {
            exportpurreq = expr
        }


        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")
        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }

        try{
            vounodup=intent.getStringExtra("vounodup")
            invoicedatedup=intent.getStringExtra("invoicedatedup")
            payduedatedup=intent.getStringExtra("payduedatedup")
            suppdescripdup=intent.getStringExtra("suppdescripdup")
            stadupspin=intent.getStringExtra("stadupspin")
        }
        catch (e:Exception){

        }


        var a = bundle.get("pnm") as Array<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy = bundle.get("phsn") as Array<String>
        val ly = bundle.get("pmanu") as Array<String>
        val fy = bundle.get("barcode") as Array<String>
        val gy = bundle.get("quan") as Array<String>
        val hy = bundle.get("price") as Array<String>
        val ky = bundle.get("tot") as Array<String>
        val my = bundle.get("cessup") as Array<String>
        val ny = bundle.get("igst") as Array<String>
        val cy = bundle.get("cgst") as Array<String>
        val sy = bundle.get("sgst") as Array<String>
        val oy = bundle.get("igsttotal") as Array<String>
        val py = bundle.get("cesstotarray") as Array<String>
        val iddd = bundle.get("idsofli") as Array<String>
        val idtally = bundle.get("tallyarray") as Array<String>
        val idrec    = bundle.get("receivedarray") as Array<String>
        println("REEECCCCIIIEEEVVVVEEE"+ Arrays.toString(idrec))
        println("KYYYY OOOFFFFF REEECCCCIIIEEEVVVVEEE"+ Arrays.toString(iddd))
        val spri     = bundle.get("received_price") as Array<String>
        val stot     = bundle.get("received_total") as Array<String>
        val staxt    = bundle.get("received_taxtot") as Array<String>
        val scesstot =bundle.get("received_cesstot") as Array<String>
        val sgross    = bundle.get("received_grosstot") as Array<String>
        val immy = bundle.get("image") as Array<String>




        try {
            val pz = bundle.get("pos") as Int

            val e = intent.getStringExtra("desc")
            desc = e
        } catch (e: Exception) {

    }
        try{
            val f = intent.getStringExtra("reqdate")
            reqdt = f
        } catch (e: Exception) {

        }

        try{
            val ff = intent.getStringExtra("orddate")
            orddate = ff
        } catch (e: Exception) {

        }

try{
            val stat = intent.getStringExtra("duedate")
            postatus = stat
} catch (e: Exception) {

}


        try{
            paidsta=intent.getStringExtra("status")
        }
        catch (e:Exception){

        }

try{
            val im=intent.getStringExtra("imgurl")
            imurl=im

    Picasso.with(this)
            .load(imurl)
            .into(comp_toolimg)

} catch (e: Exception) {

}
            println("PO STATUSSS"+postatus)

        val aa = intent.getStringExtra("nms")
        comttname.setText(aa)
        val liis = intent.getStringExtra("reqliid")
        reqliid = liis
        val b = intent.getStringExtra("ph")
        comphone.setText(b)
        val lii = intent.getStringExtra("pono")
        pono = lii

        val nm = intent.getStringExtra("reprnms")
        reprnms = nm

        val bridss = intent.getStringExtra("bridkey")
        brnchid = bridss

        frmvali=intent.getStringExtra("backvald")


        try{
            datest=intent.getStringExtra("datest")
        }
        catch (e:Exception){

        }
        try{
            val k=intent.getStringExtra("desclistn")
            desclistn=k
        }
        catch (e:Exception){

        }


        try{

            edclick=intent.getStringExtra("edclick")
        }
        catch (e:Exception){

        }




       /*fun updates() {
           update.visibility = View.VISIBLE
           prd_nm.isEnabled = true
           hsnsupin.isEnabled = true
           bcd_pid.isEnabled = true
           price.isEnabled = true
           quan_req_first.isEnabled = true
           cess_edt.isEnabled = true

           val pz = bundle.get("pos") as Int

           var prname = a[pz]
           prd_nm.setText(prname)


           //quantity
           var quant = gy[pz]
           var qu: Int
           qu = quant.toInt()
           receivearr.setText(qu.toString())


           //hsn code
           var prord = dsy[pz]
           hsnsupin.setText(prord)
           //price
           var prices = hy[pz]
           var pr: Int
           pr = prices.toInt()
           var prdiv = pr / qu
           price.setText(prdiv.toString())

           //barcode
           var bar = fy[pz]
           bcd_pid.setText(bar)

           //total
           var totalof = ky[pz]
           total.setText(totalof)
           gross_tot.setText(totalof)

           *//*  gross_tot.setText(totalof)*//*

           //cess
           var cssof = my[pz]
           cess_edt.setText(cssof)

           ///IGST
           var igstof = ny[pz]
           igst_edt.setText(igstof)

           //CGST
           var cgstof = cy[pz]
           cgst_edt.setText(cgstof)

           //SGST
           var sgstof = sy[pz]
           scgst_edt.setText(sgstof)


           var igsttotof = oy[pz]

           tax_tot.setText(igsttotof)

           var cesstotof = py[pz]

           cess_amt1.setText(cesstotof)

           var idof = iddd[pz]
           newid.setText(idof)
           idli = newid.text.toString()

           var tally = idtally[pz]
           tallyarr.setText(tally)

           var receive = idrec[pz]
           println("Received count" + receive)
           quan_req_first.setText(receive)


           var receivepri = spri[pz]
           pri = receivepri


           var receivetot = stot[pz]
           tot = receivetot


           var receivetaxtot = staxt[pz]
           taxtot = receivetaxtot

           var receivegrosstot = sgross[pz]
           gtot = receivegrosstot

           var receivecesstot = scesstot[pz]

           cess = receivecesstot


           quan_req_first.addTextChangedListener(object : TextWatcher {
               override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                   var prq: Float;
                   var igst: Float;
                   var ces: Float;
                   var pri: Int;
                   if (pr.isEmpty()) {
                       pri = 1
                   } else {
                       pri = pr.toString().toInt()
                   }
                   if (igst_edt.text.isEmpty()) {
                       igst = 0.0F

                   } else {
                       igst = igst_edt.text.toString().toFloat()
                   }
                   if (price.text.isEmpty()) {
                       prq = 0.0F
                   } else {
                       prq = price.text.toString().toFloat()
                   }
                   if (cess_edt.text.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess_edt.text.toString().replace("%", "").toFloat()
                   }
                   //IGST TOTAL
                   val ttot = (prq * pri) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //CESS TOTAL
                   val cesstot = (prq * pri) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   val fitot = ttot + cesstot + (prq * pri)
                   gross_tot.setText("$fitot")

                   var k = price.text.toString()
                   var l = k.toBigInteger()
                   val o = pri.toBigInteger()
                   val f = l.times(o)
                   total.setText(f.toString())

               }

               override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {

                   var prq: Float;
                   var igst: Float;
                   var ces: Float;
                   var pri: Int;
                   if (pr.isEmpty()) {
                       pri = 1
                   } else {
                       pri = pr.toString().toInt()
                   }
                   if (igst_edt.text.isEmpty()) {
                       igst = 0.0F

                   } else {
                       igst = igst_edt.text.toString().toFloat()
                   }
                   if (price.text.isEmpty()) {
                       prq = 0.0F
                   } else {
                       prq = price.text.toString().toFloat()
                   }
                   if (cess_edt.text.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess_edt.text.toString().replace("%", "").toFloat()
                   }
                   //IGST TOTAL
                   val ttot = (prq * pri) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //CESS TOTAL
                   val cesstot = (prq * pri) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   val fitot = ttot + cesstot + (prq * pri)
                   gross_tot.setText("$fitot")

                   var k = price.text.toString()
                   var l = k.toBigInteger()
                   val o = pri.toBigInteger()
                   val f = l.times(o)
                   total.setText(f.toString())
               }

               override fun afterTextChanged(s: Editable) {
               }
           })

           price.addTextChangedListener(object : TextWatcher {
               override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                   var prq: Float;
                   var igst: Float;
                   var ces: Float;
                   var qty: Float;
                   total.setText("")
                   gross_tot.setText("")
                   var pri: Int;
                   if (pr.isEmpty()) {
                       pri = 0

                   } else {
                       pri = pr.toString().toInt()
                   }
                   if (igst_edt.text.isEmpty()) {
                       igst = 0.0F

                   } else {
                       igst = igst_edt.text.toString().toFloat()
                   }

                   if (quan_req_first.text.isEmpty()) {
                       qty = 1.0F
                   } else {
                       qty = quan_req_first.text.toString().toFloat()
                   }

                   if (cess_edt.text.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess_edt.text.toString().replace("%", "").toFloat()
                   }


                   var k = quan_req_first.text.toString()
                   var l = pri.toBigInteger()
                   val oi = k.toBigInteger()
                   val f = l.times(oi)
                   total.setText(f.toString())
                   tax_tot.setText(f.toString())

                   //IGST TOTAL
                   val ttot = (pri * qty) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //CESS TOTAL
                   val cesstot = (pri * qty) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   val fitot = ttot + cesstot + (pri * qty)
                   gross_tot.setText("$fitot")

               }

               override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
                   var prq: Float;
                   var igst: Float;
                   var ces: Float;
                   var qty: Float;
                   total.setText("")
                   gross_tot.setText("")
                   var pri: Int;
                   if (pr.isEmpty()) {
                       pri = 0

                   } else {
                       pri = pr.toString().toInt()
                   }
                   if (igst_edt.text.isEmpty()) {
                       igst = 0.0F

                   } else {
                       igst = igst_edt.text.toString().toFloat()
                   }

                   if (quan_req_first.text.isEmpty()) {
                       qty = 1.0F
                   } else {
                       qty = quan_req_first.text.toString().toFloat()
                   }

                   if (cess_edt.text.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess_edt.text.toString().replace("%", "").toFloat()
                   }


                   var k = quan_req_first.text.toString()
                   var l = pri.toBigInteger()
                   val oi = k.toBigInteger()
                   val f = l.times(oi)
                   total.setText(f.toString())
                   tax_tot.setText(f.toString())

                   //IGST TOTAL
                   val ttot = (pri * qty) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //CESS TOTAL
                   val cesstot = (pri * qty) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   val fitot = ttot + cesstot + (pri * qty)
                   gross_tot.setText("$fitot")
               }

               override fun afterTextChanged(s: Editable) {
               }
           })


           cess_edt.addTextChangedListener(object : TextWatcher {
               override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {

                   var pri: Float;
                   var igst: Float;
                   var ces: Float;
                   var qty: Float;
                   if (price.text.isEmpty()) {
                       pri = 0.0F
                   } else {
                       pri = price.text.toString().toFloat()
                   }
                   if (quan_req_first.text.isEmpty()) {
                       qty = 1.0F
                   } else {
                       qty = quan_req_first.text.toString().toFloat()
                   }
                   if (igst_edt.text.isEmpty()) {
                       igst = 0.0F
                   } else {
                       igst = igst_edt.text.toString().replace("%", "").toFloat()
                   }
                   if (cess.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess.toString().replace("%", "").toFloat()
                   }

                   //cgst & sgst
                   val ans = igst / 2
                   cgst_edt.setText("$ans" + "%")
                   scgst_edt.setText("$ans" + "%")

                   //tax total
                   val ttot = (pri * qty) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //cess total
                   val cesstot = (pri * qty) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   //gross total
                   val fitot = ttot + cesstot + (pri * qty)
                   gross_tot.setText("$fitot")
               }

               override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                   var pri: Float;
                   var igst: Float;
                   var ces: Float;
                   var qty: Float;
                   if (price.text.isEmpty()) {
                       pri = 0.0F
                   } else {
                       pri = price.text.toString().toFloat()
                   }
                   if (quan_req_first.text.isEmpty()) {
                       qty = 1.0F
                   } else {
                       qty = quan_req_first.text.toString().toFloat()
                   }
                   if (igst_edt.text.isEmpty()) {
                       igst = 0.0F
                   } else {
                       igst = igst_edt.text.toString().replace("%", "").toFloat()
                   }
                   if (cess.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess.toString().replace("%", "").toFloat()
                   }

                   //cgst & sgst
                   val ans = igst / 2
                   cgst_edt.setText("$ans" + "%")
                   scgst_edt.setText("$ans" + "%")

                   //tax total
                   val ttot = (pri * qty) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //cess total
                   val cesstot = (pri * qty) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   //gross total
                   val fitot = ttot + cesstot + (pri * qty)
                   gross_tot.setText("$fitot")
               }

               override fun afterTextChanged(s: Editable) {
               }
           })
           igst_edt.addTextChangedListener(object : TextWatcher {
               override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                   var pri: Float;
                   var igst: Float;
                   var ces: Float;
                   var qty: Float;
                   if (price.text.isEmpty()) {
                       pri = 0.0F
                   } else {
                       pri = price.text.toString().toFloat()
                   }
                   if (quan_req_first.text.isEmpty()) {
                       qty = 1.0F
                   } else {
                       qty = quan_req_first.text.toString().toFloat()
                   }
                   if (ig.isEmpty()) {
                       igst = 0.0F
                   } else {
                       igst = ig.toString().replace("%", "").toFloat()
                   }
                   if (cess_edt.text.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess_edt.text.toString().replace("%", "").toFloat()
                   }

                   //cgst & sgst
                   val ans = igst / 2
                   cgst_edt.setText("$ans" + "%")
                   scgst_edt.setText("$ans" + "%")

                   //tax total
                   val ttot = (pri * qty) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //cess total
                   val cesstot = (pri * qty) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   //gross total
                   val fitot = ttot + cesstot + (pri * qty)
                   gross_tot.setText("$fitot")
               }

               override fun beforeTextChanged(ig: CharSequence, start: Int, count: Int, after: Int) {
                   var pri: Float;
                   var igst: Float;
                   var ces: Float;
                   var qty: Float;
                   if (price.text.isEmpty()) {
                       pri = 0.0F
                   } else {
                       pri = price.text.toString().toFloat()
                   }
                   if (quan_req_first.text.isEmpty()) {
                       qty = 1.0F
                   } else {
                       qty = quan_req_first.text.toString().toFloat()
                   }
                   if (ig.isEmpty()) {
                       igst = 0.0F
                   } else {
                       igst = ig.toString().replace("%", "").toFloat()
                   }
                   if (cess_edt.text.isEmpty()) {
                       ces = 0.0F
                   } else {
                       ces = cess_edt.text.toString().replace("%", "").toFloat()
                   }

                   //cgst & sgst
                   val ans = igst / 2
                   cgst_edt.setText("$ans" + "%")
                   scgst_edt.setText("$ans" + "%")

                   //tax total
                   val ttot = (pri * qty) * (igst / 100)
                   tax_tot.setText("$ttot")

                   //cess total
                   val cesstot = (pri * qty) * (ces / 100)
                   cess_amt1.setText("$cesstot")

                   //gross total
                   val fitot = ttot + cesstot + (pri * qty)
                   gross_tot.setText("$fitot")
               }

               override fun afterTextChanged(s: Editable) {
               }
           })

           update.setOnClickListener {
               val o = Intent(this@Supplier_fourMainActivity, Supplier_thirdMainActivity::class.java)
               o.putExtra("from_suppin", "update_supplier")
               var dx = prd_nm.text
               var ex = hsnsupin.text
               var fx = price.text.toString()
               var gx = receivearr.text
               var hx = bcd_pid.text
               var ix = total.text
               var jx = cess_edt.text
               var kx = igst_edt.text.toString()
               var px = cgst_edt.text.toString()
               var qx = scgst_edt.text.toString()
               var lx = tax_tot.text
               var mx = cess_amt1.text
               var tallx = tallyarr.text
               var receivex = quan_req_first.text
               var recpri = pri
               var rectot = tot
               var rectaxtt = taxtot
               var reccesstt = cess
               var recgrstt = gtot



               a[pz] = dx.toString()
               dsy[pz] = ex.toString()
               fy[pz] = hx.toString()
               gy[pz] = gx.toString()
               hy[pz] = fx.toString()
               ky[pz] = ix.toString()
               my[pz] = jx.toString()
               ny[pz] = kx.toString()
               cy[pz] = px.toString()
               sy[pz] = qx.toString()
               oy[pz] = lx.toString()
               py[pz] = mx.toString()
               idtally[pz] = tallx.toString()
               idrec[pz] = receivex.toString()
               spri[pz] = recpri.toString()
               stot[pz] = rectot.toString()
               staxt[pz] = rectaxtt.toString()
               sgross[pz] = recgrstt.toString()
               scesstot[pz] = reccesstt.toString()





               o.putExtra("renm", a)

               o.putExtra("remanu", ly)
               o.putExtra("rekey", iddd)
               o.putExtra("rehsn", dsy)
               o.putExtra("reprice", fx)
               o.putExtra("requan", gy)
               o.putExtra("rebc", fy)
               o.putExtra("retotal", ky)
               o.putExtra("recess", my)
               o.putExtra("reigst", ny)
               o.putExtra("recgst", cy)
               o.putExtra("resgst", sy)
               o.putExtra("retally", idtally)
               o.putExtra("rereceived", idrec)
               o.putExtra("rereceived_pri", spri)
               o.putExtra("rereceived_tot", stot)
               o.putExtra("rereceived_taxtot", staxt)
               o.putExtra("rereceived_cesstot", scesstot)
               o.putExtra("rereceived_grosstot", sgross)
               o.putExtra("reigst_total", oy)
               o.putExtra("recesstotal", py)
               o.putExtra("reimmg", immy)
               o.putExtra("pono", pono)
               o.putExtra("names", reprnms)
               o.putExtra("redesc", desc)
               o.putExtra("reorddate", orddate)
               o.putExtra("reestdt", reqdt)
               o.putExtra("restatus", postatus)

               o.putExtra("reids", reqliid)
               o.putExtra("titnm", comttname.text.toString())
               o.putExtra("tiphone", comphone.text.toString())
               startActivity(o)
               finish()

           }
       }*/








fun notupdate() {
    update.visibility = View.INVISIBLE
    val pz = bundle.get("pos") as Int


    var prname = a[pz]
    prd_nm.setText(prname)


    //quantity
    var quant = gy[pz]
    var qu: Int
    qu = quant.toInt()
    receivearr.setText(qu.toString())


    var totalof = ky[pz]
    var totalss: Float
    totalss = totalof.toFloat()
    tot = totalss.toString()

    //hsn code



    var prord = dsy[pz]
    hsnsupin.setText(prord)

    //price
    var prices = hy[pz]
    var pr: Float
    pr = prices.toFloat()
    var prdiv = totalss / qu
    pr=prdiv
    pri = pr.toString()
    println("PRICESS NOT UPDATE"+pri)



    //barcode
    var bar = fy[pz]
    bcd_pid.setText(bar)

    //total

    /*  gross_tot.setText(totalof)*/

    //cess
    var cssof = my[pz]

    cess_edt.setText(cssof)

    ///IGST
    var igstof = ny[pz]
    igst_edt.setText(igstof)

    //CGST
    var cgstof = cy[pz]
    cgst_edt.setText(cgstof)

    //SGST
    var sgstof = sy[pz]
    scgst_edt.setText(sgstof)


    var igsttotof = oy[pz]
    taxtot = igsttotof
    tax_tot.setText(taxtot)

    var cesstotof = py[pz]
    cess = cesstotof
    cess_amt1.setText(cess)


    var idof = iddd[pz]
    newid.setText(idof)
    idli = newid.text.toString()

    var tally = idtally[pz]
    tallyarr.setText(tally)

    var receive = idrec[pz]
    println("Received count" + receive)
    quan_req_first.setText(receive)


    var receivepri = spri[pz]
    println("Received Price" + receivepri)
    price.setText(receivepri)


    var receivetot = stot[pz]
    total.setText(receivetot)

    var receivetaxtot = staxt[pz]
    tax_tot.setText(DecimalFormat("##.##").format(receivetaxtot.toFloat()))

    var receivegrosstot = sgross[pz]
    gross_tot.setText(receivegrosstot)

    var receivecesstot = scesstot[pz]
    cess_amt1.setText(DecimalFormat("##.##").format(receivecesstot.toFloat()))


    quan_req_first.addTextChangedListener(object : TextWatcher {
        override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


        }

        override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {


        }

        override fun afterTextChanged(s: Editable) {
        }
    })

    price.addTextChangedListener(object : TextWatcher {
        override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


        }

        override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {

        }

        override fun afterTextChanged(s: Editable) {
        }
    })


    cess_edt.addTextChangedListener(object : TextWatcher {
        override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {


        }

        override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
        }

        override fun afterTextChanged(s: Editable) {
        }
    })
    igst_edt.addTextChangedListener(object : TextWatcher {
        override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {


        }

        override fun beforeTextChanged(ig: CharSequence, start: Int, count: Int, after: Int) {

        }

        override fun afterTextChanged(s: Editable) {
        }
    })

    userback.setOnClickListener {
        val o = Intent(this@Supplier_fourMainActivity,supplierFiveMainAct::class.java)
        o.putExtra("from_suppin", "update_supplier")
        var dx = prd_nm.text
        var ex = hsnsupin.text
        var fx = price.text
        var gx = receivearr.text
        var hx = bcd_pid.text
        var ix = tot
        var jx = cess_edt.text
        var kx = igst_edt.text.toString()
        var px = cgst_edt.text.toString()
        var qx = scgst_edt.text.toString()
        var lx = taxtot
        var mx = cess
        var tallx = tallyarr.text
        var receivex = quan_req_first.text
        var recpri = price.text.toString()
        var rectot = total.text
        var rectaxtt = tax_tot.text
        var reccesstt = cess_amt1.text
        var recgrstt = gross_tot.text



        a[pz] = dx.toString()
        dsy[pz] = ex.toString()
        fy[pz] = hx.toString()
        gy[pz] = gx.toString()
        hy[pz] = fx.toString()
        ky[pz] = ix.toString()
        my[pz] = jx.toString()
        ny[pz] = kx.toString()
        cy[pz] = px.toString()
        sy[pz] = qx.toString()
        oy[pz] = lx.toString()
        py[pz] = mx.toString()
        idtally[pz] = tallx.toString()
        idrec[pz] = receivex.toString()
        spri[pz] = recpri.toString()
        stot[pz] = rectot.toString()
        staxt[pz] = rectaxtt.toString()
        sgross[pz] = recgrstt.toString()
        scesstot[pz] = reccesstt.toString()





        o.putExtra("renm", a)

        o.putExtra("remanu", ly)
        o.putExtra("rekey", iddd)
        o.putExtra("rehsn", dsy)
        o.putExtra("reprice", hy)
        o.putExtra("requan", gy)
        o.putExtra("rebc", fy)
        o.putExtra("retotal", ky)
        o.putExtra("recess", my)
        o.putExtra("reigst", ny)
        o.putExtra("recgst", cy)
        o.putExtra("resgst", sy)
        o.putExtra("retally", idtally)
        o.putExtra("rereceived", idrec)
        o.putExtra("rereceived_pri", spri)
        o.putExtra("rereceived_tot", stot)
        o.putExtra("rereceived_taxtot", staxt)
        o.putExtra("rereceived_cesstot", scesstot)
        o.putExtra("rereceived_grosstot", sgross)
        o.putExtra("reigst_total", oy)
        o.putExtra("recesstotal", py)
        o.putExtra("reimmg", immy)
        o.putExtra("pono", pono)
        o.putExtra("names", reprnms)
        o.putExtra("redesc", desc)
        o.putExtra("reorddate", orddate)
        o.putExtra("reestdt", reqdt)
        o.putExtra("restatus", postatus)
        o.putExtra("stadupspin",stadupspin)

        o.putExtra("vounodup",vounodup)
        o.putExtra("invoicedatedup",invoicedatedup)
        o.putExtra("payduedatedup",payduedatedup)
        o.putExtra("suppdescripdup",suppdescripdup)



        o.putExtra("reids", reqliid)
        o.putExtra("titnm", comttname.text.toString())
        o.putExtra("tiphone", comphone.text.toString())
        o.putExtra("reimgurl",imurl)
        o.putExtra("status",paidsta)
        o.putExtra("brnchids",brnchid)
        o.putExtra("backvald",frmvali)
o.putExtra("datest",datest)
o.putExtra("edclick",edclick)

        o.putExtra("viewsuppin",  viewsuppin)
        o.putExtra("addsuppin",   addsuppin)
        o.putExtra("deletesuppin",deletesuppin)
        o.putExtra("editsuppin",     editesuppin)
        o.putExtra("transfersuppin", transfersuppin)
        o.putExtra("exportsuppin", exportsuppin)



       o.putExtra("viewpurord", viewpurord)
       o.putExtra("addpurord", addpurord)
       o.putExtra("deletepurord", deletepurord)
       o.putExtra("editpurord", editepurord)
       o.putExtra("transferpurord", transferpurord)
       o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)


        o.putExtra("viewpurreq", viewpurreq)
        o.putExtra("addpurreq", addpurreq)
        o.putExtra("deletepurreq", deletepurreq)
        o.putExtra("editpurreq", editepurreq)
        o.putExtra("transferpurreq", transferpurreq)
        o.putExtra("exportpurreq", exportpurreq)




        o.putExtra("desclistn",desclistn)

        startActivity(o)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()
    }
}

         notupdate()



        cgst_edt.isEnabled = false
        scgst_edt.isEnabled = false
        igst_edt.isEnabled = false


        igst_radio.setOnClickListener {
            if (igst_radio.isChecked == true) {
                csgst_radio.isChecked = false
                igst_edt.isEnabled = true
                cgst_edt.setHintTextColor(Color.parseColor("#99546e7a"));
                scgst_edt.setHintTextColor(Color.parseColor("#99546e7a"));
                cgst_edt.isEnabled = false
                scgst_edt.isEnabled = false
                igst_edt.setHintTextColor(Color.parseColor("#546e7a"));
            }
        }
        csgst_radio.setOnClickListener {
            if (csgst_radio.isChecked == true) {
                igst_radio.isChecked = false
                cgst_edt.setHintTextColor(Color.parseColor("#546e7a"));
                scgst_edt.setHintTextColor(Color.parseColor("#546e7a"));
                cgst_edt.isEnabled = true
                scgst_edt.isEnabled = true
                igst_edt.isEnabled = false
                igst_edt.setHintTextColor(Color.parseColor("#99546e7a"));
            }
        }


        //Receive function

        var tt = "Complete"
       /* quan_received.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var pri: Int;
                if (pr.isEmpty()) {
                    pri = 1
                } else {
                    pri = pr.toString().toInt()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }
                if (price.text.isEmpty()) {
                    prq = 0.0F
                } else {
                    prq = price.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq * pri) * (igst / 100)
                tax_tot1.setText("$ttot")

                //CESS TOTAL
                val cesstot = (prq * pri) * (ces / 100)
                cess_amt.setText("$cesstot")

                val fitot = ttot + cesstot + (prq * pri)
                gross_tot1.setText("$fitot")

                var k = purch_pri.text.toString()
                var l = k.toBigInteger()
                val o = pri.toBigInteger()
                val f = l.times(o)
                total_two.setText(f.toString())
                if (pr.toString()== quan_req_first.text.toString()) {
                    tallyarr.text = tt
                    postatus=tallyarr.text.toString()
                    println("Received" + tallyarr.text)
                } else {
                    tallyarr.text = "InComplete"
                    postatus=tallyarr.text.toString()
                    println("Not Received" + tallyarr.text)
                }


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {

                var prq: Float;
                var igst: Float;
                var ces: Float;
                var pri: Int;
                if (pr.isEmpty()) {
                    pri = 1
                } else {
                    pri = pr.toString().toInt()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }
                if (purch_pri.text.isEmpty()) {
                    prq = 0.0F
                } else {
                    prq = purch_pri.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq * pri) * (igst / 100)
                tax_tot1.setText("$ttot")

                //CESS TOTAL
                val cesstot = (prq * pri) * (ces / 100)
                cess_amt1.setText("$cesstot")

                val fitot = ttot + cesstot + (prq * pri)
                gross_tot1.setText("$fitot")

                var k = purch_pri.text.toString()
                var l = k.toBigInteger()
                val o = pri.toBigInteger()
                val f = l.times(o)
                total.setText(f.toString())
                if (pr.toString()== quan_req_first.text.toString()) {
                    tallyarr.text = tt
                    postatus=tallyarr.text.toString()
                    println("Received" + tallyarr.text)
                } else {
                    tallyarr.text = "InComplete"
                    postatus=tallyarr.text.toString()
                    println("Not Received" + tallyarr.text)
                }
            }

            override fun afterTextChanged(s: Editable) {
            }
        })*/



        /*price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                total.setText("")
                gross_tot.setText("")
                var pri: Int;
                if (pr.isEmpty()) {
                    pri = 0

                } else {
                    pri = pr.toString().toInt()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }

                if (quan_received.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_received.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }


                var k = quan_received.text.toString()
                try {
                    var l = pri.toBigInteger()
                    val oi = k.toBigInteger()
                    val f = l.times(oi)
                    total_two.setText(f.toString())
                    tax_tot1.setText(f.toString())
                }
                catch(e:Exception) {

                }



                //IGST TOTAL
                val ttot = (pri * qty) * (igst / 100)
                tax_tot1.setText("$ttot")

                //CESS TOTAL
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt.setText("$cesstot")

                val fitot = ttot + cesstot + (pri * qty)
                gross_tot1.setText("$fitot")


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
                var prq: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                total_two.setText("")
                gross_tot1.setText("")
                var pri: Int;
                if (pr.isEmpty()) {
                    pri = 0

                } else {
                    pri = pr.toString().toInt()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }

                if (quan_received.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_received.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }


                var k = quan_received.text.toString()
                var l = pri.toBigInteger()
                val oi = k.toBigInteger()
                val f = l.times(oi)
                total_two.setText(f.toString())
                tax_tot1.setText(f.toString())

                //IGST TOTAL
                val ttot = (pri * qty) * (igst / 100)
                tax_tot1.setText("$ttot")

                //CESS TOTAL
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt.setText("$cesstot")

                val fitot = ttot + cesstot + (pri * qty)
                gross_tot1.setText("$fitot")
            }

            override fun afterTextChanged(s: Editable) {
            }
        })*/


        }
    override fun onBackPressed() {



        //Back Action

        val bundle = intent.extras
        var frm = bundle!!.get("from_suppin").toString()

        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }

        var a = bundle.get("pnm") as Array<String>
        println(a)
        /*     val b=bundle.get("id") as Array<String>*/

        val dsy = bundle.get("phsn") as Array<String>
        val ly = bundle.get("pmanu") as Array<String>
        val fy = bundle.get("barcode") as Array<String>
        val gy = bundle.get("quan") as Array<String>
        val hy = bundle.get("price") as Array<String>
        val ky = bundle.get("tot") as Array<String>
        val my = bundle.get("cessup") as Array<String>
        val ny = bundle.get("igst") as Array<String>
        val cy = bundle.get("cgst") as Array<String>
        val sy = bundle.get("sgst") as Array<String>
        val oy = bundle.get("igsttotal") as Array<String>
        val py = bundle.get("cesstotarray") as Array<String>
        val iddd = bundle.get("idsofli") as Array<String>
        val idtally = bundle.get("tallyarray") as Array<String>
        val idrec    = bundle.get("receivedarray") as Array<String>
        println("REEECCCCIIIEEEVVVVEEE"+ Arrays.toString(idrec))
        println("KYYYY OOOFFFFF REEECCCCIIIEEEVVVVEEE"+ Arrays.toString(iddd))
        val spri     = bundle.get("received_price") as Array<String>
        val stot     = bundle.get("received_total") as Array<String>
        val staxt    = bundle.get("received_taxtot") as Array<String>
        val scesstot =bundle.get("received_cesstot") as Array<String>
        val sgross    = bundle.get("received_grosstot") as Array<String>
        val immy = bundle.get("image") as Array<String>



        try{
            datest=intent.getStringExtra("datest")
        }
        catch (e:Exception){

        }
        try {
            val pz = bundle.get("pos") as Int

            val e = intent.getStringExtra("desc")
            desc = e
            val f = intent.getStringExtra("reqdate")
            reqdt = f
            val ff = intent.getStringExtra("orddate")
            orddate = ff

            val stat = intent.getStringExtra("duedate")
            postatus = stat

            val im=intent.getStringExtra("imgurl")
            imurl=im
            println("PO STATUSSS"+postatus)
        } catch (e: Exception) {

        }
        try{
            paidsta=intent.getStringExtra("status")
        }
        catch (e:Exception){

        }

        try{

            edclick=intent.getStringExtra("edclick")
        }
        catch (e:Exception){

        }


        val aa = intent.getStringExtra("nms")
        comttname.setText(aa)
        val liis = intent.getStringExtra("reqliid")
        reqliid = liis
        val b = intent.getStringExtra("ph")
        comphone.setText(b)
        val lii = intent.getStringExtra("pono")
        pono = lii

        val nm = intent.getStringExtra("reprnms")
        reprnms = nm

        val bridss = intent.getStringExtra("bridkey")
        brnchid = bridss
        // TODO Auto-generated method stub

        update.visibility = View.INVISIBLE
        val pz = bundle.get("pos") as Int


        var prname = a[pz]
        prd_nm.setText(prname)


        //quantity
        var quant = gy[pz]
        var qu: Int
        qu = quant.toInt()
        receivearr.setText(qu.toString())

        var totalof = ky[pz]
        var totalss: Float
        totalss = totalof.toFloat()
        tot = totalss.toString()
        //hsn code



        var prord = dsy[pz]
        hsnsupin.setText(prord)
        //price
        var prices = hy[pz]
        var pr: Float
        pr = prices.toFloat()
        var prdiv = totalss / qu
        pr=prdiv
        pri = pr.toString()

        //barcode
        var bar = fy[pz]
        bcd_pid.setText(bar)

        //total

        /*  gross_tot.setText(totalof)*/

        //cess
        var cssof = my[pz]

        cess_edt.setText(cssof)

        ///IGST
        var igstof = ny[pz]
        igst_edt.setText(igstof)

        //CGST
        var cgstof = cy[pz]
        cgst_edt.setText(cgstof)

        //SGST
        var sgstof = sy[pz]
        scgst_edt.setText(sgstof)


        var igsttotof = oy[pz]
        taxtot = igsttotof

        var cesstotof = py[pz]
        cess = cesstotof

        var idof = iddd[pz]
        newid.setText(idof)
        idli = newid.text.toString()

        var tally = idtally[pz]
        tallyarr.setText(tally)

        var receive = idrec[pz]
        println("Received count" + receive)
        quan_req_first.setText(receive)


        var receivepri = spri[pz]
        price.setText(receivepri)


        var receivetot = stot[pz]
        total.setText(receivetot)

        var receivetaxtot = staxt[pz]
        tax_tot.setText(receivetaxtot)

        var receivegrosstot = sgross[pz]
        gross_tot.setText(receivegrosstot)

        var receivecesstot = scesstot[pz]
        cess_amt1.setText(DecimalFormat("##.##").format(receivecesstot.toFloat()))


        quan_req_first.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {

                var prq: Float;
                var igst: Float;
                var ces: Float;
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 1F
                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }
                if (price.text.isEmpty()) {
                    prq = 0.0F
                } else {
                    prq = price.text.toString().toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }
                //IGST TOTAL
                val ttot = (prq * pri) * (igst / 100)
                tax_tot.setText(DecimalFormat("##.##").format(ttot))

                //CESS TOTAL
                val cesstot = (prq * pri) * (ces / 100)
                cess_amt1.setText(DecimalFormat("##.##").format(cesstot))

                val fitot = ttot + cesstot + (prq * pri)
                gross_tot.setText(DecimalFormat("##.##").format(fitot))

                var k = price.text.toString()
                var l = k.toBigDecimal()
                val o = pri.toBigDecimal()
                val f = l.times(o)
                total.setText(f.toString())
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(pr: CharSequence, start: Int, count: Int, after: Int) {
                /*var prq: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                total.setText("")
                gross_tot.setText("")
                var pri: Float;
                if (pr.isEmpty()) {
                    pri = 0F

                } else {
                    pri = pr.toString().toFloat()
                }
                if (igst_edt.text.isEmpty()) {
                    igst = 0.0F

                } else {
                    igst = igst_edt.text.toString().toFloat()
                }

                if (quan_req_first.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_req_first.text.toString().toFloat()
                }

                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }


                var k = quan_req_first.text.toString()
                var l = pri.toBigDecimal()
                val oi = k.toBigDecimal()
                val f = l.times(oi)
                total.setText(f.toString())
                tax_tot.setText(DecimalFormat("##.##").format(f))

                //IGST TOTAL
                val ttot = (pri * qty) * (igst / 100)
                tax_tot.setText(DecimalFormat("##.##").format(ttot))

                //CESS TOTAL
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt1.setText(DecimalFormat("##.##").format(cesstot))

                val fitot = ttot + cesstot + (pri * qty)
                gross_tot.setText(DecimalFormat("##.##").format(fitot))*/
            }

            override fun afterTextChanged(s: Editable) {
            }
        })


        cess_edt.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })
        igst_edt.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(ig: CharSequence, start: Int, count: Int, after: Int) {
              /*  var pri: Float;
                var igst: Float;
                var ces: Float;
                var qty: Float;
                if (price.text.isEmpty()) {
                    pri = 0.0F
                } else {
                    pri = price.text.toString().toFloat()
                }
                if (quan_req_first.text.isEmpty()) {
                    qty = 1.0F
                } else {
                    qty = quan_req_first.text.toString().toFloat()
                }
                if (ig.isEmpty()) {
                    igst = 0.0F
                } else {
                    igst = ig.toString().replace("%", "").toFloat()
                }
                if (cess_edt.text.isEmpty()) {
                    ces = 0.0F
                } else {
                    ces = cess_edt.text.toString().replace("%", "").toFloat()
                }

                //cgst & sgst
                val ans = igst / 2
                cgst_edt.setText("$ans" + "%")
                scgst_edt.setText("$ans" + "%")

                //tax total
                val ttot = (pri * qty) * (igst / 100)
                tax_tot.setText(DecimalFormat("##.##").format(ttot))

                //cess total
                val cesstot = (pri * qty) * (ces / 100)
                cess_amt1.setText(DecimalFormat("##.##").format(cesstot))

                //gross total
                val fitot = ttot + cesstot + (pri * qty)
                gross_tot.setText(DecimalFormat("##.##").format(fitot))*/
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        val o = Intent(this@Supplier_fourMainActivity,supplierFiveMainAct::class.java)
        o.putExtra("from_suppin", "update_supplier")
        var dx = prd_nm.text
        var ex = hsnsupin.text
        var fx = price.text.toString()
        var gx = receivearr.text
        var hx = bcd_pid.text
        var ix = tot
        var jx = cess_edt.text
        var kx = igst_edt.text.toString()
        var px = cgst_edt.text.toString()
        var qx = scgst_edt.text.toString()
        var lx = taxtot
        var mx = cess
        var tallx = tallyarr.text
        var receivex = quan_req_first.text
        var recpri = price.text.toString()
        var rectot = total.text
        var rectaxtt = tax_tot.text
        var reccesstt = cess_amt1.text
        var recgrstt = gross_tot.text



        a[pz] = dx.toString()
        dsy[pz] = ex.toString()
        fy[pz] = hx.toString()
        gy[pz] = gx.toString()
        hy[pz] = fx.toString()
        ky[pz] = ix.toString()
        my[pz] = jx.toString()
        ny[pz] = kx.toString()
        cy[pz] = px.toString()
        sy[pz] = qx.toString()
        oy[pz] = lx.toString()
        py[pz] = mx.toString()
        idtally[pz] = tallx.toString()
        idrec[pz] = receivex.toString()
        spri[pz] = recpri.toString()
        stot[pz] = rectot.toString()
        staxt[pz] = rectaxtt.toString()
        sgross[pz] = recgrstt.toString()
        scesstot[pz] = reccesstt.toString()





        o.putExtra("renm", a)

        o.putExtra("remanu", ly)
        o.putExtra("rekey", iddd)
        o.putExtra("rehsn", dsy)
        o.putExtra("reprice", hy)
        o.putExtra("requan", gy)
        o.putExtra("rebc", fy)
        o.putExtra("retotal", ky)
        o.putExtra("recess", my)
        o.putExtra("reigst", ny)
        o.putExtra("recgst", cy)
        o.putExtra("resgst", sy)
        o.putExtra("retally", idtally)
        o.putExtra("rereceived", idrec)
        o.putExtra("rereceived_pri", spri)
        o.putExtra("rereceived_tot", stot)
        o.putExtra("rereceived_taxtot", staxt)
        o.putExtra("rereceived_cesstot", scesstot)
        o.putExtra("rereceived_grosstot", sgross)
        o.putExtra("reigst_total", oy)
        o.putExtra("recesstotal", py)
        o.putExtra("reimmg", immy)
        o.putExtra("pono", pono)
        o.putExtra("names", reprnms)
        o.putExtra("redesc", desc)
        o.putExtra("reorddate", orddate)
        o.putExtra("reestdt", reqdt)
        o.putExtra("restatus", postatus)
        o.putExtra("status",paidsta)

        o.putExtra("vounodup",vounodup)
        o.putExtra("invoicedatedup",invoicedatedup)
        o.putExtra("payduedatedup",payduedatedup)
        o.putExtra("suppdescripdup",suppdescripdup)
        o.putExtra("stadupspin",stadupspin)



        o.putExtra("edclick",edclick)

        o.putExtra("reids", reqliid)
        o.putExtra("titnm", comttname.text.toString())
        o.putExtra("tiphone", comphone.text.toString())
        o.putExtra("reimgurl",imurl)
        o.putExtra("brnchids",brnchid)
        o.putExtra("backvald",frmvali)
        o.putExtra("datest",datest)

        o.putExtra("viewsuppin",  viewsuppin)
        o.putExtra("addsuppin",   addsuppin)
        o.putExtra("deletesuppin",deletesuppin)
        o.putExtra("editsuppin",     editesuppin)
        o.putExtra("transfersuppin", transfersuppin)
        o.putExtra("exportsuppin", exportsuppin)



        o.putExtra("viewpurord", viewpurord)
        o.putExtra("addpurord", addpurord)
        o.putExtra("deletepurord", deletepurord)
        o.putExtra("editpurord", editepurord)
        o.putExtra("transferpurord", transferpurord)
        o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)


        o.putExtra("viewpurreq", viewpurreq)
        o.putExtra("addpurreq", addpurreq)
        o.putExtra("deletepurreq", deletepurreq)
        o.putExtra("editpurreq", editepurreq)
        o.putExtra("transferpurreq", transferpurreq)
        o.putExtra("exportpurreq", exportpurreq)



        o.putExtra("desclistn",desclistn)

        startActivity(o)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()

    }

    companion object {



        var pDialogs: SweetAlertDialog? = null
        private var constraintLayout3dis:ConstraintLayout?=null
        private var relativeslayoutdis: RelativeLayout? = null

        private val log_str: String? = null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE


            }
            else
            {
                constraintLayout3dis!!.visibility=View.GONE
                relativeslayoutdis!!.visibility=View.GONE


            }
        }
    }


    }

