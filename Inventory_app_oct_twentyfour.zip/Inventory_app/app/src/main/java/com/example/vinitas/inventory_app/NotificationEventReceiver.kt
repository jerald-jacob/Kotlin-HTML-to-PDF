package com.example.vinitas.inventory_app

import android.app.PendingIntent
import android.content.Intent
import android.app.AlarmManager
import android.content.Context
import android.support.v4.content.WakefulBroadcastReceiver
import android.util.Log
import java.util.*


/**
 * Created by Vinitas on 03/05/2018.
 */
class  NotificationEventReceiver : WakefulBroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        var serviceIntent: Intent? = null
        if (ACTION_START_NOTIFICATION_SERVICE == action) {
            Log.i(javaClass.simpleName, "onReceive from alarm, starting notification service")
            serviceIntent = NotificationIntentService.createIntentStartNotificationService(context)
        } else if (ACTION_DELETE_NOTIFICATION == action) {
            Log.i(javaClass.simpleName, "onReceive delete notification action, starting notification service to handle delete")
            serviceIntent = NotificationIntentService.createIntentDeleteNotification(context)
        }

        if (serviceIntent != null) {
            startWakefulService(context, serviceIntent)
        }
    }

    companion object {

        private val ACTION_START_NOTIFICATION_SERVICE = "ACTION_START_NOTIFICATION_SERVICE"
        private val ACTION_DELETE_NOTIFICATION = "ACTION_DELETE_NOTIFICATION"
        private val NOTIFICATIONS_INTERVAL_IN_HOURS =5000
        var alarmCalendar = Calendar.getInstance();

        val alarmTime = alarmCalendar.getTimeInMillis();

        fun setupAlarm(context: Context) {
            val calendar = Calendar.getInstance()
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val alarmIntent = getStartPendingIntent(context)
            alarmManager.setRepeating(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(),
                    1000 * 60 * 60, alarmIntent);
        }

        private fun getTriggerAt(now: Date): Long {
            val calendar = Calendar.getInstance()
            calendar.setTime(now)
            //calendar.add(Calendar.HOUR, NOTIFICATIONS_INTERVAL_IN_HOURS);
            return calendar.getTimeInMillis()
        }


        private fun getStartPendingIntent(context: Context): PendingIntent {
            val intent = Intent(context, NotificationEventReceiver::class.java)
            intent.action = ACTION_START_NOTIFICATION_SERVICE
            return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
        }

        fun getDeleteIntent(context: Context): PendingIntent {
            val intent = Intent(context, NotificationEventReceiver::class.java)
            intent.action = ACTION_DELETE_NOTIFICATION
            return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
        }
    }
}