package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Build
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v4.content.ContextCompat
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.ListView
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_another_select.*
import kotlinx.android.synthetic.main.activity_scroll.*


class AnotherSelectActivity : AppCompatActivity() {
    var bn= arrayOf<String>()
    var brnchid= arrayOf<String>()
    var loc=arrayOf<String>()
    var rekey=String()
    var db = FirebaseFirestore.getInstance()
    var esc= String()
    var upstr= String()
    var numberstr= String()
    var pin= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()
    var supkyval= String()
    var bsupkyval= String()
    var origisearch= arrayOf<String>()

    var brstates= String()
    var states= String()
    var pins= String()
    internal lateinit var session: SessionManagement








    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""

    var origid= String()
    val TAG = "some"

    var supkyarray= arrayOf<String>()
    var bsupkykyarray= arrayOf<String>()
    internal var dpic=arrayOf(R.drawable.ic_launcher_background,R.drawable.ic_launcher_background,R.drawable.ic_launcher_background)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_another_select)


        net_status()


        session = SessionManagement(applicationContext)
        session.checkLogin()
        val user = session.userDetails
        val name = user[SessionManagement.KEY_STATE]
        states = name.toString()


        searching.setOnClickListener {
            cardsearch.visibility= View.VISIBLE
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@AnotherSelectActivity,R.anim.slide_to_right))

            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }

        var sd= String()
        var x= String()
        var reg= String()

        val u=intent.getStringExtra("other_rbky")
        rekey=u






        val ad = intent.getStringExtra("addtrans")
        val ed = intent.getStringExtra("edittrans")
        val del = intent.getStringExtra("deletetrans")
        val vi=intent.getStringExtra("viewtrans")
        val tran=intent.getStringExtra("transfertrans")
        val ex=intent.getStringExtra("exporttrans")

        if (ad != null) {
            addtrans = ad
        }
        if (ed != null) {
            editetrans = ed
        }
        if (del != null) {
            deletetrans = del
        }
        if (vi != null) {
            viewtrans = vi
        }
        if (tran != null) {
            transfertrans = tran
        }
        if (ex != null) {
            exporttrans = ex
        }

        back3.setOnClickListener {
            finish()
        }





        fun get() {
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();
            db.collection("branch")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                        var branchid = arrayOf<String>()
                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()
                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }


                        for (document in value) {

                            Log.d("d", "key --- " + document.id + " => " + document.data)
                            println(document.data)

                            var dt = document.data
                            var ids = (document.id)


                            var name = (dt["nm"]).toString()

                            var mble = (dt["cty"]).toString()
                            var brpin = (dt["pcd"]).toString()
                            var brstate = (dt["st"]).toString()

                            brstates=brstate

                            if (ids == rekey) {

                            } else {
                                branchid = branchid.plusElement(ids)
                                nameArray = nameArray.plusElement(name)
                                bn = nameArray
                                idsArray = idsArray.plusElement("$mble  $brpin , $brstate")
                                loc = idsArray
                                brnchid = branchid

                            }
                        }
                        pDialog.dismiss()

                        if(states!=brstates){
                            val whatever = selectbranchAdapter(this@AnotherSelectActivity, branchid, nameArray, idsArray)
                            ablist.adapter = whatever
                        }

                        /*whatever.notifyDataSetChanged()*/

                    })

        }
        get()


        searchedit.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(s: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

                progressBar5.visibility=View.VISIBLE
                ablist.visibility=View.GONE

                sd = s.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                val pinStr="^\\d{6,}\$"


                println("TYPED VALUED" + x)


                fun pincodeget() {
                    if ((s.length >= 6)&&(regtr=="pin")) {
                        noresfo.visibility=View.GONE
                        ablist.visibility=View.VISIBLE
                        var branchid = arrayOf<String>()
                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        db.collection("branch").orderBy("pcd").startAt(pin).endAt(esc)
                                .get()
                                .addOnCompleteListener { task ->
                                    println(task.result)
                                    if (task.isSuccessful) {
                                        if (task.result.isEmpty == false) {
                                            for (document in task.result) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)
                                                var dt = document.data
                                                var ids = (document.id)



                                                var name = (dt["nm"]).toString()

                                                var mble = (dt["cty"]).toString()
                                                var brpin = (dt["pcd"]).toString()
                                                var brstate = (dt["st"]).toString()
                                                branchid=branchid.plusElement(ids)
                                                nameArray = nameArray.plusElement(name)
                                                bn=nameArray
                                                idsArray = idsArray.plusElement("$mble  $brpin , $brstate")
                                                loc=idsArray
                                                brnchid=branchid

                                                brstates=brstate

                                                /*  idss=idss.plusElement(path)
                                          i=idss
                                          println(id)
                                          println(i)*/
                                            }
                                            for (i in 0 until branchid.count()) {
                                                var ail = branchid[i]
                                                bsupkyval = ail
                                            }
                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + origid)
                                            if(bsupkyval==rekey){
                                                noresfo.visibility = View.VISIBLE
                                                ablist.visibility = View.GONE
                                                progressBar5.visibility=View.GONE
                                            }
                                            else {
                                                ablist.visibility = View.VISIBLE

                                                progressBar5.visibility=View.GONE
                                                if(states!=brstates){
                                                    val whatever = selectbranchAdapter(this@AnotherSelectActivity,branchid,nameArray,idsArray)
                                                    ablist.adapter = whatever
                                                }
                                            }


                                        } else {
                                            progressBar5.visibility=View.GONE
                                            println("NO RECORDSSSS FOUNDD")
                                            noresfo.visibility=View.VISIBLE
                                            ablist.visibility=View.GONE
                                        }
                                    }
                                    else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }
                                }

                    }
                }


                fun priget() {
                    if (s.length >= 2) {
                        noresfo.visibility=View.GONE
                        ablist.visibility=View.VISIBLE
                        var branchid = arrayOf<String>()
                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        db.collection("branch").orderBy("id").startAt(numberstr).endAt(esc)
                                .get()
                                .addOnCompleteListener { task ->
                                    println(task.result)
                                    if (task.isSuccessful) {
                                        if (task.result.isEmpty == false) {
                                            for (document in task.result) {

                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                println(document.data)
                                                var dt = document.data
                                                var ids = (document.id)

                                                var name = (dt["nm"]).toString()

                                                var mble = (dt["cty"]).toString()
                                                var brpin = (dt["pcd"]).toString()
                                                var brstate = (dt["st"]).toString()
                                                branchid=branchid.plusElement(ids)
                                                nameArray = nameArray.plusElement(name)
                                                bn=nameArray
                                                idsArray = idsArray.plusElement("$mble  $brpin , $brstate")
                                                loc=idsArray
                                                brnchid=branchid

                                                brstates=brstate


                                                /*  idss=idss.plusElement(path)
                                          i=idss
                                          println(id)
                                          println(i)*/
                                            }
                                            for (i in 0 until branchid.count()) {
                                                var ail = branchid[i]
                                                bsupkyval = ail
                                            }
                                            println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                            println("SAVE KEYYYY" + origid)
                                            if(bsupkyval==rekey){
                                                noresfo.visibility = View.VISIBLE
                                                ablist.visibility = View.GONE
                                                progressBar5.visibility=View.GONE

                                            }
                                            else {
                                                ablist.visibility = View.VISIBLE

                                                progressBar5.visibility=View.GONE
                                                if(states!=brstates){
                                                    val whatever = selectbranchAdapter(this@AnotherSelectActivity,branchid,nameArray,idsArray)
                                                    ablist.adapter = whatever
                                                }

                                            }


                                        } else {
                                            println("NO RECORDSSSS FOUNDD")
                                            pincodeget()
                                        }
                                    }
                                    else {
                                        Log.w(TAG, "Error getting documents.", task.exception)
                                    }
                                }

                    }
                }





                if (x.trim().matches(pinStr.toRegex()))
                {
                    upstr = x
                    println("CAME INTO PIN NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    pin=upstr
                    regtr="pin"
                    pincodeget()

                    //write code here for success
                }

                else if (x.trim().matches(regexStr.toRegex())) {
                    upstr = x
                    println("CAME INTO NUMBER"+upstr)
                    var escp = x + '\uf8ff'
                    esc = escp
                    reg = upstr
                    numberstr=upstr
                    regtr="num"
                    priget()

                    //write code here for success
                }


                if(x!==reg) {
                    val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                    upstr = upperString

                    var escp = upperString + '\uf8ff'
                    esc = escp

                    println("CAPPPSSSS" + upperString)
                }


                if ((s.length >= 3)&&(x!==reg)) {

                    noresfo.visibility=View.GONE
                    ablist.visibility=View.VISIBLE
                    var branchid = arrayOf<String>()
                    var idsArray = arrayOf<String>()
                    var nameArray = arrayOf<String>()

                    db.collection("branch").orderBy("nm").startAt(upstr).endAt(esc)
                            .get()
                            .addOnCompleteListener { task ->
                                println(task.result)
                                if (task.isSuccessful) {
                                    if (task.result.isEmpty == false) {
                                        for (document in task.result) {

                                            Log.d("d", "key --- " + document.id + " => " + document.data)
                                            println(document.data)
                                            var dt = document.data
                                            var ids = (document.id)



                                            var name = (dt["nm"]).toString()

                                            var mble = (dt["cty"]).toString()
                                            var brpin = (dt["pcd"]).toString()
                                            var brstate = (dt["st"]).toString()
                                            branchid=branchid.plusElement(ids)
                                            nameArray = nameArray.plusElement(name)
                                            bn=nameArray
                                            idsArray = idsArray.plusElement("$mble  $brpin , $brstate")
                                            loc=idsArray
                                            brnchid=branchid

                                            brstates=brstate
                                            /*  idss=idss.plusElement(path)
                                              i=idss
                                              println(id)
                                              println(i)*/






                                        }
                                        for (i in 0 until branchid.count()) {
                                            var ail = branchid[i]
                                            bsupkyval = ail
                                        }
                                        println("SAVEKEYS GET FRESTORE TO IF CHECK" + (bsupkyval))
                                        println("SAVE KEYYYY" + origid)
                                        if(bsupkyval==rekey){
                                            noresfo.visibility = View.VISIBLE
                                            ablist.visibility = View.GONE
                                            progressBar5.visibility=View.GONE

                                        }
                                        else {
                                            ablist.visibility = View.VISIBLE

                                            progressBar5.visibility=View.GONE

                                            if(states!=brstates){
                                                val whatever = selectbranchAdapter(this@AnotherSelectActivity,branchid,nameArray,idsArray)
                                                ablist.adapter = whatever
                                            }
                                        }






                                    } else {
                                        println("NO RECORDSSSS FOUNDD")
                                        noresfo.visibility=View.VISIBLE
                                        ablist.visibility=View.GONE
                                        progressBar5.visibility=View.GONE

                                    }


                                } else {
                                    Log.w(TAG, "Error getting documents.", task.exception)
                                }
                            }

                }








                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(searchedit.text.toString().isEmpty())
                {
                    ablist.visibility=View.VISIBLE
                    noresfo.visibility=View.GONE
                    progressBar5.visibility=View.GONE

                    get()


                }
            }
        })
        searback1.setOnClickListener {
            searchedit.setText("")

            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@AnotherSelectActivity,R.anim.slide_to_left))
            cardsearch.visibility=View.GONE
            noresfo.visibility=View.GONE
            ablist.visibility=View.VISIBLE
            progressBar5.visibility=View.GONE

            get()
            /* nores.visibility=View.INVISIBLE
             clilist1.visibility=View.VISIBLE
             searchedit.setText("")*/
            /* get()*/
        }



        ablist.setOnItemClickListener { parent, view, position, id  ->

            val b = Intent(applicationContext,Mainstk_branch_one::class.java)
            b.putExtra("brchnm",bn[position])
            b.putExtra("brchloc",loc[position])
            b.putExtra("brnchky",brnchid[position])
            b.putExtra("originky",rekey)
            b.putExtra("viewtrans", viewtrans)
            b.putExtra("addtrans", addtrans)
            b.putExtra("edittrans", editetrans)
            b.putExtra("deletetrans", deletetrans)
            b.putExtra("transfertrans", transfertrans)
            b.putExtra("exporttrans", exporttrans)
            b.putExtra("from","branch")
            startActivity(b)
            finish()
        }
    }
    override fun onBackPressed()

    {

        if(cardsearch.visibility==View.VISIBLE){
            cardsearch.visibility=View.GONE
        }
        else{
            finish()
        }
    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
