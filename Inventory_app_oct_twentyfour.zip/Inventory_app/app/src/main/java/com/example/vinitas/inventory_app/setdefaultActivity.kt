package com.example.vinitas.inventory_app

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_setdefault.*

class setdefaultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setdefault)
        back1.setOnClickListener {
            finish()
        }
        set.setOnClickListener {
            val b2 = Intent(applicationContext, verifyadminActivity::class.java)
            startActivity(b2)
        }
    }
}
