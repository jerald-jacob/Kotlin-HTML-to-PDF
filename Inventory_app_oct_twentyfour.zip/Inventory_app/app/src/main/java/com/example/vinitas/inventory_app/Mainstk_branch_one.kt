package com.example.vinitas.inventory_app

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.support.constraint.ConstraintLayout
import android.support.design.widget.FloatingActionButton
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.*
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
/*import com.itextpdf.text.*
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfContentByte
import com.itextpdf.text.pdf.PdfPTable
import com.itextpdf.text.pdf.PdfWriter*/
import kotlinx.android.synthetic.*

import kotlinx.android.synthetic.main.activity_setdefault.view.*
import kotlinx.android.synthetic.main.activity_with_state.*
import kotlinx.android.synthetic.main.scroll_branch_one.*

import java.io.*


import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import java.nio.file.Files.size
import java.text.DecimalFormat
import java.util.Objects.compare


class Mainstk_branch_one : AppCompatActivity() {




    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }


    var dirpath: String? = null
    var pri = arrayListOf<String>()
    var origiky= String()
    var keyofbrnch = String()
    var descriplistener= String()
    var listListener= String()
    var deletelistener=String()


    var sendst=String()
    var descripdup=String()
    var orignm=String()
    var stdatedup=String()


    var fori=0

    var grosscheck=String()
var TAG="some"
var db=FirebaseFirestore.getInstance()

    var pdfFile= String()
    private var addtrans: String=""
    private var editetrans:String=""
    private var deletetrans:String=""
    private var viewtrans:String=""
    private var transfertrans:String=""
    private var exporttrans:String=""
    private var sendtrans=String()


    private var addtransano: String=""
    private var editetransano:String=""
    private var deletetransano:String=""
    private var viewtransano:String=""
    private var transfertransano:String=""
    private var exporttransano:String=""
    private var sendtransano=String()

    private  var viewrec:String=""
    private  var addrec:String=""
    private  var deleterec:String=""
    private  var editrec:String=""
    private  var transferrec:String=""
    private  var exportrec:String=""
    private  var sendstrec:String =""
var savecli=String()


    data class sc(

            var  receivedstk_count: Any,
            var  receivedstk_date: Any,
            var  receivedstk_total: Any,
            var  status:Any

    )
    data class s(

            var stkid: String,
            var stkdate: Any,
            var stk_Desc: Any,
            var stk_destination:Any,
            var stk_total:Any,
            var stk_address:Any,
            var stk_brid:Any,
            var stk_origin:Any,
            var stk_originname:Any

        /*    var stk_wg_vol: Any,
            var stk_name: String,
            var stk_mfr: String,

            var taxchk: Any*/
    )
    data class li(

            var stk_name: Any,
            var stk_mfr: Any,
            var stk_hsn: Any,
            var stk_barcode: Any,
            var stk_received: Any,
            var stk_price: Any,
            var stk_total: Any,
            var stk_cess: Any,
            var otherstk_igst: Any,
            var otherstk_igsttotal: Any,
            var otherstk_cesstotal: Any,
            var otherstk_tally: Any,
            var otherstk_img: Any,
            var otherstk_received: Any,
            var stk_proid:Any,
            var stk_key:Any
    )

    var idstk = String()
    var datestk = String()
    var names = String()
    var addressnames= String()
    var  descstk = String()
    var  cgstt = String()
    var  sgstt = String()
    var  cesst = String()
    var  grosstt= String()

    var fbval= String()
    var pronamestr= String()
    var hsnstr = String()
    var manustr = String()
    var barcodestr= String()
    var quantitystr= String()
    var pricestr = String()
    var totstr = String()
    var cessstr = String()
    var keystr = String()
    var igststr = String()

    var igsttotstr= String()
    var cesstotstr= String()
    var tallystr = String()
    var receivedstr= String()
    var imagestr = String()
    var proidstr = String()

    var quanarrcpystr = String()

    var fnalval= String()

    var pronameArray = arrayListOf<String>()
    var hsnArray = arrayListOf<String>()
    var manufacturerArray = arrayListOf<String>()
    var barcodeArray = arrayListOf<String>()
    var quantityArray = arrayListOf<String>()
    var priceArray = arrayListOf<String>()
    var totArray = arrayListOf<String>()
    var cessArray = arrayListOf<String>()
    var keyArray = arrayListOf<String>()
    var  igstArray = arrayListOf<String>()
    var  igsttotArray = arrayListOf<String>()
    var  cesstotalArray = arrayListOf<String>()
    var  tallyArray = arrayListOf<String>()
    var receivedArray = arrayListOf<String>()
    var imageArray = arrayListOf<String>()



    //Array copy

    var pronameArraycopies = arrayListOf<String>()
    var hsnArraycopies = arrayListOf<String>()
    var manufacturerArraycopies = arrayListOf<String>()
    var barcodeArraycopies = arrayListOf<String>()
    var quantityArraycopies = arrayListOf<String>()
    var priceArraycopies = arrayListOf<String>()
    var totArraycopies = arrayListOf<String>()
    var cessArraycopies = arrayListOf<String>()
    var keyArraycopies = arrayListOf<String>()
    var  igstArraycopies = arrayListOf<String>()
    var  igsttotArraycopies = arrayListOf<String>()
    var  cesstotalArraycopies = arrayListOf<String>()
    var  tallyArraycopies = arrayListOf<String>()
    var receivedArraycopies = arrayListOf<String>()
    var imageArraycopies = arrayListOf<String>()



    var quantityArraycopy = arrayListOf<String>()
    var proidArray= arrayListOf<String>()
    var proidArraycopy= arrayListOf<String>()


    var proiddelete= arrayListOf<String>()

    var quantitydelete= arrayListOf<String>()

    var datas = ArrayList<String>()
    var downstatus= String()
    var getiddel = ArrayList<String>()
    var ids= arrayOf<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scroll_branch_one)


        net_status()      //Check internet status.


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@Mainstk_branch_one) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }



        //Define No connection view and other views when inetrnet connection is off.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        pur_savedis=findViewById(R.id.save)

        userbackdis=findViewById(R.id.userback)
        mnudis=findViewById(R.id.mnu)
        ponodis=findViewById(R.id.stno)
        orddatedis=findViewById(R.id.stdate)

        descripdis=findViewById(R.id.descrip)
        fabdis=findViewById(R.id.fab)
        pur_listdis=findViewById(R.id.br_st__list)
        editdis=findViewById(R.id.edit)

        addLogText(NetworkUtil.getConnectivityStatusString(this@Mainstk_branch_one))


        img_arrow.setOnClickListener {  //arrow mark displays when the list items is greater than 4


            br_st__list.setSelection(br_st__list.getCount() - 1);


        }


        var nameofbrnch = String()
        var locofbrnch = String()

        var datestk = String()
        var smlistids = String()
        var descstk = String()
        var stkidstock = String()
        var ididdb = String()

        var i = arrayListOf<String>()

        var checkcount = arrayListOf<Int>()

        var idsforup = ArrayList<Any>()
        var idsup = String()


        var pronameArraydel = arrayListOf<String>()
        var hsnArraydel = arrayListOf<String>()
        var manufacturerArraydel = arrayListOf<String>()
        var barcodeArraydel = arrayListOf<String>()
        var quantityArraydel = arrayListOf<String>()
        var priceArraydel = arrayListOf<String>()
        var totArraydel = arrayListOf<String>()
        var cessArraydel = arrayListOf<String>()
        var keyArraydel = arrayListOf<String>()
        var igstArraydel = arrayListOf<String>()

        var igsttotArraydel = arrayListOf<String>()
        var cesstotArraydel = arrayListOf<String>()
        var tallyArraydel = arrayListOf<String>()
        var receivedArraydel = arrayListOf<String>()
        var imageArraydel = arrayListOf<String>()
        var proidArraydel = arrayListOf<String>()
        var quantityArraycopydel = arrayListOf<String>()


        //Delete Action


        br_st__list.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        br_st__list.setMultiChoiceModeListener(object : AbsListView.MultiChoiceModeListener {
            override fun onItemCheckedStateChanged(mode: ActionMode, position: Int, id: Long, checked: Boolean) {



                //GEt the selected list item values

                if (pronameArray.get(position).isNotEmpty()) {
                    pronamestr = pronameArray.get(position)
                } else {
                    pronamestr = ""
                }




                if (hsnArray.get(position).isNotEmpty()) {
                    hsnstr = hsnArray.get(position)
                } else {
                    hsnstr = "0"
                }



                if (manufacturerArray.get(position).isNotEmpty()) {
                    manustr = manufacturerArray.get(position)
                } else {
                    manustr = "0"
                }


                if (manufacturerArray.get(position).isNotEmpty()) {
                    manustr = manufacturerArray.get(position)
                } else {
                    manustr = "0"
                }

                if (barcodeArray.get(position).isNotEmpty()) {
                    barcodestr = barcodeArray.get(position)
                } else {
                    barcodestr = "0"
                }
                if (quantityArray.get(position).isNotEmpty()) {
                    quantitystr = quantityArray.get(position)
                } else {
                    quantitystr = "0"
                }

                if (priceArray.get(position).isNotEmpty()) {
                    pricestr = priceArray.get(position)
                } else {
                    pricestr = "0"
                }
                if (totArray.get(position).isNotEmpty()) {
                    totstr = totArray.get(position)
                } else {
                    totstr = "0"
                }

                if (cessArray.get(position).isNotEmpty()) {
                    cessstr = cessArray.get(position)
                } else {
                    cessstr = "0"
                }

                if (keyArray.get(position).isNotEmpty()) {
                    keystr = keyArray.get(position)
                } else {
                    keystr = "0"
                }
                if (igstArray.get(position).isNotEmpty()) {
                    igststr = igstArray.get(position)
                } else {
                    igststr = "0"
                }


                if (igsttotArray.get(position).isNotEmpty()) {
                    igsttotstr = igsttotArray.get(position)
                } else {
                    igsttotstr = "0"
                }
                if (cesstotalArray.get(position).isNotEmpty()) {
                    cesstotstr = cesstotalArray.get(position)
                } else {
                    cesstotstr = "0"
                }
                if (tallyArray.get(position).isNotEmpty()) {
                    tallystr = tallyArray.get(position)
                } else {
                    tallystr = "0"
                }
                if (receivedArray.get(position).isNotEmpty()) {
                    receivedstr = receivedArray.get(position)
                } else {
                    receivedstr = "0"
                }
                if (imageArray.get(position).isNotEmpty()) {
                    imagestr = imageArray.get(position)
                } else {
                    imagestr = "0"
                }

                if (proidArray.get(position).isNotEmpty()) {
                    proidstr = proidArray.get(position)
                } else {
                    proidstr = ""
                }


                if (quantityArraycopy.get(position).isNotEmpty()) {
                    quanarrcpystr = quantityArraycopy.get(position)
                } else {
                    quanarrcpystr = ""
                }


                //capture total checked items and put the values to array


                if (checked == true) {
                    pronameArraydel.add(pronamestr)
                    hsnArraydel.add(hsnstr)
                    manufacturerArraydel.add(manustr)
                    barcodeArraydel.add(barcodestr)
                    quantityArraydel.add(quantitystr)
                    priceArraydel.add(pricestr)
                    totArraydel.add(totstr)
                    cessArraydel.add(cessstr)
                    keyArraydel.add(keystr)
                    igstArraydel.add(igststr)

                    igsttotArraydel.add(igsttotstr)
                    cesstotArraydel.add(cesstotstr)
                    tallyArraydel.add(tallystr)
                    receivedArraydel.add(receivedstr)
                    imageArraydel.add(imagestr)
                    proidArraydel.add(proidstr)

                    quantityArraycopydel.add(quanarrcpystr)

                    /* pronameArraydelglo=pronameArraydel
                     hsnArraydelglo=hsnArraydel
                     manufacturerArraydelglo=manufacturerArraydel
                     barcodeArraydelglo=barcodeArraydel
                     quantityArraydelglo=quantityArraydel
                     priceArraydelglo=priceArraydel
                     totArraydelglo=totArraydel
                     cessArraydelglo=cessArraydel
                     keyArraydelglo=keyArraydel
                     igstArraydelglo=igstArraydel
                     cgstArraydelglo=cgstArraydel
                     sgstArraydelglo=sgstArraydel
                     igsttotArraydelglo=igsttotArraydel
                     cesstotalArraydelglo=cesstotArraydel
                     tallyArraydelglo=tallyArraydel
                     receivedArraydelglo=receivedArraydel
                     imageArraydelglo=imageArraydel*/


                    println("pronameArray ARRAY SELECTED DELETE" + pronameArraydel)
                    println("hsnArray ARRAY SELECTED DELETE" + hsnArraydel)
                    println("manufacturerArray ARRAY SELECTED DELETE" + manufacturerArraydel)
                    println("barcodeArray ARRAY SELECTED DELETE" + barcodeArraydel)
                    println("quantityArray ARRAY SELECTED DELETE" + quantityArraydel)
                    println("priceArray ARRAY SELECTED DELETE" + priceArraydel)
                    println("totArray ARRAY SELECTED DELETE" + totArraydel)
                    println("cessArray ARRAY SELECTED DELETE" + cessArraydel)
                    println("keyArray ARRAY SELECTED DELETE" + keyArraydel)
                    println("igstArray ARRAY SELECTED DELETE" + igstArraydel)

                    println("igsttotArray ARRAY SELECTED DELETE" + igsttotArraydel)
                    println("cesstotalArray ARRAY SELECTED DELETE" + cesstotArraydel)
                    println("tallyArray ARRAY SELECTED DELETE" + tallyArraydel)
                    println("receivedArray ARRAY SELECTED DELETE" + receivedArraydel)
                    println("imageArray ARRAY SELECTED DELETE" + imageArraydel)
                    println("proidarray ARRAY SELECTED DELETE" + proidArraydel)

                } else {
                    pronameArraydel.remove(pronamestr)
                    hsnArraydel.remove(hsnstr)
                    manufacturerArraydel.remove(manustr)
                    barcodeArraydel.remove(barcodestr)
                    quantityArraydel.remove(quantitystr)
                    priceArraydel.remove(pricestr)
                    totArraydel.remove(totstr)
                    cessArraydel.remove(cessstr)
                    keyArraydel.remove(keystr)
                    igstArraydel.remove(igststr)

                    igsttotArraydel.remove(igsttotstr)
                    cesstotArraydel.remove(cesstotstr)
                    tallyArraydel.remove(tallystr)
                    receivedArraydel.remove(receivedstr)
                    imageArraydel.remove(imagestr)
                    proidArraydel.remove(proidstr)
                    quantityArraycopydel.remove(quanarrcpystr)

                    /*pronameArraydelglo=pronameArraydel
                    hsnArraydelglo=hsnArraydel
                    manufacturerArraydelglo=manufacturerArraydel
                    barcodeArraydelglo=barcodeArraydel
                    quantityArraydelglo=quantityArraydel
                    priceArraydelglo=priceArraydel
                    totArraydelglo=totArraydel
                    cessArraydelglo=cessArraydel
                    keyArraydelglo=keyArraydel
                    igstArraydelglo=igstArraydel
                    cgstArraydelglo=cgstArraydel
                    sgstArraydelglo=sgstArraydel
                    igsttotArraydelglo=igsttotArraydel
                    cesstotalArraydelglo=cesstotArraydel
                    tallyArraydelglo=tallyArraydel
                    receivedArraydelglo=receivedArraydel
                    imageArraydelglo=imageArraydel*/


                    println("pronameArray ARRAY UNSELETED DELETE" + pronameArraydel)
                    println("hsnArray ARRAY UNSELETED DELETE" + hsnArraydel)
                    println("manufacturerArray ARRAY UNSELETED DELETE" + manufacturerArraydel)
                    println("barcodeArray ARRAY UNSELETED DELETE" + barcodeArraydel)
                    println("quantityArray ARRAY UNSELETED DELETE" + quantityArraydel)
                    println("priceArray ARRAY UNSELETED DELETE" + priceArraydel)
                    println("totArray ARRAY UNSELETED DELETE" + totArraydel)
                    println("cessArray ARRAY UNSELETED DELETE" + cessArraydel)
                    println("keyArray ARRAY UNSELETED DELETE" + keyArraydel)
                    println("igstArray ARRAY UNSELETED DELETE" + igstArraydel)

                    println("igsttotArray ARRAY UNSELETED DELETE" + igsttotArraydel)
                    println("cesstotalArray ARRAY UNSELETED DELETE" + cesstotArraydel)
                    println("tallyArray ARRAY UNSELETED DELETE" + tallyArraydel)
                    println("receivedArray ARRAY UNSELETED DELETE" + receivedArraydel)
                    println("imageArray ARRAY UNSELETED DELETE" + imageArraydel)
                    println("proidarray ARRAY UNSELETED DELETE" + proidArraydel)


                }


                println("CREATEDDDD out")
                println("LIST POSITIONNNNNN   " + idsforup)
                val checkedCounts = br_st__list.checkedItemCount


                //setting CAB title
                mode.setTitle("" + checkedCounts + " Selected")
                Log.d(TAG, " " + id)
            }

            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                //Inflate the CAB and Invisible other views in toolbar

                toolbar1.visibility = View.INVISIBLE
                save.visibility = View.INVISIBLE
                userback.visibility = View.INVISIBLE
                mnu.visibility = View.INVISIBLE
                edit.visibility = View.INVISIBLE
                comp_toolimg.visibility = View.INVISIBLE
                comttname.visibility = View.INVISIBLE
                comphone.visibility = View.INVISIBLE
                mode.getMenuInflater().inflate(R.menu.menu_delete, menu);
                return true;
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
                return false
            }

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {



                //Here remove  the values in that array

                println("CREATEDDDD")
                /*        val deleteSize = dlt.size
                          Log.i("tsdfs", "  " + dlt.size)
                          *//*val cate = null
                    val data = s(cat = cate)*//*
                    val i = 0
                    Log.d("dlt", " " + dlt.get(i))*/
                val itemId = item.getItemId()
                val deleteSize = idsforup.size
                //val i = 0
                var refiddel = listoids.text.toString()
                var pathfdel = "${origiky}_Stock_Transfer/$refiddel/Stock_products"
                if ((itemId == R.id.delete) && (deletetrans == "true")) {

                    deletelistener = "listdelete"

                    for (i in 0 until pronameArraydel.size) {

                        pronameArray.remove(pronameArraydel.get(i))
                        hsnArray.remove(hsnArraydel.get(i))
                        manufacturerArray.remove(manufacturerArraydel.get(i))
                        barcodeArray.remove(barcodeArraydel.get(i))
                        quantityArray.remove(quantityArraydel.get(i))
                        priceArray.remove(priceArraydel.get(i))
                        totArray.remove(totArraydel.get(i))
                        cessArray.remove(cessArraydel.get(i))
                        keyArray.remove(keyArraydel.get(i))
                        igstArray.remove(igstArraydel.get(i))

                        igsttotArray.remove(igsttotArraydel.get(i))
                        cesstotalArray.remove(cesstotArraydel.get(i))
                        tallyArray.remove(tallyArraydel.get(i))
                        receivedArray.remove(receivedArraydel.get(i))
                        imageArray.remove(imageArraydel.get(i))
                        proidArray.remove(proidArraydel.get(i))


                        proiddelete.add(proidArraydel.get(i))
                        quantitydelete.add(quantityArraycopydel.get(i))

                        println("proiddelete ARRAY AFTER DELETE" + proiddelete)
                        println("quantityArraycopy ARRAY AFTER DELETE" + quantitydelete)

                    }



                    println("pronameArray ARRAY AFTER DELETE" + pronameArray)
                    println("pronameArray ARRAY AFTER DELETE" + pronameArray)
                    println("hsnArray ARRAY AFTER DELETE" + hsnArray)
                    println("manufacturerArray ARRAY AFTER DELETE" + manufacturerArray)
                    println("barcodeArray ARRAY AFTER DELETE" + barcodeArray)
                    println("quantityArray ARRAY AFTER DELETE" + quantityArray)
                    println("priceArray ARRAY AFTER DELETE" + priceArray)
                    println("totArray ARRAY AFTER DELETE" + totArray)
                    println("cessArray ARRAY AFTER DELETE" + cessArray)
                    println("keyArray ARRAY AFTER DELETE" + keyArray)
                    println("igstArray ARRAY AFTER DELETE" + igstArray)

                    println("igsttotArray ARRAY AFTER DELETE" + igsttotArray)
                    println("cesstotalArray ARRAY AFTER DELETE" + cesstotalArray)
                    println("tallyArray ARRAY AFTER DELETE" + tallyArray)
                    println("receivedArray ARRAY AFTER DELETE" + receivedArray)
                    println("imageArray ARRAY AFTER DELETE" + imageArray)

                    println("proidarray ARRAY AFTER DELETE" + proidArray)
                    println("proidcpyarray ARRAY AFTER DELETE" + proidArraycopy)


                    val whatever = scrolladd_stock_one_adap(this@Mainstk_branch_one, pronameArray, manufacturerArray, hsnArray, barcodeArray,
                            quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray,
                            receivedArray, imageArray)
                    br_st__list.adapter = whatever


                    //Footer inflates the extra space to the bottom of the list.

                    val footer = View.inflate(this@Mainstk_branch_one, R.layout.footer, null);
                    br_st__list.addFooterView(footer, null, false)




                    println("pronameArray DELETE" + pronameArray)
                    println("pronameArrayDELETE" + pronameArray)
                    println("hsnArray DELETE" + hsnArray)
                    println("manufacturerArray  DELETE" + manufacturerArray)
                    println("barcodeArray  DELETE" + barcodeArray)
                    println("quantityArray DELETE" + quantityArray)
                    println("priceArray DELETE" + priceArray)
                    println("totArray DELETE" + totArray)
                    println("cessArray DELETE" + cessArray)
                    println("keyArray  DELETE" + keyArray)
                    println("igstArray DELETE" + igstArray)

                    println("igsttotArray  DELETE" + igsttotArray)
                    println("cesstotalArray DELETE" + cesstotalArray)
                    println("tallyArray DELETE" + tallyArray)
                    println("receivedArray DELETE" + receivedArray)
                    println("imageArray DELETE" + imageArray)

                    println("proidarray DELETE" + proidArray)
                    println("proidcpyarray  DELETE" + proidArraycopy)









                    //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.

                    if (priceArray.isNotEmpty() == true) {


                        var total = 0.0F
                        var igsttot = 0.0F
                        var cesstotals = 0.0F
                        var b = 2
                        for (i in 0 until proidArray.size) {


                            var c = (priceArray[i])
                            var cy = (igsttotArray[i])
                            var cyz = (cesstotalArray[i])
                            var qyz = (quantityArray[i])


                            var cdec = c.toBigDecimal()
                            var qyzdec = qyz.toBigDecimal()
                            var totquanpri = (cdec * qyzdec)




                            total = total.plus(totquanpri.toInt())

                            igsttot = igsttot.plus(cy.toFloat())
                            cesstotals = cesstotals.plus(cyz.toFloat())

                            igst_tot.setText((String.format("%.2f",igsttot)))
                            var l = igst_tot.text.toString()
                            var ss = l.toBigDecimal()
                            var tt = ss / b.toBigDecimal()
                            cgst_tot.setText((String.format("%.2f",tt)))
                            sgst_tot.setText((String.format("%.2f",tt)))

                            cess_tot.setText((String.format("%.2f",cesstotals)))

                            var f = cesstotals
                            var g = igsttot

                            var op = total
                            var m = f.toFloat()
                            var n = g.toFloat()

                            var yy = m + n + op

                            try {
                                gross_tot.setText((String.format("%.2f",yy)))
                                grosscheck = gross_tot.text.toString()
                            } catch (e: Exception) {
                                gross_tot.setText((String.format("%.2f",yy)))
                                grosscheck = gross_tot.text.toString()
                            }

                            if (pronameArray.size > 4) {
                                img_arrow.visibility = View.VISIBLE
                            }

                        }
                    } else {
                        gross_tot.text = DecimalFormat("##.##").format(0.0)
                        grosscheck = gross_tot.text.toString()

                        igst_tot.text = DecimalFormat("##.##").format(0.0)
                        cgst_tot.text = DecimalFormat("##.##").format(0.0)
                        sgst_tot.text = DecimalFormat("##.##").format(0.0)
                        cess_tot.text = DecimalFormat("##.##").format(0.0)
                    }


                } else {
                    popup("delete")
                }

                mode.finish()
                pronameArraydel.clear()
                hsnArraydel.clear()
                manufacturerArraydel.clear()
                barcodeArraydel.clear()
                quantityArraydel.clear()
                priceArraydel.clear()
                totArraydel.clear()
                cessArraydel.clear()
                keyArraydel.clear()
                igstArraydel.clear()

                igsttotArraydel.clear()
                cesstotArraydel.clear()
                tallyArraydel.clear()
                receivedArraydel.clear()
                imageArraydel.clear()
                proidArraydel.clear()
                return true

            }

            override fun onDestroyActionMode(mode: ActionMode) {

                // When destroy action of the list select and visible other views in toolbar


                toolbar1.visibility = View.VISIBLE
                save.visibility = View.VISIBLE
                userback.visibility = View.VISIBLE
                mnu.visibility = View.VISIBLE
                comp_toolimg.visibility = View.INVISIBLE
                comttname.visibility = View.VISIBLE
                comphone.visibility = View.VISIBLE
            }

        })




        edit.setOnClickListener {

            if (editetrans == "true") {

                br_st__list.isClickable = true

                edit.visibility = View.GONE
                fab.visibility = View.VISIBLE


                mnu.visibility = View.VISIBLE
                descrip.isEnabled = true
                stdate.isEnabled = true

                cgst.isEnabled = true
                sgst.isEnabled = true

                fab.isEnabled = true


                val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                br_st__list.adapter = whatever

                save.visibility = View.VISIBLE


            } else if (editetrans == "false") {
                popup("Edit")
            }

        }


        var doup = arrayListOf<String>()


        val bundle = intent.extras
        var frm = bundle!!.get("from").toString()

        ///Get from product select list
        datestk = stdate.text.toString()


        stdate.setOnClickListener(View.OnClickListener {   //Datepicker dialog popup
            val cldr = Calendar.getInstance()
            val day = cldr.get(Calendar.DAY_OF_MONTH)
            val month = cldr.get(Calendar.MONTH)
            val year = cldr.get(Calendar.YEAR)
            // date picker dialog
            val picker = DatePickerDialog(this@Mainstk_branch_one,
                    DatePickerDialog.OnDateSetListener { view, year, monthOfYear, dayOfMonth -> stdate.setText(dayOfMonth.toString() + "/" + (monthOfYear + 1) + "/" + year) }, year, month, day)
            picker.show()
        })
        if (frm == "branch") {
            val c = Calendar.getInstance()
            System.out.println("Current time =&gt; " + c.time)

            val df = SimpleDateFormat("dd/MM/yyyy")
            val formattedDate = df.format(c.time)

            stdate.setText(formattedDate)  //Set current date on edittext


            val a = intent.getStringExtra("brchnm")
            comttname.setText(a)
            nameofbrnch = comttname.text.toString()
            println(nameofbrnch)
            val ab = intent.getStringExtra("brchloc")
            comphone.setText(ab)
            locofbrnch = comphone.text.toString()
            println(locofbrnch)
            val brid = intent.getStringExtra("brnchky")
            brnchid.setText(brid)
            val abc = intent.getStringExtra("originky")
            origiky = abc


            db.collection("branch").document(abc) //Get origin branch's name and key
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            if (task.result != null) {
                                var document=task.result
                                orignm=document.id
                                Log.d("data", "is" + task.result.data)
                                var orig = document.get("nm").toString()
                                orignm=orig

                                println("orignm mm"+orignm)

                            } else {
                                Log.d("data", "is not here")
                            }
                        } else {
                            Log.d("task is not success", "full" + task.exception)
                        }

                    }
            keyofbrnch = brnchid.text.toString()


            //For transfer

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


        }



        else if (frm == "list") {   //Here we can add multiple stock list items from (product_list_activity)

            val aw = bundle!!.get("pname") as ArrayList<String>
            val bw = bundle!!.get("pitem") as ArrayList<String>
            val cw = bundle!!.get("phsn") as ArrayList<String>
            val dw = bundle!!.get("porder") as ArrayList<String>
            /*    val ew=bundle!!.get("pcomplete") as Array<string>*/
            val fw = bundle!!.get("pprice") as ArrayList<String>
            val hw = bundle!!.get("ptot") as ArrayList<String>
            val gw = bundle!!.get("poarray") as ArrayList<String>
            val lw = bundle!!.get("cessarray") as ArrayList<String>
            val mw = bundle!!.get("igstarray") as ArrayList<String>
            val nw = bundle!!.get("igsttotarray") as ArrayList<String>
            val ow = bundle!!.get("cesstotalarray") as ArrayList<String>
            val pw = bundle!!.get("tallyarray") as ArrayList<String>
            val rew = bundle!!.get("receivedarray") as ArrayList<String>
            val piddli = bundle!!.get("reiddofli") as ArrayList<String>
            val prids = bundle!!.get("proidarrays") as ArrayList<String>
            try {
                val requancpyarr = bundle!!.get("requancpy") as ArrayList<String>
                quantityArraycopy = requancpyarr
            } catch (e: Exception) {

            }
            val reproidscpy = bundle!!.get("proidarrayscpy") as ArrayList<String>


            val nms = intent.getStringExtra("branch")
            val nmsaddrss = intent.getStringExtra("address")
            val keybranch = intent.getStringExtra("brkey")
            val orgnky = intent.getStringExtra("originkey")

            try {
                orignm = intent.getStringExtra("orignm")
            }
            catch (e:Exception)

            {

            }
            deletelistener = intent.getStringExtra("deletelistener")

            try {
                descripdup = intent.getStringExtra("descripdup")
                stdatedup = intent.getStringExtra("stdatedup")
            } catch (e: Exception) {

            }

            try {
                val prodel = bundle.get("proiddelete") as ArrayList<String>

                if (prodel.isNotEmpty() == true) {
                    proiddelete = prodel
                } else {

                }

                val quandel = bundle.get("quantitydelete") as ArrayList<String>

                if (quandel.isNotEmpty() == true) {
                    quantitydelete = prodel
                } else {

                }
            } catch (e: Exception) {

            }


            val imm = bundle!!.get("imi") as ArrayList<String>

            ids = bundle!!.get("ids") as Array<String>

            val pdate = intent.getStringExtra("redate")
            val pstkid = intent.getStringExtra("restkid")
            val pdesc = intent.getStringExtra("redesc")
            val piddb = intent.getStringExtra("reiddb")

            val groschk = intent.getStringExtra("groschk")

            grosscheck = groschk


            println("grosscheck VALUE LISt" + grosscheck)

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")


            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }







            stdate.setText(pdate)
            descrip.setText(pdesc)
            stno.setText(pstkid)
            brnchid.setText(keybranch)
            listoids.setText(piddb)
            comttname.setText(nms)
            comphone.setText(nmsaddrss)

            datestk = stdate.text.toString()
            descstk = descrip.text.toString()
            nameofbrnch = comttname.text.toString()
            locofbrnch = comphone.text.toString()
            keyofbrnch = brnchid.text.toString()
            stkidstock = stno.text.toString()
            ididdb = listoids.text.toString()


            origiky = orgnky










            pronameArray = aw
            manufacturerArray = bw
            quantityArray = dw
            priceArray = fw
            hsnArray = cw
            barcodeArray = gw
            totArray = hw
            cessArray = lw
            keyArray = piddli
            igstArray = mw
            igsttotArray = nw
            cesstotalArray = ow
            tallyArray = pw
            receivedArray = rew
            imageArray = imm







            proidArray = prids

            proidArraycopy = reproidscpy


            println("QUANCOPY LIST" + quantityArraycopy)
            println("PROCOPY LIST" + proidArraycopy)
            println("PRO LIST" + proidArray)


            val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray,
                    cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            br_st__list.adapter = whatever
            val footer = View.inflate(this@Mainstk_branch_one, R.layout.footer, null);
            br_st__list.addFooterView(footer, null, false)



            //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.

            if (savecli != "clicked") {
                var total = 0.0F
                var igsttot = 0.0F
                var cesstotals = 0.0F
                var b = 2
                for (i in 0 until proidArray.count()) {
                    var c = (priceArray[i])
                    var cy = (igsttotArray[i])
                    var cyz = (cesstotalArray[i])
                    var qyz = (quantityArray[i])


                    var cdec = c.toBigDecimal()
                    var qyzdec = qyz.toBigDecimal()
                    var totquanpri = (cdec * qyzdec)




                    total = total.plus(totquanpri.toInt())

                    igsttot = igsttot.plus(cy.toFloat())
                    cesstotals = cesstotals.plus(cyz.toFloat())

                    igst_tot.setText((String.format("%.2f",igsttot)))
                    var l = igst_tot.text.toString()
                    var ss = l.toBigDecimal()
                    var tt = ss / b.toBigDecimal()
                    cgst_tot.setText((String.format("%.2f",tt)))
                    sgst_tot.setText((String.format("%.2f",tt)))

                    cess_tot.setText((String.format("%.2f",cesstotals)))

                    var f = cesstotals
                    var g = igsttot

                    var op = total
                    var m = f.toFloat()
                    var n = g.toFloat()

                    var yy = m + n + op

                    try {
                        gross_tot.setText((String.format("%.2f",yy)))

                    } catch (e: Exception) {
                        gross_tot.setText((String.format("%.2f",yy)))

                    }


                    if (pronameArray.size > 4) {
                        img_arrow.visibility = View.VISIBLE
                    }


                }


            }


///LOCAL DELETE


            ///UPDATE PAGE


        } else if (frm == "list_single") {  //Here we can add single list item from (product_list_activity)


            val aw = bundle!!.get("pname") as ArrayList<String>


            val ffrt = aw.toString()
            var ffnm = ffrt.removeSurrounding("[", "]")

            val bw = bundle!!.get("pitem") as ArrayList<String>

            val ffit = bw.toString()
            var ffmanu = ffit.removeSurrounding("[", "]")

            val cw = bundle!!.get("phsn") as ArrayList<String>

            val ffhs = cw.toString()
            var ffhsn = ffhs.removeSurrounding("[", "]")

            val dw = bundle!!.get("porder") as ArrayList<String>

            val ford = dw.toString()
            var ffquan = ford.removeSurrounding("[", "]")


            /*    val ew=bundle!!.get("pcomplete") as Array<String>*/
            val fw = bundle!!.get("pprice") as ArrayList<String>

            val fpri = fw.toString()
            var ffpri = fpri.removeSurrounding("[", "]")


            val hw = bundle!!.get("ptot") as ArrayList<String>


            val ftot = hw.toString()
            var fftot = ftot.removeSurrounding("[", "]")


            val gw = bundle!!.get("poarray") as ArrayList<String>
            val lw = bundle!!.get("cessarray") as ArrayList<String>
            val mw = bundle!!.get("igstarray") as ArrayList<String>
            val nw = bundle!!.get("igsttotarray") as ArrayList<String>
            val ow = bundle!!.get("cesstotalarray") as ArrayList<String>
            val pw = bundle!!.get("tallyarray") as ArrayList<String>
            val rew = bundle!!.get("receivedarray") as ArrayList<String>
            val piddli = bundle!!.get("reiddofli") as ArrayList<String>
            val prid = bundle!!.get("proidarray") as ArrayList<String>

            deletelistener = intent.getStringExtra("deletelistener")

            try {
                descripdup = intent.getStringExtra("descripdup")
                stdatedup = intent.getStringExtra("stdatedup")
            } catch (e: Exception) {

            }

            try {
                val prodel = bundle.get("proiddelete") as ArrayList<String>

                if (prodel.isNotEmpty() == true) {
                    proiddelete = prodel
                } else {

                }

                val quandel = bundle.get("quantitydelete") as ArrayList<String>

                if (quandel.isNotEmpty() == true) {
                    quantitydelete = prodel
                } else {

                }
            } catch (e: Exception) {

            }
            try {
                orignm = intent.getStringExtra("orignm")

            }
            catch (e:Exception)

            {

            }

            try {
                val requancpyarr = bundle!!.get("requancpy") as ArrayList<String>
                quantityArraycopy = requancpyarr
            } catch (e: Exception) {

            }
            val reproidscpy = bundle!!.get("proidarrayscpy") as ArrayList<String>

            val nms = intent.getStringExtra("branch")
            val nmsaddrss = intent.getStringExtra("address")
            val keybranch = intent.getStringExtra("brkey")
            val orgnky = intent.getStringExtra("originkey")
            val imm = bundle!!.get("imi") as ArrayList<String>

            ids = bundle!!.get("ids") as Array<String>

            val pdate = intent.getStringExtra("redate")
            val pstkid = intent.getStringExtra("restkid")
            val pdesc = intent.getStringExtra("redesc")
            val piddb = intent.getStringExtra("reiddb")

            val groschk = intent.getStringExtra("groschk")

            grosscheck = groschk

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }






            stdate.setText(pdate)
            descrip.setText(pdesc)
            stno.setText(pstkid)
            brnchid.setText(keybranch)
            listoids.setText(piddb)
            comttname.setText(nms)
            comphone.setText(nmsaddrss)

            datestk = stdate.text.toString()
            descstk = descrip.text.toString()
            nameofbrnch = comttname.text.toString()
            locofbrnch = comphone.text.toString()
            keyofbrnch = brnchid.text.toString()
            stkidstock = stno.text.toString()
            ididdb = listoids.text.toString()


            origiky = orgnky












            pronameArray = aw
            manufacturerArray = bw
            quantityArray = dw
            priceArray = fw
            hsnArray = cw
            barcodeArray = gw
            totArray = hw
            cessArray = lw
            keyArray = piddli
            igstArray = mw
            igsttotArray = nw
            cesstotalArray = ow
            tallyArray = pw
            receivedArray = rew
            imageArray = imm




            proidArray = prid

            proidArraycopy = reproidscpy

            println("PRONMARRAY DUDE" + (pronameArray))

            println("QUANCOPY LIST" + quantityArraycopy)
            println("PROCOPY LIST" + proidArraycopy)
            println("PRO LIST" + proidArray)


            println("QUANCOPY LIST" + quantityArraycopy)

            val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray,
                    cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            br_st__list.adapter = whatever
            val footer = View.inflate(this@Mainstk_branch_one, R.layout.footer, null);
            br_st__list.addFooterView(footer, null, false)


            //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.


            if (savecli != "clicked") {
                var total = 0.0F
                var igsttot = 0.0F
                var cesstotals = 0.0F
                var b = 2
                for (i in 0 until proidArray.count()) {
                    var c = (priceArray[i])
                    var cy = (igsttotArray[i])
                    var cyz = (cesstotalArray[i])
                    var qyz = (quantityArray[i])


                    var cdec = c.toBigDecimal()
                    var qyzdec = qyz.toBigDecimal()
                    var totquanpri = (cdec * qyzdec)




                    total = total.plus(totquanpri.toInt())

                    igsttot = igsttot.plus(cy.toFloat())
                    cesstotals = cesstotals.plus(cyz.toFloat())

                    igst_tot.setText((String.format("%.2f",igsttot)))
                    var l = igst_tot.text.toString()
                    var ss = l.toBigDecimal()
                    var tt = ss / b.toBigDecimal()
                    cgst_tot.setText((String.format("%.2f",tt)))
                    sgst_tot.setText((String.format("%.2f",tt)))

                    cess_tot.setText((String.format("%.2f",cesstotals)))

                    var f = cesstotals
                    var g = igsttot

                    var op = total
                    var m = f.toFloat()
                    var n = g.toFloat()

                    var yy = m + n + op

                    try {
                        gross_tot.setText((String.format("%.2f",yy)))

                    } catch (e: Exception) {
                        gross_tot.setText((String.format("%.2f",yy)))

                    }



                    if (pronameArray.size > 4) {
                        img_arrow.visibility = View.VISIBLE
                    }

                    ///LOCAL DELETE

                }
            }
        }


        else if (frm == "update") {   //Here we can get updated list items from (Mainstk_branch_two)


            save.visibility = View.VISIBLE


            fab.isEnabled = true


            val av = bundle!!.get("renm") as ArrayList<String>
            val bv = bundle!!.get("rehsn") as ArrayList<String>
            val mv = bundle!!.get("remanu") as ArrayList<String>
            val dv = bundle!!.get("reprice") as ArrayList<String>
            val ev = bundle!!.get("requan") as ArrayList<String>
            val fv = bundle!!.get("rebc") as ArrayList<String>
            val hv = bundle!!.get("retotal") as ArrayList<String>
            val gv = bundle!!.get("recess") as ArrayList<String>
            val iv = bundle!!.get("reigst") as ArrayList<String>
            val jv = bundle!!.get("reigst_total") as ArrayList<String>
            val kv = bundle!!.get("recesstotal") as ArrayList<String>
            val rekey = bundle!!.get("rekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            try {
                val reproid = bundle!!.get("reproid") as ArrayList<String>
                proidArray = reproid
                println("proidArray" + proidArray)
            } catch (e: Exception) {

            }
            try {
                val reproidscpy = bundle!!.get("reproidscpy") as ArrayList<String>

                proidArraycopy = reproidscpy
            } catch (e: Exception) {

            }

            try {
                val requancpy = bundle!!.get("requancpy") as ArrayList<String>
                quantityArraycopy = requancpy

            } catch (e: Exception) {

            }


            try {
                descripdup = intent.getStringExtra("descripdup")
                stdatedup = intent.getStringExtra("stdatedup")
            } catch (e: Exception) {

            }


            try {
                val prodel = bundle.get("proiddelete") as ArrayList<String>

                if (prodel.isNotEmpty() == true) {
                    proiddelete = prodel
                } else {

                }

                val quandel = bundle.get("quantitydelete") as ArrayList<String>

                if (quandel.isNotEmpty() == true) {
                    quantitydelete = prodel
                } else {

                }
            } catch (e: Exception) {

            }


            val n = intent.getStringExtra("branch")
            val pp = intent.getStringExtra("address")
            val pdate = intent.getStringExtra("redate")
            val pstkid = intent.getStringExtra("restkid")
            val br = intent.getStringExtra("brnchky")
            val pdesc = intent.getStringExtra("redesc")
            val piddb = intent.getStringExtra("reiddb")
            val piddli = intent.getStringExtra("reiddofli")
            var smli = intent.getStringExtra("smlistidss")
            var originkeyup = intent.getStringExtra("oribrnky")


            ids = bundle!!.get("ids") as Array<String>

            var grocheck = intent.getStringExtra("groschk")
            grosscheck = grocheck

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            deletelistener = intent.getStringExtra("deletelistner")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }





            origiky = originkeyup

            try {
                orignm = intent.getStringExtra("orignm")

            }
            catch (e:Exception)

            {

            }
            println("UPDATE IDDDDDD" + Arrays.toString(ids))



            liids.setText(piddli)
            idsup = liids.text.toString()


            val immv = bundle!!.get("reimmg") as ArrayList<String>

            ids = bundle!!.get("ids") as Array<String>

            comttname.setText(n)
            comphone.setText(pp)
            stdate.setText(pdate.toString())
            descrip.setText(pdesc.toString())
            stno.setText(pstkid)
            listoids.setText(piddb)
            descstk = descrip.text.toString()
            datestk = stdate.text.toString()
            stkidstock = stno.text.toString()
            ididdb = listoids.text.toString()

            brnchid.setText(br.toString())
            keyofbrnch = brnchid.text.toString()



            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = dv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            cessArray = gv
            keyArray = rekey
            igstArray = iv
            igsttotArray = jv
            cesstotalArray = kv
            tallyArray = ktally
            receivedArray = rereceive
            imageArray = immv









            println("QUANCOPY UPDATE" + quantityArraycopy)


            val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            br_st__list.adapter = whatever


            val footer = View.inflate(this@Mainstk_branch_one, R.layout.footer, null);
            br_st__list.addFooterView(footer, null, false)


            //Calculates the list item's price and tax values and display the grosstotal,cess total,tax total.

            if (savecli != "clicked") {
                var total = 0.0F
                var igsttot = 0.0F
                var cesstotals = 0.0F
                var b = 2
                for (i in 0 until proidArray.count()) {
                    var c = (priceArray[i])
                    var cy = (igsttotArray[i])
                    var cyz = (cesstotalArray[i])
                    var qyz = (quantityArray[i])


                    var cdec = c.toBigDecimal()
                    var qyzdec = qyz.toBigDecimal()
                    var totquanpri = (cdec * qyzdec)




                    total = total.plus(totquanpri.toInt())

                    igsttot = igsttot.plus(cy.toFloat())
                    cesstotals = cesstotals.plus(cyz.toFloat())

                    igst_tot.setText((String.format("%.2f",igsttot)))
                    var l = igst_tot.text.toString()
                    var ss = l.toBigDecimal()
                    var tt = ss / b.toBigDecimal()
                    cgst_tot.setText((String.format("%.2f",tt)))
                    sgst_tot.setText((String.format("%.2f",tt)))

                    cess_tot.setText((String.format("%.2f",cesstotals)))

                    var f = cesstotals
                    var g = igsttot

                    var op = total
                    var m = f.toFloat()
                    var n = g.toFloat()

                    var yy = m + n + op

                    try {
                        gross_tot.setText((String.format("%.2f",yy)))

                    } catch (e: Exception) {
                        gross_tot.setText((String.format("%.2f",yy)))

                    }


                    if (pronameArray.size > 4) {
                        img_arrow.visibility = View.VISIBLE
                    }
                }
            }


        } else if (frm == "frm_pdf") {   //From pdf activity


            val av = bundle!!.get("renm") as ArrayList<String>
            val bv = bundle!!.get("rehsn") as ArrayList<String>
            val mv = bundle!!.get("remanu") as ArrayList<String>
            /*   val dv=bundle!!.get("reprice") as Array<SListtring>*/
            val ev = bundle!!.get("requan") as ArrayList<String>
            val fv = bundle!!.get("rebc") as ArrayList<String>
            val hv = bundle!!.get("retotal") as ArrayList<String>
            val gv = bundle!!.get("recess") as ArrayList<String>
            val iv = bundle!!.get("reigst") as ArrayList<String>
            val jv = bundle!!.get("reigst_total") as ArrayList<String>
            val kv = bundle!!.get("recesstotal") as ArrayList<String>
            val rekey = bundle!!.get("rekey") as ArrayList<String>
            val ktally = bundle!!.get("retally") as ArrayList<String>
            val rereceive = bundle!!.get("rereceived") as ArrayList<String>
            try {
                val requancpy = bundle!!.get("requancpy") as ArrayList<String>
                quantityArraycopy = requancpy
            } catch (e: Exception) {

            }
            val reproids = bundle!!.get("reproids") as ArrayList<String>
            val reproidscpy = bundle!!.get("reproidscpy") as ArrayList<String>


            try {
                orignm = intent.getStringExtra("orignm")

            }
            catch (e:Exception)

            {

            }

            try {
                val prodel = bundle.get("proiddelete") as ArrayList<String>

                if (prodel.isNotEmpty() == true) {
                    proiddelete = prodel
                } else {

                }

                val quandel = bundle.get("quantitydelete") as ArrayList<String>

                if (quandel.isNotEmpty() == true) {
                    quantitydelete = prodel
                } else {

                }
            } catch (e: Exception) {

            }

            try {
                grosscheck=intent.getStringExtra("grosschk")
                descripdup = intent.getStringExtra("descripdup")
                stdatedup = intent.getStringExtra("stdatedup")
            } catch (e: Exception) {

            }

            val grosst = intent.getStringExtra("gross")

            println("GROSS TOT" + grosstt)


            val cgst = intent.getStringExtra("cgsttot")

            val sgst = intent.getStringExtra("sgsttot")

            val cess = intent.getStringExtra("cesstot")




            cgst_tot.setText((String.format("%.2f",cgst.toFloat())))
            sgst_tot.setText((String.format("%.2f",sgst.toFloat())))
            cess_tot.setText((String.format("%.2f",cess.toFloat())))
            gross_tot.setText((String.format("%.2f",grosst.toFloat())))


            val n = intent.getStringExtra("branch")
            val pp = intent.getStringExtra("address")
            val pdate = intent.getStringExtra("redate")
            val pstkid = intent.getStringExtra("restkid")
            val br = intent.getStringExtra("brnchky")
            val pdesc = intent.getStringExtra("redesc")
            val piddb = intent.getStringExtra("reiddb")
            val piddli = intent.getStringExtra("reiddofli")
            var smli = intent.getStringExtra("smlistidss")
            var originkeyup = intent.getStringExtra("oribrnky")

            deletelistener = intent.getStringExtra("deletelistener")

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }





            origiky = originkeyup


            println("UPDATE IDDDDDD" + Arrays.toString(ids))
            liids.setText(piddli)
            idsup = liids.text.toString()


            val immv = bundle!!.get("reimmg") as ArrayList<String>
            comttname.setText(n)
            comphone.setText(pp)
            stdate.setText(pdate.toString())
            descrip.setText(pdesc.toString())
            stno.setText(pstkid.toString())
            brnchid.setText(br)
            listoids.setText(piddb)


            descstk = descrip.text.toString()
            datestk = stdate.text.toString()
            stkidstock = stno.text.toString()
            ididdb = listoids.text.toString()


            keyofbrnch = brnchid.text.toString()



            pronameArray = av
            manufacturerArray = mv
            quantityArray = ev
            priceArray = hv
            hsnArray = bv
            barcodeArray = fv
            totArray = hv
            cessArray = gv
            keyArray = rekey
            igstArray = iv
            igsttotArray = jv
            cesstotalArray = kv
            tallyArray = ktally
            receivedArray = rereceive
            imageArray = immv
            proidArray = reproids
            proidArraycopy = reproidscpy







            println("QUANCOPY PDF" + quantityArraycopy)


            val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray,
                    cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
            br_st__list.adapter = whatever
            val footer = View.inflate(this@Mainstk_branch_one, R.layout.footer, null);
            br_st__list.addFooterView(footer, null, false)


            if (pronameArray.size > 4) {
                img_arrow.visibility = View.VISIBLE
            }

            /* var total = 0.0F
            var igsttot = 0.0F
            var cesstotals = 0.0F
            var b = 2
            for (i in 0 until proidArray.count()) {
                var c = (priceArray[i])
                var cy=(igsttotArray[i])
                var cyz=(cesstotalArray[i])
                var qyz=(quantityArray[i])


                    var cdec = c.toBigDecimal()
                    var qyzdec = qyz.toBigDecimal()
                    var totquanpri = (cdec * qyzdec)




                    total = total.plus(totquanpri.toInt())

                    igsttot = igsttot.plus(cy.toFloat())
                    cesstotals = cesstotals.plus(cyz.toFloat())

                    igst_tot.text = DecimalFormat("##.##").format(igsttot)
                    var l = igst_tot.text.toString()
                    var ss = l.toBigDecimal()
                    var tt = ss / b.toBigDecimal()
                    cgst_tot.text = DecimalFormat("##.##").format(tt)
                    sgst_tot.text = DecimalFormat("##.##").format(tt)

                cess_tot.text = DecimalFormat("##.##").format(cesstotals)

                    var f = cesstotals
                    var g = igsttot

                    var op = total
                    var m = f.toFloat()
                    var n = g.toFloat()

                    var yy = m + n + op

                    try {
                        gross_tot.setText(DecimalFormat("##.##").format(yy))
                        grosscheck = gross_tot.text.toString()
                    } catch (e: Exception) {
                        gross_tot.text = DecimalFormat("##.##").format(yy)
                        grosscheck = gross_tot.text.toString()
                    }

                    var dup = pronameArray[i]
                    var tup = dup.removeSuffix("- ml")











                }*/


        } else if (frm == "startlist") {  //Here we can view,edit,save the existing stock transfer


            save.visibility = View.INVISIBLE
            edit.visibility = View.VISIBLE

            mnu.visibility = View.GONE

            fab.isEnabled = false
            fab.visibility = View.INVISIBLE


            descrip.isEnabled = false
            stdate.isEnabled = false
            cgst.isEnabled = false
            sgst.isEnabled = false
            br_st__list.isClickable = false


            val name = intent.getStringExtra("brnm")
            val date = intent.getStringExtra("date")
            val description = intent.getStringExtra("description")
            val Stockids = intent.getStringExtra("Stockids")
            val listids = intent.getStringExtra("listids")
            val soriky = intent.getStringExtra("origiid")
            val bridky = intent.getStringExtra("brids")

            try{
                orignm=intent.getStringExtra("orignm")
            }
            catch (e:Exception){

            }

            val ad = intent.getStringExtra("addtrans")
            val ed = intent.getStringExtra("edittrans")
            val del = intent.getStringExtra("deletetrans")
            val vi = intent.getStringExtra("viewtrans")
            val tran = intent.getStringExtra("transfertrans")
            val ex = intent.getStringExtra("exporttrans")
            sendtrans = intent.getStringExtra("sendtrans")

            if (ad != null) {
                addtrans = ad
            }
            if (ed != null) {
                editetrans = ed
            }
            if (del != null) {
                deletetrans = del
            }
            if (vi != null) {
                viewtrans = vi
            }
            if (tran != null) {
                transfertrans = tran
            }
            if (ex != null) {
                exporttrans = ex
            }

            println("ADD TRANSFER" + addtrans)


            val adano = intent.getStringExtra("addtransano")
            val edano = intent.getStringExtra("edittransano")
            val delano = intent.getStringExtra("deletetransano")
            val viano = intent.getStringExtra("viewtransano")
            val tranano = intent.getStringExtra("transfertransano")
            val exano = intent.getStringExtra("exporttransano")
            sendtransano = intent.getStringExtra("sendtransano")
            if (adano != null) {
                addtransano = adano
            }
            if (edano != null) {
                editetransano = edano
            }
            if (delano != null) {
                deletetransano = delano
            }
            if (viano != null) {
                viewtransano = viano
            }
            if (tranano != null) {
                transfertransano = tranano
            }
            if (exano != null) {
                exporttransano = exano
            }


            val adrec = intent.getStringExtra("addrec")
            val edrec = intent.getStringExtra("editrec")
            val delrec = intent.getStringExtra("deleterec")
            val virec = intent.getStringExtra("viewrec")
            val tranrec = intent.getStringExtra("transferrec")
            val exrec = intent.getStringExtra("exportrec")
            val sendrec = intent.getStringExtra("sendstrec")

            if (adrec != null) {
                addrec = adrec
            }
            if (edrec != null) {
                editrec = edrec
            }
            if (delrec != null) {
                deleterec = delrec
            }
            if (virec != null) {
                viewrec = virec
            }
            if (tranrec != null) {
                transferrec = tranrec
            }
            if (exrec != null) {
                exportrec = exrec
            }
            if (sendrec != null) {
                sendstrec = sendrec
            }


            //Purchase order


            comttname.setText(name)
            stdate.setText(date)
            descrip.setText(description)
            stno.setText(Stockids)
            listoids.setText(listids)
            brnchid.setText(bridky)
            origiky = soriky
            datestk = stdate.text.toString()
            try {
                stdatedup = datestk
            } catch (e: Exception) {

            }
            println("DATE DUDEEEE" + datestk)
            descstk = descrip.text.toString()
            descripdup = descstk
            stkidstock = stno.text.toString()
            ididdb = listoids.text.toString()


            nameofbrnch = comttname.text.toString()
            locofbrnch = comphone.text.toString()
            keyofbrnch = brnchid.text.toString()

            var lista = arrayListOf<String>()
            var d = arrayListOf<String>()
            var dp = arrayListOf<String>()
            var upret = arrayListOf<String>()
            var dpu = arrayListOf<String>()
            var dlt = arrayOf<String>()


            val dl = intent.getStringArrayListExtra("dlt")


            val t = intent.getStringExtra("reid")
            Log.d("gfdgdhd", "RE_   ID OUTTTTT" + t)


            //Save

            db.collection("${origiky}_Stock_Transfer/${listoids.text}/Stock_products")
                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                        if (e != null) {
                            Log.w("", "Listen failed.", e)
                            return@EventListener
                        }

                        if (value.isEmpty == false) {
                            for (document in value) {

                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                println(document.data)

                                var dt = document.data
                                var id = (document.id)
                                id = id
                                ids = ids.plusElement(id)
                                /*idsforup=ids*/
                                println("Heyyyyyyy" + Arrays.toString(ids))
                                println("HELLOOOOOOOOO" + id)
                                pronameArray.add(dt["stk_name"].toString())

                                manufacturerArray.add(dt["stk_mfr"].toString())
                                hsnArray.add(dt["stk_hsn"].toString())

                                quantityArray.add(dt["stk_received"].toString())

                                priceArray.add(dt["stk_price"].toString())
                                totArray.add(dt["stk_total"].toString())
                                barcodeArray.add(dt["stk_barcode"].toString())
                                cessArray.add(dt["stk_cess"].toString())
                                igstArray.add(dt["otherstk_igst"].toString())
                                igsttotArray.add(dt["otherstk_igsttotal"].toString())
                                cesstotalArray.add(dt["otherstk_cesstotal"].toString())
                                tallyArray.add(dt["otherstk_tally"].toString())
                                receivedArray.add(dt["otherstk_received"].toString())
                                proidArray.add(dt["stk_proid"].toString())
                                proidArraycopy.add(dt["stk_proid"].toString())
                                keyArray.add(id)
                                quantityArraycopy.add(dt["stk_received"].toString())

                                println("QUANCOPY STARTLIST" + quantityArraycopy)
                                println("PRID COPY STARTLIST" + proidArraycopy)





                                try {
                                    var im = (dt["otherstk_img"].toString())
                                    if (im.isNotEmpty()) {

                                        imageArray.add(im)

                                    } else {
                                        imageArray.add("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                    }
                                } catch (e: Exception) {

                                }

                            }
                        } else {

                        }
                        val whatever = scrolladd_stock_one_adap(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray,
                                totArray, cessArray, keyArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, imageArray)
                        br_st__list.adapter = whatever
                        val footer = View.inflate(this@Mainstk_branch_one, R.layout.footer, null);
                        br_st__list.addFooterView(footer, null, false)

                        save_progress.visibility = View.GONE
                        if (savecli != "clicked") {
                            var total = 0.0F
                            var igsttot = 0.0F
                            var cesstotals = 0.0F
                            var b = 2
                            for (i in 0 until proidArray.count()) {
                                var c = (priceArray[i])
                                var cy = (igsttotArray[i])
                                var cyz = (cesstotalArray[i])
                                var qyz = (quantityArray[i])


                                var cdec = c.toBigDecimal()
                                var qyzdec = qyz.toBigDecimal()
                                var totquanpri = (cdec * qyzdec)




                                total = total.plus(totquanpri.toInt())

                                igsttot = igsttot.plus(cy.toFloat())
                                cesstotals = cesstotals.plus(cyz.toFloat())

                                igst_tot.setText((String.format("%.2f",igsttot)))
                                var l = igst_tot.text.toString()
                                var ss = l.toBigDecimal()
                                var tt = ss / b.toBigDecimal()
                                cgst_tot.setText((String.format("%.2f",tt)))
                                sgst_tot.setText((String.format("%.2f",tt)))

                                cess_tot.setText((String.format("%.2f",cesstotals)))

                                var f = cesstotals
                                var g = igsttot

                                var op = total
                                var m = f.toFloat()
                                var n = g.toFloat()

                                var yy = m + n + op

                                try {
                                    gross_tot.setText((String.format("%.2f",yy)))
                                    grosscheck = gross_tot.text.toString()
                                } catch (e: Exception) {
                                    gross_tot.setText((String.format("%.2f",yy)))
                                    grosscheck = gross_tot.text.toString()
                                }

                                if (pronameArray.size > 4) {
                                    img_arrow.visibility = View.VISIBLE
                                }

                            }
                        }


                    })


        }
        descrip.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {


            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {


            }
        })
        save.setOnClickListener { views ->


            if (grosscheck != gross_tot.text.toString()) {
                listListener = "listadded"
            }

            if (deletelistener == "listdelete") {
                listListener = "listadded"
            }
            if ((stdatedup != stdate.text.toString()) || (descripdup != descrip.text.toString())) {
                descriplistener = "descchanged"
            }



            if (net_status() == true) {
                savecli = "clicked"
                println("TRANSFER TRANS" + transfertrans)
                if ((listoids.text == "") && (transfertrans == "true")&&(pronameArray.isNotEmpty())) {
                    pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialogs!!.setTitleText("Saving...")
                    pDialogs!!.setCancelable(false)
                    pDialogs!!.show()



                    //Save stock transfer

                    onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray,
                            priceArray, totArray, cessArray, igstArray, igsttotArray, cesstotalArray, tallyArray,
                            receivedArray, keyArray, imageArray, proidArray)

                } else if ((listoids.text != "") && (transfertrans == "true")&&(pronameArray.isNotEmpty())) {


                    if (((descriplistener == "descchanged") && (listListener == "listadded"))||((descriplistener != "descchanged")&&(listListener == "listadded"))) {

                       pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                        pDialogs!!.setTitleText("Saving...")
                        pDialogs!!.setCancelable(false)
                        pDialogs!!.show()



                        //Update existing stock transfer


                        var stkid = (stno.text).toString()
                        var stkdate = (stdate.text).toString()
                        var stkdesc = (descrip.text).toString()
                        var destination = (comttname.text).toString()
                        var address = (comphone.text).toString()
                        var stktotals = (gross_tot.text).toString()
                        var brid = (brnchid.text).toString()
                        var originid = origiky

                        var recnt = "0"
                        var rec_status = "Not Tallied"
                        val c = Calendar.getInstance()
                        System.out.println("Current time =&gt; " + c.time)


                        val df = SimpleDateFormat("dd/MM/yyyy")
                        val formattedDate = df.format(c.time)
                        var dt = formattedDate

                        val data = s(stkid = stkid, stkdate = stkdate, stk_Desc = stkdesc, stk_destination = destination,
                                stk_address = address, stk_total = stktotals, stk_brid = brid, stk_origin = originid,stk_originname = orignm)
                        var db = FirebaseFirestore.getInstance()
                        println(Arrays.toString(ids))
                        var refid = listoids.text.toString()
                        println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                        var path = "${origiky}_Stock_Transfer/$refid/Stock_products"
                        var receive_path = "${brnchid.text.toString()}_Receive Stock/$refid/Received stock items"


                        val map = mutableMapOf<String, Any?>()
                        map.put("Receive_count", recnt)
                        map.put("Receive_date", dt)

                        map.put("Status", rec_status)

                        for (m in 0 until ids.size) {
                            db.collection(path).document(ids[m].toString())
                                    .delete()
                                    .addOnCompleteListener {

                                        for (m in 0 until ids.size) {
                                            db.collection(receive_path).document(ids[m].toString())
                                                    .delete()
                                                    .addOnCompleteListener {

                                                    }
                                        }
                                    }
                        }

                        db.collection("${origiky}_Stock_Transfer").document(listoids.text.toString())
                                .set(data)
                                .addOnCompleteListener {


                                    db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                            .set(data)
                                    db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                            .update(map)
                                            .addOnSuccessListener {
                                            }
                                }


                        if (deletelistener == "listdelete") {

                            for (i in 0 until proiddelete.size) {

                                var priddel = proiddelete[i]
                                var quandel = quantitydelete[i]

                                println("priddel value" + priddel)
                                println("quantitydel value" + quandel)

                                var pathofstr = priddel + "_" + originid

                                stock_in_hand_update_del(i, pathofstr, quandel, priddel)  //Update the stock on hand value when the stock is transferred.


                            }


                        }




                        for (i in 0 until proidArray.size) {
                            var stk_name = pronameArray[i]
                            var stk_mfr = manufacturerArray[i]
                            var stk_hsn = hsnArray[i]
                            var stk_bcode = barcodeArray[i]
                            var stk_quan = quantityArray[i]
                            var stk_pri = priceArray[i]
                            var stk_tot = totArray[i]
                            var stk_cess = cessArray[i]
                            var stk_igst = igstArray[i]
                            var stk_igsttot = igsttotArray[i]
                            var stk_cesstot = cesstotalArray[i]
                            var stk_tally = tallyArray[i]
                            var stk_received = receivedArray[i]
                            var stk_key = keyArray[i]
                            var im_arr = imageArray[i]

                            var pro_id = proidArray[i]


                            var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally, otherstk_received = stk_received, otherstk_img = im_arr, stk_proid = pro_id)


                            db.collection(path)
                                    .add(d)

                                    .addOnSuccessListener { documentReference ->

                                        var resid = documentReference.id

                                        db.collection("${brnchid.text.toString()}_Receive Stock/$refid/Received stock items").document(resid)
                                                .set(d)


                                        var qntval = quantityArray[i]

                                        var proids = proidArray[i]

                                        var proidscpy = proidArraycopy[i]

                                        var quancpy = quantityArraycopy[i]


                                        var pathfrbs = proids + "_" + originid

                                        println("PRO ID OF ARRAY" + proids)

                                        println("QUANTITY OF ARRAY" + qntval)

                                        println("GET OF ARRAY" + pathfrbs)

                                        stock_in_hand_update(i, pathfrbs, qntval, quancpy, proids, proidscpy) //Update the stock on hand value when the stock is transferred.


                                    }

                        }




                        Handler().postDelayed(Runnable {

                            try {
                                pDialogs!!.dismiss()
                            }
                            catch (e:Exception){

                            }


                            //Back action

                            Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()
                            val i = Intent(this@Mainstk_branch_one, WithStateActivity::class.java)
                            i.putExtra("from_br", "brsave")




                            i.putExtra("viewtrans", viewtrans)
                            i.putExtra("addtrans", addtrans)
                            i.putExtra("edittrans", editetrans)
                            i.putExtra("deletetrans", deletetrans)
                            i.putExtra("transfertrans", transfertrans)
                            i.putExtra("exporttrans", exporttrans)
                            i.putExtra("sendtrans", sendtrans)


                            i.putExtra("viewtransano", viewtransano)
                            i.putExtra("addtransano", addtransano)
                            i.putExtra("edittransano", editetransano)
                            i.putExtra("deletetransano", deletetransano)
                            i.putExtra("transfertransano", transfertransano)
                            i.putExtra("exporttransano", exporttransano)
                            i.putExtra("sendtransano", sendtransano)

                            i.putExtra("viewrec", viewrec)
                            i.putExtra("addrec", addrec)
                            i.putExtra("deleterec", deleterec)
                            i.putExtra("editrec", editrec)
                            i.putExtra("transferrec", transferrec)
                            i.putExtra("exportrec", exportrec)
                            i.putExtra("sendstrec", sendstrec)



                            i.putExtra("brky", keyofbrnch)
                            i.putExtra("orky", origiky)
                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                            finish()
                        },4000)


                    }
                    else if((descriplistener == "descchanged") && (listListener != "listadded")){
                        var refid = listoids.text.toString()
                        println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                        var path = "${origiky}_Stock_Transfer/$refid/Stock_products"
                        var receive_path = "${brnchid.text.toString()}_Receive Stock/$refid/Received stock items"

                         pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                        pDialogs!!.setTitleText("Saving...")
                        pDialogs!!.setCancelable(false)
                        pDialogs!!.show()

                        var stkid = (stno.text).toString()
                        var stkdate = (stdate.text).toString()
                        var stkdesc = (descrip.text).toString()
                        var destination = (comttname.text).toString()
                        var address = (comphone.text).toString()
                        var stktotals = (gross_tot.text).toString()
                        var brid = (brnchid.text).toString()
                        var originid = origiky

                        var recnt = "0"
                        var rec_status = "Not Tallied"
                        val c = Calendar.getInstance()
                        System.out.println("Current time =&gt; " + c.time)


                        val df = SimpleDateFormat("dd/MM/yyyy")
                        val formattedDate = df.format(c.time)
                        var dt = formattedDate

                        val data = s(stkid = stkid, stkdate = stkdate, stk_Desc = stkdesc,
                                stk_destination = destination, stk_address = address,
                                stk_total = stktotals, stk_brid = brid, stk_origin = originid,stk_originname = orignm)
                        var db = FirebaseFirestore.getInstance()
                        println(Arrays.toString(ids))



                        val map = mutableMapOf<String, Any?>()
                        map.put("Receive_count", recnt)
                        map.put("Receive_date", dt)

                        map.put("Status", rec_status)

                        db.collection("${origiky}_Stock_Transfer").document(listoids.text.toString())
                                .set(data)
                                .addOnCompleteListener {


                                    db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                            .set(data)
                                    db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                            .update(map)
                                            .addOnSuccessListener {
                                                Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()

                                                try {
                                                    pDialogs!!.dismiss()
                                                }
                                                catch (e:Exception){

                                                }

                                                val i = Intent(this@Mainstk_branch_one, WithStateActivity::class.java)
                                                i.putExtra("from_br", "brsave")




                                                i.putExtra("viewtrans", viewtrans)
                                                i.putExtra("addtrans", addtrans)
                                                i.putExtra("edittrans", editetrans)
                                                i.putExtra("deletetrans", deletetrans)
                                                i.putExtra("transfertrans", transfertrans)
                                                i.putExtra("exporttrans", exporttrans)
                                                i.putExtra("sendtrans", sendtrans)


                                                i.putExtra("viewtransano", viewtransano)
                                                i.putExtra("addtransano", addtransano)
                                                i.putExtra("edittransano", editetransano)
                                                i.putExtra("deletetransano", deletetransano)
                                                i.putExtra("transfertransano", transfertransano)
                                                i.putExtra("exporttransano", exporttransano)
                                                i.putExtra("sendtransano", sendtransano)

                                                i.putExtra("viewrec", viewrec)
                                                i.putExtra("addrec", addrec)
                                                i.putExtra("deleterec", deleterec)
                                                i.putExtra("editrec", editrec)
                                                i.putExtra("transferrec", transferrec)
                                                i.putExtra("exportrec", exportrec)
                                                i.putExtra("sendstrec", sendstrec)



                                                i.putExtra("brky", keyofbrnch)
                                                i.putExtra("orky", origiky)
                                                startActivity(i)
                                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                                finish()
                                            }
                                }

                    }
                    else if((descriplistener.isEmpty()) && (listListener.isEmpty())){
                        Toast.makeText(applicationContext,"Nothing happened for save",Toast.LENGTH_SHORT).show()

                    }

                    } else {
                    if (transfertrans == "false") {
                        popup("Transfer")
                    }
                    else if(pronameArray.isEmpty()){
                        val dialog=AlertDialog.Builder(this)
                                with(dialog){
                                    setTitle("Unable to transfer")
                                    setMessage("Please select some products.")
                                    setCancelable(false)
                                            setPositiveButton("Ok"){dialog,button ->
                                            dialog.dismiss()
                                            }
                                    val builders=dialog.create()
                                    builders.show()
                                }
                    }
                }
                } else {
                    Toast.makeText(applicationContext, "Please turn on your connection", Toast.LENGTH_SHORT).show()
                }
            }











        /*Log.d("dlt", "  " + dl)
    if (dl != null) {
        val db = FirebaseFirestore.getInstance()
        val TAG = "some"
        for (i in dl) {
            db.collection("products").document(i)
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {

                            Log.d(TAG, "cleared")



                            compnameArray = compnameArray.plusElement(task.result.get("p_nm").toString())

                            itemnmArray = itemnmArray.plusElement(task.result.get("wg_vol").toString() + " ml")
                            hsnArray = hsnArray.plusElement(task.result.get("hsn").toString())
                            orderArray = orderArray.plusElement(task.result.get("mfr").toString())
                            poArray = poArray.plusElement(task.result.get("bc").toString())



                            completeArray = completeArray.plusElement("0 / 0 Received")
                            priceArray = priceArray.plusElement(task.result.get("price").toString())



                            stk = stk.plusElement(task.result.get("mx_stk").toString())

                            imageArray = imageArray.plusElement(R.drawable.loreal_bottl)
                            d.add(task.result.id.toString())
                            dp.add(task.result.get("price").toString())
                            Log.v("bfhsfss", "PRICES VALUESSSSSSSSSSS" + d)


                            val whatever = scroll_stock_one_adap(this, compnameArray, d, orderArray, hsnArray, poArray, completeArray, priceArray, itemnmArray, imageArray)
                            br_st__list.adapter = whatever
                            Helper.getListViewSize(br_st__list);
                            var total = 0
                            for (i in 0 until dp.count()) {
                                var c = (dp[i])
                                total = total.plus(c.toInt())
                                gross_tot.text = total.toString()
                                Log.v("fgarghhgioghigjrio", "TOTALLLLLLLLLLLLL" + total)
                            }


                        } else {
                            Log.w(TAG, "Error getting documents.", task.exception)
                        }
                    }
        }
    }

*/



        //Navigate  list items to edit activity (Mainstk_branch_two)

        br_st__list.setOnItemClickListener { parent, views, position, id ->

            if(br_st__list.isClickable==true) {

                val b = Intent(applicationContext, Mainstk_branch_two::class.java)

                b.putExtra("from", "updatelist")
                b.putExtra("pnm", pronameArray)
                b.putExtra("pmanu", manufacturerArray)
                b.putExtra("phsn", hsnArray)
                b.putExtra("barcode", barcodeArray)
                b.putExtra("price", priceArray)
                b.putExtra("proids", proidArray)
                b.putExtra("proidscpy", proidArraycopy)
                b.putExtra("quan", quantityArray)
                b.putExtra("tot", totArray)
                b.putExtra("cessup", cessArray)
                b.putExtra("igst", igstArray)
                b.putExtra("igsttotal", igsttotArray)
                b.putExtra("cesstotarray", cesstotalArray)
                b.putExtra("tallyarray", tallyArray)
                b.putExtra("receivedarray", receivedArray)
                b.putExtra("quanarraycpy", quantityArraycopy)
                b.putExtra("deletelistner", deletelistener)





                b.putExtra("proiddelete", proiddelete)

                b.putExtra("quantitydelete", quantitydelete)



                 b.putExtra("descripdup",descripdup)
                 b.putExtra("stdatedup",stdatedup)



                b.putExtra("image", imageArray)
                b.putExtra("branch", comttname.text.toString())
                b.putExtra("address", comphone.text.toString())
                b.putExtra("sstkdate", stdate.text.toString())
                b.putExtra("orignm",orignm)
                b.putExtra("ssstockid", stkidstock)
                b.putExtra("ssstkdesc", descstk)
                b.putExtra("idofdb", ididdb)
                b.putExtra("idsofli", keyArray)
                b.putExtra("groschk", gross_tot.text.toString())
                b.putExtra("smlistids", smlistids)
                b.putExtra("keybrnch", keyofbrnch)
                b.putExtra("originkeys", origiky)


                b.putExtra("ids", ids)




                b.putExtra("viewtrans", viewtrans)
                b.putExtra("addtrans", addtrans)
                b.putExtra("edittrans", editetrans)
                b.putExtra("deletetrans", deletetrans)
                b.putExtra("transfertrans", transfertrans)
                b.putExtra("exporttrans", exporttrans)
                b.putExtra("sendtrans", sendtrans)


                b.putExtra("viewtransano", viewtransano)
                b.putExtra("addtransano", addtransano)
                b.putExtra("edittransano", editetransano)
                b.putExtra("deletetransano", deletetransano)
                b.putExtra("transfertransano", transfertransano)
                b.putExtra("exporttransano", exporttransano)
                b.putExtra("sendtransano", sendtransano)

                b.putExtra("viewrec", viewrec)
                b.putExtra("addrec", addrec)
                b.putExtra("deleterec", deleterec)
                b.putExtra("editrec", editrec)
                b.putExtra("transferrec", transferrec)
                b.putExtra("exportrec", exportrec)
                b.putExtra("sendstrec", sendstrec)



                b.putExtra("pos", position)
                println("KEY OF BRANCHHHH" + keyofbrnch)
                startActivity(b)
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_left)
                finish()
            }
            else{

            }
        }


/*fun tot() {


    val ca = intent.getStringExtra("nms")
    comttname.setText(ca)
    val cab = intent.getStringExtra("nmsstate")
    comphone.setText(cab)
}
tot()*/

        var s = pri.add(priceArray.toString())
        Log.v("ghdgkhgfhg", "PRICESSSSSSSS" + s)





        //Navigate to add product lists (product_list_activity)

        fab.setOnClickListener {
            println(priceArray.size)
            println(pronameArray)
            println(priceArray)
            if ((priceArray.size == 0)&&(addtrans=="true")) {

                val intent = Intent(this, product_list_activity::class.java)
                intent.putExtra("from", "emptylist")
                intent.putExtra("branch", comttname.text.toString())
                intent.putExtra("address", comphone.text.toString())
                intent.putExtra("brnchid",keyofbrnch)
                intent.putExtra("date",stdate.text.toString())
                intent.putExtra("ssstockid",stno.text.toString())
                intent.putExtra("ssstkdesc",descrip.text.toString())
                intent.putExtra("origiid",origiky)
                intent.putExtra("groschk",gross_tot.text.toString())

                intent.putExtra("deletelistner",deletelistener)







                intent.putExtra("orignm",orignm)


                intent.putExtra("viewtrans", viewtrans)
                intent.putExtra("addtrans", addtrans)
                intent.putExtra("edittrans", editetrans)
                intent.putExtra("deletetrans", deletetrans)
                intent.putExtra("transfertrans", transfertrans)
                intent.putExtra("exporttrans", exporttrans)
                intent.putExtra("sendtrans", sendtrans)

                intent.putExtra("descripdup",descripdup)
                intent.putExtra("stdatedup",stdatedup)
                intent.putExtra("viewtransano", viewtransano)
                intent.putExtra("addtransano", addtransano)
                intent.putExtra("edittransano", editetransano)
                intent.putExtra("deletetransano", deletetransano)
                intent.putExtra("transfertransano", transfertransano)
                intent.putExtra("exporttransano", exporttransano)
                intent.putExtra("sendtransano", sendtransano)

                intent.putExtra("viewrec", viewrec)
                intent.putExtra("addrec", addrec)
                intent.putExtra("deleterec", deleterec)
                intent.putExtra("editrec", editrec)
                intent.putExtra("transferrec", transferrec)
                intent.putExtra("exportrec", exportrec)
                intent.putExtra("sendstrec",sendstrec)






                intent.putExtra("proiddelete", proiddelete)

                intent.putExtra("quantitydelete", quantitydelete)

                println(nameofbrnch)

                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                finish()
            } else if((priceArray.size != 0)&&(addtrans=="true")){
                val intent = Intent(this, product_list_activity::class.java)
                intent.putExtra("from", "datalist")
                intent.putExtra("namess", pronameArray)
                intent.putExtra("orderarray", manufacturerArray)
                intent.putExtra("hsn", hsnArray)
                intent.putExtra("poarray", barcodeArray)
                intent.putExtra("complete", quantityArray)
                intent.putExtra("price", priceArray)
                intent.putExtra("total", totArray)
                intent.putExtra("cess", cessArray)
                intent.putExtra("igst", igstArray)
                intent.putExtra("igsttotal", igsttotArray)
                intent.putExtra("cesstotarray", cesstotalArray)
                intent.putExtra("tallyarray", tallyArray)
                intent.putExtra("receivedarray", receivedArray)
                intent.putExtra("proidarray", proidArray)
                intent.putExtra("proidarraycpy", proidArraycopy)
                intent.putExtra("quancpy", quantityArraycopy)

                intent.putExtra("im", imageArray)
                intent.putExtra("branch", comttname.text.toString())
                intent.putExtra("address", comphone.text.toString())
                intent.putExtra("sstkdate",stdate.text.toString())
                intent.putExtra("ssstockid",stno.text.toString())
                intent.putExtra("ssstkdesc",descrip.text.toString())
                intent.putExtra("idofdb",ididdb)
                intent.putExtra("brnchid",keyofbrnch)
                intent.putExtra("grosschk",grosscheck)
                intent.putExtra("idsofli",keyArray)
                intent.putExtra("origiid",origiky)

                intent.putExtra("orignm",orignm)
                intent.putExtra("ids",ids)







                intent.putExtra("descripdup",descripdup)
                intent.putExtra("stdatedup",stdatedup)

                intent.putExtra("viewtrans", viewtrans)
                intent.putExtra("addtrans", addtrans)
                intent.putExtra("edittrans", editetrans)
                intent.putExtra("deletetrans", deletetrans)
                intent.putExtra("transfertrans", transfertrans)
                intent.putExtra("exporttrans", exporttrans)
                intent.putExtra("sendtrans", sendtrans)


                intent.putExtra("viewtransano", viewtransano)
                intent.putExtra("addtransano", addtransano)
                intent.putExtra("edittransano", editetransano)
                intent.putExtra("deletetransano", deletetransano)
                intent.putExtra("transfertransano", transfertransano)
                intent.putExtra("exporttransano", exporttransano)
                intent.putExtra("sendtransano", sendtransano)

                intent.putExtra("viewrec", viewrec)
                intent.putExtra("addrec", addrec)
                intent.putExtra("deleterec", deleterec)
                intent.putExtra("editrec", editrec)
                intent.putExtra("transferrec", transferrec)
                intent.putExtra("exportrec", exportrec)
                intent.putExtra("sendstrec",sendstrec)



                intent.putExtra("proiddelete", proiddelete)

                intent.putExtra("quantitydelete", quantitydelete)

                intent.putExtra("deletelistner",deletelistener)



                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                finish()
            }
            else{
                popup("Add")
            }



        }
        userback.setOnClickListener {
          onBackPressed()
        }

        mnu.setOnClickListener({ //Menu contains two options 'Send this ST' , 'Export as Pdf'.


            val popup = PopupMenu(this@Mainstk_branch_one, mnu)

            popup.menuInflater.inflate(R.menu.branch_one, popup.menu)

            popup.setOnMenuItemClickListener { item ->

                if(item.title=="Send this ST"){   //Clicked 'Send this ST'

            if((exporttrans=="true")&&(net_status()==true)) {


                sendst="send"

            idstk = stno.text.toString()
            names = comttname.text.toString()
            addressnames = comphone.text.toString()
            cgstt = cgst_tot.text.toString()
            sgstt = sgst_tot.text.toString()
            cesst = cess_tot.text.toString()
            grosstt = gross_tot.text.toString()

                val b = Intent(this@Mainstk_branch_one, MainBranchPdf::class.java)
                b.putExtra("from", "mainpdf")
                b.putExtra("pnm", pronameArray)
                b.putExtra("pmanu", manufacturerArray)
                b.putExtra("phsn", hsnArray)
                b.putExtra("barcode", barcodeArray)
                b.putExtra("price", priceArray)

                b.putExtra("deletelistener",deletelistener)


                b.putExtra("proiddelete", proiddelete)

                b.putExtra("quantitydelete", quantitydelete)
                b.putExtra("quan", quantityArray)
                b.putExtra("tot", totArray)
                b.putExtra("cessup", cessArray)
                b.putExtra("igst", igstArray)
                b.putExtra("igsttotal", igsttotArray)
                b.putExtra("cesstotarray", cesstotalArray)
                b.putExtra("tallyarray", tallyArray)
                b.putExtra("receivedarray", receivedArray)
                b.putExtra("proidarray", proidArray)
                b.putExtra("proidarraycpy", proidArraycopy)
                b.putExtra("quancpyarray", quantityArraycopy)
                b.putExtra("image", imageArray)
                b.putExtra("branch", comttname.text.toString())
                b.putExtra("address", comphone.text.toString())
                b.putExtra("sstkdate", stdate.text.toString())
                b.putExtra("ssstockid", stkidstock)
                b.putExtra("ssstkdesc", descstk)
                b.putExtra("idofdb", ididdb)
                b.putExtra("idsofli", keyArray)
                b.putExtra("smlistids", smlistids)
                b.putExtra("keybrnch", keyofbrnch)
                b.putExtra("gross", gross_tot.text.toString())
                b.putExtra("cgsttot", cgst_tot.text.toString())
                b.putExtra("sgsttot", sgst_tot.text.toString())
                b.putExtra("cesstot", cess_tot.text.toString())

                b.putExtra("sendst",sendst)
                b.putExtra("originkeys", origiky)

                b.putExtra("descripdup",descripdup)
                b.putExtra("stdatedup",stdatedup)
                b.putExtra("grosschk",grosscheck)
                b.putExtra("ids",ids)

                b.putExtra("orignm",orignm)
                b.putExtra("viewtrans", viewtrans)
                b.putExtra("addtrans", addtrans)
                b.putExtra("edittrans", editetrans)
                b.putExtra("deletetrans", deletetrans)
                b.putExtra("transfertrans", transfertrans)
                b.putExtra("exporttrans", exporttrans)
                b.putExtra("sendtrans", sendtrans)


                b.putExtra("viewtransano", viewtransano)
                b.putExtra("addtransano", addtransano)
                b.putExtra("edittransano", editetransano)
                b.putExtra("deletetransano", deletetransano)
                b.putExtra("transfertransano", transfertransano)
                b.putExtra("exporttransano", exporttransano)
                b.putExtra("sendtransano", sendtransano)

                b.putExtra("viewrec", viewrec)
                b.putExtra("addrec", addrec)
                b.putExtra("deleterec", deleterec)
                b.putExtra("editrec", editrec)
                b.putExtra("transferrec", transferrec)
                b.putExtra("exportrec", exportrec)
                b.putExtra("sendstrec",sendstrec)





                println("KEY OF BRANCHHHH" + keyofbrnch)
                startActivity(b)
                overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                finish()


    /*createandDisplayPdf(idstk, datestk, names, addressnames, descstk, cgstt, sgstt, cesst, grosstt)  //Make stock transfer details to pdf document.
    var f = idstk + "_stock transfer"

    var y = f + ".pdf"
    val share = Intent(Intent.ACTION_SEND)   //And send that pdf document using this 'ACTION_SEND'
    share.type = "application/pdf"

    pdfFile = File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Stock Transfer" + "/" + y).toString()


    try {
        sendMail(pdfFile)
    } catch (e: IOException) {
        Toast.makeText(applicationContext, "Couldn't Send", Toast.LENGTH_SHORT).show()
    }*/
}
                    else{
                if(net_status()==false){
                    Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()

                }
                else{
                    popup("Send")

                }
                    }

                    return@setOnMenuItemClickListener true


                    // View v1 = iv.getRootView(); //even this works
                    // View v1 = findViewById(android.R.id.content); //this works too
                    // but gives only content
                    /*   var myBitmap: Bitmap? = null
                       v1.isDrawingCacheEnabled = true
                       myBitmap = v1.drawingCache
                       saveBitmap(myBitmap)*/

                }
                else if(item.title=="Export as pdf") {             //Navigate  to pdf activity with details. (MainBranchPdf)


                    if ((exporttrans == "true")&&(net_status()==true)) {
                        val b = Intent(this@Mainstk_branch_one, MainBranchPdf::class.java)
                        b.putExtra("from", "mainpdf")
                        b.putExtra("pnm", pronameArray)
                        b.putExtra("pmanu", manufacturerArray)
                        b.putExtra("phsn", hsnArray)
                        b.putExtra("barcode", barcodeArray)
                        b.putExtra("price", priceArray)

                        b.putExtra("deletelistener",deletelistener)


                        b.putExtra("proiddelete", proiddelete)

                        b.putExtra("quantitydelete", quantitydelete)
                        b.putExtra("quan", quantityArray)
                        b.putExtra("tot", totArray)
                        b.putExtra("cessup", cessArray)
                        b.putExtra("igst", igstArray)
                        b.putExtra("igsttotal", igsttotArray)
                        b.putExtra("cesstotarray", cesstotalArray)
                        b.putExtra("tallyarray", tallyArray)
                        b.putExtra("receivedarray", receivedArray)
                        b.putExtra("proidarray", proidArray)
                        b.putExtra("proidarraycpy", proidArraycopy)
                        b.putExtra("quancpyarray", quantityArraycopy)
                        b.putExtra("image", imageArray)
                        b.putExtra("branch", comttname.text.toString())
                        b.putExtra("address", comphone.text.toString())
                        b.putExtra("sstkdate", stdate.text.toString())
                        b.putExtra("ssstockid", stkidstock)
                        b.putExtra("ssstkdesc", descstk)
                        b.putExtra("idofdb", ididdb)
                        b.putExtra("idsofli", keyArray)
                        b.putExtra("smlistids", smlistids)
                        b.putExtra("keybrnch", keyofbrnch)
                        b.putExtra("gross", gross_tot.text.toString())
                        b.putExtra("cgsttot", cgst_tot.text.toString())
                        b.putExtra("sgsttot", sgst_tot.text.toString())
                        b.putExtra("cesstot", cess_tot.text.toString())
                        b.putExtra("sendst",sendst)

                        b.putExtra("originkeys", origiky)

                        b.putExtra("descripdup",descripdup)
                        b.putExtra("stdatedup",stdatedup)
                        b.putExtra("grosschk",grosscheck)
                        b.putExtra("ids",ids)

                        b.putExtra("orignm",orignm)
                        b.putExtra("viewtrans", viewtrans)
                        b.putExtra("addtrans", addtrans)
                        b.putExtra("edittrans", editetrans)
                        b.putExtra("deletetrans", deletetrans)
                        b.putExtra("transfertrans", transfertrans)
                        b.putExtra("exporttrans", exporttrans)
                        b.putExtra("sendtrans", sendtrans)


                        b.putExtra("viewtransano", viewtransano)
                        b.putExtra("addtransano", addtransano)
                        b.putExtra("edittransano", editetransano)
                        b.putExtra("deletetransano", deletetransano)
                        b.putExtra("transfertransano", transfertransano)
                        b.putExtra("exporttransano", exporttransano)
                        b.putExtra("sendtransano", sendtransano)

                        b.putExtra("viewrec", viewrec)
                        b.putExtra("addrec", addrec)
                        b.putExtra("deleterec", deleterec)
                        b.putExtra("editrec", editrec)
                        b.putExtra("transferrec", transferrec)
                        b.putExtra("exportrec", exportrec)
                        b.putExtra("sendstrec",sendstrec)





                        println("KEY OF BRANCHHHH" + keyofbrnch)
                        startActivity(b)
                        overridePendingTransition(R.anim.slide_in_left,R.anim.slide_out_left)
                        finish()
                    }
                }
                else{
                    if(net_status()==false){
                        Toast.makeText(applicationContext,"You're offline",Toast.LENGTH_SHORT).show()

                    }
                    else{
                        popup("Export")

                    }
                }
                true
            }

            popup.show()

        })


    }


    override fun onBackPressed() {


println("grosscheck value onbackpressed"+grosscheck)
        println("grosstotal value onbackpressed"+gross_tot.text.toString())

        if (grosscheck != gross_tot.text.toString()) {
            if(pronameArray.isNotEmpty()) {
                listListener = "listadded"
            }
            else if(pronameArray.isEmpty()){
                listListener = ""

            }

        }

        if(deletelistener=="listdelete"){
            listListener="listadded"
        }
        if((stdatedup!=stdate.text.toString())||(descripdup!=descrip.text.toString())){
            if(pronameArray.isNotEmpty()) {
                descriplistener = "descchanged"
            }
            else if(pronameArray.isEmpty()){
                descriplistener = ""

            }
        }


        if((listListener=="listadded")||(descriplistener=="descchanged")){

            savepopup()

        }
        else if((listListener.isEmpty())&&(descriplistener.isEmpty())){
            val i = Intent(this@Mainstk_branch_one, WithStateActivity::class.java)
            i.putExtra("from_br", "brsave")







            i.putExtra("viewtrans", viewtrans)
            i.putExtra("addtrans", addtrans)
            i.putExtra("edittrans", editetrans)
            i.putExtra("deletetrans", deletetrans)
            i.putExtra("transfertrans", transfertrans)
            i.putExtra("exporttrans", exporttrans)
            i.putExtra("sendtrans", sendtrans)


            i.putExtra("viewtransano", viewtransano)
            i.putExtra("addtransano", addtransano)
            i.putExtra("edittransano", editetransano)
            i.putExtra("deletetransano", deletetransano)
            i.putExtra("transfertransano", transfertransano)
            i.putExtra("exporttransano", exporttransano)
            i.putExtra("sendtransano", sendtransano)

            i.putExtra("viewrec", viewrec)
            i.putExtra("addrec", addrec)
            i.putExtra("deleterec", deleterec)
            i.putExtra("editrec", editrec)
            i.putExtra("transferrec", transferrec)
            i.putExtra("exportrec", exportrec)
            i.putExtra("sendstrec",sendstrec)



            i.putExtra("brky", keyofbrnch)
            i.putExtra("orky", origiky)
            startActivity(i)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }
    }

    fun savepopup(){   // save popup

 val builder = AlertDialog.Builder(this@Mainstk_branch_one)
        with(builder) {
            setTitle("Save changes?")
            setMessage("Do you want to save?")
            setPositiveButton("Yes") { dialog, whichButton ->

                if(net_status()==true) {
                    savecli="clicked"

                    if ((listoids.text == "") && (transfertrans == "true")&&(pronameArray.isNotEmpty())) {
                        pDialogs = SweetAlertDialog(this@Mainstk_branch_one, SweetAlertDialog.PROGRESS_TYPE)
                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                        pDialogs!!.setTitleText("Saving...")
                        pDialogs!!.setCancelable(false)
                        pDialogs!!.show()


                        //Save new stock transfer
                        onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray, cessArray, igstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, keyArray, imageArray, proidArray)

                    } else if ((listoids.text != "") && (transfertrans == "true")&&(pronameArray.isNotEmpty())) {


                        if (((descriplistener == "descchanged") && (listListener == "listadded")) || ((descriplistener != "descchanged") && (listListener == "listadded"))) {

                             pDialogs = SweetAlertDialog(this@Mainstk_branch_one, SweetAlertDialog.PROGRESS_TYPE)

                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                            pDialogs!!.setTitleText("Saving...")
                            pDialogs!!.setCancelable(false)
                            pDialogs!!.show()


                            //update the existing stock transfer

                            var stkid = (stno.text).toString()
                            var stkdate = (stdate.text).toString()
                            var stkdesc = (descrip.text).toString()
                            var destination = (comttname.text).toString()
                            var address = (comphone.text).toString()
                            var stktotals = (gross_tot.text).toString()
                            var brid = (brnchid.text).toString()
                            var originid = origiky

                            var recnt = "0"
                            var rec_status = "Not Tallied"
                            val c = Calendar.getInstance()
                            System.out.println("Current time =&gt; " + c.time)


                            val df = SimpleDateFormat("dd/MM/yyyy")
                            val formattedDate = df.format(c.time)
                            var dt = formattedDate

                            val data = s(stkid = stkid, stkdate = stkdate, stk_Desc = stkdesc,
                                    stk_destination = destination, stk_address = address,
                                    stk_total = stktotals, stk_brid = brid, stk_origin = originid,stk_originname = orignm)
                            var db = FirebaseFirestore.getInstance()
                            println(Arrays.toString(ids))
                            var refid = listoids.text.toString()
                            println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                            var path = "${origiky}_Stock_Transfer/$refid/Stock_products"
                            var receive_path = "${brnchid.text.toString()}_Receive Stock/$refid/Received stock items"


                            val map = mutableMapOf<String, Any?>()
                            map.put("Receive_count", recnt)
                            map.put("Receive_date", dt)

                            map.put("Status", rec_status)

                            for (m in 0 until ids.size) {
                                db.collection(path).document(ids[m].toString())
                                        .delete()
                                        .addOnCompleteListener {

                                            for (m in 0 until ids.size) {
                                                db.collection(receive_path).document(ids[m].toString())
                                                        .delete()
                                                        .addOnCompleteListener {

                                                        }
                                            }
                                        }
                            }

                            db.collection("${origiky}_Stock_Transfer").document(listoids.text.toString())
                                    .set(data)
                                    .addOnCompleteListener {


                                        db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                                .set(data)
                                        db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                                .update(map)
                                                .addOnSuccessListener {
                                                }
                                    }


                            if (deletelistener == "listdelete") {

                                for (i in 0 until proiddelete.size) {

                                    var priddel = proiddelete[i]
                                    var quandel = quantitydelete[i]

                                    println("priddel value" + priddel)
                                    println("quantitydel value" + quandel)

                                    var pathofstr = priddel + "_" + originid

                                    stock_in_hand_update_del(i, pathofstr, quandel, priddel)  //Update the stock on hand value


                                }


                            }




                            for (i in 0 until proidArray.size) {
                                var stk_name = pronameArray[i]
                                var stk_mfr = manufacturerArray[i]
                                var stk_hsn = hsnArray[i]
                                var stk_bcode = barcodeArray[i]
                                var stk_quan = quantityArray[i]
                                var stk_pri = priceArray[i]
                                var stk_tot = totArray[i]
                                var stk_cess = cessArray[i]
                                var stk_igst = igstArray[i]
                                var stk_igsttot = igsttotArray[i]
                                var stk_cesstot = cesstotalArray[i]
                                var stk_tally = tallyArray[i]
                                var stk_received = receivedArray[i]
                                var stk_key = keyArray[i]
                                var im_arr = imageArray[i]

                                var pro_id = proidArray[i]


                                var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally, otherstk_received = stk_received, otherstk_img = im_arr, stk_proid = pro_id)


                                db.collection(path)
                                        .add(d)

                                        .addOnSuccessListener { documentReference ->

                                            var resid = documentReference.id

                                            db.collection("${brnchid.text.toString()}_Receive Stock/$refid/Received stock items").document(resid)
                                                    .set(d)


                                            var qntval = quantityArray[i]

                                            var proids = proidArray[i]

                                            var proidscpy = proidArraycopy[i]

                                            var quancpy = quantityArraycopy[i]


                                            var pathfrbs = proids + "_" + originid

                                            println("PRO ID OF ARRAY" + proids)

                                            println("QUANTITY OF ARRAY" + qntval)

                                            println("GET OF ARRAY" + pathfrbs)

                                            stock_in_hand_update(i, pathfrbs, qntval, quancpy, proids, proidscpy) //Update the stock on hand value


                                        }


                            }







                            Handler().postDelayed(Runnable {
                                try {
                                    pDialogs!!.dismiss()
                                }
                                catch (e:Exception){

                                }
                                Toast.makeText(this@Mainstk_branch_one, "Your Data is Saved", Toast.LENGTH_LONG).show()

                            val i = Intent(this@Mainstk_branch_one, WithStateActivity::class.java)
                            i.putExtra("from_br", "brsave")




                            i.putExtra("viewtrans", viewtrans)
                            i.putExtra("addtrans", addtrans)
                            i.putExtra("edittrans", editetrans)
                            i.putExtra("deletetrans", deletetrans)
                            i.putExtra("transfertrans", transfertrans)
                            i.putExtra("exporttrans", exporttrans)
                            i.putExtra("sendtrans", sendtrans)


                            i.putExtra("viewtransano", viewtransano)
                            i.putExtra("addtransano", addtransano)
                            i.putExtra("edittransano", editetransano)
                            i.putExtra("deletetransano", deletetransano)
                            i.putExtra("transfertransano", transfertransano)
                            i.putExtra("exporttransano", exporttransano)
                            i.putExtra("sendtransano", sendtransano)

                            i.putExtra("viewrec", viewrec)
                            i.putExtra("addrec", addrec)
                            i.putExtra("deleterec", deleterec)
                            i.putExtra("editrec", editrec)
                            i.putExtra("transferrec", transferrec)
                            i.putExtra("exportrec", exportrec)
                            i.putExtra("sendstrec", sendstrec)



                            i.putExtra("brky", keyofbrnch)
                            i.putExtra("orky", origiky)
                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                            finish()
                            },4000)
                        } else if ((descriplistener == "descchanged") && (listListener != "listadded")) {


                            //update the existing stock transfer

                            var refid = listoids.text.toString()
                            println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                            var path = "${origiky}_Stock_Transfer/$refid/Stock_products"
                            var receive_path = "${brnchid.text.toString()}_Receive Stock/$refid/Received stock items"

                            pDialogs = SweetAlertDialog(this@Mainstk_branch_one, SweetAlertDialog.PROGRESS_TYPE)
                            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                            pDialogs!!.setTitleText("Saving...")
                            pDialogs!!.setCancelable(false)
                            pDialogs!!.show()

                            var stkid = (stno.text).toString()
                            var stkdate = (stdate.text).toString()
                            var stkdesc = (descrip.text).toString()
                            var destination = (comttname.text).toString()
                            var address = (comphone.text).toString()
                            var stktotals = (gross_tot.text).toString()
                            var brid = (brnchid.text).toString()
                            var originid = origiky

                            var recnt = "0"
                            var rec_status = "Not Tallied"
                            val c = Calendar.getInstance()
                            System.out.println("Current time =&gt; " + c.time)


                            val df = SimpleDateFormat("dd/MM/yyyy")
                            val formattedDate = df.format(c.time)
                            var dt = formattedDate

                            val data = s(stkid = stkid, stkdate = stkdate, stk_Desc = stkdesc, stk_destination = destination,
                                    stk_address = address, stk_total = stktotals, stk_brid = brid, stk_origin = originid,stk_originname = orignm)
                            var db = FirebaseFirestore.getInstance()
                            println(Arrays.toString(ids))


                            val map = mutableMapOf<String, Any?>()
                            map.put("Receive_count", recnt)
                            map.put("Receive_date", dt)

                            map.put("Status", rec_status)

                            db.collection("${origiky}_Stock_Transfer").document(listoids.text.toString())
                                    .set(data)
                                    .addOnCompleteListener {


                                        db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                                .set(data)
                                        db.collection("${brnchid.text.toString()}_Receive Stock").document(listoids.text.toString())
                                                .update(map)
                                                .addOnSuccessListener {
                                                    Toast.makeText(this@Mainstk_branch_one, "Your Data is Saved", Toast.LENGTH_LONG).show()

                                                    try {
                                                        pDialogs!!.dismiss()
                                                    }
                                                    catch (e:Exception){

                                                    }
                                                    val i = Intent(this@Mainstk_branch_one, WithStateActivity::class.java)
                                                    i.putExtra("from_br", "brsave")




                                                    i.putExtra("viewtrans", viewtrans)
                                                    i.putExtra("addtrans", addtrans)
                                                    i.putExtra("edittrans", editetrans)
                                                    i.putExtra("deletetrans", deletetrans)
                                                    i.putExtra("transfertrans", transfertrans)
                                                    i.putExtra("exporttrans", exporttrans)
                                                    i.putExtra("sendtrans", sendtrans)


                                                    i.putExtra("viewtransano", viewtransano)
                                                    i.putExtra("addtransano", addtransano)
                                                    i.putExtra("edittransano", editetransano)
                                                    i.putExtra("deletetransano", deletetransano)
                                                    i.putExtra("transfertransano", transfertransano)
                                                    i.putExtra("exporttransano", exporttransano)
                                                    i.putExtra("sendtransano", sendtransano)

                                                    i.putExtra("viewrec", viewrec)
                                                    i.putExtra("addrec", addrec)
                                                    i.putExtra("deleterec", deleterec)
                                                    i.putExtra("editrec", editrec)
                                                    i.putExtra("transferrec", transferrec)
                                                    i.putExtra("exportrec", exportrec)
                                                    i.putExtra("sendstrec", sendstrec)



                                                    i.putExtra("brky", keyofbrnch)
                                                    i.putExtra("orky", origiky)
                                                    startActivity(i)
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                                    finish()
                                                }
                                    }

                        }
                        else if((descriplistener.isEmpty()) && (listListener.isEmpty())){
                            Toast.makeText(applicationContext,"Nothing happened for save",Toast.LENGTH_SHORT).show()

                        }
                    }
                     else  {
                        if (transfertrans == "false") {
                            popup("Transfer")
                        }
                        else if(pronameArray.isEmpty()){   // If none products were selected,couldn't transfer to branch.
                            val dialog=AlertDialog.Builder(this@Mainstk_branch_one)
                            with(dialog){
                                setTitle("Unable to transfer")
                                setMessage("Please select some products.")
                                setCancelable(false)
                                setPositiveButton("Ok"){dialog,button ->
                                    dialog.dismiss()
                                }
                                val builders=dialog.create()
                                builders.show()
                            }
                        }
                    }
                }
                else{
                    dialog.dismiss()
                }
            }
            setNegativeButton("No") { dialog, whichButton ->


                //Back action
                val i = Intent(this@Mainstk_branch_one, WithStateActivity::class.java)
                i.putExtra("from_br", "brsave")




               i.putExtra("viewtrans", viewtrans)
               i.putExtra("addtrans", addtrans)
               i.putExtra("edittrans", editetrans)
               i.putExtra("deletetrans", deletetrans)
               i.putExtra("transfertrans", transfertrans)
               i.putExtra("exporttrans", exporttrans)
               i.putExtra("sendtrans", sendtrans)


               i.putExtra("viewtransano", viewtransano)
               i.putExtra("addtransano", addtransano)
               i.putExtra("edittransano", editetransano)
               i.putExtra("deletetransano", deletetransano)
               i.putExtra("transfertransano", transfertransano)
               i.putExtra("exporttransano", exporttransano)
               i.putExtra("sendtransano", sendtransano)

               i.putExtra("viewrec", viewrec)
               i.putExtra("addrec", addrec)
               i.putExtra("deleterec", deleterec)
               i.putExtra("editrec", editrec)
               i.putExtra("transferrec", transferrec)
               i.putExtra("exportrec", exportrec)
               i.putExtra("sendstrec",sendstrec)



                i.putExtra("brky", keyofbrnch)
                i.putExtra("orky", origiky)
                startActivity(i)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }
            // Dialog
            val dialog = builder.create()
            dialog.show()
        }

    }



    //Create and write pdf document for 'Send this ST' option.

   /* fun createandDisplayPdf(id:String, requestdt:String, reqname:String, reqphone:String,reqestidate:String,cgsttotal:String, sgsttotal:String, cesstotal:String, grosstot:String) {
        val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Stock Transfer"

            val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs()
            var f = idstk + "_stock transfer"

            var y=f+".pdf"

            val file = File(dir,y)
            val fOut =  FileOutputStream(file)





            PdfWriter.getInstance(doc, fOut)


            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= Font.BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize);
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Stock Transfer",fontsubheading)

            val a1=  Paragraph("Branch Name:             "+reqname,font)
            val b1=  Paragraph("Branch Address:           "+reqphone,font)
            val c1=  Paragraph("ST No:                        "+id,font)
            val d1=  Paragraph("Date:                          "+requestdt,font)
            val e1=  Paragraph("Description:                    "+reqestidate,font)
            val p13 =  Paragraph("CGST Total:                  "+cgsttotal,font)
            val p14 =  Paragraph("SGST Total:                  "+sgsttotal,font)
            val p15 =  Paragraph("CESS Total:                  "+cesstotal,font)
            val p7 =  Paragraph("Gross Total:                 "+grosstot,font)
            val p8=   Paragraph("Product Details",fontsubheading)

            val pnm= Paragraph("Product Name")
            val pri= Paragraph("Price")

            val table =  PdfPTable( floatArrayOf(2F,6F, 5F, 5F, 4F,6F, 4F ));

            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

            table.addCell("S.No")
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");

            table.addCell("Quantity");
            table.addCell("Taxes")
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for(j in 0 until cells.size)
            {
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var ces=0.0F
            for (i in 0 until priceArray.size)
            {



                var pri=priceArray[i].toFloat()
                var quan=quantityArray[i].toFloat()
                var e=igsttotArray[i].toFloat()
                var f=cesstotalArray[i].toFloat()




                    var jj = e + f

                    var grtt = jj
                    var grflo = grtt
                    var gttt = grflo + (pri * quan)





                    table.addCell(i.toString())
                    table.addCell(pronameArray[i])
                    table.addCell(hsnArray[i])
                    table.addCell(priceArray[i])

                    table.addCell(quantityArray[i])
                    table.addCell(grtt.toString())

                    table.addCell(gttt.toString())

            }
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER)
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            *//* table.addCell("")

             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("")
             table.addCell("IGST Total")
             table.addCell(igstto)*//*

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgstt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgstt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cesst)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grosstt)

            *//*val table =  PdfPTable(10);
            val  cell = PdfPCell(pnm);
           cell.colspan=1
           cell.setBorder(PdfPCell.NO_BORDER);
           cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);
            val cellCaveat =  PdfPCell(pri);
            cellCaveat.setColspan(1);
            cellCaveat.setBorder(PdfPCell.NO_BORDER);
            table.addCell(cellCaveat);
           table.addCell(cellCaveat);
           doc.add(table)*//*





            //add paragraph to document
            doc.add(h1)
            doc.add( Chunk.NEWLINE);
            doc.add(hs1)


            doc.add( Chunk.NEWLINE);
            doc.add(c1)
            doc.add( Chunk.NEWLINE );
            doc.add(d1)
            doc.add( Chunk.NEWLINE );
            doc.add(e1)
            doc.add( Chunk.NEWLINE );
            doc.add(a1)
            doc.add( Chunk.NEWLINE );
            doc.add(b1)
            doc.add( Chunk.NEWLINE );
            *//*doc.add( Chunk.NEWLINE );
            doc.add(p13)
            doc.add( Chunk.NEWLINE );
            doc.add(p14)
            doc.add( Chunk.NEWLINE );
            doc.add(p15)
            doc.add( Chunk.NEWLINE );
            doc.add(p7)*//*



            doc.add( Chunk.NEWLINE );
            doc.add(table)

            downstatus="success"


        } catch ( de: DocumentException) {
            downstatus="not"
        } catch ( e: IOException) {
            Log.e("PDFCreator", "ioException:" + e)
        }
        finally {
            doc.close()
        }


    }*/




    fun sendMail(path: String) {  //Send this stock transfer to desired path.
        val emailIntent = Intent(Intent.ACTION_SEND)
        emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,
                arrayOf("it@vinitas.co.in"))
        emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,
                "STOCK TRANSFER")
        emailIntent.putExtra(android.content.Intent.EXTRA_TEXT,
                "This is an autogenerated mail from Vinitas Inventory")
        emailIntent.type = "application/pdf"
        val myUri = Uri.parse("file://" + path)
        emailIntent.putExtra(Intent.EXTRA_STREAM, myUri)
        startActivity(Intent.createChooser(emailIntent, "Send mail..."))
        finish()
    }

    /*override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.branch_one, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.ex -> {

                val v1 = window.decorView.rootView
                // View v1 = iv.getRootView(); //even this works
                // View v1 = findViewById(android.R.id.content); //this works too
                // but gives only content
                var myBitmap: Bitmap? = null
                v1.isDrawingCacheEnabled = true
                myBitmap = v1.drawingCache
                saveBitmap(myBitmap)
                return true
            }

            else -> return super.onOptionsItemSelected(item)
        }
    }*/


    //ID GENERARION FUNCTION

    private fun onStarClicked1(pronameArray:ArrayList<String>, manufacturerArray:ArrayList<String>, hsnArray:ArrayList<String>, barcodeArray:ArrayList<String>,
                               quantityArray:ArrayList<String>, priceArray:ArrayList<String>, totArray:ArrayList<String>, cessArray:ArrayList<String>,
                               igstArray:ArrayList<String>, igsttotArray:ArrayList<String>, cesstotalArray:ArrayList<String>, tallyArray: ArrayList<String>,
                               receivedArray: ArrayList<String>, keyArray:ArrayList<String>,imageArray: ArrayList<String>,proidArray:ArrayList<String>) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("stockIds")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value

                prod_insert(id.toString(),pronameArray,manufacturerArray,hsnArray,barcodeArray,quantityArray,priceArray,totArray,cessArray,
                        igstArray,igsttotArray,cesstotalArray,tallyArray,receivedArray,keyArray,imageArray,proidArray)


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }

    fun prod_insert(id1: String, pronameArray: ArrayList<String>, manufacturerArray: ArrayList<String>, hsnArray: ArrayList<String>, barcodeArray: ArrayList<String>,
                    quantityArray: ArrayList<String>, priceArray: ArrayList<String>, totArray: ArrayList<String>, cessArray: ArrayList<String>,igstArray:ArrayList<String>,
                    igsttotArray:ArrayList<String>,cesstotalArray:ArrayList<String>,tallyArray:ArrayList<String>,receivedArray:ArrayList<String>,keyArray:ArrayList<String>,
                    imageArray: ArrayList<String>,proidArray:ArrayList<String>) {


        var stkid = "ST" + id1
        var stkdate = (stdate.text).toString()
        var stkdesc = (descrip.text).toString()
        var destination = (comttname.text).toString()
        var address = (comphone.text).toString()
        var stktotals = (gross_tot.text).toString()
        var stkbrid = (brnchid.text).toString()
        var originid = origiky
        var recnt = "0"
        var rec_status = "Not Tallied"
        val c = Calendar.getInstance()
        System.out.println("Current time =&gt; " + c.time)

        val df = SimpleDateFormat("dd/MM/yyyy")
        val formattedDate = df.format(c.time)
        var dt = formattedDate


        val data = s(stkid = stkid, stkdate = stkdate, stk_Desc = stkdesc,
                stk_destination = destination, stk_address = address, stk_total = stktotals,
                stk_brid = stkbrid, stk_origin = originid,stk_originname = orignm)
        var db = FirebaseFirestore.getInstance()
        db.collection("${origiky}_Stock_Transfer")
                .add(data)
                .addOnSuccessListener { documentReference ->


                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    var refid = documentReference.id
                    val map = mutableMapOf<String, Any?>()
                    map.put("Receive_count", recnt)
                    map.put("Receive_date", dt)

                    map.put("Status", rec_status)

                    db.collection("${brnchid.text.toString()}_Receive Stock").document(refid)
                            .set(data)
                    db.collection("${brnchid.text.toString()}_Receive Stock").document(refid)
                            .update(map)

                    var path = "${origiky}_Stock_Transfer/$refid/Stock_products"

                    for (i in 0 until priceArray.size) {


                        fori+=i
                        var stk_name = pronameArray[i]
                        var stk_mfr = manufacturerArray[i]
                        var stk_hsn = hsnArray[i]
                        var stk_bcode = barcodeArray[i]
                        var stk_quan = quantityArray[i]
                        var stk_pri = priceArray[i]
                        var stk_tot = totArray[i]
                        var stk_cess = cessArray[i]
                        var stk_igst = igstArray[i]
                        var stk_igsttot = igsttotArray[i]
                        var stk_cesstot = cesstotalArray[i]
                        var stk_tally = tallyArray[i]
                        var stk_received = receivedArray[i]
                        var img_arr = imageArray[i]
                        var stk_key = keyArray[i]
                        var pro_id = proidArray[i]


                        var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot,
                                stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key,
                                otherstk_tally = stk_tally, otherstk_received = stk_received, otherstk_img = img_arr, stk_proid = pro_id)







                        db.collection(path)
                                .add(d)


                                .addOnSuccessListener { documentReference ->


                                    var resid = documentReference.id

                                    db.collection("${brnchid.text.toString()}_Receive Stock/$refid/Received stock items").document(resid)
                                            .set(d)

                                    val database = FirebaseDatabase.getInstance()


                                    var qntval = quantityArray[i]

                                    var proids = proidArray[i]


                                    println("PRO ID OF ARRAY" + proids)
                                    println("QUANTITY OF ARRAY" + qntval)


                                    var pathfrbs = proids + "_" + originid

                                    println("GET  OF ARRAY" + pathfrbs)

                                    stock_in_hand(i, pathfrbs, qntval, proids)





                                }













                    }

                        Handler().postDelayed(Runnable {
                            try {
                                pDialogs!!.dismiss()
                            }
                            catch (e:Exception){

                            }
                            val i = Intent(this@Mainstk_branch_one, WithStateActivity::class.java)
                            i.putExtra("from_br", "brsave")




                            i.putExtra("viewtrans", viewtrans)
                            i.putExtra("addtrans", addtrans)
                            i.putExtra("edittrans", editetrans)
                            i.putExtra("deletetrans", deletetrans)
                            i.putExtra("transfertrans", transfertrans)
                            i.putExtra("exporttrans", exporttrans)
                            i.putExtra("sendtrans", sendtrans)


                            i.putExtra("viewtransano", viewtransano)
                            i.putExtra("addtransano", addtransano)
                            i.putExtra("edittransano", editetransano)
                            i.putExtra("deletetransano", deletetransano)
                            i.putExtra("transfertransano", transfertransano)
                            i.putExtra("exporttransano", exporttransano)
                            i.putExtra("sendtransano", sendtransano)

                            i.putExtra("viewrec", viewrec)
                            i.putExtra("addrec", addrec)
                            i.putExtra("deleterec", deleterec)
                            i.putExtra("editrec", editrec)
                            i.putExtra("transferrec", transferrec)
                            i.putExtra("exportrec", exportrec)
                            i.putExtra("sendstrec", sendstrec)



                            i.putExtra("brky", keyofbrnch)
                            i.putExtra("orky", origiky)

                            Toast.makeText(applicationContext, "Transferred successfully", Toast.LENGTH_SHORT).show()
                            startActivity(i)
                            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                            finish()

                        }, 4000)



                }





                            .addOnFailureListener { e ->
                                Log.w(TAG, "Error adding document", e)
                                Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                                /* save_progress.visibility = android.view.View.GONE*/
                            }


    }


    fun popup(st:String){     //Access denied popup
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }


    fun stock_in_hand(i:Int,path:String,qnt:String,prid:String){   //Update the stock on hand value in origin branch which depends upon how many quantities
                                                                    //of products we have sent.
        pDialogs!!.setTitleText("Stocks transferring...")
        data class Count(var number: Int)
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("$path")
        myRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                var p = mutableData.value
                if(p == null)
                {
                    p =  0
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p =  0

                } else {
                    // Star the post and add self to stars

                        p = Integer.parseInt(p.toString())-qnt.toInt()
                        if (p<0){
                            p=0
                        }
                    /*else if (rr.isNotEmpty()||cls.isEmpty()){
                        p = Integer.parseInt(p.toString()) + qnt.toInt()
                        if (p<0){
                            p=0
                        }
                    }*/

                }

                // Set value and report transaction success
                mutableData.value = p
                val map = mutableMapOf<String, Any?>()
                map.put("$origiky",p)
                db.collection("product").document(prid)
                        .update(map)
                        .addOnSuccessListener {


                        }


                //mutableData.setValue(p.number)
                return Transaction.success(mutableData)
            }

            override  fun onComplete(databaseError : DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {

            }

                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)

            })
        }


    fun stock_in_hand_update(i:Int,path:String,qnt:String,qaucpy:String,prid:String,proidscpy:String) {

        //Update the stock on hand value in origin branch which depends upon how many quantities
        //of products we have sent.


        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("$path")
        myRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                var p = mutableData.value
                if (p == null) {
                    p = 0
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 0

                } else {
                    // Star the post and add self to stars

                    p = Integer.parseInt(p.toString())+qaucpy.toInt()-qnt.toInt()
                    if (p < 0) {
                        p = 0
                    }
                    /*else if (rr.isNotEmpty()||cls.isEmpty()){
                        p = Integer.parseInt(p.toString()) + qnt.toInt()
                        if (p<0){
                            p=0
                        }
                    }*/

                }

                // Set value and report transaction success
                mutableData.value = p
                val map = mutableMapOf<String, Any?>()
                map.put("$origiky",p)
                db.collection("product").document(prid)
                        .update(map)

                //mutableData.setValue(p.number)
                return Transaction.success(mutableData)
            }

            override fun onComplete(databaseError: DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {

            }

            // Transaction completed
            // Log.d("", "postTransaction:onComplete:" + databaseError)

        })

    }


    fun stock_in_hand_update_del(i:Int,path:String,qnt:String,proidscpy:String) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("$path")
        myRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                var p = mutableData.value
                if (p == null) {
                    p = 0
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 0

                } else {
                    // Star the post and add self to stars

                    p = Integer.parseInt(p.toString())+qnt.toInt()
                    if (p < 0) {
                        p = 0
                    }
                    /*else if (rr.isNotEmpty()||cls.isEmpty()){
                        p = Integer.parseInt(p.toString()) + qnt.toInt()
                        if (p<0){
                            p=0
                        }
                    }*/

                }

                // Set value and report transaction success
                mutableData.value = p
                val map = mutableMapOf<String, Any?>()
                map.put("$origiky",p)
                db.collection("product").document(proidscpy)
                        .update(map)

                //mutableData.setValue(p.number)
                return Transaction.success(mutableData)
            }

            override fun onComplete(databaseError: DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {

            }

            // Transaction completed
            // Log.d("", "postTransaction:onComplete:" + databaseError)

        })

    }
    fun stock_in_hand_update_del2(i:Int,path:String,qnt:String,qaucpy:String,prid:String,proidscpy:String) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("$path")
        myRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                var p = mutableData.value
                if (p == null) {
                    p = 0
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 0

                } else {
                    // Star the post and add self to stars

                    p = Integer.parseInt(p.toString())+qaucpy.toInt()-qnt.toInt()
                    if (p < 0) {
                        p = 0
                    }
                    /*else if (rr.isNotEmpty()||cls.isEmpty()){
                        p = Integer.parseInt(p.toString()) + qnt.toInt()
                        if (p<0){
                            p=0
                        }
                    }*/

                }

                // Set value and report transaction success
                mutableData.value = p
                val map = mutableMapOf<String, Any?>()
                map.put("$origiky",p)
                db.collection("product").document(prid)
                        .update(map)

                //mutableData.setValue(p.number)
                return Transaction.success(mutableData)
            }

            override fun onComplete(databaseError: DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {

            }

            // Transaction completed
            // Log.d("", "postTransaction:onComplete:" + databaseError)

        })

    }
    fun stock_in_hand_update_del3(i:Int,path:String,qnt:String,qaucpy:String,prid:String,proidscpy:String) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("$path")
        myRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                var p = mutableData.value
                if (p == null) {
                    p = 0
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 0

                } else {
                    // Star the post and add self to stars

                    p = Integer.parseInt(p.toString())-qaucpy.toInt()
                    if (p < 0) {
                        p = 0
                    }
                    /*else if (rr.isNotEmpty()||cls.isEmpty()){
                        p = Integer.parseInt(p.toString()) + qnt.toInt()
                        if (p<0){
                            p=0
                        }
                    }*/

                }

                // Set value and report transaction success
                mutableData.value = p
                val map = mutableMapOf<String, Any?>()
                map.put("$origiky",p)
                db.collection("product").document(prid)
                        .update(map)

                //mutableData.setValue(p.number)
                return Transaction.success(mutableData)
            }

            override fun onComplete(databaseError: DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {

            }

            // Transaction completed
            // Log.d("", "postTransaction:onComplete:" + databaseError)

        })

    }
    companion object {

        //Listens internet status whether net is on/off.


        private var relativeslayoutdis:RelativeLayout?=null
        private var pur_savedis:Button?=null
        private var userbackdis:ImageButton?=null
        private var mnudis:ImageButton?=null
        private var constraintLayout3dis: ConstraintLayout?=null
        private var editdis:ImageButton?=null
        private val log_str: String? = null
        private var pDialogs: SweetAlertDialog? = null

        private var ponodis:EditText?=null
        private var orddatedis:EditText?=null

        private var descripdis:EditText?=null
        private var fabdis: FloatingActionButton?=null
        private var pur_listdis:ListView?=null

        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                /// if connection is off then all views becomes disable



                relativeslayoutdis!!.visibility=View.VISIBLE
                constraintLayout3dis!!.visibility=View.VISIBLE
                pur_savedis!!.isEnabled=false
                userbackdis!!.isEnabled=false
                mnudis!!.isEnabled=false
                editdis!!.isEnabled=false

                ponodis!!.isEnabled=false
                orddatedis!!.isEnabled=false

                descripdis!!.isEnabled=false
                fabdis!!.isEnabled=false
                pur_listdis!!.isClickable=false
                pur_listdis!!.isEnabled=false
                pur_listdis!!.isLongClickable=false

                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }
            }
            else
            {
                /// if connection is off then all views becomes enabled


                relativeslayoutdis!!.visibility=View.GONE
                constraintLayout3dis!!.visibility=View.GONE
                pur_savedis!!.isEnabled=true
                userbackdis!!.isEnabled=true
                mnudis!!.isEnabled=true
                editdis!!.isEnabled=true


                ponodis!!.isEnabled=false

                if(editdis!!.visibility!=View.VISIBLE){
                    orddatedis!!.isEnabled=true

                    descripdis!!.isEnabled=true
                    pur_listdis!!.isEnabled=true
                    fabdis!!.isEnabled=true
                    pur_listdis!!.isClickable=true
                    pur_listdis!!.isLongClickable=true
                }


            }
        }
    }

    fun net_status():Boolean{       //Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


    }










