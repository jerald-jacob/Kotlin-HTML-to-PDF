package com.example.vinitas.inventory_app

import android.content.Context
import android.graphics.Color
import android.graphics.Color.parseColor
import android.view.Gravity
import android.view.View
import android.widget.TextView
import android.view.ViewGroup
import java.nio.file.Files.size
import android.widget.SpinnerAdapter
import android.widget.BaseAdapter


class CustomSpinnerAdapter(private val activity: Context, private val asr: ArrayList<String>) : BaseAdapter(), SpinnerAdapter {


    override fun getCount(): Int {
        return asr.size
    }

    override fun getItem(i: Int): Any {
        return asr[i]
    }

    override fun getItemId(i: Int): Long {
        return i.toLong()
    }

    var selectedItem = -1

    override fun getDropDownView(position: Int, convertView: View, parent: ViewGroup): View {
        val txt = TextView(activity)
        txt.setPadding(16, 16, 16, 16)
        txt.textSize = 18f
        txt.gravity = Gravity.CENTER_VERTICAL
        txt.text = asr[position]
        txt.setTextColor(Color.parseColor("#000000"))
       /* var v: View? = null
        v = super.getDropDownView(position, null, parent)
        // If this is the selected item position
        if (position === selectedItem) {
            v!!.setBackgroundColor(activity.resources.getColor(R.color.viewclr))
        } else {
            // for other views
            v!!.setBackgroundColor(Color.WHITE)

        }*/
        return txt
    }

    override fun getView(i: Int, view: View, viewgroup: ViewGroup): View {
        val txt = TextView(activity)
        txt.gravity = Gravity.CENTER
        txt.setPadding(16, 16, 16, 16)
        txt.textSize = 16f
        txt.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_outline_arrow_drop_down_circle_24px, 0)
        txt.text = asr[i]
        txt.setTextColor(Color.parseColor("#000000"))
        return txt
    }

}