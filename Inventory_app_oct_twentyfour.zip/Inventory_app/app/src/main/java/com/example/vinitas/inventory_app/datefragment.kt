package com.example.vinitas.inventory_app

import android.app.DatePickerDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.widget.DatePicker

import java.util.Calendar


class DatePickerFragment : DialogFragment(), DatePickerDialog.OnDateSetListener {

    private var calendar: Calendar? = null
    private var maxCalendar: Calendar? = null
    private var minCalendar: Calendar? = null
    private var onDateSetListener: DatePickerDialog.OnDateSetListener? = null

    fun setup(calendar: Calendar, onDateSetListener: DatePickerDialog.OnDateSetListener) {
        this.calendar = calendar
        this.onDateSetListener = onDateSetListener
    }

    fun setup(calendar: Calendar, maxCalendar: Calendar, onDateSetListener: DatePickerDialog.OnDateSetListener) {
        this.calendar = calendar
        this.maxCalendar = maxCalendar
        this.onDateSetListener = onDateSetListener
    }

    fun setup(calendar: Calendar, maxCalendar: Calendar, minCalendar: Calendar) {
        this.calendar = calendar
        this.maxCalendar = maxCalendar
        this.minCalendar = minCalendar
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val year = calendar!!.get(Calendar.YEAR)
        val month = calendar!!.get(Calendar.MONTH)
        val day = calendar!!.get(Calendar.DAY_OF_MONTH)

        val dialog = DatePickerDialog(activity!!, android.R.style.Theme_Holo_Light_Dialog_MinWidth, this, year, month, day)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        if (minCalendar != null) {
            dialog.datePicker.minDate = minCalendar!!.timeInMillis
        }

        if (maxCalendar != null) {
            dialog.datePicker.maxDate = maxCalendar!!.timeInMillis
        }

        return dialog
    }

    override fun onDateSet(view: DatePicker, year: Int, month: Int, day: Int) {
        if (onDateSetListener != null) {
            onDateSetListener!!.onDateSet(view, year, month, day)
        } else {

        }
    }

    companion object {

        private val TAG = DatePickerFragment::class.java.simpleName
    }
}