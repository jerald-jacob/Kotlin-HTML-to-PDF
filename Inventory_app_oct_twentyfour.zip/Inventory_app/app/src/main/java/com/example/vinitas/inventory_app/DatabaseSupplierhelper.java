package com.example.vinitas.inventory_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by vinitas stock on 28-02-2018.
 */

public class DatabaseSupplierhelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "suppliers.db";//database name
    private static final String TABLE_NAME = "suppliers";//TAble name

    public DatabaseSupplierhelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {//Create table
        db.execSQL("create table " + TABLE_NAME +" (id TEXT PRIMARY KEY,spnm TEXT,spid TEXT,spmobcat1 TEXT,spmobcat2 TEXT,spmobcat3 TEXT,spmob1 TEXT,spmob2 TEXT,spmob3 TEXT,spmob4 TEXT,spaddress1 TEXT,spaddress2 TEXT,spaddress3 TEXT,spcity TEXT,spstate TEXT, sppincode TEXT,sppgpsco_or  TEXT,spemail TEXT,spcontact_person TEXT,spgst TEXT,spimglink TEXT,prodkey TEXT,status TEXT,img1n TEXT,img2n TEXT,img3n TEXT,img4n TEXT,img5n TEXT,img1url TEXT,img2url TEXT,img3url TEXT,img4url TEXT,img5url TEXT,img1nhigh TEXT,img2nhigh TEXT,img3nhigh TEXT,img4nhigh TEXT,img5nhigh TEXT,img1urlhigh TEXT,img2urlhigh TEXT,img3urlhigh TEXT,img4urlhigh TEXT,img5urlhigh TEXT,spmobcat4 TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    //Insert supplier details

    public boolean insertData(String id,String spnm,String spid,String spmobcat1,String spmobcat2,String spmobcat3,String spmob1,String spmob2,String spmob3,String spmob4,
                              String spaddress1,String spaddress2,String spaddress3,String spcity,String  spstate,String sppincode ,String sppgpsco_or,String spemail,
                              String spcontact_person,String spgst,String spimglink,String prodkey,String status,String img1n,String img2n,String img3n,
                              String img4n,String img5n,String img1url,String img2url,String img3url,String img4url,String img5url,String img1nhigh,String img2nhigh,
                              String img3nhigh,String img4nhigh,String img5nhigh,String img1urlhigh,String img2urlhigh,String img3urlhigh,String img4urlhigh,String img5urlhigh,String spmobcat4) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id",id);
        contentValues.put("spnm ",spnm);
        contentValues.put("spid",spid);
        contentValues.put("spmobcat1",spmobcat1);
        contentValues.put("spmobcat2",spmobcat2);
        contentValues.put("spmobcat3",spmobcat3);
        contentValues.put("spmob1",spmob1);
        contentValues.put("spmob2",spmob2);
        contentValues.put("spmob3",spmob3);
        contentValues.put("spmob4",spmob4);
        contentValues.put("spaddress1",spaddress1);
        contentValues.put("spaddress2",spaddress2);
        contentValues.put("spaddress3",spaddress3);
        contentValues.put("spcity",spcity);
        contentValues.put("spstate",spstate);
        contentValues.put("sppincode",sppincode);
        contentValues.put("sppgpsco_or",sppgpsco_or);
        contentValues.put("spemail",spemail);
        contentValues.put("spcontact_person",spcontact_person);
        contentValues.put("spgst",spgst);
        contentValues.put("spimglink",spimglink);
        contentValues.put("prodkey",prodkey);
        contentValues.put("status",status);

        contentValues.put("img1n",img1n);
        contentValues.put("img2n",img2n);
        contentValues.put("img3n",img3n);
        contentValues.put("img4n",img4n);
        contentValues.put("img5n",img5n);
        contentValues.put("img1url",img1url);
        contentValues.put("img2url",img2url);
        contentValues.put("img3url",img3url);
        contentValues.put("img4url",img4url);
        contentValues.put("img5url",img5url);
        contentValues.put("img1nhigh",img1nhigh);
        contentValues.put("img2nhigh",img2nhigh);
        contentValues.put("img3nhigh",img3nhigh);
        contentValues.put("img4nhigh",img4nhigh);
        contentValues.put("img5nhigh",img5nhigh);
        contentValues.put("img1urlhigh",img1urlhigh);
        contentValues.put("img2urlhigh",img2urlhigh);
        contentValues.put("img3urlhigh",img3urlhigh);
        contentValues.put("img4urlhigh",img4urlhigh);
        contentValues.put("img5urlhigh",img5urlhigh);
        contentValues.put("spmobcat4",spmobcat4);
        long result = db.insert(TABLE_NAME,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        //Get all datas from table

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME+" ORDER BY status DESC " ,null);


        return res;
    }

    public void deleteall(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_NAME);
    }

    public boolean checkIfRecordExist(String COL_2)//Check if record already exists
    {
        try
        {
            SQLiteDatabase db=this.getReadableDatabase();
            Cursor cursor=db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE id ='"+COL_2+"'",null);
            if (cursor.moveToFirst())
            {
                db.close();
                Log.d("Record  Already Exists", "Table is:"+TABLE_NAME+" ColumnName:"+COL_2);
                return true;//record Exists

            }
            Log.d("New Record  ", "Table is:"+TABLE_NAME+" ColumnName:"+COL_2+" Column Value:"+COL_2);
            db.close();
        }
        catch(Exception errorException)
        {
            Log.d("Exception occured", "Exception occured "+errorException);
            // db.close();
        }
        return false;
    }
    public int getNotesCount() {//Check counts of datas
        String countQuery = "SELECT  * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        int count = cursor.getCount();
        cursor.close();


        // return count
        return count;
    }

    //Update Supplier details

    public boolean updatedata(String id,String spnm,String spid,String spmobcat1,String spmobcat2,String spmobcat3,String spmob1,String spmob2,String spmob3,
                              String spmob4,String spaddress1,String spaddress2,String spaddress3,String spcity,String  spstate,String sppincode ,String sppgpsco_or,
                              String spemail,String spcontact_person,String spgst,String spimglink,String prodkey,String status,String img1n,String img2n,String img3n,
                              String img4n,String img5n,String img1url,String img2url,String img3url,String img4url,String img5url,String img1nhigh,String img2nhigh,
                              String img3nhigh,String img4nhigh,String img5nhigh,String img1urlhigh,String img2urlhigh,String img3urlhigh,String img4urlhigh,String img5urlhigh,String spmobcat4) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id",id);
        contentValues.put("spnm ",spnm);
        contentValues.put("spid",spid);
        contentValues.put("spmobcat1",spmobcat1);
        contentValues.put("spmobcat2",spmobcat2);
        contentValues.put("spmobcat3",spmobcat3);
        contentValues.put("spmob1",spmob1);
        contentValues.put("spmob2",spmob2);
        contentValues.put("spmob3",spmob3);
        contentValues.put("spmob4",spmob4);
        contentValues.put("spaddress1",spaddress1);
        contentValues.put("spaddress2",spaddress2);
        contentValues.put("spaddress3",spaddress3);
        contentValues.put("spcity",spcity);
        contentValues.put("spstate",spstate);
        contentValues.put("sppincode",sppincode);
        contentValues.put("sppgpsco_or",sppgpsco_or);
        contentValues.put("spemail",spemail);
        contentValues.put("spcontact_person",spcontact_person);
        contentValues.put("spgst",spgst);
        contentValues.put("spimglink",spimglink);
        contentValues.put("prodkey",prodkey);
        contentValues.put("status",status);
        contentValues.put("img1n",img1n);
        contentValues.put("img2n",img2n);
        contentValues.put("img3n",img3n);
        contentValues.put("img4n",img4n);
        contentValues.put("img5n",img5n);
        contentValues.put("img1url",img1url);
        contentValues.put("img2url",img2url);
        contentValues.put("img3url",img3url);
        contentValues.put("img4url",img4url);
        contentValues.put("img5url",img5url);
        contentValues.put("img1nhigh",img1nhigh);
        contentValues.put("img2nhigh",img2nhigh);
        contentValues.put("img3nhigh",img3nhigh);
        contentValues.put("img4nhigh",img4nhigh);
        contentValues.put("img5nhigh",img5nhigh);
        contentValues.put("img1urlhigh",img1urlhigh);
        contentValues.put("img2urlhigh",img2urlhigh);
        contentValues.put("img3urlhigh",img3urlhigh);
        contentValues.put("img4urlhigh",img4urlhigh);
        contentValues.put("img5urlhigh",img5urlhigh);
        contentValues.put("spmobcat4",spmobcat4);

        db.update(TABLE_NAME, contentValues, "id = ?",new String[] { id });
        return true;
    }

    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "id = ?",new String[] {id});
    }
    public Cursor retrieve(String searchTerm)//Retreive details of the suppliers by search terms
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c=null;

        if(searchTerm != null && searchTerm.length()>0)
        {
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"spnm"+" LIKE '%"+searchTerm+"%'";
            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE spnm LIKE '%"+searchTerm+"%' OR spcity LIKE '%"+searchTerm+"%' OR spmob1 LIKE '%"+searchTerm+"%'",null);
            return c;

        }

        c=db.query(TABLE_NAME,null,null,null,null,null,null);
        return c;
    }
    public Cursor getOne(String idd){//Get data by id
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c=null;
        String query = "SELECT * FROM "+TABLE_NAME+" WHERE id = ?" +idd;
        if (idd != null && idd.length()>0) {
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"spnm"+" LIKE '%"+idd+"%'";
            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE id LIKE '%"+idd+"%'",null);
            return c;
            /*c=db.rawQuery("select * from "+TABLE_NAME+" where id = "+idd,null);
            //c = db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE id = "+idd,null);
            return c;*/
        }
        c=db.query(TABLE_NAME,null,null,null,null,null,null);
        return c;
    }

}