package com.example.vinitas.inventory_app

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import kotlinx.android.synthetic.main.receive_list.*
import kotlinx.android.synthetic.main.scroll_stk_one.*

/**
 * Created by vinitas stock on 04-01-2018.
 */
class receiveAdapter(
        private val context: Activity,
        private val idArray: Array<String>,
        private val ori: Array<String>,
        private val items: Array<String>,
        private val date: Array<String>,
        private val transfer: Array<String>,
        private val tally: Array<String>,
        private val tallysucs: Array<String>,
        private val text8: Array<String>) : ArrayAdapter<Any>(context, R.layout.receive_list, idArray) {
    override fun getView(position: Int, view: View?, parent: ViewGroup): View {
        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.receive_list, null, true)
        val id = rowView.findViewById<TextView>(R.id.id) as TextView
        val origin3 = rowView.findViewById<TextView>(R.id.origin3) as TextView
        val des = rowView.findViewById<TextView>(R.id.des) as TextView
        val dated = rowView.findViewById<TextView>(R.id.dated) as TextView
        val trans = rowView.findViewById<TextView>(R.id.trans) as TextView
        val tall = rowView.findViewById<TextView>(R.id.tall) as TextView
        val tallsu = rowView.findViewById<TextView>(R.id.tallied) as TextView
        val textView8 = rowView.findViewById<TextView>(R.id.textView8) as TextView

        id.text = idArray[position]
        origin3.text = ori[position]
        des.text = items[position]
        dated.text = date[position]
        trans.text = transfer[position]
        tall.text = tally[position]
        tallsu.text = tallysucs[position]
        textView8.text = text8[position]

      /*  context.tall.visibility=View.VISIBLE
        context.tall.text="Not tallied"
        val a=context.tallnottall.text
        if(a.equals("Not tallied")){
           context.tall.visibility=View.VISIBLE
        }
        else{
            context.tallied.visibility=View.INVISIBLE
        }*/



        if(items[position].isEmpty()){
            des.setText("No description.")
        }


        return rowView

    }
}

