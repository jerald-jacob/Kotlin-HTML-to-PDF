package com.example.vinitas.inventory_app

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.ProgressDialog
import android.content.*
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.view.View

import android.widget.*
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.*
import android.print.PdfView
import android.print.PrintAttributes
import android.print.PrintManager

import android.widget.TextView
import android.widget.TableLayout
import android.support.annotation.NonNull
import android.support.annotation.RequiresApi
import android.support.constraint.ConstraintLayout
import android.support.v4.app.NotificationCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.Gravity
import android.view.Gravity.CENTER
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil

import dmax.dialog.SpotsDialog

import kotlinx.android.synthetic.main.activity_main_pdf.*

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.lang.Thread.sleep
import java.text.SimpleDateFormat
import java.util.*


@RequiresApi(Build.VERSION_CODES.LOLLIPOP)

class MainActivity_pdf : AppCompatActivity() {
    var  pronameArray       = arrayOf<String>()
    var  hsnArray           = arrayOf<String>()
    var  manufacturerArray  = arrayOf<String>()
    var  barcodeArray       = arrayOf<String>()
    var  quantityArray      = arrayOf<String>()
    var  priceArray         = arrayOf<String>()
    var  totArray           = arrayOf<String>()
    var  cessArray          = arrayOf<String>()
    var  imageArray         = arrayOf<String>()
    var  igstArray         = arrayOf<String>()
    var  cgstArray         = arrayOf<String>()
    var  sgstArray         = arrayOf<String>()
    var  igsttotArray         = arrayOf<String>()
    var  cesstotalArray         = arrayOf<String>()
    var receivedArray = arrayOf<String>()
    var receivedArraypri = arrayOf<String>()
    var receivedArraytaxtot = arrayOf<String>()
    var receivedArraytotal = arrayOf<String>()
    var receivedArraygrosstotal = arrayOf<String>()
    var receivedArraycesstotal = arrayOf<String>()
    var tallyArray = arrayOf<String>()
    var keyArray = arrayOf<String>()
    var downstatus= String()
    var htmlDocument= String()


    var vounodup= String()
    var invoicedatedup= String()
    var payduedatedup= String()
    var suppdescripdup= String()

    var paidsta=String()

    var statdup=String()


    var imgname= String()
    var imgnameedit= String()

    var frmval= String()
var datest= String()
    var singrosstot= arrayOf<String>()

    var edclick=String()
    var igsttt= String()
    var cgsttt= String()
    var sgsttt= String()
    var cestt= String()
    var grosstt= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""




var t= String()
var cells=arrayOf<String>()
    var dirpath: String? = null


    var reqliid = String()
    var reprnms = String()
    var pono = String()
    var recstatus = String()
    var recprice = String()
    var cess = String()
    var tot = String()
    var taxtot = String()
    var grossto = String()
    var pri = String()
    var gtot = String()
    var idkey = String()
    var reckey = String()
    var nwkey = String()

 var smill= String()
    var imurl = String()
    var brnchid= String()

    var progressDoalog: ProgressDialog? = null

    var suppname= String()
    var suppphone= String()



    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""



    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()











    var idli = String()
    var reqdt = String()
    var desc = String()
    var orddate = String()
    var postatus = String()
    var tt=arrayOf<String>()



    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private var myWebView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_pdf)

        net_status()//Check net status

        val webView = findViewById<WebView>(R.id.webviews) as WebView //Initaialize web view

        myWebView = webView//Assign web view globally

        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@MainActivity_pdf) > 0)
        {

        }
        else{

            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()
        }


        //Define No connection view when inetrnet connection is off.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        cont=findViewById<ConstraintLayout>(R.id.container)


        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")


        frmval=intent.getStringExtra("backvald")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }


        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr
        }
        if (expr != null) {
            exportpurreq = expr
        }


        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")

        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }










        //Get details from supplier invoice (supplier_thirdmain_act)


        val bundle = intent.extras


        var a = bundle.get("pnm") as Array<String>
        val dsy = bundle.get("phsn") as Array<String>
        val ly = bundle.get("pmanu") as Array<String>
        val fy = bundle.get("barcode") as Array<String>
        val gy = bundle.get("quan") as Array<String>
        val hy = bundle.get("price") as Array<String>
        val ky = bundle.get("tot") as Array<String>
        val my = bundle.get("cessup") as Array<String>
        val ny = bundle.get("igst") as Array<String>
        val cy = bundle.get("cgst") as Array<String>
        val sy = bundle.get("sgst") as Array<String>
        val oy = bundle.get("igsttotal") as Array<String>
        val py = bundle.get("cesstotarray") as Array<String>
        val iddd = bundle.get("idsofli") as Array<String>
try {
    val immy = bundle.get("image") as Array<String>
    tt = immy.clone()
}
catch(e:Exception){

}




        val idtally = bundle.get("tallyarray") as Array<String>
        val idrec    = bundle.get("receivedarray") as Array<String>
        println("REEECCCCIIIEEEVVVVEEE"+ Arrays.toString(idrec))

        val spri     = bundle.get("received_price") as Array<String>
        val stot     = bundle.get("received_total") as Array<String>
        val staxt    = bundle.get("received_taxtot") as Array<String>
        val scesstot = bundle.get("received_cesstot") as Array<String>
        val sgross    = bundle.get("received_grosstot") as Array<String>


        try {



            val f = intent.getStringExtra("reqdate")
            reqdt = f //Invoice



            val ff = intent.getStringExtra("orddate")
            orddate = ff //Date

            val stat = intent.getStringExtra("duedate")
            postatus = stat //Due date
        }
        catch (e: Exception) {
            val ff = intent.getStringExtra("orddate")
            orddate = ff //Date

            val stat = intent.getStringExtra("duedate")
            postatus = stat //Due date

        }

        try{
            paidsta=intent.getStringExtra("status")
        }
        catch (e:Exception){

        }

        try{
            statdup=intent.getStringExtra("statdup")


        }
        catch (e:Exception){

        }

        try {
            val e = intent.getStringExtra("desc")
            desc = e

            val liis = intent.getStringExtra("reqliid")
            reqliid = liis
        }
        catch (e:Exception){
            val liis = intent.getStringExtra("reqliid")
            reqliid = liis
        }

        try {
            val lii = intent.getStringExtra("pono")
            pono = lii //Voucher no

        }
        catch (e:Exception){

        }

        try{
            val datestt=intent.getStringExtra("datest")
            datest=datestt
        }
        catch (e:Exception)
        {

        }


        try{
            edclick=intent.getStringExtra("edclick")

        }
        catch(e:Exception){

        }

        try{
            vounodup=intent.getStringExtra("vounodup")
            invoicedatedup=intent.getStringExtra("invoicedatedup")
            payduedatedup=intent.getStringExtra("payduedatedup")
            suppdescripdup=intent.getStringExtra("suppdescripdup")
        }
        catch (e:Exception){

        }

        try {




            val grosst = intent.getStringExtra("gross")
            grossto = grosst

            val igstt = intent.getStringExtra("igsts")
            igsttt = igstt

            val cgstt = intent.getStringExtra("cgsts")
            cgsttt = cgstt

            val sgstt = intent.getStringExtra("sgsts")
            sgsttt = sgstt

            val cesst = intent.getStringExtra("cessts")
            cestt = cesst

            val nm = intent.getStringExtra("reprnms")
            reprnms = nm


        }
        catch(e:Exception){
            val igstt = intent.getStringExtra("igsts")
            igsttt = igstt

            val cgstt = intent.getStringExtra("cgsts")
            cgsttt = cgstt

            val sgstt = intent.getStringExtra("sgsts")
            sgsttt = sgstt

            val cesst = intent.getStringExtra("cessts")
            cestt = cesst

            val nm = intent.getStringExtra("reprnms")
            reprnms = nm
        }





        try {
    val im = intent.getStringExtra("imgurl")
    imurl = im

    val bridss = intent.getStringExtra("bridkey")
    brnchid = bridss

    val supnm = intent.getStringExtra("supnm")
    suppname = supnm //Supplier name

    val supph = intent.getStringExtra("supph")
    suppphone = supph //Supplier phone
}
catch (e:Exception){
    val bridss = intent.getStringExtra("bridkey")
    brnchid = bridss

    val supnm = intent.getStringExtra("supnm")
    suppname = supnm //Supplier name

    val supph = intent.getStringExtra("supph")
    suppphone = supph //Supplier phone
}



            //Supname

        /*    if(suppname.isNotEmpty()){
                suppliernm.setText(suppname)
            }
            else{
                suppliernm.setText("-")
            }


            //Supphone

            if(suppphone.isNotEmpty()){
                supplierph.setText(suppphone)
            }
            else{
                supplierph.setText("-")
            }


        if (grossto.isNotEmpty()) {
            gross.setText(grossto)
        } else {
            gross.setText("-")
        }

        //IGST TOT


            //Invoice

            if(reqdt.isNotEmpty()){
                invdate.setText(reqdt)
            }
            else{
                invdate.setText("-")
            }

            //Date
            if(orddate.isNotEmpty()){
                date.setText(orddate)
            }
            else{
                date.setText("-")
            }

                    //Due date
            if(postatus.isNotEmpty()){
                paydue.setText(postatus)
            }
            else{
                paydue.setText("-")
            }

            //Voucher date
            if(pono.isNotEmpty()){
                vouno.setText(pono)
            }
            else{
                vouno.setText("-")
            }*/

        try {
            imgname = intent.getStringExtra("imgname")
        }
        catch (e:Exception){

        }


        try {
            imgnameedit = intent.getStringExtra("imgnameedit")

        }
        catch (e:Exception){

        }








      /*  val aa = intent.getStringExtra("nms")
        comttname.setText(aa)
        val liis = intent.getStringExtra("reqliid")
        reqliid = liis
        val b = intent.getStringExtra("ph")
        comphone.setText(b)*/




        pronameArray= a.clone()
        hsnArray= dsy.clone()
        manufacturerArray =ly.clone()
        barcodeArray=fy.clone()
        quantityArray=gy.clone()
        priceArray=hy.clone()
        totArray =ky.clone()
        receivedArray=idrec.clone()
        cessArray =my.clone()
        igstArray =ny.clone()
        cgstArray =cy.clone()
        sgstArray =sy.clone()
        igsttotArray=oy.clone()
        cesstotalArray=py.clone()
        tallyArray=idtally.clone()
        receivedArraypri=spri.clone()
        receivedArraytotal=stot.clone()
        receivedArraytaxtot=staxt.clone()
        receivedArraycesstotal=scesstot.clone()
        receivedArraygrosstotal=sgross.clone()
        imageArray=tt.clone()
        keyArray=iddd.clone()


        addData();

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView,
                                                  url: String): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                //createWebPrintJob(view)
                myWebView = null
            }
        }


        pdf.setOnClickListener {

            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Supplier Invoice"
            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs()

            var f = pono


            var y = f +".pdf"





            val file = File(dir, y)
            val progressDialog = ProgressDialog(this@MainActivity_pdf)
            progressDialog.setMessage("Please wait")
            progressDialog.show()
            try {
                PdfView.createWebPrintJob(this@MainActivity_pdf, webView, file, y, object : PdfView.Callback {

                    override fun success(path: String) {
                        progressDialog.dismiss()
                        val builder = android.app.AlertDialog.Builder(this@MainActivity_pdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->
                                PdfView.openPdfFile(this@MainActivity_pdf, path)
                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }

                    override fun failure() {
                        progressDialog.dismiss()

                    }
                })
            }
            catch (e:Exception){
                Toast.makeText(applicationContext,"Already exist",Toast.LENGTH_SHORT).show()
            }


        }

          //Export As pdf
     /*   u = findViewById<ScrollView>(R.id.ss) as ScrollView
         zw=findViewById<HorizontalScrollView>(R.id.hh) as HorizontalScrollView*/
       /* pdf.setOnClickListener {


            //Create local path storage for this pdf
            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Supplier Invoice"

            val dir = File(path);
            if (!dir.exists())
                dir.mkdirs();
            var f = pono


            var y = f +".pdf"

            val file = File(dir, y);
            if (file.exists()) {


                val builder = AlertDialog.Builder(this)//If file already exist alert
                with(builder) {
                    setTitle("File Already Exist")
                    setMessage("Do you want to overwrite the existing file?")





                    setPositiveButton("Yes") { dialog, whichButton ->//Overwrite the exists pdf


                        val dialo =  SpotsDialog(context,"Downloading pdf...");

                        dialo.show();
                        createandDisplayPdf(suppname, suppphone, pono, orddate, reqdt, postatus, grossto)//Pdf write fiunction
                        val timer2 = Timer()
                        timer2.schedule(object : TimerTask() {
                            override fun run() {

                                var jumpTime = 0;
                                dialo.dismiss()

                                if(downstatus=="success") {

                                    val mBuilder = NotificationCompat.Builder(this@MainActivity_pdf)
                                    val intent = Intent(Intent.ACTION_GET_CONTENT)
                                    val uri = Uri.parse(Environment.getExternalStorageDirectory().path
                                            + File.separator + "Supplier Invoice" + File.separator)
                                    intent.setDataAndType(uri, "application/pdf")//Open pdf with pdf reader

                                    val pendingIntent = PendingIntent.getActivity(this@MainActivity_pdf, 0, intent, 0)
                                    mBuilder.setContentIntent(pendingIntent)


                                    val mNotifyManager = this@MainActivity_pdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;



                                    //Notification alert
                                    mBuilder.setContentTitle(y)
                                    mBuilder.setContentText("Downloaded")
                                    mBuilder.setSmallIcon(R.drawable.ic_logo)
                                    mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                                    mBuilder.setProgress(100, 100, false)
                                    mNotifyManager.notify(0, mBuilder.build());
                                }


                                timer2.cancel() //this will cancel the timer of the system
                            }


                        }, 3000)

                        val handler = Handler()
                        handler.postDelayed({
                            println("INSIDE IF"+a)
                            if(file.exists()) {
                                val builder = AlertDialog.Builder(this@MainActivity_pdf)
                                with(builder) {
                                    setTitle("File downloaded")
                                    setMessage("Do you want to open a file?")
                                    setPositiveButton("Open") { dialog, whichButton ->

                                        var f = pono
                                        var s = smill
                                        var c = suppname
                                        var y = f+".pdf"
                                        viewPdf("Supplier Invoice", y)

                                    }
                                    setNegativeButton("Cancel") { dialog, whichButton ->
                                        //showMessage("Close the game or anything!")
                                        dialog.dismiss()
                                    }

                                    // Dialog
                                    val dialog = builder.create()

                                    dialog.show()
                                }
                            }
                            else{

                            }
                        }, 4000)



















                      *//*  val timer2 = Timer()
                        timer2.schedule(object : TimerTask() {
                            override fun run() {

                                dialog.dismiss()
                                var b="null"
                                t=b
                                timer2.cancel() //this will cancel the timer of the system
                            }


                        }, 3000)*//*

                        *//*val handler = Handler()
                        handler.postDelayed({
                            println("INSIDE IF"+a)
                            val alert1 = AlertDialog.Builder(this@MainActivity_pdf)
                            val inflater1 = this@MainActivity_pdf.layoutInflater
                            val dialog1 = alert1.create()
                            dialog1.setView(inflater1.inflate(R.layout.open_pdf, null))
                            dialog1.show()
                            val vw = dialog1.findViewById<Button>(R.id.viw) as Button
                            val cancel = dialog1.findViewById<Button>(R.id.button3) as Button
                            vw.setOnClickListener {

                                var f=pono
                                var s=smill
                                var c=suppname
                                var y=f+"_"+c+"_"+s+".pdf"
                                viewPdf("Supplier Invoice",y)
                            }
                            cancel.setOnClickListener {
                                dialog1.hide()
                            }
                        }, 4000)*//*
                    }

                    setNegativeButton("NO") { dialog, whichButton ->
                        //showMessage("Close the game or anything!")
                        dialog.dismiss()
                    }

                    // Dialog
                    val dialog = builder.create()

                    dialog.show()
                }

            }
        else

            {



            *//*    val alert = AlertDialog.Builder(this@MainActivity_pdf)
                val inflater = this@MainActivity_pdf.layoutInflater
                val dialog = alert.create()
                dialog.setView(inflater.inflate(R.layout.generate_pdf, null))
                dialog.show()
                var a="isshow"
                alert.setCancelable(true);*//*



                val dialo =  SpotsDialog(this,"Downloading pdf...");

                dialo.show();



                val timer2 = Timer()
                timer2.schedule(object : TimerTask() {
                    override fun run() {
                        createandDisplayPdf(suppname, suppphone, pono, orddate, reqdt, postatus, grossto)//Pdf write fiunction
                        var jumpTime = 0;
                          if(downstatus=="success"){

                              val mBuilder = NotificationCompat.Builder(this@MainActivity_pdf)
                              val intent = Intent(Intent.ACTION_GET_CONTENT)
                              val uri = Uri.parse(Environment.getExternalStorageDirectory().path
                                      + File.separator + "Supplier Invoice" + File.separator)
                              intent.setDataAndType(uri, "application/pdf")//Open pdf with pdf reader

                              val pendingIntent = PendingIntent.getActivity(this@MainActivity_pdf, 0, intent, 0)
                              mBuilder.setContentIntent(pendingIntent)


                              val mNotifyManager = this@MainActivity_pdf.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;


                              //Notification alert

                              mBuilder.setContentTitle(y)
                              mBuilder.setContentText("Downloaded")
                              mBuilder.setSmallIcon(R.drawable.ic_logo)
                              mBuilder.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE or Notification.DEFAULT_LIGHTS)
                              mBuilder.setProgress(100, 100, false)
                              mNotifyManager.notify(0, mBuilder.build());
                          }

                        dialo.dismiss()

                        timer2.cancel() //this will cancel the timer of the system
                    }


                }, 3000)

                val handler = Handler()
                handler.postDelayed({
                    println("INSIDE IF"+a)
                    if(file.exists()) {
                        val builder = AlertDialog.Builder(this@MainActivity_pdf)
                        with(builder) {
                            setTitle("File downloaded")
                            setMessage("Do you want to open a file?")
                            setPositiveButton("Open") { dialog, whichButton ->

                                var f = pono
                                var s = smill
                                var c = suppname
                                var y = f+".pdf"
                                viewPdf("Supplier Invoice", y)

                            }
                            setNegativeButton("Cancel") { dialog, whichButton ->
                                //showMessage("Close the game or anything!")
                                dialog.dismiss()
                            }

                            // Dialog
                            val dialog = builder.create()

                            dialog.show()
                        }
                    }
                    else{

                    }
                }, 4000)

            }








            *//* val u = findViewById<ScrollView>(R.id.ss) as ScrollView
            val zx=findViewById<HorizontalScrollView>(R.id.hh) as HorizontalScrollView
            val yx=findViewById<RelativeLayout>(R.id.relative) as RelativeLayout
            val cx=findViewById<TableLayout>(R.id.table) as TableLayout

            val totalHeight = cx.height+u.height
            val totalWidth = cx.width+u.width

            val b = getBitmapFromView(yx, totalHeight, totalWidth)
            *//**//*  val share = Intent(Intent.ACTION_SEND)
              share.type = "image/jpeg"*//**//*
            val bytes = ByteArrayOutputStream()
            b.compress(Bitmap.CompressFormat.JPEG, 100, bytes)

            val f = File(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
            try {
                f.createNewFile()
                val fo = FileOutputStream(f)
                fo.write(bytes.toByteArray())
                imageToPDF()

            } catch (e: IOException) {
                e.printStackTrace()
            }*//*



        }*/




        back.setOnClickListener {
            //Back action
            val o = Intent(this@MainActivity_pdf, Supplier_thirdMainActivity::class.java)
            o.putExtra("from_suppin", "from_pdf")
            o.putExtra("renm", a)

            o.putExtra("remanu", ly)
            o.putExtra("rekey", iddd)
            o.putExtra("rehsn", dsy)
            o.putExtra("reprice", hy)
            o.putExtra("requan", gy)
            o.putExtra("rebc", fy)
            o.putExtra("retotal", ky)
            o.putExtra("recess", my)
            o.putExtra("reigst", ny)
            o.putExtra("recgst", cy)
            o.putExtra("resgst", sy)
            o.putExtra("retally", idtally)
            o.putExtra("rereceived", idrec)
            o.putExtra("rereceived_pri", spri)
            o.putExtra("rereceived_tot", stot)
            o.putExtra("rereceived_taxtot", staxt)
            o.putExtra("rereceived_cesstot", scesstot)
            o.putExtra("rereceived_grosstot", sgross)
            o.putExtra("reigst_total", oy)
            o.putExtra("recesstotal", py)
            o.putExtra("reimmg", tt)
            o.putExtra("pono", pono)
            o.putExtra("names", reprnms)
            o.putExtra("redesc", desc)
            o.putExtra("reorddate", orddate)
            o.putExtra("reestdt", reqdt)
            o.putExtra("restatus", postatus)
            o.putExtra("reids", reqliid)
            o.putExtra("titnm", suppname)
            o.putExtra("status",paidsta)
            o.putExtra("tiphone", suppphone)
            o.putExtra("reimgurl",imurl)
            o.putExtra("brnchids",brnchid)
            o.putExtra("backvald",frmval)
            o.putExtra("datest",datest)
            o.putExtra("edclick",edclick)
            o.putExtra("statdup",statdup)
            o.putExtra("regross", grossto)
            o.putExtra("reigsts", igsttt)
            o.putExtra("recgsts", cgsttt)
            o.putExtra("resgsts", sgsttt)
            o.putExtra("recessts", cestt)

            o.putExtra("viewsuppin",viewsuppin)
            o.putExtra("addsuppin",addsuppin)
            o.putExtra("deletesuppin",deletesuppin)
            o.putExtra("editsuppin",editesuppin)
            o.putExtra("transfersuppin",transfersuppin)
            o.putExtra("exportsuppin",exportsuppin)

            o.putExtra("viewpurord", viewpurord)
            o.putExtra("addpurord", addpurord)
            o.putExtra("deletepurord", deletepurord)
            o.putExtra("editpurord", editepurord)
            o.putExtra("transferpurord", transferpurord)
            o.putExtra("exportpurord", exportpurord)
            o.putExtra("sendpurord", sendpurpo)


            o.putExtra("viewpurreq", viewpurreq)
            o.putExtra("addpurreq", addpurreq)
            o.putExtra("deletepurreq", deletepurreq)
            o.putExtra("editpurreq", editepurreq)
            o.putExtra("transferpurreq", transferpurreq)
            o.putExtra("exportpurreq", exportpurreq)




            o.putExtra("vounodup",vounodup)
            o.putExtra("invoicedatedup",invoicedatedup)
            o.putExtra("payduedatedup",payduedatedup)
            o.putExtra("suppdescripdup",suppdescripdup)

           o.putExtra("imgname", imgname)


           o.putExtra("imgnameedit",imgnameedit)


            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
        }


    }


    fun view(){



    }



//    fun getBitmapFromView(view: View, totalHeight: Int, totalWidth: Int): Bitmap {
//        val bitmap: Bitmap
//
//        val returnedBitmap = Bitmap.createBitmap(totalWidth, totalHeight, Bitmap.Config.ARGB_8888)
//      /*  view.layout(0, 0, view.getLayoutParams().width,
//                view.getLayoutParams().height);*/
//        val canvas = Canvas(returnedBitmap)
//        val bgDrawable = view.background
//        if (bgDrawable != null)
//            bgDrawable.draw(canvas)
//        else
//            canvas.drawColor(Color.WHITE)
//        view.draw(canvas)
//       /* view.setDrawingCacheEnabled(true)
//        val bitmap = Bitmap.createBitmap(view.getDrawingCache())*/
//        return returnedBitmap
//    }
//       fun imageToPDF() {
//           /*    try {
//               val img = Image.getInstance(Environment.getExternalStorageDirectory().toString() + File.separator + "image.jpg")
//               val image = Image.getInstance(img)
//               val width = image.width
//               val height = image.height
//               val page = Rectangle(width,height)
//               val document = Document(page)
//               dirpath = Environment.getExternalStorageDirectory().toString()
//               val writer= PdfWriter.getInstance(document, FileOutputStream(dirpath + "/NewPDF.pdf")) //  Change pdf's name.
//               document.open()
//               val canvas = writer.getDirectContentUnder()
//               canvas.addImage(image, width, 0F, 0F, height, 0F, -height / 2);
//               document.newPage();
//               canvas.addImage(image, width, 0F, 0F, height, 0F, 0F);
//               document.newPage();
//               canvas.addImage(image, width, 0F, 0F, height, -width / 2, - height / 2);
//               document.newPage();
//               canvas.addImage(image, width, 0F, 0F, height, -width / 2, 0F);
//               document.close()
//               Toast.makeText(this, "PDF Generated successfully!..", Toast.LENGTH_SHORT).show()
//           } catch (e: Exception) {
//
//           }*/
//
//       }









    private fun getTextView(id: Int, title: String, color: Int, typeface: Int, bgColor: Int): TextView {
        val tv = TextView(this)//Document's fonts and design
        tv.id = id
        tv.text = title.toUpperCase()
        tv.setTextColor(color)
        tv.setPadding(20, 20, 20, 20)
        tv.setGravity(Gravity.CENTER);
        tv.setTypeface(Typeface.DEFAULT, typeface)
        tv.setBackgroundColor(bgColor)
        tv.layoutParams = getLayoutParams()

        return tv
    }

    private fun getLayoutParams(): TableRow.LayoutParams {//Table row layout design
        val params = TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT,
                TableRow.LayoutParams.WRAP_CONTENT)
        params.setMargins(2, 0, 0, 2)
        return params
    }

    private fun getTblLayoutParams(): TableLayout.LayoutParams {
        return TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT,
                TableLayout.LayoutParams.WRAP_CONTENT)
    }

    fun addHeaders() {//TAble headers
        val tl = findViewById<TableLayout>(R.id.table)
        val tr = TableRow(this)

        tr.layoutParams = getLayoutParams()
        tr.addView(getTextView(0, "S.No", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))

        tr.addView(getTextView(0, "Product name", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "HSN/SAC", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Price", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Quantity", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "          Tax         ", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tr.addView(getTextView(0, "Total", ContextCompat.getColor(this, R.color.fab), Typeface.BOLD,  ContextCompat.getColor(this, R.color.white)))
        tl.addView(tr, getTblLayoutParams())
    }
    var ee=0.0F
    var cc=0.0F
    var gros=0.0F
    var ig=0.0F
    var cg=0.0F
    var sg=0.0F
    var etot=0.0F
    var ftot=0.0F

    var ces=0.0F
    var quanflo=0.0F


    fun addData() {//Fill datas on table









        htmlDocument = "<html><body><h3>Vinitas Enterprises Pvt Ltd</h3><h4>" + "Supplier Invoice</h4>" +

                "<table class=Border>"+

                "<tr>"+
                "<td class=Border>Supplier Name:  </td>"+
                "<td class=Border> $suppname </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Supplier Phone:</td>"+
                "<td class=Border> $suppphone </td>"+
                "</tr>"+

                "<tr>"+
                "<td class=Border>Voucher No:   </td>"+
                "<td class=Border>$pono </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Date: </td>"+
                "<td class=Border>$orddate  </td>"+
                "</tr>"+

                "<tr>"+
                "<td class=Border>Invoice Date:</td>"+
                "<td class=Border>$reqdt  </td>"+"</tr>"+
                "<tr>"+

                "<td class=Border>Payment Due Date: </td>"+
                "<td class=Border>$postatus </td>"+
                "</tr>"+

                "<style>"+
                "table, th, td {"+
                "border: 1px solid black;"+
                "border-collapse: collapse;"+
                "}"+
                "th, td {"+
                "padding: 15px;"+
                "}"+
                "th {"+
                "text-align: left;"+
                "}"+
                "td.Hidden {"+
                "visibility: hidden;"+
                "}"+
                "td.Border {"+
                "border:none;"+
                "width:60%;"+
                "padding:8px;"+
                "}"+
                "table.Border {"+
                "border:none;"+

                "}"+
                "</style>"+
                "<h4>" + "Product Details</h4>"+
                "<table style=\"width:100%\">"+
                "<tr>"+







                "<th>S.No</th>"+
                "<th>Product name</th>"+
                "<th>HSN/SAC Code</th>"+

                "<th>Price</th>"+
                "<th>Quantity</th>"+
                "<th>Tax</th>"+
                "<th>Total</th>"+
                "</tr>"

        val tl = findViewById<TableLayout>(R.id.table)

        for (i in 0 until priceArray.size) {

            var pri=priceArray[i].toFloat()

            var quan = receivedArray[i]


            if(quan.toString().isEmpty()){
                quanflo= 0.0F
            }
            else if(quan.toString().isNotEmpty()){
                quanflo = receivedArray[i].toFloat()
                etot=igsttotArray[i].toFloat()
                ftot=cesstotalArray[i].toFloat()
            }



            var jj=etot+ftot


            var grtt=jj
            var grflo=grtt
            var gttt=grflo+(pri*quanflo)

            var grossrealtot=gttt+gros


            singrosstot=singrosstot.plusElement(grossrealtot.toString())

            println("Gross totals"+Arrays.toString(singrosstot))

            htmlDocument=htmlDocument+
                    "<tr>"+
                    "<td>${i+1}</td>"+
                    "<td>${pronameArray[i]}</td>"+
                    "<td>${hsnArray[i]}</td>"+
                    "<td>${priceArray[i]}</td>"+
                    "<td>${quantityArray[i]}</td>"+
                    "<td>$grtt</td>"+
                    "<td>$gttt</td>"+
                    "</tr>"

            if(priceArray.size==i){

            }


           /* tr.addView(getTextView(i + 1, (i+1).toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i + 1, pronameArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, hsnArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))

            tr.addView(getTextView(i +1, priceArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, receivedArray[i], ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tr.addView(getTextView(i +1, grtt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))

            tr.addView(getTextView(i +1, gttt.toString(), ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
            tl.addView(tr, getTblLayoutParams())*/
        }




        htmlDocument=htmlDocument+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>IGST TOTAL:</td>"+
                "<td>$igsttt</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>CGST TOTAL:</td>"+
                "<td>$cgsttt</td>"+
                "</tr>"+
                "<tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>SGST TOTAL:</td>"+
                "<td>$sgsttt</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td>Cess TOTAL:</td>"+
                "<td>$cestt</td>"+
                "</tr>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td class=Hidden></td>"+
                "<td> Gross TOTAL:</td>"+
                "<td>$grossto</td>"+

                "</tr>"+"</body></html>"


        myWebView!!.loadDataWithBaseURL(null, htmlDocument, "text/HTML", "UTF-8", null)




      /*  val t2 = findViewById<TableLayout>(R.id.table1)
        val t3 = findViewById<TableLayout>(R.id.table2)
        val tr2 = TableRow(this)
        val tr3 = TableRow(this)
        val tr4 = TableRow(this)
        val tr6 = TableRow(this)
        val tr5 = TableRow(this)

        val trval2= TableRow(this)
        val trval3= TableRow(this)
        val trval4= TableRow(this)
        val trval5= TableRow(this)
        val trval6= TableRow(this)

        var ttgross=0.0F
    *//*    for(l in 0 until singrosstot.size)

        {

            var arrgrosstt=singrosstot[l].toFloat()
            ttgross=ttgross+arrgrosstt
            grosstt=ttgross.toString()
            println("TOTAL"+ttgross+l)
            println("GROSS TOTAL"+grosstt+l)



        }*//*

        tr2.layoutParams = getLayoutParams()

        trval2.addView(getTextView( 0,igsttt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval3.addView(getTextView( 0,cgsttt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval4.addView(getTextView( 0,sgsttt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval5.addView(getTextView( 0,cestt, ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        trval6.addView(getTextView( 0,grossto,ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        tr2.addView(getTextView( 1,"IGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr3.addView(getTextView( 1,"CGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr4.addView(getTextView( 1,"SGST TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr5.addView(getTextView( 1,"Cess TOTAL:", ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))
        tr6.addView(getTextView( 1,"Gross TOTAL:",ContextCompat.getColor(this, R.color.fab), Typeface.NORMAL, ContextCompat.getColor(this, R.color.white)))


        t2.addView(tr2, getTblLayoutParams())
        t2.addView(tr3, getTblLayoutParams())
        t2.addView(tr4, getTblLayoutParams())
        t2.addView(tr5, getTblLayoutParams())
        t2.addView(tr6, getTblLayoutParams())


        t3.addView(trval2, getTblLayoutParams())
        t3.addView(trval3, getTblLayoutParams())
        t3.addView(trval4, getTblLayoutParams())
        t3.addView(trval5, getTblLayoutParams())
        t3.addView(trval6, getTblLayoutParams())*/

    }

    /*override fun onClick(v: View) {
        val id = v.id
        val tv = findViewById<TextView>(id)
        if (null != tv) {
            Log.i("onClick", "Clicked on row :: " + id)
            Toast.makeText(this, "Clicked on row :: " + id + ", Text :: " + tv.text, Toast.LENGTH_SHORT).show()
        }
    }*/


    override fun onBackPressed() {



        //Back action

        val bundle = intent.extras


        var a = bundle.get("pnm") as Array<String>
        val dsy = bundle.get("phsn") as Array<String>
        val ly = bundle.get("pmanu") as Array<String>
        val fy = bundle.get("barcode") as Array<String>
        val gy = bundle.get("quan") as Array<String>
        val hy = bundle.get("price") as Array<String>
        val ky = bundle.get("tot") as Array<String>
        val my = bundle.get("cessup") as Array<String>
        val ny = bundle.get("igst") as Array<String>
        val cy = bundle.get("cgst") as Array<String>
        val sy = bundle.get("sgst") as Array<String>
        val oy = bundle.get("igsttotal") as Array<String>
        val py = bundle.get("cesstotarray") as Array<String>
        val iddd = bundle.get("idsofli") as Array<String>
        try {
            val immy = bundle.get("image") as Array<String>
            tt=immy.clone()
        }
        catch(e:Exception){

        }

        val idtally = bundle.get("tallyarray") as Array<String>
        val idrec    = bundle.get("receivedarray") as Array<String>
        println("REEECCCCIIIEEEVVVVEEE"+ Arrays.toString(idrec))

        val spri     = bundle.get("received_price") as Array<String>
        val stot     = bundle.get("received_total") as Array<String>
        val staxt    = bundle.get("received_taxtot") as Array<String>
        val scesstot =bundle.get("received_cesstot") as Array<String>
        val sgross    = bundle.get("received_grosstot") as Array<String>


        try{
            datest=intent.getStringExtra("datest")
        }
        catch (e:Exception){

        }


        try {



            val f = intent.getStringExtra("reqdate")
            reqdt = f //Invoice


            val e = intent.getStringExtra("desc")
            desc = e

            val liis = intent.getStringExtra("reqliid")
            reqliid = liis

            val ff = intent.getStringExtra("orddate")
            orddate = ff //Date

            val stat = intent.getStringExtra("duedate")
            postatus = stat //Due date

            val lii = intent.getStringExtra("pono")
            pono = lii //Voucher no

            val grosstot = intent.getStringExtra("gross")
            grossto = grosstot //Voucher no

            val supnm = intent.getStringExtra("supnm")
            suppname = supnm //Supplier name

            val supph = intent.getStringExtra("supph")
            suppphone = supph //Supplier phone

            try{
                paidsta=intent.getStringExtra("status")
            }
            catch (e:Exception){

            }
            //Supname

           /* if(suppname.isNotEmpty()){
                suppliernm.setText(suppname)
            }
            else{
                suppliernm.setText("NONE")
            }


            //Supphone

            if(suppphone.isNotEmpty()){
                supplierph.setText(suppphone)
            }
            else{
                supplierph.setText("NONE")
            }


            //Gross tot
            if(grossto.isNotEmpty()){
                gross.setText(grossto)
            }
            else{
                gross.setText("NONE")
            }

            //Invoice

            if(reqdt.isNotEmpty()){
                invdate.setText(reqdt)
            }
            else{
                invdate.setText("NONE")
            }

            //Date
            if(orddate.isNotEmpty()){
                date.setText(orddate)
            }
            else{
                date.setText("NONE")
            }

            //Due date
            if(postatus.isNotEmpty()){
                paydue.setText(postatus)
            }
            else{
                paydue.setText("NONE")
            }

            //Voucher date
            if(pono.isNotEmpty()){
                vouno.setText(pono)
            }
            else{
                vouno.setText("NONE")
            }
*/

        }
        catch (e: Exception) {

        }
        /*  val aa = intent.getStringExtra("nms")
          comttname.setText(aa)
          val liis = intent.getStringExtra("reqliid")
          reqliid = liis
          val b = intent.getStringExtra("ph")
          comphone.setText(b)*/

        try {
            imgname = intent.getStringExtra("imgname")
        }
        catch (e:Exception){

        }


        try {
            imgnameedit = intent.getStringExtra("imgnameedit")

        }
        catch (e:Exception){

        }

        try{
            edclick=intent.getStringExtra("edclick")
        }
        catch (e:Exception){

        }

        try{
            vounodup=intent.getStringExtra("vounodup")
            invoicedatedup=intent.getStringExtra("invoicedatedup")
            payduedatedup=intent.getStringExtra("payduedatedup")
            suppdescripdup=intent.getStringExtra("suppdescripdup")
        }
        catch (e:Exception){

        }

        pronameArray= a.clone()
        hsnArray= dsy.clone()
        manufacturerArray =ly.clone()
        barcodeArray=fy.clone()
        quantityArray=gy.clone()
        priceArray=hy.clone()
        totArray =ky.clone()
        receivedArray=idrec.clone()
        cessArray =my.clone()
        igstArray =ny.clone()
        cgstArray =cy.clone()
        sgstArray =sy.clone()
        igsttotArray=oy.clone()
        cesstotalArray=py.clone()
        tallyArray=idtally.clone()
        receivedArraypri=spri.clone()
        receivedArraytotal=stot.clone()
        receivedArraytaxtot=staxt.clone()
        receivedArraycesstotal=scesstot.clone()
        receivedArraygrosstotal=sgross.clone()
        imageArray=tt.clone()





        val o = Intent(this@MainActivity_pdf, Supplier_thirdMainActivity::class.java)
        o.putExtra("from_suppin", "from_pdf")
        o.putExtra("renm", a)
        o.putExtra("remanu", ly)
        o.putExtra("rekey", iddd)
        o.putExtra("rehsn", dsy)
        o.putExtra("reprice", hy)
        o.putExtra("requan", gy)
        o.putExtra("rebc", fy)
        o.putExtra("retotal", ky)
        o.putExtra("recess", my)
        o.putExtra("reigst", ny)
        o.putExtra("recgst", cy)
        o.putExtra("resgst", sy)
        o.putExtra("retally", idtally)
        o.putExtra("rereceived", idrec)
        o.putExtra("rereceived_pri", spri)
        o.putExtra("rereceived_tot", stot)
        o.putExtra("rereceived_taxtot", staxt)
        o.putExtra("rereceived_cesstot", scesstot)
        o.putExtra("rereceived_grosstot", sgross)
        o.putExtra("reigst_total", oy)
        o.putExtra("recesstotal", py)
        o.putExtra("reimmg", tt)
        o.putExtra("pono", pono)
        o.putExtra("edclick",edclick)
        o.putExtra("statdup",statdup)

        o.putExtra("names", reprnms)
        o.putExtra("redesc", desc)
        o.putExtra("reorddate", orddate)
        o.putExtra("reestdt", reqdt)
        o.putExtra("restatus", postatus)
        o.putExtra("regross", grossto)
        o.putExtra("reigsts", igsttt)
        o.putExtra("recgsts", cgsttt)
        o.putExtra("resgsts", sgsttt)
        o.putExtra("recessts", cestt)
        o.putExtra("reids", reqliid)
        o.putExtra("titnm", suppname)
        o.putExtra("tiphone", suppphone)
        o.putExtra("reimgurl",imurl)
        o.putExtra("brnchids",brnchid)
        o.putExtra("status",paidsta)
        o.putExtra("backvald",frmval)
        o.putExtra("viewsuppin",viewsuppin)
        o.putExtra("addsuppin",addsuppin)
        o.putExtra("deletesuppin",deletesuppin)
        o.putExtra("editsuppin",editesuppin)
        o.putExtra("transfersuppin",transfersuppin)
        o.putExtra("exportsuppin",exportsuppin)

        o.putExtra("vounodup",vounodup)
        o.putExtra("invoicedatedup",invoicedatedup)
        o.putExtra("payduedatedup",payduedatedup)
        o.putExtra("suppdescripdup",suppdescripdup)

        o.putExtra("datest",datest)
        o.putExtra("viewpurord", viewpurord)
        o.putExtra("addpurord", addpurord)
        o.putExtra("deletepurord", deletepurord)
        o.putExtra("editpurord", editepurord)
        o.putExtra("transferpurord", transferpurord)
        o.putExtra("exportpurord", exportpurord)
        o.putExtra("sendpurord", sendpurpo)



        o.putExtra("viewpurreq", viewpurreq)
        o.putExtra("addpurreq", addpurreq)
        o.putExtra("deletepurreq", deletepurreq)
        o.putExtra("editpurreq", editepurreq)
        o.putExtra("transferpurreq", transferpurreq)
        o.putExtra("exportpurreq", exportpurreq)





        o.putExtra("imgname", imgname)


        o.putExtra("imgnameedit",imgnameedit)


        startActivity(o)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()
    }


    /*fun createandDisplayPdf(nm:String,ph:String,vno:String,date:String,ivdt:String,paydt:String,grosstot:String) {//Create,write,export pdf
         val FONT = "res/font/roboto.xml";
        val doc = Document()

        try {
            val path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Supplier Invoice"

           val dir =  File(path);
            if(!dir.exists())
                dir.mkdirs();
            var f=pono
             smill=System.currentTimeMillis().toString()
            var c=suppname
            var y=f+".pdf"

            val file = File(dir,y);
            val fOut =  FileOutputStream(file);




            PdfWriter.getInstance(doc,fOut)

            //open the document
            doc.open();
            val fntSize = 9.5f;
            val fntSizeheading = 14.5f;
            val fntSizesubheading = 12.5f;
            val b= BOLD
            val fontheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizeheading,b);
            val fontsubheading = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSizesubheading,b);
            val font = FontFactory.getFont(FONT, "Cp1250", BaseFont.EMBEDDED,fntSize);
            val h1 =  Paragraph("Vinitas Enterprises Pvt Ltd",fontheading)
            val hs1 =  Paragraph("Supplier Invoice",fontsubheading)



            val p1 =  Paragraph("Supplier Name:             "+nm,font)

            val p2 =  Paragraph("Supplier Phone:            "+ph,font)
            val p3 =  Paragraph("Voucher No:                 "+vno,font)
            val p4 =  Paragraph("Date:                              "+date,font)
            val p5 =  Paragraph("Invoice Date:                  "+ivdt,font)
            val p6 =  Paragraph("Payment Due Date:       "+paydt,font)
            val p7 =  Paragraph("Gross Total:                    "+grosstot,font)

            val p8=   Paragraph("Product Details",fontsubheading)

            val pnm=Paragraph("Product Name")
            val pri=Paragraph("Price")

            val table =  PdfPTable( floatArrayOf(2F,6F, 5F, 5F, 4F,6F, 4F));

          table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);

            table.addCell("S.No");
            table.addCell("Product Name");
            table.addCell("HSN/SAC");
            table.addCell("Price");
            table.addCell("Quantity");
            table.addCell("Taxes");
            table.addCell("Total");
            table.setHeaderRows(1);
            val cells = table.getRow(0).getCells();
            for(j in 0 until cells.size){
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            var ee=0.0F
            var cc=0.0F
            var gros=0.0F
            var ig=0.0F
            var cg=0.0F
            var sg=0.0F
            var quan=0.0F
            var quanflo=0.0F
            var ces=0.0F
            var etot=0.0F
            var ftot=0.0F
            for (i in 0 until priceArray.size)
            {



                var pri=priceArray[i].toFloat()


                var quan = receivedArray[i]


                if(quan.toString().isEmpty()){
                    quanflo= 0.0F
                }
                else if(quan.toString().isNotEmpty()){
                    quanflo = receivedArray[i].toFloat()
                    etot=igsttotArray[i].toFloat()
                    ftot=cesstotalArray[i].toFloat()
                }


                var jj=etot+ftot

                var grtt=jj
                var grflo=grtt
                var gttt=grflo+(pri*quanflo)

                var grossrealtot=gttt+gros

                singrosstot=singrosstot.plusElement(grossrealtot.toString())

                table.addCell((i+1).toString())
                table.addCell(pronameArray[i])
                table.addCell( hsnArray[i])
                table.addCell(priceArray[i])

                table.addCell( receivedArray[i])
                table.addCell(grtt.toString())

                table.addCell(gttt.toString())
            }
            var ttgross=0.0F

          *//*  for(l in 0 until singrosstot.size)

            {

                var arrgrosstt=singrosstot[l].toFloat()
                ttgross=ttgross+arrgrosstt
                grosstt=ttgross.toString()
                println("TOTAL"+ttgross+l)
                println("GROSS TOTAL"+grosstt+l)



            }*//*
            table.getDefaultCell().setBorder(Rectangle.NO_BORDER);
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")


            table.addCell("")

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("IGST Total")
            table.addCell(igsttt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("CGST Total")
            table.addCell(cgsttt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("SGST Total")
            table.addCell(sgsttt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("Cess Total")
            table.addCell(cestt)

            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("")
            table.addCell("GrossTotal")
            table.addCell(grossto)
  *//*val table =  PdfPTable(10);
  val  cell = PdfPCell(pnm);
 cell.colspan=1
 cell.setBorder(PdfPCell.NO_BORDER);
 cell.setHorizontalAlignment(Element.ALIGN_LEFT);
  table.addCell(cell);
  val cellCaveat =  PdfPCell(pri);
  cellCaveat.setColspan(1);
  cellCaveat.setBorder(PdfPCell.NO_BORDER);
  table.addCell(cellCaveat);
 table.addCell(cellCaveat);
 doc.add(table)*//*





 //add paragraph to document
      doc.add(h1)
        doc.add( Chunk.NEWLINE );
        doc.add(hs1)
        doc.add( Chunk.NEWLINE );
        doc.add(p1);
        doc.add( Chunk.NEWLINE );
        doc.add(p2);
        doc.add( Chunk.NEWLINE );
        doc.add(p3);
        doc.add( Chunk.NEWLINE );
        doc.add(p4);
        doc.add( Chunk.NEWLINE );
        doc.add(p5);
        doc.add( Chunk.NEWLINE );
        doc.add(p6);
        doc.add( Chunk.NEWLINE );
        doc.add(p7);
        doc.add( Chunk.NEWLINE );
        doc.add(p8);
            doc.add( Chunk.NEWLINE );
                   doc.add(table)
              downstatus="success"

       } catch ( de:DocumentException) {
            downstatus="not"

       } catch ( e:IOException) {
        Log.e("PDFCreator", "ioException:" + e)
       }
       finally {
        doc.close()
       }


       }


       fun viewPdf(folder:String,file:String) {  //Open created pdf document from local storage using pdf reader.

        val pdfFile =  File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+folder,file)
           println("SD CARD URL"+pdfFile)
        val path = Uri.fromFile(pdfFile);

        // Setting the intent for pdf reader
        val pdfIntent = Intent(Intent.ACTION_VIEW)
        pdfIntent.setDataAndType(path, "application/pdf")
        pdfIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

        try {
         startActivity(pdfIntent);
        } catch (e: ActivityNotFoundException) {
         Toast.makeText(applicationContext, "Can't read pdf file", Toast.LENGTH_SHORT).show();
        }
        }*/

    /*@RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun createWebPrintJob(webView: WebView) {

        val printManager = this
                .getSystemService(Context.PRINT_SERVICE) as PrintManager

        val printAdapter = webView.createPrintDocumentAdapter("MyDocument")

        val jobName = getString(R.string.app_name) + " Print Test"

        printManager.print(jobName, printAdapter,
                PrintAttributes.Builder().build())
    }*/
    companion object {


        //Listens inetrnet status whether net is on/off.if internet connection becomes off.if connection is off then all views becomes disable.
        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var cont: ConstraintLayout?=null



        private val log_str: String? = null

        @RequiresApi(Build.VERSION_CODES.M)
        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){

                constraintLayout3dis!!.visibility=View.VISIBLE
                relativeslayoutdis!!.visibility=View.VISIBLE

                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }




            }
            else
            {



                constraintLayout3dis!!.visibility=View.GONE

                relativeslayoutdis!!.visibility=View.GONE
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }




            }
        }
    }
    fun net_status():Boolean{//Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

        }
