package com.example.vinitas.inventory_app

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.StrictMode
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.daimajia.slider.library.Animations.DescriptionAnimation
import com.daimajia.slider.library.SliderLayout
import com.daimajia.slider.library.SliderTypes.BaseSliderView
import com.daimajia.slider.library.SliderTypes.TextSliderView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activityaddproduct_images.*

import kotlinx.android.synthetic.main.scroll2_page.*
import java.io.File
import java.net.URL

class Scroll2_page : AppCompatActivity(),BaseSliderView.OnSliderClickListener {
    internal lateinit var myDb: Databasehelper_service
    //var ur : String ="https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/ourimages-13.jpg?alt=media&token=e9641bdf-30a0-4517-8d44-d7e1987ae2a8"
    //image url's
    var f1: String = ""
    var s1: String = ""
    var t1: String = ""
    var fo1: String = ""
    var fif1: String = ""
    //image name's
    var fn1: String = ""
    var sn1: String = ""
    var tn1: String = ""
    var fon1: String = ""
    var fifn1: String = ""

    //image url's
    var f1edit: String = ""
    var s1edit: String = ""
    var t1edit: String = ""
    var fo1edit: String = ""
    var fif1edit: String = ""
    //image name's
    var fn1edit: String = ""
    var sn1edit: String = ""
    var tn1edit: String = ""
    var fon1edit: String = ""
    var fifn1edit: String = ""


    //image url's
    var f1high: String = ""
    var s1high: String = ""
    var t1high: String = ""
    var fo1high: String = ""
    var fif1high: String = ""
    //image name's
    var fn1high: String = ""
    var sn1high: String = ""
    var tn1high: String = ""
    var fon1high: String = ""
    var fifn1high: String = ""

    //image url's
    var f1edithigh: String = ""
    var s1edithigh: String = ""
    var t1edithigh: String = ""
    var fo1edithigh: String = ""
    var fif1edithigh: String = ""
    //image name's
    var fn1edithigh: String = ""
    var sn1edithigh: String = ""
    var tn1edithigh: String = ""
    var fon1edithigh: String = ""
    var fifn1edithigh: String = ""

    //ids
    var newid = String()
    var upid = String()
    var editclick = String()
    var mResultsarr = arrayListOf<String>()

    var cacnm1 = String()


    var status = String()
    var maincatId = ArrayList<String>()

    var sn_err: String = ""
    var pr_err: String = ""
    var fix_chk: String = ""
    var frm_chk: String = ""

    private var add = String()
    private var edite = String()
    private var delete = String()

    var listenersave = String()
    var scrollres = String()

    var frmscrtwo = "scrtwo"

    var slide1: BaseSliderView? = null
    var slide2: BaseSliderView? = null

    var db = FirebaseFirestore.getInstance()

    data class w(
            var snm: String,            //service Name
            var sid: String,        //service Id	(Auto Id)
            var dur: String,        //Duration
            var sac: String,        //HSN / SAC Code
            var sacdesc: String,        //HSN / SAC Code
            var pr: String,     //Price
            var tx: String,     //Taxable checkbox
            var igst: String,       //Integrated Tax
            var cess: String,       //Cess
            var cgst: String,       //Central Tax
            var sgst: String,       //State Tax
            var ttot: String,       //Tax total
            var ctot: String,       //Cess total
            var gtot: String,       //Gross total
            var ecomm: String,      //Pay employee commission on this service checkbox
            var ebns: String,       //Pay bonus to employee when this service sold	checkbox
            var cry: String,        //Currency	radiobutton
            var ptg: String,        //Percentage	radiobutton
            var bval: String,       //Bonus Value
            var gdr: String,        //Gender
            var mctg: String,       //Main category
            var sctg: String,       //Sub Category
            var desc: String,        //Description
            var fp: String,     //Fixed price
            var fpr: String,        //Range of Price	From
            var tpr: String,     //	To
            var status: String,    //status of service
            var img1n: String,     //image 1 name
            var img2n: String,     //image 2 name
            var img3n: String,     //image 3 name
            var img4n: String,     //image 4 name
            var img5n: String,     //image 5 name
            var img1url: String,     //image 1 url
            var img2url: String,     //image 2 url
            var img3url: String,     //image 3 url
            var img4url: String,     //image 4 url
            var img5url: String,
            var img1nhigh: String,     //image 1 name
            var img2nhigh: String,     //image 2 name
            var img3nhigh: String,     //image 3 name
            var img4nhigh: String,     //image 4 name
            var img5nhigh: String,     //image 5 name
            var img1urlhigh: String,     //image 1 url
            var img2urlhigh: String,     //image 2 url
            var img3urlhigh: String,     //image 3 url
            var img4urlhigh: String,     //image 4 url
            var img5urlhigh: String //image 5 url
    )

    override fun onSliderClick(slider: BaseSliderView?) {
        return
    }

    var d = arrayListOf<String>()
    var file_maps = arrayListOf<String>()
    var mc = String()


    var sidss = String()
    var subcate = String()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.scroll2_page)
        net_status()
        myDb = Databasehelper_service(this)
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        val maincat = ArrayList<String>()
        val adp1 = ArrayAdapter(this@Scroll2_page, R.layout.spinner_view, maincat)
        adp1.setDropDownViewResource(R.layout.spinner_view)

        val list = ArrayList<String>()
        val dataAdapter = ArrayAdapter(this@Scroll2_page, R.layout.spinner_view, list)
        dataAdapter.setDropDownViewResource(R.layout.spinner_view)

        val subcat = ArrayList<String>()
        val adp2 = ArrayAdapter(this@Scroll2_page, R.layout.spinner_view, subcat)
        adp2.setDropDownViewResource(R.layout.spinner_view)

        /*val id = intent.getStringExtra("id2")
        val ne = intent.getStringExtra("newid2")
        if (id.isNullOrEmpty()==false){
            id2.setText(id.toString())
        }
        if (ne.isNullOrEmpty()==false){
            newid2.setText(ne.toString())
            println(newid2.text.toString())
        }*/

        add = intent.getStringExtra("add")
        edite = intent.getStringExtra("edite")
        delete = intent.getStringExtra("delete")
        val fix_err = intent.getStringExtra("fix_err")
        val frm_err = intent.getStringExtra("frm_err")
        val to_err = intent.getStringExtra("to_err")
        fix_chk = intent.getStringExtra("fix_chk")
        frm_chk = intent.getStringExtra("frm_chk")

        if (fix_chk.isNullOrEmpty() == false) {
            scroll2_fixed.isChecked = fix_chk.toBoolean()
            scroll2_fixed_price.isEnabled = fix_chk.toBoolean()
        }
        if (frm_chk.isNullOrEmpty() == false) {
            scroll2_from.isChecked = frm_chk.toBoolean()
            scroll2_price_from.isEnabled = frm_chk.toBoolean()
            scroll2_price_to.isEnabled = frm_chk.toBoolean()
        }
        if (fix_err.isNullOrEmpty() == false) {

        }
        if (frm_err.isNullOrEmpty() == false) {

        }
        if (to_err.isNullOrEmpty() == false) {

        }
        val gen_err = intent.getStringExtra("gen_err")
        val main_err = intent.getStringExtra("main_err")
        val sub_err = intent.getStringExtra("sub_err")

        if (gen_err.isNullOrEmpty() == false) {

        }
        if (main_err.isNullOrEmpty() == false) {

        }
        if (sub_err.isNullOrEmpty() == false) {

        }

        //get id's from previous page or list page
        val lid = intent.getStringExtra("lid")
        val new = intent.getStringExtra("newid")
        val state = intent.getStringExtra("state")

        if (lid.isNullOrEmpty() == false) {
            id2.setText(lid.toString())
            scroll2_edit.visibility = View.VISIBLE
            scroll2_save.visibility = View.GONE
            val edit = intent.getIntExtra("edit", View.VISIBLE)
            if (edit.equals(View.GONE)) {
                scroll2_edit.visibility = View.GONE
                scroll2_save.visibility = View.VISIBLE
            }
            if (state.isNullOrEmpty() == false) {
                println("state is not empty")
                if (state == "Enabled") {
                    status = "Enabled"
                } else if (state == "Disabled") {
                    println("state disabled")
                    status = "Disabled"
                }
            }
        }
        if (new.isNullOrEmpty() == false) {
            newid2.setText(new.toString())
        }
        if (scroll2_edit.visibility == View.VISIBLE) {
            scroll2_category.isEnabled = false
            scroll2_sub_category.isEnabled = false
            scroll2_gender.isEnabled = false
            scroll2_descrip.isEnabled = false
            scroll2_fixed.isEnabled = false
            scroll2_from.isEnabled = false
            scroll2_fixed_price.isEnabled = false
            scroll2_price_from.isEnabled = false
            scroll2_price_to.isEnabled = false
            val getone = myDb.getOne(id2.text.toString())
            if (getone.moveToNext()) {
                mc = getone.getString(22).toString()
                if (getone.getString(23).toString() != "") {
                    scroll2_descrip.setText(getone.getString(23))
                }
                if (getone.getString(24).toString() != "") {
                    scroll2_fixed_price.setText(getone.getString(24).toString())
                    scroll2_preview_price.setText("RS ${getone.getString(24).toString()}")
                }
                if (getone.getString(25) != "" && getone.getString(26) != "") {
                    scroll2_price_from.setText(getone.getString(25).toString())
                    scroll2_preview_price.setText("From RS ${getone.getString(25).toString()} to ${getone.getString(26).toString()}")
                }
                if (getone.getString(26) != "") {
                    scroll2_price_to.setText(getone.getString(26).toString())
                }
                /*val img1url = getone.getString(33).toString()
                val img2url = getone.getString(34).toString()
                val img3url = getone.getString(35).toString()
                val img4url = getone.getString(36).toString()
                val img5url = getone.getString(37).toString()

                val img1n = getone.getString(28).toString()
                val img2n = getone.getString(29).toString()
                val img3n = getone.getString(30).toString()
                val img4n = getone.getString(31).toString()
                val img5n = getone.getString(32).toString()
                var updatemaps = ArrayList<String>()
                if (img1url != "" && img1n != "") {
                    println("img1url  " + img1url)
                    f1 = img1url.toString()
                    fn1 = img1n.toString()
                    updatemaps.add(f1)
                    println("file maps   " + updatemaps)
                    //file_maps.add(f1)
                }
                if (img2url != "" && img2n != "") {
                    s1 = img2url.toString()
                    sn1 = img2n.toString()
                    updatemaps.add(s1)
                }
                if (img3url != "" && img3n != "") {
                    t1 = img3url.toString()
                    tn1 = img3n.toString()
                    updatemaps.add(t1)
                }
                if (img4url != "" && img4n != "") {
                    fo1 = img4url.toString()
                    fon1 = img4n.toString()
                    updatemaps.add(fo1)
                }
                if (img5url != "" && img5n != "") {
                    fif1 = img5url.toString()
                    fifn1 = img5n.toString()
                    updatemaps.add(fif1)
                }
                if (img1url.isNotEmpty()||img2url.isNotEmpty()||img3url.isNotEmpty()||img4url.isNotEmpty()||img5url.isNotEmpty()){
                    camback.visibility=View.GONE
                    cam.visibility=View.GONE
                    scroll2_gallery.visibility=View.VISIBLE
                }else{
                    camback.visibility=View.VISIBLE
                    cam.visibility=View.VISIBLE
                    scroll2_gallery.visibility=View.GONE
                }
                scroll2_slider3.visibility = View.VISIBLE
                if (updatemaps.isNotEmpty()) {

                    for (r in 0 until updatemaps.size) {
                        val textSliderVie = TextSliderView(this)
                        // initialize a SliderLayout
                        Log.d("file_maps", "r  " + updatemaps[r])
                        textSliderVie
                                //.description(name)
                                .image(updatemaps[r])
                                .setScaleType(BaseSliderView.ScaleType.Fit)
                                .setOnSliderClickListener(this@Scroll2_page)
                        scroll2_slider3.addSlider(textSliderVie)
                    }
                    scroll2_slider3.setPresetTransformer(SliderLayout.Transformer.Default)
                    scroll2_slider3.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                    scroll2_slider3.setCustomAnimation(DescriptionAnimation())
                    scroll2_slider3.setDuration(5000)

                    //scroll2_preview_service_image2
                val newurl = URL(file_maps[0]).openStream()
                val img = BitmapFactory.decodeStream(newurl)
                scroll2_preview_service_image2.setImageBitmap(img)
                    camback.visibility=View.GONE
                    cam.visibility=View.GONE
                    scroll2_gallery.visibility=View.VISIBLE
                }else{
                    camback.visibility=View.VISIBLE
                    cam.visibility=View.VISIBLE
                    scroll2_gallery.visibility=View.GONE
                }
                if (img1url.equals("")) {
                    scroll2_preview_service_name.setText(getone.getString(1).toString())
                    val newurl = URL("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71").openStream()
                    val img = BitmapFactory.decodeStream(newurl)
                    scroll2_preview_service_image.setImageBitmap(img)
                } else {
                    scroll2_preview_service_name.setText(getone.getString(1).toString())
                    val newurl = URL(img1url.toString()).openStream()
                    val img = BitmapFactory.decodeStream(newurl)
                    scroll2_preview_service_image.setImageBitmap(img)
                }*/
            }
        }
        val sname = intent.getStringExtra("sname")
        val sid = intent.getStringExtra("sid")
        sidss = sid
        val sdur = intent.getStringExtra("sdur")
        val hsnT = intent.getStringExtra("hsnT")
        val hsndes = intent.getStringExtra("hsndes")
        val price = intent.getStringExtra("price")
        val Tax = intent.getBooleanExtra("Tax", false)
        val intax = intent.getStringExtra("intax")
        val cess = intent.getStringExtra("cess")
        val Ctax = intent.getStringExtra("Ctax")
        val Stax = intent.getStringExtra("Stax")
        val taxtot = intent.getStringExtra("taxtot")
        val css = intent.getStringExtra("css")
        val grosstot = intent.getStringExtra("grosstot")
        val payemp = intent.getBooleanExtra("payemp", false)
        val paybonus = intent.getBooleanExtra("paybonus", false)
        val currency = intent.getBooleanExtra("currency", false)
        val percentage = intent.getBooleanExtra("percentage", false)
        val per = intent.getStringExtra("per")
        try {
            editclick = intent.getStringExtra("editclick")
        } catch (e: Exception) {

        }
        listenersave = intent.getStringExtra("listenersave")
        try {
            mResultsarr = intent.getStringArrayListExtra("mresult")
        } catch (e: Exception) {

        }
        try {
            cacnm1 = intent.getStringExtra("cacnm1")
        } catch (e: Exception) {

        }

        //image url's
        val f = intent.getStringExtra("f")
        val s = intent.getStringExtra("s")
        val t = intent.getStringExtra("t")
        val fo = intent.getStringExtra("fo")
        val fif = intent.getStringExtra("fif")
        //image name's
        val fn = intent.getStringExtra("fn")
        val sn = intent.getStringExtra("sn")
        val tn = intent.getStringExtra("tn")
        val fon = intent.getStringExtra("fon")
        val fifn = intent.getStringExtra("fifn")

        val f1edits = intent.getStringExtra("f1edit")
        val s1edits = intent.getStringExtra("s1edit")
        val t1edits = intent.getStringExtra("t1edit")
        val fo1edits = intent.getStringExtra("fo1edit")
        val fif1edits = intent.getStringExtra("fif1edit")

        val fn1edits = intent.getStringExtra("fn1edit")
        val sn1edits = intent.getStringExtra("sn1edit")
        val tn1edits = intent.getStringExtra("tn1edit")
        val fon1edits = intent.getStringExtra("fon1edit")
        val fifn1edits = intent.getStringExtra("fifn1edit")


        if (f1edits.isNullOrEmpty() != true) {
            f1edit = f1edits
            fn1edit = fn1edits
        }

        if (s1edits.isNullOrEmpty() != true) {
            s1edit = s1edits
            sn1edit = sn1edits
        }
        if (t1edits.isNullOrEmpty() != true) {
            t1edit = t1edits
            tn1edit = tn1edits
        }

        if (fo1edits.isNullOrEmpty() != true) {
            fo1edit = fo1edits
            fon1edit = fon1edits
        }

        if (fif1edits.isNullOrEmpty() != true) {
            fif1edit = fif1edits
            fifn1edit = fifn1edits
        }


        val fhigh = intent.getStringExtra("fhigh")
        val shigh = intent.getStringExtra("shigh")
        val thigh = intent.getStringExtra("thigh")
        val fohigh = intent.getStringExtra("fohigh")
        val fifhigh = intent.getStringExtra("fifhigh")
        //image name's
        val fnhigh = intent.getStringExtra("fnhigh")
        val snhigh = intent.getStringExtra("snhigh")
        val tnhigh = intent.getStringExtra("tnhigh")
        val fonhigh = intent.getStringExtra("fonhigh")
        val fifnhigh = intent.getStringExtra("fifnhigh")



        println("fhigh" + fhigh)
        println("shigh" + shigh)
        println("thigh" + thigh)
        println("fohigh" + fohigh)
        println("fifhigh" + fifhigh)


        println("fnhigh" + fnhigh)
        println("snhigh" + snhigh)
        println("tnhigh" + tnhigh)
        println("fonhigh" + fonhigh)
        println("fifnhigh" + fifnhigh)

        if (fhigh.isNullOrEmpty() == false) {
            f1high = fhigh.toString()

        }
        if (shigh.isNullOrEmpty() == false) {
            s1high = shigh.toString()

        }
        if (thigh.isNullOrEmpty() == false) {
            t1high = thigh.toString()

        }
        if (fohigh.isNullOrEmpty() == false) {
            fo1high = fohigh.toString()

        }
        if (fifhigh.isNullOrEmpty() == false) {
            fif1high = fifhigh.toString()

        }
        if (fnhigh.isNullOrEmpty() == false) {
            fn1high = fnhigh.toString()
        }
        if (snhigh.isNullOrEmpty() == false) {
            sn1high = snhigh.toString()
        }
        if (tnhigh.isNullOrEmpty() == false) {
            tn1high = tnhigh.toString()
        }
        if (fonhigh.isNullOrEmpty() == false) {
            fon1high = fonhigh.toString()
        }
        if (fifnhigh.isNullOrEmpty() == false) {
            fifn1high = fifnhigh.toString()
        }

        val f1editshigh = intent.getStringExtra("f1edithigh")
        val s1editshigh = intent.getStringExtra("s1edithigh")
        val t1editshigh = intent.getStringExtra("t1edithigh")
        val fo1editshigh = intent.getStringExtra("fo1edithigh")
        val fif1editshigh = intent.getStringExtra("fif1edithigh")

        val fn1editshigh = intent.getStringExtra("fn1edithigh")
        val sn1editshigh = intent.getStringExtra("sn1edithigh")
        val tn1editshigh = intent.getStringExtra("tn1edithigh")
        val fon1editshigh = intent.getStringExtra("fon1edithigh")
        val fifn1editshigh = intent.getStringExtra("fifn1edithigh")


        if (f1editshigh.isNullOrEmpty() != true) {
            f1edithigh = f1editshigh
            fn1edithigh = fn1editshigh
        }

        if (s1editshigh.isNullOrEmpty() != true) {
            s1edithigh = s1editshigh
            sn1edithigh = sn1editshigh
        }
        if (t1edits.isNullOrEmpty() != true) {
            t1edithigh = t1editshigh
            tn1edithigh = tn1editshigh
        }

        if (fo1editshigh.isNullOrEmpty() != true) {
            fo1edithigh = fo1editshigh
            fon1edithigh = fon1editshigh
        }

        if (fif1editshigh.isNullOrEmpty() != true) {
            fif1edithigh = fif1editshigh
            fifn1edithigh = fifn1editshigh
        }



        scroll2_edit.setOnClickListener {
            if (edite == "true" || edite.isNullOrEmpty()) {
                scroll2_save.visibility = View.VISIBLE
                scroll2_edit.visibility = View.GONE
                scroll2_category.isEnabled = true
                scroll2_sub_category.isEnabled = true
                scroll2_descrip.isEnabled = true
                scroll2_gender.isEnabled = true
                scroll2_fixed.isEnabled = true
                scroll2_from.isEnabled = true
                scroll2_fixed_price.isEnabled = true
                scroll2_price_from.isEnabled = true
                scroll2_price_to.isEnabled = true
            } else if (edite == "false") {
                popup("edit")
            }
        }
        if (f.isNullOrEmpty() == false || s.isNullOrEmpty() == false || t.isNullOrEmpty() == false || fo.isNullOrEmpty() == false || fif.isNullOrEmpty() == false) {


            scrollpro.visibility = View.VISIBLE

            scroll2_preview_service_image2.visibility = View.VISIBLE
            scroll2_slider2.visibility = View.VISIBLE
            camback.visibility = View.GONE
            cam.visibility = View.GONE
            scroll2_gallery.visibility = View.VISIBLE
            if (f.isNullOrEmpty() == false) {
                f1 = f.toString()
                file_maps.add(f1)
            }
            if (s.isNullOrEmpty() == false) {
                s1 = s.toString()
                file_maps.add(s1)
            }
            if (t.isNullOrEmpty() == false) {
                t1 = t.toString()
                file_maps.add(t1)
            }
            if (fo.isNullOrEmpty() == false) {
                fo1 = fo.toString()
                file_maps.add(fo1)
            }
            if (fif.isNullOrEmpty() == false) {
                fif1 = fif.toString()
                file_maps.add(fif1)
            }
            if (fn.isNullOrEmpty() == false) {
                fn1 = fn.toString()
            }
            if (sn.isNullOrEmpty() == false) {
                sn1 = sn.toString()
            }
            if (tn.isNullOrEmpty() == false) {
                tn1 = tn.toString()
            }
            if (fon.isNullOrEmpty() == false) {
                fon1 = fon.toString()
            }
            if (fifn.isNullOrEmpty() == false) {
                fifn1 = fifn.toString()
            }
        } else {
            scroll2_slider2.visibility = View.GONE
            scroll2_preview_service_image2.visibility = View.GONE
            scroll2_slider.visibility = View.VISIBLE
            scroll2_preview_service_image.visibility = View.VISIBLE

            camback.visibility = View.VISIBLE
            cam.visibility = View.VISIBLE
            scroll2_gallery.visibility = View.GONE
        }

        //scroll2 page items
        val gen = intent.getStringExtra("gender")
        val main = intent.getStringExtra("maincat")
        val sub = intent.getStringExtra("subcat")
        val des = intent.getStringExtra("des")
        val fix = intent.getStringExtra("fix")
        val from = intent.getStringExtra("from")
        val to = intent.getStringExtra("to")
        if (scroll2_save.visibility == View.VISIBLE) {
            scroll2_descrip.setText(des)
            scroll2_fixed_price.setText(fix)
            scroll2_price_from.setText(from)
            scroll2_price_to.setText(to)
            if (scroll2_fixed_price.text.isNotEmpty()) {
                scroll2_preview_price.setText("Rs " + scroll2_fixed_price.text.toString())
            }
            if (scroll2_price_from.text.isNotEmpty() && scroll2_price_to.text.isNotEmpty()) {
                scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString() + " to " + scroll2_price_to.text.toString())
            }
        }
        println(des)
        println("sname " + sname)
        println("payemp " + payemp)
        println("paybonus " + paybonus)
        println("currency " + currency)
        println("percentage " + percentage)
        scroll2_preview_service_name.setText(sname)
        textView1.setText(sname)
        textView2.setText(sid)
        textView3.setText(sdur)
        textView4.setText(hsnT)
        textView5.setText(hsndes)
        textView6.setText(price)
        textView7.setText(Tax.toString())
        textView8.setText(intax)
        textView9.setText(cess)
        textView10.setText(Ctax)
        textView11.setText(Stax)
        textView12.setText(taxtot)
        textView13.setText(css)
        textView14.setText(grosstot)
        textView15.setText(payemp.toString())
        textView16.setText(paybonus.toString())
        textView17.setText(currency.toString())
        textView18.setText(percentage.toString())
        textView19.setText(per)
        textView20.setText(state)

        //carsoual


        Handler().postDelayed(Runnable { loadim() }, 1000)



        scroll2_more.setOnClickListener {
            val popup = PopupMenu(this@Scroll2_page, scroll2_more)
            popup.menuInflater.inflate(R.menu.disable, popup.menu)
            val m1 = popup.menu.getItem(0)
            if (delete == "true" || delete.isNullOrEmpty()) {
                if (scroll2_save.visibility == View.VISIBLE) {
                    println("save visible")
                    println("status  " + status)
                    if (status == "Disabled") {
                        m1.title = "Enable service"
                        popup.setOnMenuItemClickListener { item ->
                            status = "Enabled"
                            Toast.makeText(this@Scroll2_page, "" + item, Toast.LENGTH_SHORT).show()
                            true
                        }
                        popup.show()
                    } else if (status == "Enabled") {
                        m1.title = "Disable service"
                        popup.setOnMenuItemClickListener { item ->
                            status = "Disabled"
                            Toast.makeText(this@Scroll2_page, "" + item, Toast.LENGTH_SHORT).show()
                            true
                        }
                        popup.show()
                    }
                }
            } else if (delete == "false") {
                popup("Disable or Enable")
            }
        }

        //scroll2_gender
        list.add("Select")
        list.add("Male")
        list.add("Female")
        list.add("Unisex")
        scroll2_gender.adapter = dataAdapter
        if (gen.isNullOrEmpty() != true) {
            val spinnerPosition = dataAdapter.getPosition(gen.toString())
            scroll2_gender.setSelection(spinnerPosition)
        }

        //scroll2_category spinner
        db.collection("servicecategory")
                .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                    if (task.isEmpty == false) {
                        if (task != null) {
                            maincat.clear()
                            maincatId.clear()
                            maincat.add("Select")
                            maincatId.add("")
                            for (document in task) {
                                println("document id : " + document.id)
                                println("document data : " + document.data)
                                val dd = document.data
                                maincatId.add(document.id)
                                val c = dd["cat"].toString()
                                maincat.add(c)
                                println(maincat)
                                scroll2_category.adapter = adp1
                                if (main.isNullOrEmpty() != true) {
                                    val spinnerPosition = adp1.getPosition(main.toString())
                                    scroll2_category.setSelection(spinnerPosition)
                                }
                            }
                        }
                    }
                })

        //scroll2_gender spinner onItemSeletedListener
        scroll2_gender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
                return
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                if (p2 == 0) {
                    /*gen_error.visibility=View.VISIBLE
                    gen_error.setError(" ")*/
                } else {
                    gen_error.visibility = View.GONE
                }
            }
        }

        //scroll2_category spinner onItemSeletedListener
        scroll2_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
                return
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                println(maincatId.get(position))
                val key = maincatId.get(position)
                //scroll2_sub_category spinner
                if (scroll2_category.selectedItemPosition == 0) {
                    /*main_error.visibility=View.VISIBLE
                    main_error.setError(" ")*/
                } else {
                    main_error.visibility = View.GONE
                    db.collection("subcategory")
                            .addSnapshotListener(EventListener<QuerySnapshot> { task, e ->
                                subcat.clear()
                                subcat.add("")
                                if (task.isEmpty == false) {
                                    if (task.isEmpty == false) {
                                        if (task != null) {
                                            for (document in task) {
                                                println("document id : " + document.id)
                                                println("document data : " + document.data)
                                                val dd = document.data
                                                val mainid = dd["main_id"].toString()
                                                scroll2_sub_category.adapter = adp2
                                                if (mainid == key) {
                                                    val c = dd["cat"].toString()
                                                    subcat.add(c)
                                                    println(subcat)
                                                    scroll2_sub_category.adapter = adp2
                                                    scroll2_sub_category.setSelection(0)
                                                    if (sub.isNullOrEmpty() != true) {
                                                        val spinnerPosition = adp2.getPosition(sub.toString())
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }
                                                    if (mc.isNotEmpty()) {
                                                        println("mc  " + mc)
                                                        val spinnerPosition = adp2.getPosition(mc)
                                                        scroll2_sub_category.setSelection(spinnerPosition)
                                                    }
                                                } else {
                                                    subcat.clear()
                                                    println("true")
                                                    adp2.notifyDataSetChanged()
                                                }
                                            }
                                        }
                                    } else {


                                    }
                                }
                            })
                }
            }
        }
        scroll2_sub_category.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(p0: AdapterView<*>?) {
                return
            }

            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
                if (position == 0) {


                } else {
                    sub_error.visibility = View.GONE
                }
            }
        }

        if (id2.text.isNotEmpty()) {
            val getone = myDb.getOne(id2.text.toString())
            if (getone.moveToNext()) {
                scroll2_title.setText(getone.getString(1).toString())
            }
        }

        //scroll2_fixed setOnCheckedChangeListener
        if (scroll2_descrip.text.isEmpty()) {
            scroll2_preview_description.setText("")
            scroll2_preview_description.visibility = View.GONE
        } else {
            scroll2_preview_description.setText(scroll2_descrip.text.toString())
            scroll2_preview_description.visibility = View.VISIBLE
        }
        if (scroll2_fixed.isChecked == true) {
            if (scroll2_fixed_price.text.isEmpty()) {
                /*fixed_error.visibility = View.VISIBLE
                fixed_error.setError(" ")*/
            }
        } else {
            fixed_error.visibility = View.GONE
        }
        scroll2_fixed.setOnCheckedChangeListener { fixed, b ->
            if (fixed.isChecked == true) {
                println("fixed  " + b)
                fixed.isChecked = true
                scroll2_fixed_price.isEnabled = true
                scroll2_from.isChecked = false
                scroll2_price_from.isEnabled = false
                scroll2_price_from.setText("")
                scroll2_price_to.isEnabled = false
                scroll2_price_to.setText("")
                from_error.visibility = View.GONE
                to_error.visibility = View.GONE
                if (scroll2_fixed_price.text.isEmpty()) {
                    /*fixed_error.visibility=View.VISIBLE
                    fixed_error.setError(" ")*/
                }
            } else {
                fixed_error.visibility = View.GONE
            }
        }
        //scroll2_from setOnCheckedChangeListener
        if (scroll2_from.isChecked == true) {
            if (scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
                /*from_error.visibility=View.VISIBLE
                from_error.setError(" ")
                to_error.visibility=View.VISIBLE
                to_error.setError(" ")*/
            }
        } else {
            from_error.visibility = View.GONE
            to_error.visibility = View.GONE
        }
        scroll2_from.setOnCheckedChangeListener { fro, b ->
            if (fro.isChecked == true) {
                scroll2_fixed.isChecked = false
                scroll2_fixed_price.isEnabled = false
                scroll2_fixed_price.setText("")
                fro.isChecked = true
                scroll2_price_from.isEnabled = true
                scroll2_price_to.isEnabled = true
                fixed_error.visibility = View.GONE
                if (scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
                    /* from_error.visibility=View.VISIBLE
                    from_error.setError(" ")
                    to_error.visibility=View.VISIBLE
                    to_error.setError(" ")*/
                }
            } else {
                from_error.visibility = View.GONE
                to_error.visibility = View.GONE
            }
        }

        //description ontextchanged
        if (scroll2_descrip.text.isEmpty()) {
            scroll2_preview_description.visibility = View.GONE
        } else {
            scroll2_preview_description.visibility = View.VISIBLE
        }
        scroll2_descrip.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_description.setText(des)
                if (des.isEmpty()) {
                    scroll2_preview_description.visibility = View.GONE
                } else {
                    scroll2_preview_description.visibility = View.VISIBLE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //fixed price ontextchanged
        if (scroll2_fixed_price.text.isEmpty() && scroll2_price_from.text.isEmpty() && scroll2_price_to.text.isEmpty()) {
            scroll2_preview_price.setText("")
        }
        scroll2_fixed_price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(price: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("Rs " + price)
                if (price.isEmpty()) {
                    scroll2_preview_price.setText("")
                }
                if (scroll2_fixed_price.text.isEmpty()) {


                } else {
                    fixed_error.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //from price ontextchanged
        scroll2_price_from.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(from: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("From Rs " + from + " to " + scroll2_price_to.text.toString())
                if (from.isEmpty()) {
                    scroll2_preview_price.setText("")
                }
                if (scroll2_price_to.text.isEmpty() && from.isEmpty()) {
                    scroll2_preview_price.setText("")
                }
                if (from.isEmpty()) {

                } else {
                    from_error.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })

        //to price ontextchanged
        scroll2_price_to.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(to: CharSequence, start: Int, before: Int, count: Int) {
                scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString() + " to " + to)
                if (to.isEmpty()) {
                    scroll2_preview_price.setText("From Rs " + scroll2_price_from.text.toString())
                }
                if (scroll2_price_from.text.isEmpty() && to.isEmpty()) {
                    scroll2_preview_price.setText("")
                }
                if (to.isEmpty()) {

                } else {
                    to_error.visibility = View.GONE
                }
            }

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
            }
        })
        println("id  " + id2.text)
        println("new id  " + newid2.text)
        //save
        scroll2_save.setOnClickListener {
            println("save clicked " + newid2.text)
            if (newid2.text.isNotEmpty()) {
                if (scroll2_fixed_price.text.isEmpty() || scroll2_price_from.text.isEmpty() || scroll2_price_to.text.isEmpty()) {
                    if (scroll2_fixed.isChecked == true) {
                        if (scroll2_fixed_price.text.isEmpty()) {

                        }
                    }
                    if (scroll2_from.isChecked == true) {
                        if (scroll2_price_from.text.isEmpty()) {

                        }
                        if (scroll2_price_to.text.isEmpty()) {

                        }
                    }
                }
                if (textView1.text.isEmpty() || textView6.text.isEmpty()) {
                    println("gender " + scroll2_gender.selectedItemPosition.toString())
                    if (scroll2_gender.selectedItemPosition == 0) {

                    }
                    if (scroll2_category.selectedItemPosition == 0) {

                    }
                    if (scroll2_sub_category.selectedItemPosition == 0) {

                    }
                    if (textView1.text.isEmpty()) {
                        sn_err = "true"
                    }
                    if (textView6.text.isEmpty()) {
                        pr_err = "true"
                    }
                    println("main " + scroll2_category.selectedItemPosition.toString())
                    println("sub " + scroll2_sub_category.selectedItemPosition.toString())
                    Toast.makeText(this, "please fill required fields!", Toast.LENGTH_LONG).show()
                } else if (textView1.text.isNotEmpty() && textView6.text.isNotEmpty()) {
                    if (scroll2_fixed_price.text.isEmpty() || scroll2_price_from.text.isEmpty() || scroll2_price_to.text.isEmpty()) {
                        if (scroll2_fixed.isChecked == true) {
                            if (scroll2_fixed_price.text.isEmpty()) {

                            }
                        }
                        if (scroll2_from.isChecked == true) {
                            if (scroll2_price_from.text.isEmpty()) {

                            }
                            if (scroll2_price_to.text.isEmpty()) {

                            }
                        }
                    }



                    if (newid2.text.isNotEmpty() && id2.text.isEmpty()) {
                        scroll2_save.isEnabled = false
                        scroll2_progress.visibility = android.view.View.VISIBLE

                    } else {
                        Toast.makeText(this@Scroll2_page, "please fill required fields!", Toast.LENGTH_LONG).show()
                        println("scroll2_price_to.text" + scroll2_price_to.text)
                    }


                } else {
                    Toast.makeText(this@Scroll2_page, "please fill required fields!", Toast.LENGTH_LONG).show()
                    println("textView1.text.isNotEmpty()&&textView6.text.isNotEmpty()&&scroll2_gender.selectedItemPosition!=0&&scroll2_category.selectedItemPosition!=0&&scroll2_sub_category.selectedItemPosition!=0" + textView1.text + "  " + textView6.text + "  " + scroll2_gender.selectedItemPosition + "  " + scroll2_category.selectedItemPosition + "  " + scroll2_sub_category.selectedItemPosition)
                }
            }
            if (id2.text.isNotEmpty()) {
                println("UPDATE")

            }
        }
        scroll2_back.setOnClickListener {
            scroll2_back.isEnabled = false
            onBackPressed()
        }
        var radioGroup1: RadioGroup? = null
        radioGroup1 = (findViewById<View>(R.id.radioGroup1) as RadioGroup)
        radioGroup1!!.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            val inten: Intent
            Log.i("matching", "matching inside1 bro" + checkedId)
            when (checkedId) {
                R.id.service -> {
                    inten = Intent(baseContext, ScrollActivity::class.java)
                    val sname = (textView1.text).toString()
                    val sid = textView2.text.toString()
                    val sdur = textView3.text.toString()
                    val hsnT = textView4.text.toString()
                    val hsndes = textView5.text.toString()
                    val price = textView6.text.toString()
                    val Tax = textView7.text.toString().toBoolean()
                    val intax = textView8.text.toString()
                    val cess = textView9.text.toString()
                    val Ctax = textView10.text.toString()
                    val Stax = textView11.text.toString()
                    val taxtot = textView12.text.toString()
                    val css = textView13.text.toString()
                    val grosstot = textView14.text.toString()
                    val payemp = textView15.text.toString().toBoolean()
                    val paybonus = textView16.text.toString().toBoolean()
                    val currency = textView17.text.toString().toBoolean()
                    val percentage = textView18.text.toString().toBoolean()
                    val per = textView19.text.toString()
                    val descrip = textView20.text.toString()
                    inten.putExtra("sname1", sname)
                    inten.putExtra("frmscrtwo", frmscrtwo)
                    inten.putExtra("sid1", sid)
                    inten.putExtra("mresult", mResultsarr)
                    inten.putExtra("cacnm1", cacnm1)
                    inten.putExtra("sdur1", sdur)
                    inten.putExtra("hsnT1", hsnT)
                    inten.putExtra("hsndes1", hsndes)
                    inten.putExtra("price1", price)
                    inten.putExtra("Tax1", Tax)
                    inten.putExtra("intax1", intax)
                    inten.putExtra("cess1", cess)
                    inten.putExtra("Ctax1", Ctax)
                    inten.putExtra("Stax1", Stax)
                    inten.putExtra("taxtot1", taxtot)
                    inten.putExtra("css1", css)
                    inten.putExtra("grosstot1", grosstot)
                    inten.putExtra("payemp1", payemp)
                    inten.putExtra("paybonus1", paybonus)
                    inten.putExtra("currency1", currency)
                    inten.putExtra("percentage1", percentage)
                    inten.putExtra("per1", per)
                    inten.putExtra("listenersave", listenersave)
                    inten.putExtra("editclick", editclick)
                    inten.putExtra("descrip1", descrip)
                    inten.putExtra("lid", lid.toString())
                    inten.putExtra("newid", newid2.text)
                    inten.putExtra("s_edit", scroll2_edit.visibility)
                    println("s_edit  " + scroll2_edit.visibility)
                    inten.putExtra("state", status)
                    println("state  " + status)
                    if (sn_err.isNotEmpty()) {
                        inten.putExtra("sn_err", sn_err)
                    }
                    if (pr_err.isNotEmpty()) {
                        inten.putExtra("pr_err", pr_err)
                    }
                    //scroll2 page items
                    if (scroll2_gender.selectedItem != null) {
                        inten.putExtra("gender", scroll2_gender.selectedItem.toString())
                    }
                    if (scroll2_category.selectedItem != null) {
                        inten.putExtra("maincat", scroll2_category.selectedItem.toString())
                    }
                    if (scroll2_sub_category.selectedItem != null) {
                        inten.putExtra("subcat", scroll2_sub_category.selectedItem.toString())
                    }
                    inten.putExtra("des", scroll2_descrip.text.toString())
                    inten.putExtra("fix", scroll2_fixed_price.text.toString())
                    inten.putExtra("from", scroll2_price_from.text.toString())
                    inten.putExtra("to", scroll2_price_to.text.toString())
                    inten.putExtra("fix_check", scroll2_fixed.isChecked)
                    inten.putExtra("from_check", scroll2_from.isChecked)
                    //image url's
                    inten.putExtra("f", f1)
                    inten.putExtra("s", s1)
                    inten.putExtra("t", t1)
                    inten.putExtra("fo", fo1)
                    inten.putExtra("fif", fif1)
                    //image name's
                    inten.putExtra("fn", fn1)
                    inten.putExtra("sn", sn1)
                    inten.putExtra("tn", tn1)
                    inten.putExtra("fon", fon1)
                    inten.putExtra("fifn", fifn1)

                    inten.putExtra("f1edit", f1edit)
                    inten.putExtra("fn1edit", fn1edit)
                    inten.putExtra("s1edit", s1edit)
                    inten.putExtra("sn1edit", sn1edit)
                    inten.putExtra("t1edit", t1edit)
                    inten.putExtra("tn1edit", tn1edit)
                    inten.putExtra("fo1edit", fo1edit)
                    inten.putExtra("fon1edit", fon1edit)
                    inten.putExtra("fif1edit", fif1edit)
                    inten.putExtra("fifn1edit", fifn1edit)

                    println("fhigh" + fhigh)
                    println("shigh" + shigh)
                    println("thigh" + thigh)
                    println("fohigh" + fohigh)
                    println("fifhigh" + fifhigh)


                    println("fnhigh" + fnhigh)
                    println("snhigh" + snhigh)
                    println("tnhigh" + tnhigh)
                    println("fonhigh" + fonhigh)
                    println("fifnhigh" + fifnhigh)
                    inten.putExtra("fhigh", f1high)
                    inten.putExtra("shigh", s1high)
                    inten.putExtra("thigh", t1high)
                    inten.putExtra("fohigh", fo1high)
                    inten.putExtra("fifhigh", fif1high)
                    //image name's
                    inten.putExtra("fnhigh", fn1high)
                    inten.putExtra("snhigh", sn1high)
                    inten.putExtra("tnhigh", tn1high)
                    inten.putExtra("fonhigh", fon1high)
                    inten.putExtra("fifnhigh", fifn1high)

                    inten.putExtra("f1edithigh", f1edithigh)
                    inten.putExtra("fn1edithigh", fn1edithigh)
                    inten.putExtra("s1edithigh", s1edithigh)
                    inten.putExtra("sn1edithigh", sn1edithigh)
                    inten.putExtra("t1edithigh", t1edithigh)
                    inten.putExtra("tn1edithigh", tn1edithigh)
                    inten.putExtra("fo1edithigh", fo1edithigh)
                    inten.putExtra("fon1edithigh", fon1edithigh)
                    inten.putExtra("fif1edithigh", fif1edithigh)
                    inten.putExtra("fifn1edithigh", fifn1edithigh)

                    inten.putExtra("add", add)
                    inten.putExtra("edit", edite)
                    inten.putExtra("delete", delete)
                    startActivity(inten)
                    overridePendingTransition(0, 0)
                    finish()
                }
                R.id.web -> {
                }
                else -> {
                }
            }
        })

        scroll2_gallery.setOnClickListener {
            scroll2_slider.removeAllSliders()
            scroll2_gallery.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_services::class.java)
            b.putExtra("id", id2.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)
            b.putExtra("f1high", f1high)
            b.putExtra("fn1high", fn1high)
            b.putExtra("s1high", s1high)
            b.putExtra("sn1high", sn1high)
            b.putExtra("t1high", t1high)
            b.putExtra("tn1high", tn1high)
            b.putExtra("fo1high", fo1high)
            b.putExtra("fon1high", fon1high)
            b.putExtra("fif1high", fif1high)
            b.putExtra("fifn1high", fifn1high)
            b.putExtra("mresult", mResultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("listenersave", listenersave)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)
            b.putExtra("f1high", f1high)
            b.putExtra("fn1high", fn1high)
            b.putExtra("s1high", s1high)
            b.putExtra("sn1high", sn1high)
            b.putExtra("t1high", t1high)
            b.putExtra("tn1high", tn1high)
            b.putExtra("fo1high", fo1high)
            b.putExtra("fon1high", fon1high)
            b.putExtra("fif1high", fif1high)
            b.putExtra("fifn1high", fifn1high)
            startActivityForResult(b, 0)
            scroll2_gallery.isEnabled = true
        }








        camback.setOnClickListener {
            camback.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_services::class.java)
            b.putExtra("id", id2.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)
            b.putExtra("mresult", mResultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("f1high", f1high)
            b.putExtra("fn1high", fn1high)
            b.putExtra("s1high", s1high)
            b.putExtra("sn1high", sn1high)
            b.putExtra("t1high", t1high)
            b.putExtra("tn1high", tn1high)
            b.putExtra("fo1high", fo1high)
            b.putExtra("fon1high", fon1high)
            b.putExtra("fif1high", fif1high)
            b.putExtra("fifn1high", fifn1high)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)



            startActivityForResult(b, 0)
            camback.isEnabled = true
        }
        cam.setOnClickListener {
            cam.isEnabled = false
            val b = Intent(applicationContext, AddImagesActivity_services::class.java)
            b.putExtra("id", id2.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)
            b.putExtra("mresult", mResultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)


            b.putExtra("f1high", f1high)
            b.putExtra("fn1high", fn1high)
            b.putExtra("s1high", s1high)
            b.putExtra("sn1high", sn1high)
            b.putExtra("t1high", t1high)
            b.putExtra("tn1high", tn1high)
            b.putExtra("fo1high", fo1high)
            b.putExtra("fon1high", fon1high)
            b.putExtra("fif1high", fif1high)
            b.putExtra("fifn1high", fifn1high)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)

            startActivityForResult(b, 0)
            cam.isEnabled = true
        }


        if (scrollres.isNotEmpty()) {

        }


    }

    fun loadim() {
        scrollpro.visibility = View.GONE
        if (file_maps.isNotEmpty()) {


            for (r in 0 until file_maps.size) {
                try {
                    val textSliderView = TextSliderView(this)
                    // initialize a SliderLayout
                    Log.d("file_maps", "r  " + file_maps[r])
                    textSliderView
                            //.description(name)
                            .image(file_maps[r])
                            .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                            .setOnSliderClickListener {
                                scroll2_slider.removeAllSliders()
                                scroll2_slider2.removeAllSliders()
                                val b = Intent(applicationContext, AddImagesActivity_services::class.java)
                                b.putExtra("id", id2.text.toString())
                                b.putExtra("f1", f1)
                                b.putExtra("fn1", fn1)
                                b.putExtra("s1", s1)
                                b.putExtra("sn1", sn1)
                                b.putExtra("t1", t1)
                                b.putExtra("tn1", tn1)
                                b.putExtra("fo1", fo1)
                                b.putExtra("fon1", fon1)
                                b.putExtra("fif1", fif1)
                                b.putExtra("fifn1", fifn1)
                                b.putExtra("f1high", f1high)
                                b.putExtra("fn1high", fn1high)
                                b.putExtra("s1high", s1high)
                                b.putExtra("sn1high", sn1high)
                                b.putExtra("t1high", t1high)
                                b.putExtra("tn1high", tn1high)
                                b.putExtra("fo1high", fo1high)
                                b.putExtra("fon1high", fon1high)
                                b.putExtra("fif1high", fif1high)
                                b.putExtra("fifn1high", fifn1high)
                                b.putExtra("f1edithigh", f1edithigh)
                                b.putExtra("fn1edithigh", fn1edithigh)
                                b.putExtra("s1edithigh", s1edithigh)
                                b.putExtra("sn1edithigh", sn1edithigh)
                                b.putExtra("t1edithigh", t1edithigh)
                                b.putExtra("tn1edithigh", tn1edithigh)
                                b.putExtra("fo1edithigh", fo1edithigh)
                                b.putExtra("fon1edithigh", fon1edithigh)
                                b.putExtra("fif1edithigh", fif1edithigh)
                                b.putExtra("fifn1edithigh", fifn1edithigh)
                                b.putExtra("f1edit", f1edit)
                                b.putExtra("fn1edit", fn1edit)
                                b.putExtra("s1edit", s1edit)
                                b.putExtra("sn1edit", sn1edit)
                                b.putExtra("t1edit", t1edit)
                                b.putExtra("tn1edit", tn1edit)
                                b.putExtra("fo1edit", fo1edit)
                                b.putExtra("fon1edit", fon1edit)
                                b.putExtra("fif1edit", fif1edit)
                                b.putExtra("fifn1edit", fifn1edit)
                                startActivityForResult(b, 0)
                                scroll2_slider.isEnabled = true
                            }
                    scroll2_slider2.addSlider(textSliderView)
                } catch (e: Exception) {

                }
            }
            scroll2_slider2.setPresetTransformer(SliderLayout.Transformer.Default)
            scroll2_slider2.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
            scroll2_slider2.setCustomAnimation(DescriptionAnimation())
            scroll2_slider2.setDuration(5000)

            //scroll2_preview_service_image2
            try {
                val newurl = URL(file_maps[0]).openStream()
                val img = BitmapFactory.decodeStream(newurl)
                scroll2_preview_service_image2.setImageBitmap(img)
            } catch (e: Exception) {

            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 0) {

            if (resultCode == Activity.RESULT_OK) {
                scrollres = "result"
                scroll2_preview_service_image2.visibility = View.GONE
                scroll2_slider2.visibility = View.GONE
                scroll2_slider3.visibility = View.GONE
                scroll2_slider.visibility = View.VISIBLE
                scroll2_preview_service_image.visibility = View.VISIBLE
                val f = data!!.getStringExtra("f");
                val fn = data!!.getStringExtra("fn");
                val s = data!!.getStringExtra("s");
                val sn = data!!.getStringExtra("sn");
                val t = data!!.getStringExtra("t");
                val tn = data!!.getStringExtra("tn");
                val fo = data!!.getStringExtra("fo");
                val fon = data!!.getStringExtra("fon");
                val fif = data!!.getStringExtra("fif");
                val fifn = data!!.getStringExtra("fifn");


                val fedit = data!!.getStringExtra("fedit")
                val fnedit = data!!.getStringExtra("fnedit")
                val sedit = data!!.getStringExtra("sedit")
                val snedit = data!!.getStringExtra("snedit")
                val tedit = data!!.getStringExtra("tedit")
                val tnedit = data!!.getStringExtra("tnedit")
                val foedit = data!!.getStringExtra("foedit")
                val fonedit = data!!.getStringExtra("fonedit")
                val fifedit = data!!.getStringExtra("fifedit")
                val fifnedit = data!!.getStringExtra("fifnedit");

                try {
                    mResultsarr = data!!.getStringArrayListExtra("mResult")
                } catch (e: Exception) {

                }



                try {
                    cacnm1 = data!!.getStringExtra("cacnm1")
                } catch (e: Exception) {

                }
                try {
                    listenersave = data!!.getStringExtra("listenersave")
                } catch (e: Exception) {

                }

                val fhigh = data!!.getStringExtra("fhigh");
                val fnhigh = data!!.getStringExtra("fnhigh");
                val shigh = data!!.getStringExtra("shigh");
                val snhigh = data!!.getStringExtra("snhigh");
                val thigh = data!!.getStringExtra("thigh");
                val tnhigh = data!!.getStringExtra("tnhigh");
                val fohigh = data!!.getStringExtra("fohigh");
                val fonhigh = data!!.getStringExtra("fonhigh");
                val fifhigh = data!!.getStringExtra("fifhigh");
                val fifnhigh = data!!.getStringExtra("fifnhigh");


                println("fhigh" + fhigh)
                println("shigh" + shigh)
                println("thigh" + thigh)
                println("fohigh" + fohigh)
                println("fifhigh" + fifhigh)


                println("fnhigh" + fnhigh)
                println("snhigh" + snhigh)
                println("tnhigh" + tnhigh)
                println("fonhigh" + fonhigh)
                println("fifnhigh" + fifnhigh)
                if (fhigh.isNotEmpty()) {


                    f1high = fhigh
                    fn1high = fnhigh
                } else {
                    f1high = ""
                    fn1high = ""
                }
                if (shigh.isNotEmpty()) {


                    s1high = shigh
                    sn1high = snhigh
                } else {
                    s1high = ""
                    sn1high = ""
                }
                if (thigh.isNotEmpty()) {


                    t1high = thigh
                    tn1high = tnhigh
                } else {
                    t1high = ""
                    tn1high = ""
                }
                if (fohigh.isNotEmpty()) {


                    fo1high = fohigh
                    fon1high = fonhigh
                } else {
                    fo1high = ""
                    fon1high = ""
                }
                if (fifhigh.isNotEmpty()) {


                    fif1high = fifhigh
                    fifn1high = fifnhigh
                } else {
                    fif1high = ""
                    fifn1high = ""
                }


                val fedithigh = data!!.getStringExtra("fedithigh")
                val fnedithigh = data!!.getStringExtra("fnedithigh")
                val sedithigh = data!!.getStringExtra("sedithigh")
                val snedithigh = data!!.getStringExtra("snedithigh")
                val tedithigh = data!!.getStringExtra("tedithigh")
                val tnedithigh = data!!.getStringExtra("tnedithigh")
                val foedithigh = data!!.getStringExtra("foedithigh")
                val fonedithigh = data!!.getStringExtra("fonedithigh")
                val fifedithigh = data!!.getStringExtra("fifedithigh")
                val fifnedithigh = data!!.getStringExtra("fifnedithigh");

                if (fedithigh.isNotEmpty()) {


                    f1edithigh = fedithigh
                    fn1edithigh = fnedithigh


                } else {


                    f1edithigh = ""
                    fn1edithigh = ""
                }
                if (sedithigh.isNotEmpty()) {


                    s1edithigh = sedithigh
                    sn1edithigh = snedithigh

                } else {


                    s1edithigh = ""
                    sn1edithigh = ""
                }
                if (tedithigh.isNotEmpty()) {

                    t1edithigh = tedithigh
                    tn1edithigh = tnedithigh

                } else {

                    t1edithigh = ""
                    tn1edithigh = ""
                }
                if (foedithigh.isNotEmpty()) {
                    fo1edithigh = foedithigh
                    fon1edithigh = fonedithigh

                } else {

                    fo1edithigh = ""
                    fon1edithigh = ""
                }
                if (fifedithigh.isNotEmpty()) {

                    fif1edithigh = fifedithigh
                    fifn1edithigh = fifnedithigh

                } else {

                    fif1edithigh = ""
                    fifn1edithigh = ""
                }





                if (fedit.isNotEmpty()) {


                    f1edit = fedit
                    fn1edit = fnedit


                } else {


                    f1edit = ""
                    fn1edit = ""
                }
                if (sedit.isNotEmpty()) {


                    s1edit = sedit
                    sn1edit = snedit

                } else {


                    s1edit = ""
                    sn1edit = ""
                }
                if (tedit.isNotEmpty()) {

                    t1edit = tedit
                    tn1edit = tnedit

                } else {

                    t1edit = ""
                    tn1edit = ""
                }
                if (foedit.isNotEmpty()) {
                    fo1edit = foedit
                    fon1edit = fonedit

                } else {

                    fo1edit = ""
                    fon1edit = ""
                }
                if (fifedit.isNotEmpty()) {

                    fif1edit = fifedit
                    fifn1edit = fifnedit

                } else {

                    fif1edit = ""
                    fifn1edit = ""
                }


                val bitmapArray = ArrayList<String>()
                bitmapArray.clear()
                if (f.isNotEmpty() || s.isNotEmpty() || t.isNotEmpty() || fo.isNotEmpty() || fif.isNotEmpty()) {
                    camback.visibility = View.GONE
                    cam.visibility = View.GONE
                    scroll2_gallery.visibility = View.VISIBLE
                } else {
                    camback.visibility = View.VISIBLE
                    cam.visibility = View.VISIBLE
                    scroll2_gallery.visibility = View.GONE
                }

                if (f.isNotEmpty()) {
                    d.add(f);bitmapArray.add(f)

                    f1 = f
                    fn1 = fn
                } else {
                    f1 = ""
                    fn1 = ""
                }
                if (s.isNotEmpty()) {
                    d.add(s);bitmapArray.add(s)

                    s1 = s
                    sn1 = sn
                } else {
                    s1 = ""
                    sn1 = ""
                }
                if (t.isNotEmpty()) {
                    d.add(t);bitmapArray.add(t)

                    t1 = t
                    tn1 = tn
                } else {
                    t1 = ""
                    tn1 = ""
                }
                if (fo.isNotEmpty()) {
                    d.add(fo);bitmapArray.add(fo)

                    fo1 = fo
                    fon1 = fon
                } else {
                    fo1 = ""
                    fon1 = ""
                }
                if (fif.isNotEmpty()) {
                    d.add(fif);bitmapArray.add(fif)

                    fif1 = fif
                    fifn1 = fifn
                } else {
                    fif1 = ""
                    fifn1 = ""
                }


                if ((id2.text.isNotEmpty()) && ((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || (fo1 != fo1edit) || (fif1 != fif1edit))) {

                    listenersave = "change"


                }


                Log.d("tag", "  " + bitmapArray)
                if (bitmapArray.isNotEmpty()) {
                    for (r in 0 until bitmapArray.size) {
                        val textSliderView = TextSliderView(this)
                        // initialize a SliderLayout
                        Log.d("khd", "r  " + bitmapArray[r])
                        textSliderView
                                //.description(name)
                                .image(bitmapArray[r])

                                .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                                .setOnSliderClickListener {
                                    scroll2_slider.removeAllSliders()
                                    scroll2_slider2.removeAllSliders()
                                    val b = Intent(applicationContext, AddImagesActivity_services::class.java)
                                    b.putExtra("id", id2.text.toString())
                                    b.putExtra("f1", f1)
                                    b.putExtra("fn1", fn1)
                                    b.putExtra("s1", s1)
                                    b.putExtra("sn1", sn1)
                                    b.putExtra("t1", t1)
                                    b.putExtra("tn1", tn1)
                                    b.putExtra("fo1", fo1)
                                    b.putExtra("fon1", fon1)
                                    b.putExtra("fif1", fif1)
                                    b.putExtra("fifn1", fifn1)
                                    b.putExtra("f1high", f1high)
                                    b.putExtra("fn1high", fn1high)
                                    b.putExtra("s1high", s1high)
                                    b.putExtra("sn1high", sn1high)
                                    b.putExtra("t1high", t1high)
                                    b.putExtra("tn1high", tn1high)
                                    b.putExtra("fo1high", fo1high)
                                    b.putExtra("fon1high", fon1high)
                                    b.putExtra("fif1high", fif1high)
                                    b.putExtra("fifn1high", fifn1high)
                                    b.putExtra("mresult", mResultsarr)
                                    b.putExtra("f1edithigh", f1edithigh)
                                    b.putExtra("fn1edithigh", fn1edithigh)
                                    b.putExtra("s1edithigh", s1edithigh)
                                    b.putExtra("sn1edithigh", sn1edithigh)
                                    b.putExtra("t1edithigh", t1edithigh)
                                    b.putExtra("tn1edithigh", tn1edithigh)
                                    b.putExtra("fo1edithigh", fo1edithigh)
                                    b.putExtra("fon1edithigh", fon1edithigh)
                                    b.putExtra("fif1edithigh", fif1edithigh)
                                    b.putExtra("fifn1edithigh", fifn1edithigh)

                                    b.putExtra("cacnm1", cacnm1)
                                    b.putExtra("f1edit", f1edit)
                                    b.putExtra("fn1edit", fn1edit)
                                    b.putExtra("s1edit", s1edit)
                                    b.putExtra("sn1edit", sn1edit)
                                    b.putExtra("t1edit", t1edit)
                                    b.putExtra("tn1edit", tn1edit)
                                    b.putExtra("fo1edit", fo1edit)
                                    b.putExtra("fon1edit", fon1edit)
                                    b.putExtra("fif1edit", fif1edit)
                                    b.putExtra("fifn1edit", fifn1edit)
                                    startActivityForResult(b, 0)
                                    scroll2_slider.isEnabled = true
                                }

                        //add your extra information
                        /*textSliderView.bundle(Bundle())
                    textSliderView.bundle.clear()*/
                        //.putString("extra", bitmapArray[r])

                        scroll2_slider.addSlider(textSliderView)
                    }
                    scroll2_slider.setPresetTransformer(SliderLayout.Transformer.Default)
                    scroll2_slider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                    scroll2_slider.setCustomAnimation(DescriptionAnimation())
                    scroll2_slider.setDuration(5000)

                    //scroll2_preview_service_image
                    val newurl = URL(bitmapArray[0]).openStream()
                    val img = BitmapFactory.decodeStream(newurl)
                    scroll2_preview_service_image.setImageBitmap(img)
                }

                //bitmapArray.addAll(data.get("bitmapArray"))
                //println(bitmapArray)
                Log.d(" ", "result " + f)
                Log.d(" ", "result " + s)
                Log.d(" ", "result " + t)
                Log.d(" ", "result " + fo)
                Log.d(" ", "result " + fif)
                /* this.runOnUiThread(Runnable() {
                    file_maps.clear()
                    d.addAll(d)
                    Log.d("map","  "+d)
                })*/
            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //Write your code if there's no result
                Log.d("no ", "Result")
            }
        }
    }

    private fun onStarClicked1() {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("service_id")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value
                if (p == null) {
                    p = 1
                } else if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }
                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(databaseError: DatabaseError?, b: Boolean, dataSnapshot: DataSnapshot) {
                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value
                textView2.setText(id.toString())
                service_insert(id.toString())
                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }

    fun service_insert(service_id: String) {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Saving...")
        pDialog.setCancelable(false);
        pDialog.show();
        val nid = newid2.text.toString()
        val sname = (textView1.text).toString()
        val sid = service_id
        val sdur = (textView3.text).toString()
        val hsnT = (textView4.text).toString()
        val hsndes = (textView5.text).toString()
        val pr = (textView6.text).toString()
        val Tax = (textView7.text.toString())
        val intax = (textView8.text).toString()
        val cess = (textView9.text).toString()
        val Ctax = (textView10.text).toString()
        val Stax = (textView11.text).toString()
        val taxtot = (textView12.text).toString()
        val css = (textView13.text).toString()
        val Gtot = (textView14.text).toString()
        val payemp = (textView15.text.toString())
        val paybonus = (textView16.text.toString())
        val currency = (textView17.text.toString())
        val percentage = (textView18.text.toString())
        val per = (textView19.text).toString()


        val retdays=""

        //val desc = (descrip.text).toString()
        val status = (textView20.text.toString())
        val gender = (scroll2_gender.selectedItem.toString())
        val maincat = (scroll2_category.selectedItem.toString())
        try {
            if (scroll2_sub_category.selectedItemPosition == 0) {

                subcate = ""
            } else {
                subcate = (scroll2_sub_category.selectedItem.toString())

            }
        } catch (e: Exception) {

        }
        val des = (scroll2_descrip.text.toString())
        val fix = (scroll2_fixed_price.text.toString())
        val from = (scroll2_price_from.text.toString())
        val to = (scroll2_price_to.text.toString())
        val img1n = fn1
        val img2n = sn1
        val img3n = tn1
        val img4n = fon1
        val img5n = fifn1
        val img1url = f1
        val img2url = s1
        val img3url = t1
        val img4url = fo1
        val img5url = fif1
        val img1nhigh = sn1high
        val img3nhigh = fn1high
        val img2nhigh = tn1high
        val img4nhigh = fon1high
        val img5nhigh = fifn1high
        val img1urlhigh = f1high
        val img2urlhigh = s1high
        val img3urlhigh = t1high
        val img4urlhigh = fo1high
        val img5urlhigh = fif1high
        val makeupitems=""

        val data = w(snm = sname, sid = sid, dur = sdur, sac = hsnT, sacdesc = hsndes, pr = pr, tx = Tax, igst = intax, cess = cess, cgst = Ctax, sgst = Stax, ttot = taxtot, ctot = css, gtot = Gtot, ecomm = payemp,
                ebns = paybonus, cry = currency, ptg = percentage, bval = per, gdr = gender, mctg = maincat, sctg = subcate, desc = des, fp = fix, fpr = from, tpr = to, status = status, img1n = img1n,
                img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url, img3url = img3url, img4url = img4url, img5url = img5url, img1nhigh = img1nhigh,
                img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh, img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)
        //if ((did.text.toString()).isEmpty()) {
        val isInserted = myDb.insertData(nid, sname, sid, sdur, hsnT, hsndes, pr, Tax, intax, cess, Ctax, Stax, taxtot, css, Gtot,
                payemp, paybonus, currency, percentage, per, gender, maincat, subcate, des, fix, from, to, status, img1n, img2n, img3n, img4n, img5n,
                img1url, img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,img1n,img2n,retdays,makeupitems)
        if (isInserted == true) {
            Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Data not Inserted", Toast.LENGTH_SHORT).show()
        }
        db.collection("service").document(newid2.text.toString())
                .set(data)
                .addOnSuccessListener {
                    Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                    scroll2_progress.visibility = android.view.View.GONE
                    /*val i=Intent(this@Scroll2_page,servicelistActivity::class.java)
                    i.putExtra("add",add)
                    i.putExtra("edite",edite)
                    i.putExtra("delete",delete)

                    startActivity(i)
                    finish()*/
                    pDialog.dismiss()
                    val t = Intent(this, servicelistActivity::class.java)
                    startActivity(t)
                    finish()
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                }
                .addOnFailureListener { Exception ->
                    //Toast.makeText(this, "not saved "+Exception.toString(), Toast.LENGTH_LONG).show()
                    //scroll2_progress.visibility = android.view.View.GONE
                }
    }

    override fun onBackPressed() {


        println("F1 VALUE" + f1)
        println("s1edit value" + f1edit)



        println("S1 VALUE" + s1)
        println("s1edit value" + s1edit)


        println("T1 VALUE" + t1)
        println("t1edit value" + t1edit)


        println("FO1 VALUE" + fo1)
        println("fofedit value" + fo1edit)


        println("FIF1 VALUE" + fif1)
        println("fif1edit value" + fif1edit)



        if ((sidss == "Auto-genereted") && ((f1.isNotEmpty()) || (s1.isNotEmpty()) || (t1.isNotEmpty()) || (fo1.isNotEmpty()) || (fif1.isNotEmpty()))) {

            println("INSIDE ONBACK")
            listenersave = "change"


        }

        if ((id2.text.isNotEmpty()) && ((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || (fo1 != fo1edit) || (fif1 != fif1edit))) {

            listenersave = "change"


        }

        if ((id2.text.isNotEmpty()) && (listenersave == "change")) {
            alert()
        } else if (((id2.text.isEmpty()) && (listenersave == "change"))) {
            alert()


        } else {
            val t = Intent(this@Scroll2_page, servicelistActivity::class.java)
            startActivity(t)
            finish()
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
        }
    }

    fun alert() {
        val builder = AlertDialog.Builder(this@Scroll2_page)
        with(builder) {
            setTitle("Save?")
            setMessage("Do you want to save?")


            // Dialog

            setPositiveButton("Yes") { dialog, whichButton ->

                dialog.dismiss()
                save()
            }


                    .setNegativeButton("No") { dialog, whichButton ->
                        //showMessage("Close the game or anything!")


                        println("F1 VALUE" + f1)
                        println("f1edit value" + f1edit)


                        if (newid2.text.toString().isNotEmpty()) {
                            println("true " + newid2.text.toString())
                            val del = ArrayList<String>()
                            val storage = FirebaseStorage.getInstance()
                            val storageRef = storage.getReference()
                            if (fn1.isEmpty() && sn1.isEmpty() && tn1.isEmpty() && fon1.isEmpty() && fifn1.isEmpty()) {
                                dialog.dismiss()
                                val t = Intent(applicationContext, servicelistActivity::class.java)
                                startActivity(t)
                                finish()
                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                            }
                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"
                            val k = fn1high
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            val file = File(dir, y)
                            if (fn1.isNotEmpty()) {
                                val k = fn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(fn1)
                                del.add(fn1high)
                            }
                            if (sn1.isNotEmpty()) {
                                val k = sn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(sn1)
                                del.add(sn1high)
                            }
                            if (tn1.isNotEmpty()) {
                                val k = tn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(tn1)
                                del.add(tn1high)
                            }
                            if (fon1.isNotEmpty()) {
                                val k = fon1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(fon1)
                                del.add(fon1high)
                            }
                            if (fifn1.isNotEmpty()) {
                                val k = fifn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(fifn1)
                                del.add(fifn1high)
                            }
                            if (del.size >= 0) {
                                for (i in del) {
                                    val imagesRef = storageRef.child("service").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {
                                                if (i == del.get(del.size - 1)) {
                                                    dialog.dismiss()
                                                    val t = Intent(applicationContext, servicelistActivity::class.java)
                                                    startActivity(t)
                                                    finish()
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);
                                                }
                                            }
                                            .addOnCompleteListener {
                                            }
                                }
                            }
                        } else if ((id2.text.isNotEmpty())) {
                            val delname = ArrayList<String>()
                            val delnameedit = ArrayList<String>()
                            val delnamehigh = ArrayList<String>()
                            val delnameedithigh = ArrayList<String>()
                            val delurl = ArrayList<String>()
                            val delurledit = ArrayList<String>()
                            val delurledithigh = ArrayList<String>()
                            val deldbnm = ArrayList<String>()
                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Service"
                            val k = fn1high
                            val recacnm = k.removeSuffix(".jpg")

                            var y = recacnm + ".png"
                            val dir = File(path);
                            if (fn1 != fn1edit) {
                                val k = fn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }

                                delname.add(fn1)
                                delnamehigh.add(fn1high)
                            }
                            if (sn1 != sn1edit) {
                                val k = sn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(sn1)
                                delnamehigh.add(sn1high)
                            }
                            if (tn1 != tn1edit) {
                                val k = tn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(tn1)
                                delnamehigh.add(tn1high)
                            }
                            if (fon1 != fon1edit) {
                                val k = fon1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fon1)
                                delnamehigh.add(fon1high)
                            }
                            if (fifn1 != fifn1edit) {
                                val k = fifn1high
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fifn1)
                                delnamehigh.add(fifn1high)
                            }


                            println("DELE NAME" + delname)
                            println("DELE NAME HIGH" + delnamehigh)


                            delurl.add(f1edit)
                            delnameedit.add(fn1edit)

                            delurledithigh.add(f1edithigh)
                            delnameedithigh.add(fn1edithigh)

                            dialog.dismiss()

                            val progressDialog = ProgressDialog(this@Scroll2_page);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);

                            deletedb()

                            if (delname.size >= 0) {
                                for (i in delname) {
                                    val storage = FirebaseStorage.getInstance()
                                    val storageRef = storage.getReference()

                                    val imagesRef = storageRef.child("service").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {

                                                if (i == delname.get(delname.size - 1)) {
                                                    for (i in delnamehigh) {
                                                        val imagesRef = storageRef.child("service").child(i)
                                                        imagesRef.delete()
                                                                .addOnSuccessListener {
                                                                    if (i == delnamehigh.get(delnamehigh.size - 1)) {

                                                                        progressDialog.dismiss()
                                                                        val t = Intent(applicationContext, servicelistActivity::class.java)
                                                                        startActivity(t)
                                                                        finish()
                                                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right);

                                                                    }

                                                                }
                                                    }
                                                }

                                            }
                                }


                            }
                        }
                    }
            val dialog = builder.create()

            dialog.show()
        }

    }


        fun deletedb() {

            if ((id2.text.isNotEmpty()) && (fn1 != fn1edit)) {
                db.collection("service").document(id2.text.toString())
                        .update("img1url", f1edit)
                        .addOnSuccessListener {
                            db.collection("service").document(id2.text.toString())
                                    .update("img1n", fn1edit)
                                    .addOnCompleteListener {
                                        db.collection("service").document(id2.text.toString())
                                                .update("img1urlhigh", f1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("service").document(id2.text.toString())
                                                            .update("img1nhigh", fn1edithigh)

                                                }
                                    }

                        }
            }
            if ((id2.text.isNotEmpty()) && (sn1 != sn1edit)) {

                db.collection("service").document(id2.text.toString())
                        .update("img2url", s1edit)
                        .addOnSuccessListener {
                            db.collection("service").document(id2.text.toString())
                                    .update("img2n", sn1edit)
                                    .addOnCompleteListener {
                                        db.collection("service").document(id2.text.toString())
                                                .update("img2urlhigh", s1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("service").document(id2.text.toString())
                                                            .update("img2nhigh", sn1edithigh)


                                                }
                                    }

                        }
            }
            if ((id2.text.isNotEmpty()) && (tn1 != tn1edit)) {
                db.collection("service").document(id2.text.toString())
                        .update("img3url", t1edit)
                        .addOnSuccessListener {
                            db.collection("service").document(id2.text.toString())
                                    .update("img3n", tn1edit)
                                    .addOnCompleteListener {
                                        db.collection("service").document(id2.text.toString())
                                                .update("img3urlhigh", t1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("service").document(id2.text.toString())
                                                            .update("img3nhigh", tn1edithigh)


                                                }
                                    }

                        }

            }
            if ((id2.text.isNotEmpty()) && (fon1 != fon1edit)) {
                db.collection("service").document(id2.text.toString())
                        .update("img4url", fo1edit)
                        .addOnSuccessListener {
                            db.collection("service").document(id2.text.toString())
                                    .update("img4n", fon1edit)
                                    .addOnCompleteListener {
                                        db.collection("service").document(id2.text.toString())
                                                .update("img4urlhigh", fo1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("service").document(id2.text.toString())
                                                            .update("img4nhigh", fon1edithigh)


                                                }
                                    }

                        }

            }
            if ((id2.text.isNotEmpty()) && (fifn1 != fifn1edit)) {
                db.collection("service").document(id2.text.toString())
                        .update("img5url", fif1edit)
                        .addOnSuccessListener {
                            db.collection("service").document(id2.text.toString())
                                    .update("img5n", fifn1edit)
                                    .addOnCompleteListener {
                                        db.collection("service").document(id2.text.toString())
                                                .update("img5urlhigh", fif1edithigh)
                                                .addOnSuccessListener {
                                                    db.collection("service").document(id2.text.toString())
                                                            .update("img5nhigh", fifn1edithigh)

                                                }
                                    }

                        }
            }
        }

    fun update(){
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
        pDialog.setTitleText("Saving...")
        pDialog.setCancelable(false);
        pDialog.show();
        val upid=id2.text.toString()
        val sname = (textView1.text).toString()
        val sid = (textView2.text.toString())
        val sdur = (textView3.text).toString()
        val hsnT = (textView4.text).toString()
        val hsndes = (textView5.text).toString()
        val pr = (textView6.text).toString()
        val Tax = (textView7.toString())
        val intax = (textView8.text).toString()
        val cess = (textView9.text).toString()
        val Ctax = (textView10.text).toString()
        val Stax = (textView11.text).toString()
        val taxtot = (textView12.text).toString()
        val css = (textView13.text).toString()
        val Gtot = (textView14.text).toString()
        val payemp = (textView15.toString())
        val paybonus = (textView16.toString())
        val currency = (textView17.toString())
        val percentage = (textView18.toString())
        val per = (textView19.text).toString()
        //val desc = (descrip.text).toString()
        val status = (textView20.text.toString())
        val gender = (scroll2_gender.selectedItem.toString())
        val maincat = (scroll2_category.selectedItem.toString())

        val retdays=""
        try {
            if (scroll2_sub_category.selectedItemPosition == 0) {

                subcate = ""
            } else {
                subcate = (scroll2_sub_category.selectedItem.toString())

            }
        }
        catch (e:Exception){

        }
        val des = (scroll2_descrip.text.toString())
        val fix=(scroll2_fixed_price.text.toString())
        val from=(scroll2_price_from.text.toString())
        val to = (scroll2_price_to.text.toString())
        val img1n=fn1
        val img2n=sn1
        val img3n=tn1
        val img4n=fon1
        val img5n=fifn1
        val img1url=f1
        val img2url=s1
        val img3url=t1
        val img4url=fo1
        val img5url=fif1

        val img1nhigh=sn1high
        val img3nhigh=fn1high
        val img2nhigh=tn1high
        val img4nhigh=fon1high
        val img5nhigh=fifn1high
        val img1urlhigh=f1high
        val img2urlhigh=s1high
        val img3urlhigh=t1high
        val img4urlhigh=fo1high
        val img5urlhigh=fif1high
        val makeupitems=""
        val data = w(snm = sname, sid = sid, dur = sdur, sac = hsnT, sacdesc = hsndes, pr = pr, tx = Tax, igst = intax, cess = cess, cgst = Ctax, sgst = Stax, ttot = taxtot, ctot = css, gtot = Gtot, ecomm = payemp, ebns = paybonus, cry = currency, ptg = percentage, bval = per, gdr = gender, mctg = maincat, sctg = subcate,
                desc = des, fp = fix, fpr = from, tpr = to, status = status, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url, img2url = img2url, img3url = img3url, img4url = img4url, img5url = img5url,img1nhigh = img1nhigh,
                img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh, img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh)
        //if ((did.text.toString()).isEmpty()) {

        if (textView1.text.isEmpty() || textView6.text.isEmpty()) {
            println("gender " + scroll2_gender.selectedItemPosition.toString())
            println("main " + scroll2_category.selectedItemPosition.toString())
            println("sub " + scroll2_sub_category.selectedItemPosition.toString())
            if (scroll2_gender.selectedItemPosition == 0){

            }
            if (scroll2_category.selectedItemPosition == 0){

            }
            if (scroll2_sub_category.selectedItemPosition == 0){

            }
            if (textView1.text.isEmpty()){
                sn_err="true"
            }
            if (textView6.text.isEmpty()){
                pr_err="true"
            }
            Toast.makeText(this, "please fill required fields!", Toast.LENGTH_LONG).show()
        } else if (textView1.text.isNotEmpty() && textView6.text.isNotEmpty()) {




                        if (newid2.text.isEmpty() && id2.text.isNotEmpty()) {
                            val isInserted = myDb.updateData(upid, sname, sid, sdur, hsnT, hsndes, pr, Tax, intax, cess, Ctax,
                                    Stax, taxtot, css, Gtot, payemp, paybonus, currency, percentage, per, gender, maincat, subcate, des,
                                    fix, from, to, status, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url, img5url,
                                    img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh,
                                    img5urlhigh,img1n,img2n,retdays,makeupitems)
                            if (isInserted == true){
                                Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show()
                                scroll2_progress.visibility = android.view.View.GONE}
                            else{
                                Toast.makeText(this, "Data not Inserted", Toast.LENGTH_SHORT).show()}
                            db.collection("service").document(id2.text.toString())
                                    .set(data)
                                    .addOnSuccessListener {
                                        //Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                        //scroll2_progress.visibility = android.view.View.GONE
                                        val t=Intent(this,servicelistActivity::class.java)
                                        startActivity(t)
                                        finish()
                                        overridePendingTransition( R.anim.slide_in_right, R.anim.slide_out_right);
                                    }
                                    .addOnFailureListener { Exception ->
                                        Toast.makeText(this, "not saved " + Exception.toString(), Toast.LENGTH_LONG).show()
                                        scroll2_progress.visibility = android.view.View.GONE
                                    }
                        }
                    else {
                        Toast.makeText(this@Scroll2_page, "please fill required fields!", Toast.LENGTH_LONG).show()
                        println("scroll2_price_to.text" + scroll2_price_to.text)
                    }
                } else {
                    Toast.makeText(this@Scroll2_page, "please fill required fields!", Toast.LENGTH_LONG).show()
                    println("scroll2_price_from.text" + scroll2_price_from.text)
                }




    }
    fun save(){

        if (textView1.text.isEmpty() || textView6.text.isEmpty()) {
            println("gender " + scroll2_gender.selectedItemPosition.toString())
            println("main " + scroll2_category.selectedItemPosition.toString())
            println("sub " + scroll2_sub_category.selectedItemPosition.toString())
            if (scroll2_gender.selectedItemPosition == 0){

            }
            if (scroll2_category.selectedItemPosition == 0){

            }
            if (scroll2_sub_category.selectedItemPosition == 0){

            }
            if (textView1.text.isEmpty()){
                sn_err="true"
            }
            if (textView6.text.isEmpty()){
                pr_err="true"
            }
            Toast.makeText(this, "please fill required fields!", Toast.LENGTH_LONG).show()
        } else if (textView1.text.isNotEmpty() && textView6.text.isNotEmpty()) {



                        if (newid2.text.isNotEmpty() && id2.text.isEmpty()) {
                            scroll2_save.isEnabled = false
                            scroll2_progress.visibility = android.view.View.VISIBLE

                        }
                    else if( id2.text.isNotEmpty()) {

                    }


                } else {
                    Toast.makeText(this@Scroll2_page, "please fill required fields!", Toast.LENGTH_LONG).show()
                    println("scroll2_price_from.text.isEmpty()&&scroll2_price_to.text.isEmpty()" + scroll2_price_from.text + "  " + scroll2_price_to.text)
                }

    }
    fun popup(st:String){
        SweetAlertDialog(this, SweetAlertDialog.ERROR_TYPE)
                .setTitleText("Access Denied!")
                .setContentText("You dont have Access to $st")
                .setConfirmText("ok")
                .setConfirmClickListener(null)
                .show()
        /*val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()*/
    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }


}

