package com.example.vinitas.netlistener.services

import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.os.Build
import android.support.annotation.RequiresApi
import android.util.Log
import com.example.vinitas.Makeup_items.Attachments_Activity
import com.example.vinitas.Makeup_items.Main_makeup
import com.example.vinitas.inventory_app.*

import com.example.vinitas.netlistener.utils.NetworkUtil


class NetworkChangeReceiver : BroadcastReceiver() {
    internal lateinit var mContext: Context

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onReceive(context: Context, intent: Intent) {
        mContext = context
        val status = NetworkUtil.getConnectivityStatusString(context)

        Log.e("Receiver ", "" + status)

        if (status == Constants.NOT_CONNECT) {
            Log.e("Receiver ", "not connection")// your code when internet lost


        } else {
            Log.e("Receiver ", "connected to internet")//your code when internet connection come back
        }
        try {
            ScrollStkOneActivity.addLogText(status)
        }
        catch (e:Exception){

        }
        try{
            AddImagesActivity_prod.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            PurchasePdfActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            MainActivity_pdf.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            MainReceivePdf.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            RequestActivityPdf.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            MainBranchPdf.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            MainPurchasefirstActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            AllbranchesActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            MybranchActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            Main_scroll_second.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            Main_makeup.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            WithStateActivity.addLogText(status)

        }
        catch (e:Exception){

        }


        try{
            SupplierListFirstMAin.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            StockTransferActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            SelectBranchActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            SupplierSecondmain.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            SupplierRequestActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            SuppSelectActivity.addLogText(status)

        }
        catch (e:Exception){

        }


        try{
            Supplier_first_MainActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            supplierFiveMainAct.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            MainSecondSupplier_secondActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            AddImagesActivity_services.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            RequestBottproActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            ReceiveActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            RequestUpdateActivity.addLogText(status)

        }
        catch (e:Exception){

        }


        try{
            PurchaseRequestActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            AddImagesActivity_supp.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            AddImagesActivity_product.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            MainActivityScroll.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            MainProductlistActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            SuppProductAddActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
           ScrollActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            Attachments_Activity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            RequestAddActivity.addLogText(status)

        }
        catch (e:Exception){

        }


        try{
            PurcathirdMainActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            MainPurchaselist_secondActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            Purchase_orderMainActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            Supplier_thirdMainActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            Mainstk_branch_one.addLogText(status)

        }
        catch (e:Exception){

        }


        try{
            Mainstk_branch_two.addLogText(status)

        }
        catch (e:Exception){

        }





        try{
            SupplierAddMain.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            PinActivity.addLogText(status)

        }
        catch (e:Exception){

        }
        try{
            servicelistActivity.addLogText(status)

        }
        catch (e:Exception){

        }

        try{
            MainActivity.addLogText(status)

        }
        catch (e:Exception){

        }


    }
}