package com.example.vinitas.inventory_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;



/**
 * Created by vinitas stock on 28-02-2018.
 */

public class Databasehelper_service extends SQLiteOpenHelper {

     int count;
     public static String key;

    public boolean givedata(String brkey){

        key="service_"+brkey;


        System.out.println("KEY VAL HELPER"+key);

        return true;
    }
    private static final String DATABASE_NAME = "service.db";//database name
    private static final String TABLE_NAME = "service";//TAble name


    private static final String s="^[a-zA-Z ]+$";

    private static final String re="^[0-9]*$";

    public Databasehelper_service(Context context) {
        super(context, DATABASE_NAME, null, 1); }

    @Override
    public void onCreate(SQLiteDatabase db) {//Create table
        db.execSQL("create table " + TABLE_NAME +" (id TEXT PRIMARY KEY,snm TEXT,sid TEXT,dur TEXT,sac TEXT,sacdesc TEXT,pr TEXT,tx TEXT,igst TEXT,cess TEXT,cgst TEXT,sgst TEXT,ttot TEXT,ctot TEXT,gtot TEXT,ecomm TEXT,ebns TEXT,cry TEXT,ptg TEXT,bval TEXT,gdr TEXT,mctg TEXT,sctg TEXT,descr TEXT,fp TEXT,fpr TEXT,tpr TEXT,status TEXT,img1n TEXT,img2n TEXT,img3n TEXT,img4n TEXT,img5n TEXT,img1url TEXT,img2url TEXT,img3url TEXT,img4url TEXT,img5url TEXT,img1nhigh TEXT,img2nhigh TEXT,img3nhigh TEXT,img4nhigh TEXT,img5nhigh TEXT,img1urlhigh TEXT,img2urlhigh TEXT,img3urlhigh TEXT,img4urlhigh TEXT,img5urlhigh TEXT,mcategky TEXT,scategky TEXT,retdate TEXT,makeupitem TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    //Insert service details

    public boolean insertData(String id,String snm,String sid,String dur,String sac,String sacdesc,String pr,String tx,String igst,String cess,String cgst,String sgst,String ttot,String ctot,String gtot,String ecomm,String ebns,String cry,String ptg,String bval,String gdr,String mctg,String sctg,String desc,String fp,String fpr,String tpr,String status,String img1n,String img2n,String img3n,String img4n,String img5n,String img1url,String img2url,String img3url,String img4url,String img5url,String img1nhigh,String img2nhigh,String img3nhigh,String img4nhigh,String img5nhigh,String img1urlhigh,String img2urlhigh,String img3urlhigh,String img4urlhigh,String img5urlhigh,String mcategky,String scategky,String retdate,String makeupitem) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id",id );//0
        contentValues.put("snm",snm );//1
        contentValues.put("sid",sid );//2
        contentValues.put("dur",dur);//3
        contentValues.put("sac",sac);//4
        contentValues.put("sacdesc",sacdesc);//5
        contentValues.put("pr",pr);//6
        contentValues.put("tx",tx  );//7
        contentValues.put("igst",igst );//8
        contentValues.put("cess",cess  );//9
        contentValues.put("cgst",cgst);//10
        contentValues.put("sgst",sgst);//11
        contentValues.put("ttot",ttot);//12
        contentValues.put("ctot",ctot);//13
        contentValues.put("gtot",gtot);//14
        contentValues.put("ecomm",ecomm);//15
        contentValues.put("ebns",ebns);//16
        contentValues.put("cry",cry);//17
        contentValues.put("ptg",ptg);//18
        contentValues.put("bval",bval);//19
        contentValues.put("gdr",gdr);//20
        contentValues.put("mctg",mctg);//21
        contentValues.put("sctg",sctg);//22
        contentValues.put("descr",desc);//23
        contentValues.put("fp",fp);//24
        contentValues.put("fpr",fpr);//25
        contentValues.put("tpr",tpr);//26
        contentValues.put("status",status);//27
        contentValues.put("img1n",img1n);//28
        contentValues.put("img2n",img2n);//29
        contentValues.put("img3n",img3n);//30

        contentValues.put("img4n",img4n);//31
        contentValues.put("img5n",img5n);//32
        contentValues.put("img1url",img1url);//33
        contentValues.put("img2url",img2url);//34
        contentValues.put("img3url",img3url);//35
        contentValues.put("img4url",img4url);//36
        contentValues.put("img5url",img5url);//37
        contentValues.put("img1nhigh",img1nhigh);//38
        contentValues.put("img2nhigh",img2nhigh);//39
        contentValues.put("img3nhigh",img3nhigh);//40
        contentValues.put("img4nhigh",img4nhigh);//41
        contentValues.put("img5nhigh",img5nhigh);//42
        contentValues.put("img1urlhigh",img1urlhigh);//43
        contentValues.put("img2urlhigh",img2urlhigh);//44
        contentValues.put("img3urlhigh",img3urlhigh);//45
        contentValues.put("img4urlhigh",img4urlhigh);//46
        contentValues.put("img5urlhigh",img5urlhigh);//47
        contentValues.put("mcategky",mcategky);//48
        contentValues.put("scategky",scategky);//49
        contentValues.put("retdate",retdate);//50
        contentValues.put("makeupitem",makeupitem);//51


        System.out.println("KEY VAL HELPER NAME INSERT"+TABLE_NAME);
        long result = db.insert(TABLE_NAME,null ,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData() {
        //Get all datas from table

        System.out.println("KEY VAL HELPER NAME GETDAT"+key);
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME+" ORDER BY status ASC " ,null);

        return res;
    }

    public boolean checkIfRecordExist(String COL_2)//Check if record already exists
    {
        try
        {
            System.out.println("KEY VAL HELPER NAME CHECKIF"+key);
            SQLiteDatabase db=this.getReadableDatabase();
            Cursor cursor=db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE id ='"+COL_2+"'",null);
            if (cursor.moveToFirst())
            {
                db.close();
                Log.d("Record  Already Exists", "Table is:"+key+" ColumnName:"+COL_2);
                return true;//record Exists

            }
            Log.d("New Record  ", "Table is:"+key+" ColumnName:"+COL_2+" Column Value:"+COL_2);
            db.close();
        }
        catch(Exception errorException)
        {
            Log.d("Exception occured", "Exception occured "+errorException);
            // db.close();
        }
        return false;
    }
    public int getNotesCount() {//Check counts of datas
        try {
            System.out.println("KEY VAL HELPER NAME COUNT"+key);
            String countQuery = "SELECT  * FROM " + TABLE_NAME;
            SQLiteDatabase db = this.getReadableDatabase();
            Cursor cursor = db.rawQuery(countQuery, null);

            count = cursor.getCount();
            cursor.close();


            // return count

        }
        catch (Exception e){

        }
        return count;
    }

    //Update Service details

    public boolean updateData(String id,String snm,String sid,String dur,String sac,
                              String sacdesc,String pr,String tx,String igst,String cess,String cgst,
                              String sgst,String ttot,String ctot,String gtot,String ecomm,String ebns,
                              String cry,String ptg,String bval,String gdr,String mctg,String sctg,String desc,
                              String fp,String fpr,String tpr,String status,String img1n,String img2n,String img3n,
                              String img4n,String img5n,String img1url,String img2url,String img3url,String img4url,
                              String img5url,String img1nhigh,String img2nhigh,String img3nhigh,String img4nhigh,
                              String img5nhigh,String img1urlhigh,String img2urlhigh,String img3urlhigh,
                              String img4urlhigh,String img5urlhigh,String mcategky,String scategky,String retdate,String makeupitem) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id",id );
        contentValues.put("snm",snm );
        contentValues.put("sid",sid );
        contentValues.put("dur",dur);
        contentValues.put("sac",sac);
        contentValues.put("sacdesc",sacdesc);
        contentValues.put("pr",pr);
        contentValues.put("tx",tx);
        contentValues.put("igst",igst);
        contentValues.put("cess",cess);
        contentValues.put("cgst",cgst);
        contentValues.put("sgst",sgst);
        contentValues.put("ttot",ttot);
        contentValues.put("ctot",ctot);
        contentValues.put("gtot",gtot);
        contentValues.put("ecomm",ecomm);
        contentValues.put("ebns",ebns);
        contentValues.put("cry",cry);
        contentValues.put("ptg",ptg);
        contentValues.put("bval",bval);
        contentValues.put("gdr",gdr);
        contentValues.put("mctg",mctg);
        contentValues.put("sctg",sctg);
        contentValues.put("descr",desc);
        contentValues.put("fp",fp);
        contentValues.put("fpr",fpr);
        contentValues.put("tpr",tpr);
        contentValues.put("status",status);
        contentValues.put("img1n",img1n);
        contentValues.put("img2n",img2n);
        contentValues.put("img3n",img3n);
        contentValues.put("img4n",img4n);
        contentValues.put("img5n",img5n);
        contentValues.put("img1url",img1url);
        contentValues.put("img2url",img2url);
        contentValues.put("img3url",img3url);
        contentValues.put("img4url",img4url);
        contentValues.put("img5url",img5url);
        contentValues.put("img1nhigh",img1nhigh);
        contentValues.put("img2nhigh",img2nhigh);
        contentValues.put("img3nhigh",img3nhigh);
        contentValues.put("img4nhigh",img4nhigh);
        contentValues.put("img5nhigh",img5nhigh);
        contentValues.put("img1urlhigh",img1urlhigh);
        contentValues.put("img2urlhigh",img2urlhigh);
        contentValues.put("img3urlhigh",img3urlhigh);
        contentValues.put("img4urlhigh",img4urlhigh);
        contentValues.put("img5urlhigh",img5urlhigh);
        contentValues.put("mcategky",mcategky);
        contentValues.put("scategky",scategky);
        contentValues.put("retdate",retdate);
        contentValues.put("makeupitem",makeupitem);


        db.update(TABLE_NAME, contentValues, "id = ?",new String[] { id });
        return true;
    }
    public void deleteall(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("delete from "+ TABLE_NAME);
    }


    public Integer deleteData (String id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, "id = ?",new String[] {id});
    }
    public Cursor retrieve(String searchTerm)//Retreive details of the services by search terms
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c=null;

        if((searchTerm != null)&&(searchTerm.length()>0))
        {
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"snm"+" LIKE '%"+searchTerm+"%'";
            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE snm LIKE '%"+searchTerm+"%' OR gtot LIKE '%"+searchTerm+"%' OR mctg LIKE '%"+searchTerm+"%' OR sctg LIKE '%"+searchTerm+"%' OR dur LIKE '%"+searchTerm+"%'",null);
            return c;

        }


        c=db.query(TABLE_NAME,null,null,null,null,null,null);
        return c;
    }

    public Cursor retrieves(String namcomp)//Retreive details of the services by search terms
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c=null;



            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"snm"+" LIKE '%"+namcomp+"%'";
            try {
                c = db.rawQuery("select * from " + TABLE_NAME + " WHERE snm LIKE '%" + namcomp + "%' OR pr LIKE '%" + namcomp + "%'", null);

            }
            catch (Exception e){

            }
        return c;


    }

    public Cursor getOne(String idd){//Get data by id
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c=null;
        String query = "SELECT * FROM "+TABLE_NAME+" WHERE id = ?" +idd;
        if (idd != null && idd.length()>0) {
            String sql="SELECT * FROM "+TABLE_NAME+" WHERE "+"snm"+" LIKE '%"+idd+"%'";
            c=db.rawQuery("select * from "+TABLE_NAME+" WHERE id LIKE '%"+idd+"%'",null);
            return c;
            /*c=db.rawQuery("select * from "+TABLE_NAME+" where id = "+idd,null);
            //c = db.rawQuery("SELECT * FROM "+TABLE_NAME+" WHERE id = "+idd,null);
            return c;*/
        }
        c=db.query(TABLE_NAME,null,null,null,null,null,null);
        return c;
    }

}