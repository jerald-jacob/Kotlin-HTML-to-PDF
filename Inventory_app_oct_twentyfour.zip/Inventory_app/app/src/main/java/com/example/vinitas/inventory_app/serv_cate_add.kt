package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.android.gms.tasks.OnFailureListener
import com.google.android.gms.tasks.OnSuccessListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.UploadTask
import com.vansuita.pickimage.bean.PickResult
import com.vansuita.pickimage.bundle.PickSetup
import com.vansuita.pickimage.dialog.PickImageDialog
import com.vansuita.pickimage.listeners.IPickResult
import kotlinx.android.synthetic.main.serv_cate_add.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URL
import java.util.*

class serv_cate_add : AppCompatActivity(), IPickResult {
    var db = FirebaseFirestore.getInstance()
    var TAG = "tag"
    lateinit var key :String
    data class s(var cat: String,var ur: String,var imgname: String)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.serv_cate_add)


        net_status()

        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        sc_add_back.setOnClickListener {
            finish()
        }
        val getid = intent.getStringExtra("id")
        sc_add_get_id.setText(getid)
        if(sc_add_get_id.text.isEmpty()) {
            val k = db.collection("servicecategory").document().id
            key = k
            println(" if   "+key)
        }else if (sc_add_get_id.text.isNotEmpty()){
            key = sc_add_get_id.text.toString()
            sc_add_save.visibility=View.GONE
            sc_add_edit.visibility=View.VISIBLE
            sc_add_name.isEnabled=false
            sc_add_card.isEnabled=false

            println("else if     "+key)
            db.collection("servicecategory").document(key)
                    .get()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            if (task.result != null) {
                                Log.d("data", "is" + task.result.data)
                                sc_add_name.setText(task.result.get("cat").toString())
                                imgname.setText(task.result.get("imgname").toString())
                                imguri.setText(task.result.get("ur").toString())
                                sc_add_cam_back.visibility=View.GONE
                                sc_add_camera.visibility=View.GONE
                                val newurl = URL(task.result.get("ur").toString()).openStream()
                                println(newurl)
                                val img = BitmapFactory.decodeStream(newurl)
                                sc_add_card.setImageBitmap(img)
                            } else {
                                Log.d("data", "is not here")
                            }
                        } else {
                            Log.d("task is not success", "full" + task.exception)
                        }
                    }

        }
        sc_add_edit.setOnClickListener {
            sc_add_save.visibility=View.VISIBLE
            sc_add_edit.visibility=View.GONE
            sc_add_name.isEnabled=true
            sc_add_card.isEnabled=true

        }
        sc_add_subcate.setOnClickListener {
            println(key)
            val b = Intent(applicationContext, serv_sub_category_list::class.java)
            b.putExtra("key",key)
            startActivity(b)
        }
        sc_add_save.setOnClickListener {
            if (sc_add_name.text.isNotEmpty() == true&& imguri.text.isNotEmpty()==true&&imgname.text.isNotEmpty()==true) {
                val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                pDialog.setTitleText("Saving...")
                pDialog.setCancelable(false)
                pDialog.show();
                val cate = sc_add_name.text.toString()
                val ur = imguri.text.toString()
                val name = imgname.text.toString()
                val data = s(cat = cate,ur =ur,imgname = name)
                //if ((did.text.toString()).isEmpty()) {
                //progress.visibility = View.VISIBLE
                sc_add_save.isEnabled = false
                println(data)
                db.collection("servicecategory").document(key)
                        .set(data)
                        .addOnSuccessListener {
                            Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                            pDialog.dismiss()
                            finish()
                        }
                        .addOnFailureListener {
                            Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                        }
            } else {
                Toast.makeText(this, "Nothing saved", Toast.LENGTH_LONG).show()
            }
        }
        sc_add_camera.setOnClickListener {
            sc_add_cam_back.visibility=View.GONE
            sc_add_camera.visibility=View.GONE
            if (imgname.text.isEmpty()) {
                PickImageDialog.build(PickSetup()).show(this@serv_cate_add)
            }else{
                val storage = FirebaseStorage.getInstance()
                val storageRef = storage.getReference()
                val imagesRef = storageRef.child(imgname.text.toString())
                imagesRef.delete()
                        .addOnSuccessListener {
                           imgname.setText("")
                            imguri.setText("")
                            PickImageDialog.build(PickSetup()).show(this@serv_cate_add)
                        }
            }
        }
        sc_add_card.setOnClickListener {
            sc_add_cam_back.visibility=View.GONE
            sc_add_camera.visibility=View.GONE
            if (imgname.text.isEmpty()) {
                PickImageDialog.build(PickSetup()).show(this@serv_cate_add)
            }else{
                val storage = FirebaseStorage.getInstance()
                val storageRef = storage.getReference()
                val imagesRef = storageRef.child(imgname.text.toString())
                imagesRef.delete()
                        .addOnSuccessListener {
                            imgname.setText("")
                            imguri.setText("")
                            PickImageDialog.build(PickSetup()).show(this@serv_cate_add)
                        }
            }
        }
    }
    override fun onBackPressed() {
        if (sc_add_get_id.text.isEmpty()) {
            if (sc_add_name.text.isEmpty() == true && imguri.text.isEmpty() == true && imgname.text.isEmpty() == true) {
                println(key)
                val sub = key+"_subcategory"
                db.collection(sub)
                        .get()
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                Log.d(TAG,"cleared")
                                Log.d(TAG,"cleared"+task.result)
                                Log.d(TAG,"cleared"+taskId)
                                Log.d(TAG,"cleared"+task.exception)
                                if (task.exception == null){
                                    finish()
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                }
                                for (document in task.result) {
                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                    val dd = document.data
                                    val img = dd["imgname"].toString()
                                    val storage = FirebaseStorage.getInstance()
                                    val storageRef = storage.getReference()
                                    val imagesRef = storageRef.child(img)
                                    imagesRef.delete()
                                            .addOnSuccessListener {
                                                println("..........................deleted.......................")
                                                db.collection(sub).document(document.id)
                                                        .delete()
                                                        .addOnSuccessListener {
                                                            println(document.id)
                                                        }
                                                finish()
                                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                                            }
                                }
                            } else {
                                Log.w(TAG, "Error getting documents.", task.exception)
                            }
                        }
            }else{
                val alert = AlertDialog.Builder(this@serv_cate_add)
                val inflater = this.layoutInflater
                val dialog = alert.create()
                dialog.setView(inflater.inflate(R.layout.sc_popup,null))
                dialog.show()
                val ok = dialog.findViewById<Button>(R.id.serv_ok) as Button
                val cancel = dialog.findViewById<Button>(R.id.serv_cancel) as Button
                ok.setOnClickListener {
                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
                    pDialog.setTitleText("Saving...")
                    pDialog.setCancelable(false)
                    pDialog.show();
                    val cate = sc_add_name.text.toString()
                    val ur = imguri.text.toString()
                    val name = imgname.text.toString()
                    val data = s(cat = cate,ur =ur,imgname = name)
                    //if ((did.text.toString()).isEmpty()) {
                    //progress.visibility = View.VISIBLE
                    sc_add_save.isEnabled = false
                    println(data)
                    db.collection("servicecategory").document(key)
                            .set(data)
                            .addOnSuccessListener {
                                Toast.makeText(this, "data is saved", Toast.LENGTH_LONG).show()
                                dialog.hide()
                                finish()
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)

                            }
                            .addOnFailureListener {
                                Toast.makeText(this, "not saved", Toast.LENGTH_LONG).show()
                            }
                }
                cancel.setOnClickListener {
                    dialog.hide()
                }
            }
        }else {
            return finish()
        }

    }
    override fun onPickResult(r: PickResult) {

        if (r.error == null) {
            sc_add_card.setImageBitmap(r.bitmap)
            val storage = FirebaseStorage.getInstance()
            val storageRef = storage.getReference()
            val generator = Random()
            var n = 1000
            n = generator.nextInt(n)
            val imname = "ourimages-$n.jpg"
            val imagesRef = storageRef.child(imname)
            sc_add_card.isDrawingCacheEnabled = true
            sc_add_card.buildDrawingCache()
            val bitmap = sc_add_card.drawingCache
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
            val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialog.setTitleText("Loading...")
            pDialog.setCancelable(false)
            pDialog.show();

            sc_add_cam_back.visibility=View.GONE
            val data = baos.toByteArray()
            val uploadTask = imagesRef.putBytes(data)
            uploadTask.addOnFailureListener(OnFailureListener {}).addOnSuccessListener(OnSuccessListener<UploadTask.TaskSnapshot> { taskSnapshot ->
                pDialog.dismiss();
                val ur = taskSnapshot.downloadUrl
                imguri.text = ur.toString()
                imgname.text = imname
                Toast.makeText(applicationContext, "URL :" + Uri.PARCELABLE_WRITE_RETURN_VALUE, Toast.LENGTH_SHORT).show()
                val localFile: File = File.createTempFile("images21", "jpg")
                // taskSnapshot.getMetadata() contains file metadata such as size, content-type, and download URL.
                val downloadUrl = taskSnapshot.downloadUrl

            })
            uploadTask.addOnProgressListener { taskSnapshot -> }.addOnPausedListener { println("Upload is paused") }
            //Image path
            r.getPath();
        } else {
            //Handle possible errors
            //TODO: do what you have to do with r.getError();
            Toast.makeText(this, r.error.message, Toast.LENGTH_LONG).show()
        }
        // Reference to an image file in Firebase Storage


    }
    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }
}
