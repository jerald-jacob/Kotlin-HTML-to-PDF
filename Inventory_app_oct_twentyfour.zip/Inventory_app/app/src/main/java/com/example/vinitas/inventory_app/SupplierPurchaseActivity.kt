package com.example.vinitas.inventory_app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_supplier_request.*

class SupplierPurchaseActivity : AppCompatActivity() {
    val db = FirebaseFirestore.getInstance()
    val TAG = "some"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_supplier_request)

        net_status()

        var snameArray = arrayOf<String>()
        var sphoneArray = arrayOf<String>()
        var slocArray = arrayOf<String>()
        var sstateArray = arrayOf<String>()
        var sgstArray = arrayOf<String>()
        var sadd1 = arrayOf<String>()
        var sadd2 = arrayOf<String>()
        var sadd3 = arrayOf<String>()
        var idArray = arrayOf<String>()
        var statusArray=arrayOf<String>()
        var imgArray=arrayOf<String>()
        var icohighArray = arrayOf<String>()
        var icohighnmArray = arrayOf<String>()
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();
        db.collection("suppliers")
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG,"cleared")
                        for (document in task.result) {
                            Log.d(TAG, "dapet" + document.id + " => " + document.data)
                            val dd = document.data
                            var id = document.id

                            snameArray=snameArray.plusElement(dd["spnm"].toString())
                            sphoneArray=sphoneArray.plusElement(dd["spmob1"].toString())
                            slocArray=slocArray.plusElement(dd["spcity"].toString())
                            idArray=idArray.plusElement(id)
                            sstateArray=sstateArray.plusElement(dd["spstate"].toString())
                            sgstArray=sgstArray.plusElement(dd["spgst"].toString())
                            sadd1=sadd1.plusElement(dd["spaddress1"].toString())
                            sadd2=sadd2.plusElement(dd["spaddress2"].toString())
                            sadd3=sadd3.plusElement(dd["spaddress3"].toString())
                            statusArray=statusArray.plusElement(dd["status"].toString())

                            icohighnmArray =icohighnmArray.plusElement(dd["img1nhigh"].toString());//23
                            icohighArray=icohighArray.plusElement(dd["img1urlhigh"].toString());//28


                            try {
                                var im = dd["img1url"].toString()
                                if (im.isNotEmpty()) {

                                    imgArray = imgArray.plusElement(im)
                                } else {
                                    imgArray =imgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                }
                            }
                            catch (e:Exception){

                            }



                        }
                        pDialog.dismiss()
                        val whatever = request_supp_adap(this,sadd1,sadd2,sadd2,sgstArray,sstateArray,idArray,statusArray,snameArray,
                                slocArray,sphoneArray,imgArray,icohighnmArray, icohighArray)
                        pur_supplier_list.adapter = whatever


                    } else {
                        Log.w(TAG, "Error getting documents.", task.exception)
                    }
                }








        pur_supplier_list.setOnItemClickListener { parent, view, position, id ->

            val k=Intent(this@SupplierPurchaseActivity,PurcathirdMainActivity::class.java)
            k.putExtra("from_pur","from_suppadd")
            k.putExtra("name",snameArray[position])
            k.putExtra("mobile",sphoneArray[position])
            k.putExtra("city",slocArray[position])
            k.putExtra("state",sstateArray[position])
            k.putExtra("gst",sgstArray[position])
            k.putExtra("addre1",sadd1[position])
            k.putExtra("addre2",sadd2[position])
            k.putExtra("addre3",sadd3[position])
            k.putExtra("imglink",imgArray[position])
            startActivity(k)


        }
        product_list_back_btn.setOnClickListener {

            finish()
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        }

    }

    override fun onBackPressed() {
       finish()
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
    }

    fun net_status():Boolean{
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
