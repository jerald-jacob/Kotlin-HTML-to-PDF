package com.example.vinitas.inventory_app

import android.Manifest
import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.net.Uri
import android.os.*
import android.support.v7.app.AppCompatActivity
import android.provider.Settings
import android.provider.Settings.Global.AIRPLANE_MODE_ON
import android.support.constraint.ConstraintLayout
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.widget.*
import cn.pedant.SweetAlert.SweetAlertDialog
import com.daimajia.slider.library.Animations.DescriptionAnimation
import com.daimajia.slider.library.SliderLayout
import com.daimajia.slider.library.SliderTypes.BaseSliderView
import com.daimajia.slider.library.SliderTypes.TextSliderView
import com.example.vinitas.Makeup_items.Main_makeup
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.android.gms.vision.barcode.Barcode
import com.google.firebase.FirebaseException
import com.google.firebase.database.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import kotlinx.android.synthetic.main.activity_main_scroll.*
import kotlinx.android.synthetic.main.activity_setdefault.view.*
import java.io.File

import java.net.URL
import java.text.DecimalFormat
import java.util.*


class MainActivityScroll : AppCompatActivity(),  BaseSliderView.OnSliderClickListener {


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null


    val EXTRA_DATA = "EXTRA_DATA"


    var protypesave=String()


    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }
    internal lateinit var myDb: Databasehelper

    //image url's
    var f1:String=""
    var s1:String=""
    var t1:String=""
    var fo1:String=""
    var fif1:String=""

    //image name's
    var fn1:String=""
    var sn1:String=""
    var tn1:String=""
    var fon1:String=""
    var fifn1:String=""


    //image url's
    var f1edit:String=""
    var s1edit:String=""
    var t1edit:String=""
    var fo1edit:String=""
    var fif1edit:String=""
    //image name's
    var fn1edit:String=""
    var sn1edit:String=""
    var tn1edit:String=""
    var fon1edit:String=""
    var fifn1edit:String=""


    var img1urlhigh:String=""
    var img2urlhigh:String=""
    var img3urlhigh:String=""
    var img4urlhigh:String=""
    var img5urlhigh:String=""
    //image name's
    var img1nhigh:String=""
    var img2nhigh:String=""
    var img3nhigh:String=""
    var img4nhigh:String=""
    var img5nhigh:String=""



    var f1edithigh:String=""
    var s1edithigh:String=""
    var t1edithigh:String=""
    var fo1edithigh:String=""
    var fif1edithigh:String=""
    //image name's
    var fn1edithigh:String=""
    var sn1edithigh:String=""
    var tn1edithigh:String=""
    var fon1edithigh:String=""
    var fifn1edithigh:String=""

    var imgurls= String()
    //product

    var makeupitemstr=String()
    private var addpro: String=""
    private var stockin_hand= String()
    private var editepro:String=""
    private var deletepro:String=""
    private var viewpro:String=""
    private var importpro:String=""
    private var exportpro:String=""


    var suppcome=""
    var suppky=""
    var suppname=""
    var cntpri:Int=0
    var cntnm:Int=0
    var cntcess:Int=0
    var cntigst:Int=0
    var cntvol:Int=0
    var cnthsc:Int=0
    var cnthscdes:Int=0
    var cntsoh:Int=0
    var cntmx:Int=0
    var cntmin:Int=0



    var prosave_key = arrayOf<String>()

    var pnamevalidate=String()
    var pidvalidate=String()
    var volvalidate=String()
    var bcodeidvalidate=String()
    var hscvalidate=String()
    var hscdesvalidate=String()
    var maincatvalidate="Select"
    var subcatvalidate="Select"
    var listvalidate="Select"
    var pricevalidate=String()
    var taxcheckvalidate="false"
    var intgstvalidate=String()
    var centgstvalidate=String()
    var stategstvalidate=String()
    var taxtotvalidate=String()
    var cessvaluevalidate=String()
    var mrpvalidate=String()
    var checkcommisionvalidate="false"
    var checkbonusvalidate="false"
    var retailvalidate="false"
    var backbarvalidate="false"
    var returnablevalidate="false"

    var currencyradiovalidate=String()
    var percenradiovalidate=String()
    var percentagevalvalidate=String()
    var maxstockvalidate=String()
    var minstockvalidate=String()
    var des_boxvalidate=String()
    var stockhandvalidate=String()

    var mresultsarr= arrayListOf<String>()
    var cacnm1= String()
    var imlistener= String()
    var brnchkeys=arrayListOf<String>()

    var stkhand=String()



    var editcli=String()

    var cnts:Int=0
    var TAG = "some"
    var auto_id=String
    var branchky= String()
    var brkey= String()
    var savefb= String()
    var saveupfb= String()
    var cesscal:Float=0.0F
    var db = FirebaseFirestore.getInstance()


    var dup= String()
    var listListener= String()

    var commonlisteners= String()

    var file_maps = arrayListOf<String>()

    data class s(

            var p_nm: String,
            var p_id: Any,
            var bc: Any,
            var wg_vol: Any,
            var ut: String,
            var ctgy: String,
            var mfr: String,
            var hsn: Any,
            var desc: Any,
            var price: Any,
            var taxchk: Any,
            var igst: Any,
            var cgst: Any,
            var sgst: Any,
            var cess: Any,
            var taxtot: Any,
            var cesstot: Any,
            var mrp: Any,
            var stock_hand: String,
            var min_stk: Any,
            var mx_stk: Any,
            var emp_com: String,
            var cn_sold: String,
            var curency: Any,
            var status:String,
            var percentage: Any,
            var retail:Any,
            var backbar:Any,
            var returnable:Any,
            var returnableday:Any,
            var percentageval: Any,
            var product_desc: Any,
            var protype:Any,
            var makeupitem:Any,

            var supp_key:Any,
            var supp_name:Any,
            var img1n:Any,
            var img2n:Any,
            var img3n:Any,
            var img4n:Any,
            var img5n:Any,
            var img1url:Any,
            var img2url:Any,
            var img3url:Any,
            var img4url:Any,
            var img5url:Any,


            var img1nhigh:String,     //image 1 name
            var img2nhigh:String,     //image 2 name
            var img3nhigh:String,     //image 3 name
            var img4nhigh:String,     //image 4 name
            var img5nhigh:String,     //image 5 name
            var img1urlhigh:String,     //image 1 url
            var img2urlhigh:String,     //image 2 url
            var img3urlhigh:String,     //image 3 url
            var img4urlhigh:String,     //image 4 url
            var img5urlhigh:String,     //image 5 url


            var orikys:Any
    )
    data class k(
            var status:String
    )
var froms= String()
var listcome= String()
    var comepro= String()
    var maincatId = ArrayList<String>()
    override fun onSliderClick(slider: BaseSliderView?)
    {
        //Toast.makeText(this, slider!!.getBundle().get("extra") + "",Toast.LENGTH_SHORT).show();
    }
    var d = arrayListOf<String>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_scroll)



        net_status()//Check net status

//Listens internet changing movements
        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@MainActivityScroll) > 0)
        {

        }
        else{

        }


        //Define No connection view when inetrnet connection is off and other views.

        relativeslayoutdis=findViewById(R.id.relativeslayout)
        consermaindis=findViewById(R.id.container)
        constraintLayout3dis=findViewById(R.id.constraintLayout3)
        scroll2_sliderdis=findViewById(R.id.scroll2_slider)
        scroll2_slider2dis=findViewById(R.id.scroll2_slider2)
        gallerydis=findViewById(R.id.gallery)
        editdis=findViewById(R.id.edit)
            addLogText(NetworkUtil.getConnectivityStatusString(this@MainActivityScroll))


        db.collection("branch")
                .get()
                .addOnCompleteListener { task ->

                        if (task.result != null) {
                            for (document in task.result) {

                                var brid=document.id
                                brnchkeys.add(brid)//Add all branches to 'brnchkeys' array

                            }
                            }
                }




        userback.setOnClickListener {

           onBackPressed()//finish back action

        }


        try {
            commonlisteners = intent.getStringExtra("listenersave")
        } catch (e: Exception) {
        }

        try {
            mresultsarr = intent.getStringArrayListExtra("mresult")
        } catch (e: Exception) {

        }
        try {
            cacnm1 = intent.getStringExtra("cacnm1")
        } catch (e: Exception) {

        }




        println("BR KEY"+brkey)


        val maincat=ArrayList<String>()
        val adp1 = ArrayAdapter(this@MainActivityScroll, R.layout.spinner_view,maincat)//Category/Group adapter
        adp1.setDropDownViewResource(R.layout.spinner_view)

        val list=ArrayList<String>()
        val dataAdapter = ArrayAdapter(this@MainActivityScroll, R.layout.spinner_view,list)//Unit measure adapter
        dataAdapter.setDropDownViewResource(R.layout.spinner_view)

        val subcat = ArrayList<String>()
        val adp2 = ArrayAdapter(this@MainActivityScroll, R.layout.spinner_view,subcat)//Manufacturer adapter
        adp2.setDropDownViewResource(R.layout.spinner_view)

        myDb = Databasehelper(this)//LOCAL SQl


        val bundle = intent.extras
        try {
            var frm = bundle!!.get("from").toString()
            froms=frm
        }
        catch(e:Exception){

        }


       /* if(froms=="scan")

        {







            val npid=intent.getStringExtra("npid")
           val pids=intent.getStringExtra("pids")
           val pnames=intent.getStringExtra("pname")
           val bcode=intent.getStringExtra("bcode")
           val pdes=intent.getStringExtra("pdes")
           val weight=intent.getStringExtra("weight")
           val psac=intent.getStringExtra("psac")
           val stkhands=intent.getStringExtra("stkhand")
           val minstocks=intent.getStringExtra("minstock")
           val maxstocks=intent.getStringExtra("maxstock")
           val prices=intent.getStringExtra("price")
           val taxable=intent.getStringExtra("taxable").toBoolean()
           val igst=intent.getStringExtra("igst")
           val cgst=intent.getStringExtra("cgst")
           val sgst=intent.getStringExtra("sgst")
           val cesss=intent.getStringExtra("cess")
           val taxtotal=intent.getStringExtra("taxtotal")
           val cessval=intent.getStringExtra("cessval")
           val currency=intent.getStringExtra("currency").toBoolean()
           val percentage=intent.getStringExtra("percentage").toBoolean()
           val percentagevalue=intent.getStringExtra("percentagevalue")
           val product_dec=intent.getStringExtra("product_dec")
           val mrPs=intent.getStringExtra("mrP")
           val cates=intent.getStringExtra("cate").toBoolean()
           val manufactures=intent.getStringExtra("manufacture").toBoolean()
           val uts=intent.getStringExtra("ut").toBoolean()
           val consold=intent.getStringExtra("consold").toBoolean()
           val comm=intent.getStringExtra("comm").toBoolean()
           val statuss=intent.getStringExtra("status")
           val img1n=intent.getStringExtra("img1n")
           val img2n=intent.getStringExtra("img2n")
            val img3n=intent.getStringExtra("img3n")
            val img4n=intent.getStringExtra("img4n")
            val img5n=intent.getStringExtra("img5n")
            val img1url=intent.getStringExtra("img1url")
            val img2url=intent.getStringExtra("img2url")
            val img3url=intent.getStringExtra("img3url")
            val img4url=intent.getStringExtra("img4url")
            val img5url=intent.getStringExtra("img5url")
            val orikyss=intent.getStringExtra("orikys")
            val idss=intent.getStringExtra("idss")



            id.setText(npid)
            println("ID"+npid)

            println("ID IRUKU"+id.text.toString())
            println("ID IRUKUSAVE"+idsmy.text.toString())


            pid.setText(pids)
            pname.setText(pnames)
            hscdes.setText(pdes)
            branchky=orikyss
            vol.setText(weight)
            hsc.setText(psac)
            stockhand.setText(stkhands)
            stkhand=stockhand.text.toString()
            minstock.setText(minstocks)
            maxstock.setText(maxstocks)
            price.setText(prices)
            taxcheck.isChecked=taxable
            intgst.setText(igst)
            centgst.setText(cgst)
            stategst.setText(sgst)
            cess.setText(cesss)
            taxtot.setText(taxtotal)
            cessvalue.setText(cessval)
            currencyradio.isChecked=currency
            percenradio.isChecked=percentage
            percentageval.setText(percentagevalue)
            des_box.setText(product_dec)
            mrp.setText(mrPs)
            cate.isSelected=cates
            manu.isSelected=manufactures
            unitspinner.isSelected=uts
            checkbonus.isChecked=consold
            checkcommision.isChecked=comm
           disable.setText(statuss)
            idsmy.setText(idss)

            fn1=img1n
            sn1=img2n
            tn1=img3n
            fon1=img4n
            fifn1=img5n
           f1=img1url
            s1=img2url
           t1=img3url
            fo1=img4url
            fif1=img5url



            if(idsmy.text.toString().isNotEmpty()){
                vert.visibility=View.GONE
            }
            else if(id.text.toString().isNotEmpty()){
                vert.visibility=View.VISIBLE

            }






            try {
                bcodeid.setText(bcode)
            }
            catch (e:Exception){

            }

        }*/


        Handler().postDelayed(Runnable { loadim() }, 1000)






     if(froms=="add"){   //When new product insert



         try{
             suppcome=intent.getStringExtra("addforsupp")

             suppky=intent.getStringExtra("suppky")

             println("value"+suppcome)
             println("suppky value"+suppky)
         }
         catch (e:Exception){

         }




         try {
             val prkey = intent.getStringExtra("prky")
             prosave_key = prosave_key.plusElement(prkey)


         } catch(e: Exception) {

         }

         db.collection("productcategory")
                 .get()
                 .addOnCompleteListener {task->


                         if(task.result.isEmpty==false){
                         if (task.result != null){
                             maincat.clear()
                             maincatId.clear()
                             maincat.add("Select")
                             maincatId.add("")
                             for (document in task.result){
                                 println("document id : "+document.id)
                                 println("document data : "+document.data)
                                 val dd=document.data
                                 maincatId.add(document.id)
                                 val c = dd["cat"].toString()
                                 maincat.add(c)
                                 println(maincat)
                                 cate.adapter=adp1  // Category/Group spinner adapter
                                 /*  if (main.isNullOrEmpty()!=true){
                                       val spinnerPosition = adp1.getPosition(main.toString())
                                       cate.setSelection(spinnerPosition)
                                   }*/
                             }
                         }

                         else{

                         }
                     }
                     else
                         {
                             maincat.add("Select")
                             cate.adapter=adp1
                         }

                 }


         db.collection("unit")
                 .get()
                 .addOnCompleteListener {task->
                     if(task.result.isEmpty==false){

                         if (task.result != null){
                             list.clear()
                             maincatId.clear()
                             list.add("Select")
                             maincatId.add("")
                             for (document in task.result){
                                 println("document id : "+document.id)
                                 println("document data : "+document.data)
                                 val dd=document.data
                                 maincatId.add(document.id)
                                 val c = dd["cat"].toString()
                                 list.add(c)
                                 println(maincat)
                                 unitspinner.adapter=dataAdapter // Unit/measure adapter
                                 /*  if (main.isNullOrEmpty()!=true){
                                       val spinnerPosition = adp1.getPosition(main.toString())
                                       cate.setSelection(spinnerPosition)
                                   }*/
                             }
                         }
                     }
                     else{
                         list.add("Select")
                         unitspinner.adapter=dataAdapter
                     }
                 }


         db.collection("manufacturer")
                 .get()
                 .addOnCompleteListener {task->
                     if(task.result.isEmpty==false){
                         if (task.result != null){
                             subcat.clear()
                             maincatId.clear()
                             subcat.add("Select")
                             maincatId.add("")
                             for (document in task.result){
                                 println("document id : "+document.id)
                                 println("document data : "+document.data)
                                 val dd=document.data
                                 maincatId.add(document.id)
                                 val c = dd["cat"].toString()
                                 subcat.add(c)
                                 println(maincat)
                                 manu.adapter=adp2 // Manufacturer spinner adapter
                                 /*  if (main.isNullOrEmpty()!=true){
                                       val spinnerPosition = adp1.getPosition(main.toString())
                                       cate.setSelection(spinnerPosition)
                                   }*/
                             }
                         }
                     }
                     else
                     {
                         subcat.add("Select")
                         manu.adapter=adp2
                     }
                 }


            val a = intent.getStringExtra("newid")
            val ad=intent.getStringExtra("addpro")
            val ed=intent.getStringExtra("editpro")
            val viw=intent.getStringExtra("viewpro")
            val impo=intent.getStringExtra("importpro")
            val expo=intent.getStringExtra("exportpro")
            val del=intent.getStringExtra("deletepro")

            val keyss=intent.getStringExtra("keybr")

            println("HELLO UPDATE EDIT"+ed)

            if (ad!=null)
            {
                addpro = ad
            }
            if(ed!=null){
                editepro = ed
            }
            if (del!=null){
                deletepro = del
            }
            if (viw!=null){
                viewpro = viw
            }
            if (impo!=null){
                importpro = impo
            }
            if (expo!=null){
                exportpro = expo
            }


comepro="yes"


            branchky = keyss
            idsmy.setText(a)


             if(branchky.isEmpty()){

                 val service_access = SessionManagement(this)
                 val user = service_access.userDetails
                 val name = user[SessionManagement.KEY_NAME] //Get branch key from session
                 branchky = name.toString()
             }



         val image_view = findViewById<ImageView>(R.id.imageView41)
         val image_button = findViewById(R.id.imageButton2) as ImageButton

         image_button.setOnClickListener { //Navigate to multi select images activity

             val b = Intent(this@MainActivityScroll, AddImagesActivity_prod::class.java)
             b.putExtra("id", id.text.toString())
             b.putExtra("f1", f1)
             b.putExtra("fn1", fn1)
             b.putExtra("s1", s1)
             b.putExtra("sn1", sn1)
             b.putExtra("t1", t1)
             b.putExtra("tn1", tn1)
             b.putExtra("fo1", fo1)
             b.putExtra("fon1", fon1)
             b.putExtra("fif1", fif1)
             b.putExtra("fifn1", fifn1)

             b.putExtra("f1edit", f1edit)
             b.putExtra("fn1edit", fn1edit)
             b.putExtra("s1edit", s1edit)
             b.putExtra("sn1edit", sn1edit)
             b.putExtra("t1edit", t1edit)
             b.putExtra("tn1edit", tn1edit)
             b.putExtra("fo1edit", fo1edit)
             b.putExtra("fon1edit", fon1edit)
             b.putExtra("fif1edit", fif1edit)
             b.putExtra("fifn1edit", fifn1edit)

             b.putExtra("f1high", img1urlhigh)
             b.putExtra("fn1high", img1nhigh)
             b.putExtra("s1high", img2urlhigh)
             b.putExtra("sn1high", img2nhigh)
             b.putExtra("t1high", img3urlhigh)
             b.putExtra("tn1high",img3nhigh)
             b.putExtra("fo1high", img4urlhigh)
             b.putExtra("fon1high", img4nhigh)
             b.putExtra("fif1high", img5urlhigh)
             b.putExtra("fifn1high",img5nhigh)
             b.putExtra("mresult", mresultsarr)
             b.putExtra("cacnm1", cacnm1)
             b.putExtra("listenersave", commonlisteners)
             b.putExtra("f1edithigh", f1edithigh)
             b.putExtra("fn1edithigh", fn1edithigh)
             b.putExtra("s1edithigh", s1edithigh)
             b.putExtra("sn1edithigh", sn1edithigh)
             b.putExtra("t1edithigh", t1edithigh)
             b.putExtra("tn1edithigh", tn1edithigh)
             b.putExtra("fo1edithigh", fo1edithigh)
             b.putExtra("fon1edithigh", fon1edithigh)
             b.putExtra("fif1edithigh", fif1edithigh)
             b.putExtra("fifn1edithigh", fifn1edithigh)

             b.putExtra("addpro",addpro)
             b.putExtra("editpro",editepro)
             b.putExtra("deletepro",deletepro)
             b.putExtra("viewpro",viewpro)
             b.putExtra("importpro",importpro)
             b.putExtra("exportpro",exportpro)
             b.putExtra("changestock", stockin_hand)

             startActivityForResult(b, 0)
             gallery.isEnabled = true
         }
         image_view.setOnClickListener { //Navigate to multi select images activity

             val b = Intent(this@MainActivityScroll, AddImagesActivity_prod::class.java)
             b.putExtra("id", id.text.toString())
             b.putExtra("f1", f1)
             b.putExtra("fn1", fn1)
             b.putExtra("s1", s1)
             b.putExtra("sn1", sn1)
             b.putExtra("t1", t1)
             b.putExtra("tn1", tn1)
             b.putExtra("fo1", fo1)
             b.putExtra("fon1", fon1)
             b.putExtra("fif1", fif1)
             b.putExtra("fifn1", fifn1)

             b.putExtra("f1edit", f1edit)
             b.putExtra("fn1edit", fn1edit)
             b.putExtra("s1edit", s1edit)
             b.putExtra("sn1edit", sn1edit)
             b.putExtra("t1edit", t1edit)
             b.putExtra("tn1edit", tn1edit)
             b.putExtra("fo1edit", fo1edit)
             b.putExtra("fon1edit", fon1edit)
             b.putExtra("fif1edit", fif1edit)
             b.putExtra("fifn1edit", fifn1edit)

             b.putExtra("f1high", img1urlhigh)
             b.putExtra("fn1high", img1nhigh)
             b.putExtra("s1high", img2urlhigh)
             b.putExtra("sn1high", img2nhigh)
             b.putExtra("t1high", img3urlhigh)
             b.putExtra("tn1high",img3nhigh)
             b.putExtra("fo1high", img4urlhigh)
             b.putExtra("fon1high", img4nhigh)
             b.putExtra("fif1high", img5urlhigh)
             b.putExtra("fifn1high",img5nhigh)
             b.putExtra("mresult", mresultsarr)
             b.putExtra("cacnm1", cacnm1)
             b.putExtra("listenersave", commonlisteners)
             b.putExtra("f1edithigh", f1edithigh)
             b.putExtra("fn1edithigh", fn1edithigh)
             b.putExtra("s1edithigh", s1edithigh)
             b.putExtra("sn1edithigh", sn1edithigh)
             b.putExtra("t1edithigh", t1edithigh)
             b.putExtra("tn1edithigh", tn1edithigh)
             b.putExtra("fo1edithigh", fo1edithigh)
             b.putExtra("fon1edithigh", fon1edithigh)
             b.putExtra("fif1edithigh", fif1edithigh)
             b.putExtra("fifn1edithigh", fifn1edithigh)

             b.putExtra("addpro",addpro)
             b.putExtra("editpro",editepro)
             b.putExtra("deletepro",deletepro)
             b.putExtra("viewpro",viewpro)
             b.putExtra("importpro",importpro)
             b.putExtra("exportpro",exportpro)
             b.putExtra("changestock",stockin_hand)

             startActivityForResult(b, 0)
             gallery.isEnabled = true
         }






        }

        else if(froms=="list"){  //If already exist product and from product list click


         try {
             db.collection("product").document(id.text.toString())
                     .get()
                     .addOnCompleteListener { task ->
                         var ff = task.result.data
                         var supky = ff["supp_key"].toString() //Get supplier key from productdb
                         suppky = supky

                     }
         }
         catch (e:Exception){

         }

         try{
             suppcome=intent.getStringExtra("addforsupp")

             suppky=intent.getStringExtra("suppky")

             println("value"+suppcome)
             println("suppky value"+suppky)
         }
         catch (e:Exception){

         }

            vert.visibility=View.GONE
            val b = intent.getStringExtra("id")
            id.setText(b)

          /*  val ces=intent.getStringExtra("cesss")*/
      /*      println("CESS VALUES IN LIST"+ces)*/


       /*  cessvaluevalidate=ces*/



         //Product accesses

            val ad=intent.getStringExtra("addpro")
            val ed=intent.getStringExtra("editpro")
            val viw=intent.getStringExtra("viewpro")
            val impo=intent.getStringExtra("importpro")
            val expo=intent.getStringExtra("exportpro")
            val del=intent.getStringExtra("deletepro")
           stockin_hand=intent.getStringExtra("changestock")
            val keyss=intent.getStringExtra("keybr")


         try {
             val prkey = intent.getStringExtra("prky")
             prosave_key = prosave_key.plusElement(prkey)


         } catch(e: Exception) {

         }

            println("HELLO UPDATE EDIT"+ed)

            if (ad!=null)
            {
                addpro = ad
            }
            if(ed!=null){
                editepro = ed
            }
            if (del!=null){
                deletepro = del
            }
            if (viw!=null){
                viewpro = viw
            }
            if (impo!=null){
                importpro = impo
            }
            if (expo!=null){
                exportpro = expo
            }

            listcome="yes"



            branchky = keyss


            if (id.text.isNotEmpty()) { //For exisiting product


                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference(id.text.toString() + "_" + branchky)

                val messageListener = object : ValueEventListener {

                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        if (dataSnapshot.exists()) {

                            val message = dataSnapshot.value
                            stockhand.setText(message.toString())
                            stockhandvalidate=message.toString() //Get stockonhand value from firebase db
                            println("SOH"+message)

                        }
                    }

                    override fun onCancelled(databaseError: DatabaseError)
                    {
                        // Failed to read value
                    }
                }

                myRef!!.addValueEventListener(messageListener)





                save.visibility = View.INVISIBLE
                edit.visibility = View.VISIBLE
                gallery.visibility=View.INVISIBLE




                val getone = myDb.getOne(id.text.toString()) //Get values from  sql table by product id
                                                                    // and fill the values in a corresponding fields

                while (getone.moveToNext()) {

                    var i=0

                    pname.setText(getone.getString(2))

                    pnamevalidate=getone.getString(2)

                    ttname.setText(getone.getString(2))


                    pid.setText(getone.getString(1))


                    vol.setText(getone.getString(5))
                    volvalidate=getone.getString(5)

                   val k = getone.getString(9)
                    val kmanu =getone.getString(8)
                    val categ=getone.getString(7)

                    maincatvalidate=getone.getString(7)
                    subcatvalidate=getone.getString(8)
                    listvalidate=getone.getString(9)

                    makeupitemstr=getone.getString(55)

                    println("CATE"+categ)
                    bcodeid.setText(getone.getString(3))
                    bcodeidvalidate=getone.getString(3)
                    hsc.setText(getone.getString(6))
                    hscvalidate=getone.getString(6)

                    hscdes.setText(getone.getString(4))
                    hscdesvalidate=getone.getString(4)

                    maincat.add(categ)
                    println("CATEG"+maincat)
                    db.collection("productcategory")
                            .get()
                            .addOnCompleteListener {task->

                                    if (task.result.isEmpty == false) {
                                        if (task.result != null) {

                                            maincatId.clear()

                                            maincatId.add("")
                                            for (document in task.result) {
                                                i += 1
                                                println("document id : " + document.id)
                                                println("document data : " + document.data)
                                                val dd = document.data
                                                maincatId.add(document.id)
                                                val c = dd["cat"].toString()



                                                if (c == categ) {
                                                    dup = c
                                                } else {
                                                    maincat.add(c)
                                                }



                                                println(maincat)
                                                println("CATEG" + maincat)
                                                cate.adapter = adp1  //Category / Group adapter
                                                /*  if (main.isNullOrEmpty()!=true){
                                                  val spinnerPosition = adp1.getPosition(main.toString())
                                                  cate.setSelection(spinnerPosition)
                                              }*/
                                            }
                                        }
                                    }
                                    else
                                    {
                                        maincat.add(categ)

                                        cate.adapter = adp1 //Category / Group adapter
                                    }


                            }



                    val categories1 = ArrayList<String>()
                    subcat.add(kmanu)
                    println("MANU SPIN"+subcat)

                    db.collection("manufacturer")
                            .get()
                            .addOnCompleteListener {task->

                                      if (task.result.isEmpty == false) {
                                    if (task.result != null){

                                        maincatId.clear()

                                        maincatId.add("")
                                        for (document in task.result){
                                            println("document id : "+document.id)
                                            println("document data : "+document.data)
                                            val dd=document.data
                                            maincatId.add(document.id)
                                            val c = dd["cat"].toString()



                                            if(c==kmanu){
                                                dup=c
                                            }
                                            else{
                                                subcat.add(c)
                                            }
                                            println(maincat)
                                            println("MANU SPIN"+subcat)
                                            manu.adapter=adp2 //MAnufacturer spinner adapter
                                            /*  if (main.isNullOrEmpty()!=true){
                                                  val spinnerPosition = adp1.getPosition(main.toString())
                                                  cate.setSelection(spinnerPosition)
                                              }*/
                                        }
                                    }
                                }
                                    else{

                                          subcat.add(kmanu)
                                          manu.adapter=adp2
                                      }
                            }






                    val categories2 = ArrayList<String>()
                    list.add(k)

                    println("UNIT SPIN"+list)

                    db.collection("unit")
                            .get()
                            .addOnCompleteListener {task->

                                    if (task.result.isEmpty == false) {

                                        if (task.result != null) {

                                            maincatId.clear()

                                            maincatId.add("")
                                            for (document in task.result) {
                                                println("document id : " + document.id)
                                                println("document data : " + document.data)
                                                val dd = document.data
                                                maincatId.add(document.id)
                                                val c = dd["cat"].toString()




                                                if (c == k) {
                                                    dup = c
                                                } else {
                                                    list.add(c)
                                                }
                                                println(maincat)
                                                println("UNIT SPIN" + list)
                                                unitspinner.adapter = dataAdapter  //Unit / Measure spinner adapter
                                                /*  if (main.isNullOrEmpty()!=true){
                                                  val spinnerPosition = adp1.getPosition(main.toString())
                                                  cate.setSelection(spinnerPosition)
                                              }*/
                                            }
                                        }


                                }
                                    else{
                                        list.add(k)
                                        unitspinner.adapter = dataAdapter


                                    }
                            }





                    println("PRICE" + getone.getString(11))
                   fn1 = getone.getString(29).toString()

                   sn1 = getone.getString(30).toString()
                   tn1 = getone.getString(31).toString()
                   fon1 = getone.getString(32).toString()
                   fifn1 = getone.getString(33).toString()
                   f1 = getone.getString(34).toString()
                    println("IMG URLSSSS" + getone.getString(34).toString())
                    println("IMG NAMES" + getone.getString(29).toString())
                    println("IMG names" + fn1)
                    s1 = getone.getString(35).toString()
                    t1 = getone.getString(36).toString()
                    fo1 = getone.getString(37).toString()
                    fif1 = getone.getString(38).toString()

                    img1nhigh=getone.getString(39).toString()
                    img2nhigh=getone.getString(40).toString()
                    img3nhigh=getone.getString(41).toString()
                    img4nhigh=getone.getString(42).toString()
                    img5nhigh=getone.getString(43).toString()
                    img1urlhigh=getone.getString(44).toString()
                    img2urlhigh=getone.getString(45).toString()
                    img3urlhigh=getone.getString(46).toString()
                    img4urlhigh=getone.getString(47).toString()
                    img5urlhigh=getone.getString(48).toString()


                    f1edithigh=getone.getString(44).toString()
                    fn1edithigh=getone.getString(39).toString()
                    s1edithigh=getone.getString(45).toString()
                    sn1edithigh=getone.getString(40).toString()
                    t1edithigh=getone.getString(46).toString()
                    tn1edithigh=getone.getString(41).toString()
                    fo1edithigh=getone.getString(47).toString()
                    fon1edithigh=getone.getString(42).toString()
                    fif1edithigh=getone.getString(48).toString()
                    fifn1edithigh=getone.getString(43).toString()



                    f1edit =  getone.getString(34).toString()
                    fn1edit = getone.getString(29).toString()
                    s1edit = getone.getString(35).toString()
                    sn1edit = getone.getString(30).toString()
                    t1edit = getone.getString(36).toString()
                    tn1edit = getone.getString(31).toString()
                    fo1edit = getone.getString(37).toString()
                    fon1edit = getone.getString(32).toString()
                    fif1edit = getone.getString(38).toString()
                    fifn1edit = getone.getString(33).toString()

                    if((f1.isNotEmpty())||(s1.isNotEmpty())){
                        imageView41.visibility=View.GONE
                        imageButton2.visibility=View.GONE
                        gallery.visibility=View.VISIBLE
                    }



                    val image_view = findViewById<ImageView>(R.id.imageView41)
                    val image_button = findViewById(R.id.imageButton2) as ImageView

                    image_button.setOnClickListener { //Navigate to multi select images activity
                        scroll2_slider.removeAllSliders()

                        val b = Intent(this@MainActivityScroll, AddImagesActivity_prod::class.java)
                        b.putExtra("id", id.text.toString())
                        b.putExtra("f1", f1)
                        b.putExtra("fn1", fn1)
                        b.putExtra("s1", s1)
                        b.putExtra("sn1", sn1)
                        b.putExtra("t1", t1)
                        b.putExtra("tn1", tn1)
                        b.putExtra("fo1", fo1)
                        b.putExtra("fon1", fon1)
                        b.putExtra("fif1", fif1)
                        b.putExtra("fifn1", fifn1)

                        b.putExtra("f1edit", f1edit)
                        b.putExtra("fn1edit", fn1edit)
                        b.putExtra("s1edit", s1edit)
                        b.putExtra("sn1edit", sn1edit)
                        b.putExtra("t1edit", t1edit)
                        b.putExtra("tn1edit", tn1edit)
                        b.putExtra("fo1edit", fo1edit)
                        b.putExtra("fon1edit", fon1edit)
                        b.putExtra("fif1edit", fif1edit)
                        b.putExtra("fifn1edit", fifn1edit)

                        b.putExtra("f1high", img1urlhigh)
                        b.putExtra("fn1high", img1nhigh)
                        b.putExtra("s1high", img2urlhigh)
                        b.putExtra("sn1high", img2nhigh)
                        b.putExtra("t1high", img3urlhigh)
                        b.putExtra("tn1high",img3nhigh)
                        b.putExtra("fo1high", img4urlhigh)
                        b.putExtra("fon1high", img4nhigh)
                        b.putExtra("fif1high", img5urlhigh)
                        b.putExtra("fifn1high",img5nhigh)
                        b.putExtra("mresult", mresultsarr)
                        b.putExtra("cacnm1", cacnm1)
                        b.putExtra("listenersave", commonlisteners)
                        b.putExtra("f1edithigh", f1edithigh)
                        b.putExtra("fn1edithigh", fn1edithigh)
                        b.putExtra("s1edithigh", s1edithigh)
                        b.putExtra("sn1edithigh", sn1edithigh)
                        b.putExtra("t1edithigh", t1edithigh)
                        b.putExtra("tn1edithigh", tn1edithigh)
                        b.putExtra("fo1edithigh", fo1edithigh)
                        b.putExtra("fon1edithigh", fon1edithigh)
                        b.putExtra("fif1edithigh", fif1edithigh)
                        b.putExtra("fifn1edithigh", fifn1edithigh)

                        b.putExtra("addpro",addpro)
                        b.putExtra("editpro",editepro)
                        b.putExtra("deletepro",deletepro)
                        b.putExtra("viewpro",viewpro)
                        b.putExtra("importpro",importpro)
                        b.putExtra("exportpro",exportpro)
                        b.putExtra("changestock", stockin_hand)

                        startActivityForResult(b, 0)
                        gallery.isEnabled = true
                    }
                    image_view.setOnClickListener { //Navigate to multi select images activity
                        scroll2_slider.removeAllSliders()

                        val b = Intent(this@MainActivityScroll, AddImagesActivity_prod::class.java)
                        b.putExtra("id", id.text.toString())
                        b.putExtra("f1", f1)
                        b.putExtra("fn1", fn1)
                        b.putExtra("s1", s1)
                        b.putExtra("sn1", sn1)
                        b.putExtra("t1", t1)
                        b.putExtra("tn1", tn1)
                        b.putExtra("fo1", fo1)
                        b.putExtra("fon1", fon1)
                        b.putExtra("fif1", fif1)
                        b.putExtra("fifn1", fifn1)

                        b.putExtra("f1edit", f1edit)
                        b.putExtra("fn1edit", fn1edit)
                        b.putExtra("s1edit", s1edit)
                        b.putExtra("sn1edit", sn1edit)
                        b.putExtra("t1edit", t1edit)
                        b.putExtra("tn1edit", tn1edit)
                        b.putExtra("fo1edit", fo1edit)
                        b.putExtra("fon1edit", fon1edit)
                        b.putExtra("fif1edit", fif1edit)
                        b.putExtra("fifn1edit", fifn1edit)

                        b.putExtra("f1high", img1urlhigh)
                        b.putExtra("fn1high", img1nhigh)
                        b.putExtra("s1high", img2urlhigh)
                        b.putExtra("sn1high", img2nhigh)
                        b.putExtra("t1high", img3urlhigh)
                        b.putExtra("tn1high",img3nhigh)
                        b.putExtra("fo1high", img4urlhigh)
                        b.putExtra("fon1high", img4nhigh)
                        b.putExtra("fif1high", img5urlhigh)
                        b.putExtra("fifn1high",img5nhigh)
                        b.putExtra("mresult", mresultsarr)
                        b.putExtra("cacnm1", cacnm1)
                        b.putExtra("listenersave", commonlisteners)
                        b.putExtra("f1edithigh", f1edithigh)
                        b.putExtra("fn1edithigh", fn1edithigh)
                        b.putExtra("s1edithigh", s1edithigh)
                        b.putExtra("sn1edithigh", sn1edithigh)
                        b.putExtra("t1edithigh", t1edithigh)
                        b.putExtra("tn1edithigh", tn1edithigh)
                        b.putExtra("fo1edithigh", fo1edithigh)
                        b.putExtra("fon1edithigh", fon1edithigh)
                        b.putExtra("fif1edithigh", fif1edithigh)
                        b.putExtra("fifn1edithigh", fifn1edithigh)

                        b.putExtra("addpro",addpro)
                        b.putExtra("editpro",editepro)
                        b.putExtra("deletepro",deletepro)
                        b.putExtra("viewpro",viewpro)
                        b.putExtra("importpro",importpro)
                        b.putExtra("exportpro",exportpro)
                        b.putExtra("changestock",stockin_hand)

                        startActivityForResult(b, 0)
                        gallery.isEnabled = true
                    }


                    println("IMG URLSSSS" + getone.getString(34).toString())
                    price.setText(getone.getString(11))
                    pricevalidate=getone.getString(11)

                    taxcheck.setChecked(getone.getString(15).toBoolean())
                    taxcheckvalidate=getone.getString(15)

                    intgst.setText(getone.getString(16))
                    intgstvalidate=getone.getString(16)


                    println("CESSS"+getone.getString(19))

                    try {
                        cess.setText(getone.getString(19))
                        cessvaluevalidate=getone.getString(19)
                    }
                    catch (e:Exception){

                    }

                    centgst.setText(getone.getString(17))


                    stategst.setText(getone.getString(18))


                    taxtot.setText(getone.getString(20))




                    retail.setChecked(getone.getString(50).toBoolean())
                    retailvalidate=getone.getString(50)
                    backbox.setChecked(getone.getString(51).toBoolean())
                    backbarvalidate=getone.getString(51)
                    try {
                        returnablevalidate = getone.getString(53)
                    }
                    catch (e:Exception){

                    }

                    cessvalue.setText(getone.getString(21))



                    protypesave=getone.getString(52)
                    mrp.setText(getone.getString(22))
                    checkcommision.setChecked(getone.getString(14).toBoolean())
                    checkcommisionvalidate=getone.getString(14)

                    checkbonus.setChecked(getone.getString(13).toBoolean())

                    checkbonusvalidate=getone.getString(13)


                    currencyradio.setChecked(getone.getString(23).toBoolean())

                    percenradio.setChecked(getone.getString(25).toBoolean())
                    percentageval.setText(getone.getString(26))

                    percentagevalvalidate=getone.getString(26)

                    maxstock.setText(getone.getString(12))
                    maxstockvalidate=getone.getString(12)

                    minstock.setText(getone.getString(10))
                    minstockvalidate=getone.getString(10)


                    des_box.setText(getone.getString(27))
                    des_boxvalidate=getone.getString(27)
                    disable.setText(getone.getString(24))

                    println("IMG URLSSSS" + f1)











                    // All views becomes disabled when edit button is visible
                    pname.isEnabled = false
                    pid.isEnabled = false

                    vol.isEnabled = false
                    unitspinner.isEnabled = false
                    manu.isEnabled = false
                    cate.isEnabled = false
                    bcodeid.isEnabled = false
                    hsc.isEnabled = false
                    hscdes.isEnabled = false
                    price.isEnabled = false
                    taxcheck.isEnabled = false
                    intgst.isEnabled = false
                    cess.isEnabled = false
                    centgst.isEnabled = false
                    stategst.isEnabled = false
                    taxtot.isEnabled = false
                    cessvalue.isEnabled = false
                    mrp.isEnabled = false
                    checkcommision.isEnabled = false
                    checkbonus.isEnabled = false
                    currencyradio.isEnabled = false
                    percenradio.isEnabled = false
                    percentageval.isEnabled = false
                    maxstock.isEnabled = false
                    minstock.isEnabled = false
                    stockhand.isEnabled = false
                    des_box.isEnabled = false

                    retail.isEnabled=false
                    backbox.isEnabled=false
                }
            }
            else {
                println(idsmy.text.toString())
            }
        }




        // If imagelinks are not empty then add image links to 'filemaps' array for slider view.
        //Image links from local storage or online db

        if (f1.isNullOrEmpty() == false || s1.isNullOrEmpty() == false || t1.isNullOrEmpty() == false || fo1.isNullOrEmpty() == false || fif1.isNullOrEmpty() == false) {


            scrollpro.visibility = View.VISIBLE


            scroll2_slider2.visibility = View.VISIBLE
            imageView41.visibility = View.GONE
            imageButton2.visibility = View.GONE
            gallery.visibility = View.VISIBLE
            if (f1.isNullOrEmpty() == false) {
                f1 = f1.toString()

            }
            if (s1.isNullOrEmpty() == false) {
                s1 = s1.toString()

            }
            if (t1.isNullOrEmpty() == false) {
                t1 = t1.toString()

            }
            if (fo1.isNullOrEmpty() == false) {
                fo1 = fo1.toString()

            }
            if (fif1.isNullOrEmpty() == false) {
                fif1 = fif1.toString()

            }
            if (fn1.isNullOrEmpty() == false) {
                fn1 = fn1.toString()
                img1nhigh=img1nhigh.toString()



                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img1nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(f1)
                    }
                }
                catch (e:Exception){
                    file_maps.add(f1)
                }
            }
            if (sn1.isNullOrEmpty() == false) {
                sn1 = sn1.toString()
                img2nhigh=img2nhigh.toString()

                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img2nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(s1)
                    }
                }
                catch (e:Exception){
                    file_maps.add(s1)
                }
            }
            if (tn1.isNullOrEmpty() == false) {
                tn1 = tn1.toString()
                img3nhigh=img3nhigh.toString()
                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img3nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(t1)
                    }
                }
                catch (e:Exception){
                    file_maps.add(t1)
                }



            }
            if (fon1.isNullOrEmpty() == false) {
                fon1 = fon1.toString()
                img4nhigh=img4nhigh.toString()
                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img4nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(fo1)
                    }
                }
                catch (e:Exception){
                    file_maps.add(fo1)
                }
            }
            if (fifn1.isNullOrEmpty() == false) {
                fifn1 = fifn1.toString()


                img5nhigh=img5nhigh.toString()
                try {

                    val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                    val dir = File(path);
                    if (!dir.exists())
                        dir.mkdirs()

                    val k = img5nhigh
                    val recacnm = k.removeSuffix(".jpg")
                    cacnm1 = recacnm
                    var y = recacnm + ".png"

                    val file = File(dir, y)
                    println("CONTENT URI" + file)
                    if (file.exists()) {
                        val contentUri = Uri.fromFile(File("$path/$y"))
                        file_maps.add(contentUri.toString())
                    }
                    else{
                        file_maps.add(fif1)
                    }
                }
                catch (e:Exception){
                    file_maps.add(fif1)
                }

            }
        } else {
            scroll2_slider2.visibility = View.GONE

            scroll2_slider.visibility = View.VISIBLE

            imageView41.visibility = View.VISIBLE
            imageButton2.visibility = View.VISIBLE
            gallery.visibility = View.GONE
        }


        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

       /* val file_maps = HashMap<String, Int>()
        file_maps.put("jkhdflh", R.drawable.loreal_bottl)
        file_maps.put("Big Bang Theory", R.drawable.loreal_bottl)
        file_maps.put("House of Cards", R.drawable.loreal_bottl)
        file_maps.put("Game of Thrones", R.drawable.loreal_bottl)
        for (name in file_maps.keys) {
            val textSliderView = TextSliderView(this)
            // initialize a SliderLayout
            textSliderView
                    //.description(name)
                    .image(file_maps.get(name)!!)
                    //.setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(this)

            //add your extra information
            textSliderView.bundle(Bundle())
            textSliderView.bundle
                    .putString("extra", name)

            mDemoSlider.addSlider(textSliderView)
        }
        mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Default)
        mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
        mDemoSlider.setCustomAnimation(DescriptionAnimation())*/




        /* db.collection("manufacturer")
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        save_progress.visibility = android.view.View.VISIBLE
                        Log.d("task is", "successful")
                        for (document in task.result) {
                            Log.d("data", "is" + document.id + document.data)
                            categories.add(document.get("cat").toString())
                            save_progress.visibility = android.view.View.GONE

                        }
                    } else {
                        Log.i("no", "no")
                    }
                }

                .addOnFailureListener {
                    Log.e("task is", "not complete")
                }*/



        val f = intent.getStringExtra("f")
        val s = intent.getStringExtra("s")
        val t = intent.getStringExtra("t")
        val fo = intent.getStringExtra("fo")
        val fif = intent.getStringExtra("fif")
        //image name's
        val fn = intent.getStringExtra("fn")
        val sn = intent.getStringExtra("sn")
        val tn = intent.getStringExtra("tn")
        val fon = intent.getStringExtra("fon")
        val fifn = intent.getStringExtra("fifn")



        vert.setOnClickListener({ //Image button vert menu contains Popup with the title of Enable/Disable,Change stock on hand


            val popup = PopupMenu(this@MainActivityScroll, vert)

            popup.menuInflater.inflate(R.menu.menu_main, popup.menu)
            val m1 = popup.menu.getItem(1)
            if (deletepro=="true"||deletepro.isNullOrEmpty()) {
                if (disable.text == "Disable") {
                    m1.title = "Enable product"


                    popup.setOnMenuItemClickListener { item ->//Click disable title and change the status of the product as 'DISABLED'
                        if(net_status()==true) {
                            if (item.itemId == R.id.ex) {

                                val builder = android.app.AlertDialog.Builder(this@MainActivityScroll)
                                with(builder) {
                                    setTitle("Enable")
                                    setMessage("Please enable the product before you change stock")
                                    setCancelable(false)
                                    setPositiveButton("ok") { dialog, whichButton ->
                                        dialog.dismiss()
                                    }


                                    val dialog = builder.create()

                                    dialog.show()
                                }


                            }

                            if (item.itemId == R.id.im) {
                                var npid = id.text.toString()
                                var pid = (pid.text).toString()
                                var pname = (pname.text).toString()
                                var bcode = (bcodeid.text).toString()
                                var pdes = (hscdes.text).toString()
                                var orikys = branchky
                                var weight = (vol.text).toString()
                                var psac = (hsc.text).toString()

                                if (stockhand.text.toString().isNotEmpty()) {
                                    var stockonhand = (stockhand.text).toString()
                                    stkhand = stockonhand
                                } else {

                                    stkhand = "0"
                                }

                                var minstock = (minstock.text).toString()
                                var maxstock = (maxstock.text).toString()
                                var price = (price.text).toString()
                                var taxable = taxcheck.isChecked.toString()
                                var igst = (intgst.text).toString()
                                var cgst = (centgst.text).toString()
                                var sgst = (stategst.text).toString()
                                var cess = (cess.text).toString()
                                var taxtotal = (taxtot.text).toString()
                                var cessval = (cessvalue.text).toString()
                                var currency = currencyradio.isChecked.toString()
                                var percentage = percenradio.isChecked.toString()
                                var percentagevalue = (percentageval.text).toString()
                                var product_dec = (des_box.text).toString()
                                var mrP = (mrp.text).toString()
                                var cate = cate.selectedItem.toString()
                                var manufacture = manu.selectedItem.toString()
                                var ut = unitspinner.selectedItem.toString()
                                var consold = checkbonus.isChecked.toString()
                                var comm = checkcommision.isChecked.toString()
                                var status = (disable.text).toString()


                                var ret = retail.isChecked.toString()
                                var bskbr = backbox.isChecked.toString()
                                var returnables="false"
                                var retday=""








                                val img1n = fn1
                                val img2n = sn1
                                val img3n = tn1
                                val img4n = fon1
                                val img5n = fifn1
                                val img1url = f1
                                val img2url = s1
                                val img3url = t1
                                val img4url = fo1
                                val img5url = fif1

                                val builder = android.app.AlertDialog.Builder(this@MainActivityScroll)
                                with(builder) {
                                    setTitle("Confirm?")
                                    setMessage("Are you sure want to enable?")
                                    setPositiveButton("Yes") { dialog, whichButton ->  //Click enable title and change the status of the product as 'Active'
                                        pDialogs = SweetAlertDialog(this@MainActivityScroll, SweetAlertDialog.PROGRESS_TYPE);
                                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                        pDialogs!!.setTitleText("Enabling...");
                                        pDialogs!!.setCancelable(false);
                                        pDialogs!!.show();
                                        disable.setText("Active")
                                        var status = (disable.text).toString()

                                        val map = mutableMapOf<String, Any?>()
                                        map.put("status", status)
                                        db.collection("product").document(id.text.toString())
                                                .update(map)
                                                .addOnSuccessListener {
                                                    val isInserted = myDb.updatedata(npid, pid, pname, bcode, pdes, weight, psac, cate,
                                                            manufacture, ut, minstock, price, maxstock, consold, comm, taxable, igst, cgst,
                                                            sgst, cess, taxtotal, cessval, mrP, currency, status, percentage, percentagevalue,
                                                            product_dec, stkhand, img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url,
                                                            img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                                                            img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys, ret, bskbr,protypesave,returnables,retday,makeupitemstr)

                                                    if (isInserted == true) {
                                                    } else {
                                                    }
                                                    try{
                                                        pDialogs!!.dismiss()
                                                    }
                                                    catch (e:Exception)
                                                    {

                                                    }

                                                    Toast.makeText(applicationContext, "Enabled", Toast.LENGTH_LONG).show()
                                                    val o = Intent(this@MainActivityScroll, MainProductlistActivity::class.java)

                                                    o.putExtra("frm_main", "main")


                                                    o.putExtra("addpro", addpro)
                                                    o.putExtra("editpro", editepro)
                                                    o.putExtra("deletepro", deletepro)
                                                    o.putExtra("viewpro", viewpro)
                                                    o.putExtra("importpro", importpro)
                                                    o.putExtra("exportpro", exportpro)
                                                    o.putExtra("changestock", stockin_hand)
                                                    o.putExtra("skey", branchky)

                                                    startActivity(o)

                                                    finish()
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)

                                                }
                                    }
                                    setNegativeButton("No") { dialog, whichButton ->
                                        dialog.dismiss()
                                    }

                                    val dialog = builder.create()

                                    dialog.show()
                                }

                            }
                        }
                        else if(net_status()==false){
                            Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
                        }



                        true
                    }



                    popup.show()
                } else if (disable.text == "Active") {


                    m1.title = "Disable product"
                    popup.setOnMenuItemClickListener { item ->

                        if(net_status()==true){
                        if (item.itemId == R.id.ex) {


                            if(stockin_hand=="true") {//Click Change stockon hand title and change the stock of the product.
                                val alert = AlertDialog.Builder(this@MainActivityScroll)
                                val inflater = this.layoutInflater
                                /*with(alert) {
            setTitle("Select Branch")
            }*/
                                val dialog = alert.create()
                                dialog.setView(inflater.inflate(R.layout.stock_popup, null))
                                dialog.show()
                                val stkedt = dialog.findViewById<EditText>(R.id.stkhand) as EditText

                                stkedt.text=stockhand.text

                                val okact = dialog.findViewById<Button>(R.id.holiok) as Button
                                val cancelact = dialog.findViewById<Button>(R.id.holicancel) as Button

                                okact.setOnClickListener {

                                    val h = stkedt.text
                                    stockhand.setText(h)
                                    dialog.hide()


                                }
                                cancelact.setOnClickListener {
                                    dialog.hide()
                                }
                            }
                            else if(stockin_hand=="false"){
                                popup("change stock")
                            }

                        }


                        if (item.itemId == R.id.im) {

                            var npid = id.text.toString()
                            var pid = (pid.text).toString()
                            var pname = (pname.text).toString()
                            var bcode = (bcodeid.text).toString()
                            var pdes = (hscdes.text).toString()
                            var orikys = branchky
                            var weight = (vol.text).toString()
                            var psac = (hsc.text).toString()

                            if (stockhand.text.toString().isNotEmpty()) {
                                var stockonhand = (stockhand.text).toString()
                                stkhand = stockonhand
                            } else {

                                stkhand = "0"
                            }

                            var minstock = (minstock.text).toString()
                            var maxstock = (maxstock.text).toString()
                            var price = (price.text).toString()
                            var taxable = taxcheck.isChecked.toString()
                            var igst = (intgst.text).toString()
                            var cgst = (centgst.text).toString()
                            var sgst = (stategst.text).toString()
                            var cess = (cess.text).toString()
                            var taxtotal = (taxtot.text).toString()
                            var cessval = (cessvalue.text).toString()
                            var currency = currencyradio.isChecked.toString()
                            var percentage = percenradio.isChecked.toString()
                            var percentagevalue = (percentageval.text).toString()
                            var product_dec = (des_box.text).toString()
                            var mrP = (mrp.text).toString()
                            var cate = cate.selectedItem.toString()
                            var manufacture = manu.selectedItem.toString()
                            var ut = unitspinner.selectedItem.toString()
                            var consold = checkbonus.isChecked.toString()
                            var comm = checkcommision.isChecked.toString()
                            var status = (disable.text).toString()

                            var ret = retail.isChecked.toString()
                            var bskbr = backbox.isChecked.toString()
                            var returnables="false"
                            var retday=""


                            val img1n = fn1
                            val img2n = sn1
                            val img3n = tn1
                            val img4n = fon1
                            val img5n = fifn1
                            val img1url = f1
                            val img2url = s1
                            val img3url = t1
                            val img4url = fo1
                            val img5url = fif1

                            val builder = android.app.AlertDialog.Builder(this@MainActivityScroll)
                            with(builder) {
                                setTitle("Confirm?")
                                setMessage("Are you sure want to disable?")
                                setPositiveButton("Yes") { dialog, whichButton ->
                                    pDialogs = SweetAlertDialog(this@MainActivityScroll, SweetAlertDialog.PROGRESS_TYPE);
                                    pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                    pDialogs!!.setTitleText("Disabling...");
                                    pDialogs!!.setCancelable(false);
                                    pDialogs!!.show();
                                    disable.setText("Disable")
                                    var status = (disable.text).toString()

                                    val map = mutableMapOf<String, Any?>()
                                    map.put("status", status)
                                    db.collection("product").document(id.text.toString())
                                            .update(map)
                                            .addOnSuccessListener {
                                                val isInserted = myDb.updatedata(npid, pid, pname, bcode, pdes, weight,
                                                        psac, cate, manufacture, ut, minstock, price, maxstock, consold,
                                                        comm, taxable, igst, cgst, sgst, cess, taxtotal, cessval, mrP,
                                                        currency, status, percentage, percentagevalue, product_dec, stkhand,
                                                        img1n, img2n, img3n, img4n, img5n, img1url, img2url, img3url, img4url,
                                                        img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh,
                                                        img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys, ret, bskbr,protypesave,returnables,retday,makeupitemstr)

                                                if (isInserted == true) {
                                                } else {
                                                }
                                                try{
                                                    pDialogs!!.dismiss()
                                                }
                                                catch (e:Exception)
                                                {

                                                }
                                                Toast.makeText(applicationContext, "Disabled", Toast.LENGTH_LONG).show()
                                                val o = Intent(this@MainActivityScroll, MainProductlistActivity::class.java)

                                                o.putExtra("frm_main", "main")


                                                o.putExtra("addpro", addpro)
                                                o.putExtra("editpro", editepro)
                                                o.putExtra("deletepro", deletepro)
                                                o.putExtra("viewpro", viewpro)
                                                o.putExtra("importpro", importpro)
                                                o.putExtra("exportpro", exportpro)
                                                o.putExtra("changestock", stockin_hand)
                                                o.putExtra("skey", branchky)

                                                startActivity(o)
                                                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                                finish()


                                            }
                                }
                                setNegativeButton("No") { dialog, whichButton ->
                                    dialog.dismiss()
                                }

                                val dialog = builder.create()

                                dialog.show()
                            }
                        }

                    }
                    else if(net_status()==false){
                        Toast.makeText(applicationContext,"No internet connection",Toast.LENGTH_SHORT).show()
                    }
                        true
                    }
                        popup.show()

                }
            }



            else if (deletepro=="false"){
                popup("Disable or Enable")
            }

        })









        currencyradio.isEnabled = false//Disable currency radio button
        currencyradio.setTextColor(getResources().getColor(R.color.lightblue));//Change color of currncy radio
        percenradio.isEnabled = false//Disable prcentage radio button
        percenradio.setTextColor(getResources().getColor(R.color.lightblue));//Change color of percentage radio
        percentageval.isEnabled = false //Disable percentage value

        checkbonus.setOnClickListener {//bonus checkbox click

            if (checkbonus.isChecked == true) {   //if Bonus checked is true

                currencyradio.isEnabled = true //Currency Radio is enabled

                currencyradio.setTextColor(getResources().getColor(R.color.toolbar));//Currency Radio color chage
                currencyradio.isChecked = true
                percenradio.isEnabled = true
                percentageval.isEnabled = true


                percenradio.setTextColor(getResources().getColor(R.color.toolbar));


            }
            if (checkbonus.isChecked == false) {
                currencyradio.isEnabled = false
                currencyradio.setTextColor(getResources().getColor(R.color.lightblue));
                currencyradio.isChecked = false
                percenradio.isEnabled = false
                percenradio.setTextColor(getResources().getColor(R.color.lightblue));
                percenradio.isChecked = false
                percentageval.isEnabled = false

            }
        }

        currencyradio.setOnClickListener {
            if (currencyradio.isChecked == true) {
                percenradio.isChecked = false
                percentageval.isEnabled = true

                currencyradio.setTextColor(getResources().getColor(R.color.toolbar))
                percenradio.setTextColor(getResources().getColor(R.color.lightblue));

            }
        }


        percenradio.setOnClickListener {

            if (percenradio.isChecked == true) {
                currencyradio.isChecked = false
                percentageval.isEnabled = true
                percenradio.setTextColor(getResources().getColor(R.color.toolbar));
                currencyradio.setTextColor(getResources().getColor(R.color.lightblue));
            }
        }
        //Tax Checkbox
        taxcheck.setOnCheckedChangeListener { compoundButton, b -> //Taxable click

            if (taxcheck.isChecked==true){ //Taxable ischecked true
                intgst.isEnabled=true
                cess.isEnabled=true
                centgst.isEnabled=false
                stategst.isEnabled=false
            }else{
                intgst.isEnabled=false
                intgst.setText("")
                cess.isEnabled=false
                cess.setText("")
                centgst.isEnabled=false
                centgst.setText("")
                stategst.isEnabled=false
                stategst.setText("")
               mrp.setText(price.text.toString())

            }
        }
//Price



        //During price edittext changelitener which calculates the price with gst and cess values
        price.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {
                errorproprice.visibility = View.INVISIBLE
                var pri : Float; var igst : Float; var ces : Float;
                if (pr.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=pr.toString().toFloat()
                }
                if (intgst.text.isEmpty()){
                    igst=0.0F
                }else{
                    igst =intgst.text.toString().replace("%","").toFloat()
                }
                if (cess.text.isEmpty()){
                    ces = 0.0F
                }else{
                    try {
                        ces = cess.text.toString().replace("%", "").toFloat()
                        cesscal=ces
                    }
                    catch (e:Exception){

                    }
                }

                //cgst & sgst
                val ans =igst/2
                centgst.setText("$ans"+"%")
                stategst.setText("$ans"+"%")

                //tax total
                val ttot = (pri*igst)/100
                taxtot.setText((String.format("%.2f",ttot)))

                //cess total
                val cesstot = (pri*cesscal)/100
                cessvalue.setText((String.format("%.2f",cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                mrp.setText((String.format("%.2f",g)))

              /*  if(id.text.isNotEmpty()){
                    cntpri+=1
                }


                if((cntpri>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"


                if((cntpri==1)&&(listcome=="yes"))
                {
                    commonlisteners=""

                        }*/



            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                if(price.text.toString().isEmpty()){
                    commonlisteners=""
                }

            }
        })

//Intagrated Tax
        //During intgst edittext changelitener which calculates the price with gst and cess values
        intgst.addTextChangedListener(object : TextWatcher {
            var hint: Boolean = false
            override fun onTextChanged(ig: CharSequence, start: Int, before: Int, count: Int) {
                intgst.setTextSize(14F);
                var pri : Float; var igst : Float; var ces : Float;
                if (price.text.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=price.text.toString().toFloat()
                }
                if (ig.isEmpty()){
                    igst=0.0F
                }else{
                    igst =ig.toString().replace("%","").toFloat()
                }
                if (cess.text.isEmpty()){
                    ces = 0.0F
                }else {
                    try {
                        ces = cess.toString().replace("%", "").toFloat()
                        cesscal = ces
                    } catch (e: Exception) {

                    }
                }

                //cgst & sgst
                val ans =igst/2
                centgst.setTextSize(14F);
                stategst.setTextSize(14F);
                centgst.setText("$ans"+"%")
                stategst.setText("$ans"+"%")

                //tax total
                val ttot = (pri*igst)/100
                taxtot.setText((String.format("%.2f",ttot)))

                //cess total
                val cesstot = (pri*cesscal)/100
                cessvalue.setText((String.format("%.2f",cesstot)))

                //gross total
                val g = ttot + pri + cesstot
                mrp.setText((String.format("%.2f",g)))
               /* if(id.text.isNotEmpty()){
                    cntigst+=1
                }


                if((cntigst>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"

                if((cntigst==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {


            }
            override fun afterTextChanged(s: Editable)
            {
                if(intgst.text.toString().isEmpty()){
                    commonlisteners=""
                }
            }
        })
//cess
        //During cess edittext changelitener which calculates the price with gst and cess values

        cess.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(cess: CharSequence, start: Int, before: Int, count: Int) {
                var pri : Float; var igst : Float; var ces : Float;
                if (price.text.isEmpty()){
                    pri = 0.0F
                }else{
                    pri=price.text.toString().toFloat()
                }
                if (intgst.text.isEmpty()){
                    igst=0.0F
                }else{
                    igst =intgst.text.toString().replace("%","").toFloat()
                }
                if (cess.isEmpty()){
                    ces = 0.0F
                }else{
                    try {
                        ces = cess.toString().replace("%", "").toFloat()
                        cesscal = ces
                    }
                    catch(e:Exception){

                    }
                }

                //cgst & sgst
                val ans =igst/2
                stategst.setTextSize(14F)
                centgst.setTextSize(14F)
                centgst.setText("$ans"+"%")
                stategst.setText("$ans"+"%")

                //tax total
                val ttot = (pri*igst)/100
                taxtot.setText((String.format("%.2f",ttot)))

                //cess total
                val cesstot = (pri*cesscal)/100
                cessvalue.setText((String.format("%.2f",cesstot)))

                //gross total
                val g = ttot + pri + cesstot
               mrp.setText((String.format("%.2f",g)))

                /*if(id.text.isNotEmpty()){
                    cntcess+=1
                }


                if((cntcess>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"


                if((cntcess==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
                if(cess.text.toString().isEmpty()){
                    commonlisteners=""
                }
            }
        })


        if(checkbonus.isEnabled==true) {
            if (checkbonus.isChecked == true) {
                percenradio.isEnabled = true
                currencyradio.isEnabled = true
                percentageval.isEnabled = true
                currencyradio.setTextColor(Color.parseColor("#546e7a"))
                percenradio.setTextColor(Color.parseColor("#546e7a"))
                percentageval.setTextColor(Color.parseColor("#546e7a"))
            } else {
                percenradio.isEnabled = false
                percentageval.isEnabled = false
                currencyradio.isEnabled = false
                currencyradio.setTextColor(Color.parseColor("#d3d3d3"))
                percentageval.setTextColor(Color.parseColor("#d3d3d3"))
                percentageval.setTextColor(Color.parseColor("#d3d3d3"))
            }
        }
        checkbonus.setOnCheckedChangeListener { button, state ->
            if(checkbonus.isEnabled==true) {
                if (state == true) {
                    percenradio.isEnabled = true
                    currencyradio.isEnabled = true
                    percentageval.isEnabled = true
                    percenradio.setTextColor(Color.parseColor("#546e7a"))
                    currencyradio.setTextColor(Color.parseColor("#546e7a"))
                    percentageval.setTextColor(Color.parseColor("#546e7a"))
                } else {
                    percenradio.isEnabled = false
                    percentageval.isEnabled = false
                    currencyradio.isEnabled = false
                    currencyradio.setTextColor(Color.parseColor("#d3d3d3"))
                    percenradio.setTextColor(Color.parseColor("#d3d3d3"))
                    percentageval.setTextColor(Color.parseColor("#d3d3d3"))
                }
            }
        }
        currencyradio.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                percenradio.isChecked = false
                percenradio.setTextColor(Color.parseColor("#d3d3d3"))
                percentageval.setText("")
            } else if (state == false) {
                percenradio.isChecked = true
                percenradio.setTextColor(Color.parseColor("#546e7a"))
                percentageval.setText("")
            }
        }
        percenradio.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                currencyradio.isChecked = false
                currencyradio.setTextColor(Color.parseColor("#d3d3d3"))
                percentageval.setText("")
            } else if (state == false) {
                currencyradio.isChecked = true
                currencyradio.setTextColor(Color.parseColor("#546e7a"))
                percentageval.setText("")
            }
        }


        retail.setOnCheckedChangeListener { button, state ->
            if (state == true) {
             reterr.visibility=View.INVISIBLE
                bkbxerr.visibility=View.INVISIBLE





            } else if (state == false) {

            }
        }
        backbox.setOnCheckedChangeListener { button, state ->
            if (state == true) {
                reterr.visibility=View.INVISIBLE
                bkbxerr.visibility=View.INVISIBLE





            } else if (state == false) {

            }
        }



        pname.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
                errorpronm.visibility = View.INVISIBLE
/*
                if(id.text.isNotEmpty()){
                    cntnm+=1
                }


                if((cntnm>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"


                if((cntnm==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {}

            override fun afterTextChanged(arg0: Editable) {

                if(pname.text.toString().isEmpty()){
                    commonlisteners=""
                }
            }

        })



        //Update









        edit.setOnClickListener {  //If edit imagebutton clikcs,All views becomes enabled.
            if (editepro == "true" || editepro.isNullOrEmpty()) {
                editcli="clicked"
                edit.visibility = View.INVISIBLE
                vert.visibility=View.VISIBLE
                save.visibility = View.VISIBLE
                gallery.visibility=View.VISIBLE
                save.setText("SAVE")
                pname.isEnabled = true
                imageButton2.isEnabled=true
                imageView41.isEnabled=true
                pid.isEnabled = false
                vol.isEnabled = true
                unitspinner.isEnabled = true
                manu.isEnabled = true
                cate.isEnabled = true
                bcodeid.isEnabled = true
                hsc.isEnabled = true
                hscdes.isEnabled = true
                price.isEnabled = true
                taxcheck.isEnabled = true
                intgst.isEnabled = true
                cess.isEnabled = true
                centgst.isEnabled = true
                stategst.isEnabled = true
                taxtot.isEnabled = true
                cessvalue.isEnabled = true
                mrp.isEnabled = true
                checkcommision.isEnabled = true
                checkbonus.isEnabled = true
                currencyradio.isEnabled = true
                percenradio.isEnabled = true
                percentageval.isEnabled = true
                maxstock.isEnabled = true
                minstock.isEnabled = true
                stockhand.isEnabled = true
                des_box.isEnabled = true
                retail.isEnabled=true
                backbox.isEnabled=true

            } else if (editepro == "false") {
                popup("edit")
            }
        }

        gallery.setOnClickListener { //Navigate to multi select images
            scroll2_slider.removeAllSliders()
            println("GALLSERYYYYYYYYYYYYY")
            gallery.isEnabled = false
            val b = Intent(this@MainActivityScroll, AddImagesActivity_prod::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)

            b.putExtra("edtcli",editcli)

            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("listenersave", commonlisteners)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)

            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)

           b.putExtra("addpro",addpro)
           b.putExtra("editpro",editepro)
           b.putExtra("deletepro",deletepro)
           b.putExtra("viewpro",viewpro)
           b.putExtra("importpro",importpro)
           b.putExtra("exportpro",exportpro)
            b.putExtra("changestock", stockin_hand)

            startActivityForResult(b, 0)
            gallery.isEnabled = true
        }


        scroll2_slider.setOnClickListener { //Navigate to multi select images
            scroll2_slider.removeAllSliders()
            scroll2_slider.isEnabled = false
            val b = Intent(this@MainActivityScroll, AddImagesActivity_prod::class.java)
            b.putExtra("id", id.text.toString())
            b.putExtra("f1", f1)
            b.putExtra("fn1", fn1)
            b.putExtra("s1", s1)
            b.putExtra("sn1", sn1)
            b.putExtra("t1", t1)
            b.putExtra("tn1", tn1)
            b.putExtra("fo1", fo1)
            b.putExtra("fon1", fon1)
            b.putExtra("fif1", fif1)
            b.putExtra("fifn1", fifn1)
            b.putExtra("edtcli",editcli)

            b.putExtra("f1high", img1urlhigh)
            b.putExtra("fn1high", img1nhigh)
            b.putExtra("s1high", img2urlhigh)
            b.putExtra("sn1high", img2nhigh)
            b.putExtra("t1high", img3urlhigh)
            b.putExtra("tn1high",img3nhigh)
            b.putExtra("fo1high", img4urlhigh)
            b.putExtra("fon1high", img4nhigh)
            b.putExtra("fif1high", img5urlhigh)
            b.putExtra("fifn1high",img5nhigh)
            b.putExtra("mresult", mresultsarr)
            b.putExtra("cacnm1", cacnm1)
            b.putExtra("listenersave", commonlisteners)
            b.putExtra("f1edithigh", f1edithigh)
            b.putExtra("fn1edithigh", fn1edithigh)
            b.putExtra("s1edithigh", s1edithigh)
            b.putExtra("sn1edithigh", sn1edithigh)
            b.putExtra("t1edithigh", t1edithigh)
            b.putExtra("tn1edithigh", tn1edithigh)
            b.putExtra("fo1edithigh", fo1edithigh)
            b.putExtra("fon1edithigh", fon1edithigh)
            b.putExtra("fif1edithigh", fif1edithigh)
            b.putExtra("fifn1edithigh", fifn1edithigh)

            b.putExtra("f1edit", f1edit)
            b.putExtra("fn1edit", fn1edit)
            b.putExtra("s1edit", s1edit)
            b.putExtra("sn1edit", sn1edit)
            b.putExtra("t1edit", t1edit)
            b.putExtra("tn1edit", tn1edit)
            b.putExtra("fo1edit", fo1edit)
            b.putExtra("fon1edit", fon1edit)
            b.putExtra("fif1edit", fif1edit)
            b.putExtra("fifn1edit", fifn1edit)

            b.putExtra("addpro",addpro)
            b.putExtra("editpro",editepro)
            b.putExtra("deletepro",deletepro)
            b.putExtra("viewpro",viewpro)
            b.putExtra("importpro",importpro)
            b.putExtra("exportpro",exportpro)
            b.putExtra("changestock", stockin_hand)

            startActivityForResult(b, 0)
            scroll2_slider.isEnabled = true
        }


        save.setOnClickListener { //save click

            if (net_status() == true) {

                println("ID IRUKU" + id.text.toString())
                println("ID IRUKUSAVE" + idsmy.text.toString())


                if (pname.length() == 0) { //If pname edittext field length=0 then  'Required field*' error displayed
                    errorpronm.visibility = View.VISIBLE

                    errorpronm.setText("Required field*")
                    Toast.makeText(applicationContext, "Please fill required fields", Toast.LENGTH_SHORT).show()
                }
                if (price.length() == 0) { //If price edittext field length=0 then  'Required field*' error displayed
                    errorproprice.visibility = View.VISIBLE

                    errorproprice.setText("Required field*")
                    Toast.makeText(applicationContext, "Please fill required fields", Toast.LENGTH_SHORT).show()
                }

                if (retail.isChecked==false&&backbox.isChecked==false) { //If retail checkbox,backbox checkbox is not checked then 'Required field*' error displayed
                    reterr.visibility = View.VISIBLE

                    bkbxerr.visibility=View.VISIBLE



                    Toast.makeText(applicationContext, "Please Check retail or backbar", Toast.LENGTH_SHORT).show()
                }



                if ((idsmy.text != "") && (errorpronm.visibility == View.INVISIBLE) && (errorproprice.visibility == View.INVISIBLE)&&((reterr.visibility==View.INVISIBLE&&bkbxerr.visibility==View.INVISIBLE))) {
                    println("WHERE IT IS COME ON START" + id.text.toString())

                    onStarClicked1()  //Insert to online db and sql db if all error views are invisible
                }

                if(id.text.isNotEmpty()) {   ////Update to online db and sql db if all error views are invisible

                    if ((pnamevalidate != pname.text.toString()) || (volvalidate != vol.text.toString()) || (bcodeidvalidate != bcodeid.text.toString()) ||
                            (hscvalidate != hsc.text.toString()) || (hscdesvalidate != hscdes.text.toString()) || (maincatvalidate != cate.selectedItem.toString()) ||
                            (subcatvalidate != manu.selectedItem.toString()) || (listvalidate != unitspinner.selectedItem.toString()) || (pricevalidate != price.text.toString())
                            || (taxcheckvalidate != taxcheck.isChecked.toString()) || (intgstvalidate != intgst.text.toString()) || (cessvaluevalidate != cess.text.toString())
                            || (checkcommisionvalidate != checkcommision.isChecked.toString())||(retailvalidate!=retail.isChecked.toString())||(backbarvalidate!=backbox.isChecked.toString())||((returnablevalidate!="false")) || (percentagevalvalidate != percentageval.text.toString()) || (maxstockvalidate != maxstock.text.toString())
                            || (minstockvalidate != minstock.text.toString()) || (des_boxvalidate != des_box.text.toString()) || (stockhandvalidate != stockhand.text.toString())) {

                        commonlisteners = "change"
                        println("ONBACK URL1 NOT EQUAL" + f1)

                    } else if (((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || (fo1 != fo1edit) || (fif1 != fif1edit))) {
                        println("ONBACK URL1 EDIT NOT EQUAl" + f1)
                        commonlisteners = "change"
                    }


                    var npid = id.text.toString()
                    var pid = (pid.text).toString()
                    var pname = (pname.text).toString()
                    var bcode = (bcodeid.text).toString()
                    var pdes = (hscdes.text).toString()
                    var orikys = branchky
                    var weight = (vol.text).toString()
                    var psac = (hsc.text).toString()


                    var minstock = (minstock.text).toString()
                    var maxstock = (maxstock.text).toString()
                    var price = (price.text).toString()
                    var taxable = taxcheck.isChecked.toString()
                    var igst = (intgst.text).toString()
                    var cgst = (centgst.text).toString()
                    var sgst = (stategst.text).toString()
                    var cess = (cess.text).toString()
                    var taxtotal = (taxtot.text).toString()
                    var cessval = (cessvalue.text).toString()
                    var currency = currencyradio.isChecked.toString()
                    var percentage = percenradio.isChecked.toString()
                    var percentagevalue = (percentageval.text).toString()
                    var product_dec = (des_box.text).toString()
                    var mrP = (mrp.text).toString()
                    var cate = cate.selectedItem.toString()
                    var manufacture = manu.selectedItem.toString()
                    var ut = unitspinner.selectedItem.toString()
                    var consold = checkbonus.isChecked.toString()
                    var comm = checkcommision.isChecked.toString()
                    var status = (disable.text).toString()



                    var ret=retail.isChecked.toString()
                    var bkbr=backbox.isChecked.toString()
                    var returnables="false"
                    var retdate=""
                    if (f1.isEmpty()) {

                    }


                    if (stockhand.text.toString().isNotEmpty()) {
                        var stockonhand = (stockhand.text).toString()
                        stkhand = stockonhand
                    } else {

                        stkhand = "0"
                    }


                        protypesave=""





                    val img1n = fn1
                    val img2n = sn1
                    val img3n = tn1
                    val img4n = fon1
                    val img5n = fifn1
                    val img1url = f1
                    val img2url = s1
                    val img3url = t1
                    val img4url = fo1
                    val img5url = fif1


                    println("WHERE IT IS COMEOR" + id.text.toString())
                    val data = s(p_id = pid, p_nm = pname, bc = bcode, desc = pdes, wg_vol = weight, hsn = psac, ctgy = cate,
                            mfr = manufacture, ut = ut, min_stk = minstock, price = price, mx_stk = maxstock, cn_sold = consold,
                            emp_com = comm, taxchk = taxable, igst = igst, cgst = cgst, sgst = sgst, cess = cess, taxtot = taxtotal,
                            cesstot = cessval, mrp = mrP, curency = currency, status = status, percentage = percentage,retail = ret,backbar = bkbr,
                            percentageval = percentagevalue, product_desc = product_dec, stock_hand = stkhand,
                            img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = img1url,
                            img2url = img2url, img3url = img3url, img4url = img4url, img5url = img5url, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                            img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh,
                            img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh, orikys = orikys,supp_key = suppky,supp_name = suppname,protype = protypesave,returnable = returnables,returnableday = retdate,makeupitem = makeupitemstr)




                    if ((id.text != "") && (errorpronm.visibility == View.INVISIBLE) && (errorproprice.visibility == View.INVISIBLE)&&((reterr.visibility==View.INVISIBLE&&bkbxerr.visibility==View.INVISIBLE))&&(commonlisteners=="change")) {

                        pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                        pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                        pDialogs!!.setTitleText("Saving...")
                        pDialogs!!.setCancelable(false)
                        pDialogs!!.show();


                        //Update to local sql table
                        val db = FirebaseFirestore.getInstance()
                        val isInserted = myDb.updatedata(npid, pid, pname, bcode, pdes, weight, psac, cate,
                                manufacture, ut, minstock, price, maxstock, consold, comm, taxable, igst, cgst, sgst, cess, taxtotal, cessval,
                                mrP, currency, status, percentage,percentagevalue, product_dec, stkhand, img1n, img2n, img3n,
                                img4n, img5n, img1url, img2url, img3url, img4url,img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                                img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys,ret,bkbr,protypesave,returnables,retdate,makeupitemstr)

                        if (isInserted == true) {
                            Toast.makeText(this, "Saving...", Toast.LENGTH_SHORT).show()
                        } else {
                        }

                        db.collection("product").document(id.text.toString())

                                .set(data)  //Update to online db
                                .addOnSuccessListener {
                                    val map = mutableMapOf<String, Any?>()
                                    map.put("$branchky", stkhand)
                                    db.collection("product").document(id.text.toString())
                                            .update(map)
                                            .addOnCompleteListener {
                                                val database = FirebaseDatabase.getInstance()


                                                if (stockhand.text.toString().isNotEmpty()) {
                                                    val service_access = SessionManagement(this)
                                                    val user = service_access.userDetails

                                                    // name
                                                    val name = user[SessionManagement.KEY_NAME]
                                                    brkey = name.toString()
                                                    for (i in 0 until brnchkeys.size) {
                                                        if (brnchkeys[i].toString() == brkey) {
                                                            println("BRANCH KEY" + brkey)
                                                            println("BRANCH KEY ARRAY" + brnchkeys[i])

                                                            println("STOCK HAND" + stockhand.text.toString())
                                                            println("ID" + id.text.toString())

                                                            var ad = brnchkeys[i]  //Get stockonhand values and update to online db

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$ad", stockhand.text.toString())
                                                            db.collection("product").document(id.text.toString())
                                                                    .set(map, SetOptions.merge())
                                                                    .addOnSuccessListener {

                                                                    }


                                                        } else {

                                                            val database = FirebaseDatabase.getInstance()
                                                            val myRef = database.getReference(id.text.toString() + "_" + brnchkeys[i])

                                                            val messageListener = object : ValueEventListener {

                                                                override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                    if (dataSnapshot.exists()) {

                                                                        val message = dataSnapshot.value

                                                                        var ads = brnchkeys[i]

                                                                        val map = mutableMapOf<String, Any?>()

                                                                        map.put("$ads", message)
                                                                        db.collection("product").document(id.text.toString())
                                                                                .update(map)
                                                                                .addOnSuccessListener {

                                                                                }

                                                                    }
                                                                }

                                                                override fun onCancelled(databaseError: DatabaseError) {
                                                                    // Failed to read value
                                                                }
                                                            }

                                                            myRef!!.addValueEventListener(messageListener)


                                                        }

                                                    }
                                                } else {

                                                    stkhand = "0"
                                                }

                                                if (id.text.toString().isNotEmpty()) {
                                                    val myRef = database.getReference(id.text.toString() + "_" + branchky)

                                                    myRef.setValue(stockhand.text.toString())
                                                } else {
                                                    val myRef = database.getReference(idsmy.text.toString() + "_" + branchky)

                                                    myRef.setValue(stockhand.text.toString())
                                                }
                                            }
                                            .addOnSuccessListener {


                                                if(suppcome.isNotEmpty()&&suppcome=="supplier"){  //Navigate to supplier's products list activity
                                                    val data = Intent(applicationContext,SupplierSecondmain::class.java)

                                                    // Add the required data to be returned to the MainActivity
                                                    data.putExtra("proky", Arrays.toString(prosave_key))

                                                    // Set the resultCode to Activity.RESULT_OK to
                                                    // indicate a success and attach the Intent
                                                    // which contains our result data
                                                    setResult(Activity.RESULT_OK, data)

                                                    // With finish() we close the AnotherActivity to
                                                    // return to MainActivity
                                                    finish()


                                                    Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()
                                                    try{
                                                        pDialogs!!.dismiss()
                                                    }
                                                    catch (e:Exception)
                                                    {

                                                    }

                                                }

                                                else if(suppcome.isEmpty()) {  //Normal back action

                                                    Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()
                                                    try{
                                                        pDialogs!!.dismiss()
                                                    }
                                                    catch (e:Exception)
                                                    {

                                                    }

                                                    val o = Intent(this@MainActivityScroll, MainProductlistActivity::class.java)

                                                    o.putExtra("frm_main", "main")


                                                    o.putExtra("addpro", addpro)
                                                    o.putExtra("editpro", editepro)
                                                    o.putExtra("deletepro", deletepro)
                                                    o.putExtra("viewpro", viewpro)
                                                    o.putExtra("importpro", importpro)
                                                    o.putExtra("exportpro", exportpro)
                                                    o.putExtra("changestock", stockin_hand)
                                                    o.putExtra("skey", branchky)

                                                    startActivity(o)
                                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                                    finish()
                                                }
                                            }


                                }

                                .addOnFailureListener {
                                    Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show()
                                    try{
                                        pDialogs!!.dismiss()
                                    }
                                    catch (e:Exception)
                                    {

                                    }
                                }


                    } else {
                        if (id.text.toString().isEmpty()) {
                            Toast.makeText(applicationContext, "Please fill required fields", Toast.LENGTH_SHORT).show()
                        }
                        else if((id.text.toString().isNotEmpty())&&(commonlisteners.isEmpty())){

                            Toast.makeText(applicationContext, "Nothing happened for save", Toast.LENGTH_SHORT).show()

                        }

                    }
                }

                //Validation for save
            } else {
                Toast.makeText(applicationContext, "Please turn on your connection", Toast.LENGTH_SHORT).show()
            }

        }



        stockhand.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

               /* if(id.text.isNotEmpty()){
                    cntsoh+=1
                }


                if((cntsoh>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"

                if((cntsoh==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


            }

            override fun afterTextChanged(arg0: Editable) {
               /* if(stockhand.text.toString().isEmpty()){
                    commonlisteners=""
                }*/
            }

        })

        maxstock.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

              /*  if(id.text.isNotEmpty()){
                    cntmx+=1
                }


                if((cntmx>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"


                if((cntmx==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


            }

            override fun afterTextChanged(arg0: Editable) {

                /*if(maxstock.text.toString().isEmpty()){
                    commonlisteners=""
                }*/
            }

        })

        minstock.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

             /*   if(id.text.isNotEmpty()){
                    cntmin+=1
                }


                if((cntmin>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"

                if((cntmin==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


            }

            override fun afterTextChanged(arg0: Editable) {
/*
                if(minstock.text.toString().isEmpty()){
                    commonlisteners=""
                }*/
            }

        })




        hscdes.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

             /*   if(id.text.isNotEmpty()){
                    cnthscdes+=1
                }


                if((cnthscdes>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"

                if((cnthscdes==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


            }

            override fun afterTextChanged(arg0: Editable) {

                /*if(hscdes.text.toString().isEmpty()){
                    commonlisteners=""
                }*/
            }

        })
        hsc.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {

             /*   if(id.text.isNotEmpty()){
                    cnthsc+=1
                }


                if((cnthsc>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"

                if((cnthsc==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/
            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


            }

            override fun afterTextChanged(arg0: Editable) {

            }

        })


        percentageval.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(pr: CharSequence, start: Int, before: Int, count: Int) {


            }
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun afterTextChanged(s: Editable) {
                var pri:Float
                if(currencyradio.isChecked==true){
                    if(s.isNotEmpty()){

                        pri=s.toString().toFloat()
                        if((price.text.toString().isNotEmpty())){
                           if (pri>price.text.toString().toFloat()) {  //If  currency value is higher than price alert popup
                               percentageval.isEnabled = false
                               val builder = AlertDialog.Builder(this@MainActivityScroll)
                               with(builder) {
                                   setTitle("Exceed")
                                   setMessage("Given value is higher than price.")
                                   builder.setCancelable(false)

                                   setPositiveButton("Ok") { dialog, whichButton ->
                                       percentageval.isEnabled = true
                                       percentageval.setText("")
                                       dialog.dismiss()
                                   }
                                   val dialog = builder.create()
                                   dialog.show()
                               }
                           }
                        }
                        else{
                            val builder = AlertDialog.Builder(this@MainActivityScroll)
                            with(builder) {
                                setTitle("Alert")
                                setMessage("please fill price field before currency")
                                builder.setCancelable(false)

                                setPositiveButton("Ok") { dialog, whichButton ->
                                    percentageval.isEnabled=true
                                    percentageval.setText("")
                                    dialog.dismiss()
                                }
                                val dialog = builder.create()
                                dialog.show()
                            }
                        }
                    }
                }
                else if(percenradio.isChecked==true){
                    if(s.isNotEmpty()){
                        pri=s.toString().toFloat()
                        if(pri>100){   //If  percentage value is higher than price alert popup
                            percentageval.isEnabled=false
                            val builder = AlertDialog.Builder(this@MainActivityScroll)
                            with(builder) {
                                setTitle("Exceed")
                                setMessage("Given percentage value is greater than 100.")
                                builder.setCancelable(false)
                                setPositiveButton("Ok") { dialog, whichButton ->
                                    percentageval.isEnabled=true

                                    percentageval.setText("")
                                    dialog.dismiss()
                                }
                                val dialog = builder.create()
                                dialog.show()
                            }
                        }

                    }
                }
            }
        })


        vol.addTextChangedListener(object : TextWatcher {

            override fun onTextChanged(cs: CharSequence, arg1: Int, arg2: Int, arg3: Int) {
/*
                if(id.text.isNotEmpty()){
                    cntvol+=1
                }


                if((cntvol>=2)&&(id.text.isNotEmpty())){
                    commonlisteners="change"
                }

                commonlisteners="change"

                if((cntvol==1)&&(listcome=="yes"))
                {
                    commonlisteners=""
                }*/

            }

            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int, arg3: Int) {


            }

            override fun afterTextChanged(arg0: Editable) {
                if(vol.text.toString().isEmpty()){
                    commonlisteners=""
                }
            }

        })





        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERMISSION_REQUEST)
        }
        bcodeid.setOnFocusChangeListener(View.OnFocusChangeListener { v, hasFocus ->

            if((bcodeid.length() == 0)&&(bcodeid.isFocused==true))  {
                val b = Intent(this@MainActivityScroll, ScanProductActivity::class.java)
                /*var npid = id.text.toString()
                var pids = (pid.text).toString()
                var pname = (pname.text).toString()
                var bcode = (bcodeid.text).toString()
                var pdes = (hscdes.text).toString()

                var weight = (vol.text).toString()
                var psac = (hsc.text).toString()
                if(stockhand.text.toString().isNotEmpty()) {
                    var stockonhand = (stockhand.text).toString()
                    stkhand=stockonhand
                }
                else{

                    stkhand="0"
                }


                var minstock = (minstock.text).toString()
                var maxstock = (maxstock.text).toString()
                var price = (price.text).toString()
                var taxable = taxcheck.isChecked.toString()
                var igst = (intgst.text).toString()
                var cgst = (centgst.text).toString()
                var sgst = (stategst.text).toString()
                var cess = (cess.text).toString()
                var taxtotal = (taxtot.text).toString()
                var cessval = (cessvalue.text).toString()
                var currency = currencyradio.isChecked.toString()
                var percentage = percenradio.isChecked.toString()
                var percentagevalue = (percentageval.text).toString()
                var product_dec = (des_box.text).toString()
                var mrP = (mrp.text).toString()
                var cate = cate.selectedItem.toString()
                var manufacture = manu.selectedItem.toString()
                var ut = unitspinner.selectedItem.toString()
                var consold = checkbonus.isChecked.toString()
                var comm = checkcommision.isChecked.toString()
                var status=(disable.text).toString()
                var idss=idsmy.text.toString()
                val img1n=fn1
                val img2n=sn1
                val img3n=tn1
                val img4n=fon1
                val img5n=fifn1
                val img1url=f1
                val img2url=s1
                val img3url=t1
                val img4url=fo1
                val img5url=fif1
                val orikys=branchky
                b.putExtra("npid",npid)
                b.putExtra("pids",pids)
                b.putExtra("pname",pname)
                b.putExtra("bcode",bcode)
                b.putExtra("pdes",pdes)
                b.putExtra("weight",weight)
                b.putExtra("psac",psac)
                b.putExtra("stkhand",stkhand)
                b.putExtra("minstock",minstock)
                b.putExtra("maxstock",maxstock)
                b.putExtra("price",price)
                b.putExtra("taxable",taxable)
                b.putExtra("igst",igst)
                b.putExtra("cgst",cgst)
                b.putExtra("sgst",sgst)
                b.putExtra("cess",cess)
                b.putExtra("taxtotal",taxtotal)
                b.putExtra("cessval",cessval)
                b.putExtra("currency",currency)
                b.putExtra("percentage",percentage)
                b.putExtra("percentagevalue",percentagevalue)
                b.putExtra("product_dec",product_dec)
                b.putExtra("mrP",mrP)
                b.putExtra("cate",cate)
                b.putExtra("manufacture",manufacture)
                b.putExtra("ut",ut)
                b.putExtra("consold",consold)
                b.putExtra("comm",comm)
                b.putExtra("status",status)
                b.putExtra("img1n",img1n)
                b.putExtra("img2n",img2n)
                b.putExtra("img3n",img3n)
                b.putExtra("img4n",img4n)
                b.putExtra("img5n",img5n)
                b.putExtra("img1url",img1url)
                b.putExtra("img2url",img2url)
                b.putExtra("img3url",img3url)
                b.putExtra("img4url",img4url)
                b.putExtra("img5url",img5url)
                b.putExtra("orikys",orikys)
                b.putExtra("idss",idss)*/

                startActivityForResult(b, 1)

            } else {


            }

        })
        bcodeid.addTextChangedListener(object : TextWatcher {

            override fun afterTextChanged(s: Editable) {
                if((bcodeid.length() == 0)&&(bcodeid.isFocused==true))
                {



                    //Navigate to barcode scan activity

                    val b = Intent(this@MainActivityScroll, ScanProductActivity::class.java)
                    /*var npid = id.text.toString()
                    var pids = (pid.text).toString()
                    var pname = (pname.text).toString()
                    var bcode = (bcodeid.text).toString()
                    var pdes = (hscdes.text).toString()

                    var weight = (vol.text).toString()
                    var psac = (hsc.text).toString()
                    if(stockhand.text.toString().isNotEmpty()) {
                        var stockonhand = (stockhand.text).toString()
                        stkhand=stockonhand
                    }
                    else{

                        stkhand="0"
                    }


                    var minstock = (minstock.text).toString()
                    var maxstock = (maxstock.text).toString()
                    var price = (price.text).toString()
                    var taxable = taxcheck.isChecked.toString()
                    var igst = (intgst.text).toString()
                    var cgst = (centgst.text).toString()
                    var sgst = (stategst.text).toString()
                    var cess = (cess.text).toString()
                    var taxtotal = (taxtot.text).toString()
                    var cessval = (cessvalue.text).toString()
                    var currency = currencyradio.isChecked.toString()
                    var percentage = percenradio.isChecked.toString()
                    var percentagevalue = (percentageval.text).toString()
                    var product_dec = (des_box.text).toString()
                    var mrP = (mrp.text).toString()
                    var cate = cate.selectedItem.toString()
                    var manufacture = manu.selectedItem.toString()
                    var ut = unitspinner.selectedItem.toString()
                    var consold = checkbonus.isChecked.toString()
                    var comm = checkcommision.isChecked.toString()
                    var status=(disable.text).toString()
                    var idss=idsmy.text.toString()
                    val img1n=fn1
                    val img2n=sn1
                    val img3n=tn1
                    val img4n=fon1
                    val img5n=fifn1
                    val img1url=f1
                    val img2url=s1
                    val img3url=t1
                    val img4url=fo1
                    val img5url=fif1
                    val orikys=branchky
                    b.putExtra("npid",npid)
                    b.putExtra("pids",pids)
                    b.putExtra("pname",pname)
                    b.putExtra("bcode",bcode)
                    b.putExtra("pdes",pdes)
                    b.putExtra("weight",weight)
                    b.putExtra("psac",psac)
                    b.putExtra("stkhand",stkhand)
                    b.putExtra("minstock",minstock)
                    b.putExtra("maxstock",maxstock)
                    b.putExtra("price",price)
                    b.putExtra("taxable",taxable)
                    b.putExtra("igst",igst)
                    b.putExtra("cgst",cgst)
                    b.putExtra("sgst",sgst)
                    b.putExtra("cess",cess)
                    b.putExtra("taxtotal",taxtotal)
                    b.putExtra("cessval",cessval)
                    b.putExtra("currency",currency)
                    b.putExtra("percentage",percentage)
                    b.putExtra("percentagevalue",percentagevalue)
                    b.putExtra("product_dec",product_dec)
                    b.putExtra("mrP",mrP)
                    b.putExtra("cate",cate)
                    b.putExtra("manufacture",manufacture)
                    b.putExtra("ut",ut)
                    b.putExtra("consold",consold)
                    b.putExtra("comm",comm)
                    b.putExtra("status",status)
                    b.putExtra("img1n",img1n)
                    b.putExtra("img2n",img2n)
                    b.putExtra("img3n",img3n)
                    b.putExtra("img4n",img4n)
                    b.putExtra("img5n",img5n)
                    b.putExtra("img1url",img1url)
                    b.putExtra("img2url",img2url)
                    b.putExtra("img3url",img3url)
                    b.putExtra("img4url",img4url)
                    b.putExtra("img5url",img5url)
                    b.putExtra("orikys",orikys)
                    b.putExtra("idss",idss)*/
                    startActivityForResult(b, 1)

                }
             /*   if(bcodeid.text.toString().isEmpty()){
                    commonlisteners=""
                }
                if(bcodeid.text.toString().isNotEmpty()){
                    commonlisteners="change"
                }*/

            }

            override fun beforeTextChanged(s: CharSequence, start: Int,
                                           count: Int, after: Int) {


            }

            override fun onTextChanged(s: CharSequence, start: Int,
                                       before: Int, count: Int) {

            }
        })


        /* mDemoSlider.setDuration(4000)*/


    }



    //ID GENERARION FUNCTION

    private fun onStarClicked1() {


        if(net_status()==true) {

             pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialogs!!.setTitleText("Preparing...")
            pDialogs!!.setCancelable(false)

            pDialogs!!.show();



            println("INSIDE ONSTARTCLICK")
            data class Count(var number: Int)

            val database = FirebaseDatabase.getInstance()
            val myRef = database.getReference("produtadd")
            myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
                override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                    var p = mutableData.value


                    if (p == null) {
                        p = 1
                    }

                    if (p == 0) {
                        // Unstar the post and remove self from stars
                        p = 1

                    } else {
                        // Star the post and add self to stars
                        p = Integer.parseInt(p.toString()) + 1
                    }

                    // Set value and report transaction success
                    mutableData.value = p
                    //mutableData.setValue(p.number)
                    return com.google.firebase.database.Transaction.success(mutableData)
                }

                override fun onComplete(
                        databaseError: DatabaseError?,
                        b: Boolean,
                        dataSnapshot: DataSnapshot
                ) {

                    println(dataSnapshot)
                    println(dataSnapshot.value)
                    val id = dataSnapshot.value  //Returns the new product's count value


                    prod_insert(id.toString())


                    // Transaction completed
                    // Log.d("", "postTransaction:onComplete:" + databaseError)
                }
            })
        }
        else{
            Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()

        }
    }

   fun prod_insert(id1:String)

   {




       pDialogs!!.setTitleText("Saving...")








           if (pname.length() == 0) {      //If pname edittext field length=0 then  'Required field*' error displayed
               errorpronm.visibility = View.VISIBLE

               errorpronm.setText("Required field*")
           }
           if (price.length() == 0) {      //If price edittext field length=0 then  'Required field*' error displayed
               errorproprice.visibility = View.VISIBLE

               errorproprice.setText("Required field*")
           }
       if (retail.isChecked==false&&backbox.isChecked==false) {   //If retail checkbox,backbox checkbox is not checked then 'Required field*' error displayed
           reterr.visibility = View.VISIBLE

           bkbxerr.visibility=View.VISIBLE


           Toast.makeText(applicationContext, "Please Check retail or backbar", Toast.LENGTH_SHORT).show()
       }
           var npid = idsmy.text.toString()
           var pid = "PRD" + id1
           var pname = (pname.text).toString()
           var bcode = (bcodeid.text).toString()
           var pdes = (hscdes.text).toString()

           var weight = (vol.text).toString()
           var psac = (hsc.text).toString()

           if (stockhand.text.toString().isNotEmpty()) {

               var stockonhand = (stockhand.text).toString()
               stkhand = stockonhand

           } else {

               stkhand = "0"
           }



           protypesave=""


           var minstock = (minstock.text).toString()
           var maxstock = (maxstock.text).toString()
           var price = (price.text).toString()
           var taxable = taxcheck.isChecked.toString()
           var igst = (intgst.text).toString()
           var cgst = (centgst.text).toString()
           var sgst = (stategst.text).toString()
           var cess = (cess.text).toString()
           var taxtotal = (taxtot.text).toString()
           var cessval = (cessvalue.text).toString()
           var currency = currencyradio.isChecked.toString()
           var percentage = percenradio.isChecked.toString()
           var percentagevalue = (percentageval.text).toString()
           var product_dec = (des_box.text).toString()
           var mrP = (mrp.text).toString()
           var cate = cate.selectedItem.toString()
           var manufacture = manu.selectedItem.toString()
           var ut = unitspinner.selectedItem.toString()
           var consold = checkbonus.isChecked.toString()
           var comm = checkcommision.isChecked.toString()
           var status = (disable.text).toString()
           val img1n = fn1
           val img2n = sn1
           val img3n = tn1
           val img4n = fon1
           val img5n = fifn1
           if (f1.isNotEmpty()) {
               val img1url = f1
               imgurls = img1url
           }
           if (f1.isEmpty()) {

           }

       var ret=retail.isChecked.toString()
       var bkbr=backbox.isChecked.toString()
       var returnables="false"
       var retdate=""


           val img2url = s1
           val img3url = t1
           val img4url = fo1
           val img5url = fif1
           var orikys = branchky
           val data = s(p_id = pid, p_nm = pname, bc = bcode, desc = pdes, wg_vol = weight, hsn = psac, ctgy = cate,
                   mfr = manufacture, ut = ut, min_stk = minstock, price = price, mx_stk = maxstock, cn_sold = consold,
                   emp_com = comm, taxchk = taxable, igst = igst, cgst = cgst, sgst = sgst, cess = cess, taxtot = taxtotal,
                   cesstot = cessval, mrp = mrP, curency = currency, status = status, percentage = percentage, retail = ret,backbar = bkbr, percentageval = percentagevalue,
                   product_desc = product_dec, stock_hand = stkhand, img1n = img1n, img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = imgurls,
                   img2url = img2url, img3url = img3url, img4url = img4url, img5url = img5url, img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh, img4nhigh = img4nhigh, img5nhigh = img5nhigh,
                   img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh, img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh,
                   orikys = branchky,supp_key = suppky,supp_name = suppname,protype = protypesave,returnable = returnables,returnableday = retdate,makeupitem = makeupitemstr)
           val TAG = "some"
           /*    save_progress.visibility = android.view.View.VISIBLE*/



           save.isEnabled = false
           var db = FirebaseFirestore.getInstance()




   db.collection("product").document(idsmy.text.toString())
            .set(data)    //Insert date to product db

            .addOnSuccessListener { documentReference ->
                var kk = idsmy.text.toString()

                prosave_key = prosave_key.plusElement(kk)

                if (net_status() == true) {

                    val map = mutableMapOf<String, Any?>()
                    map.put("$branchky", stkhand)
                    db.collection("product").document(idsmy.text.toString())
                            .update(map)
                            .addOnCompleteListener {

                            }



                    println("AT THE TIME OF SAVE CESS" + cess)


                    val database = FirebaseDatabase.getInstance()

                    if (idsmy.text.toString().isNotEmpty()) {

                        for (i in 0 until brnchkeys.size) {
                            if (brnchkeys[i].toString() == branchky) {  //Merge stockhandd of branches to product db
                                var ad = brnchkeys[i]

                                val map = mutableMapOf<String, Any?>()
                                map.put("$ad", stkhand)
                                db.collection("product").document(idsmy.text.toString())
                                        .update(map)

                                val myRef = database.getReference(idsmy.text.toString() + "_" + brnchkeys[i])

                                myRef.setValue(stkhand)
                            } else {
                                var ads = brnchkeys[i]
                                val myRef = database.getReference(idsmy.text.toString() + "_" + brnchkeys[i])


                                val map = mutableMapOf<String, Any?>()


                                map.put("$ads", "0")
                                db.collection("product").document(idsmy.text.toString())
                                        .update(map)

                                myRef.setValue("0")
                            }
                        }


                    } else {

                        val myRef = database.getReference(id.text.toString() + "_" + branchky)

                        myRef.setValue(stkhand)
                    }


                    //Insert to local sql db
                    val isInserted = myDb.insertData(npid, pid, pname, bcode, pdes, weight, psac, cate, manufacture, ut, minstock,
                            price, maxstock, consold, comm, taxable, igst, cgst, sgst, cess, taxtotal, cessval, mrP, currency, status,
                            percentage, percentagevalue, product_dec, stkhand, img1n, img2n, img3n, img4n, img5n, imgurls,
                            img2url, img3url, img4url, img5url, img1nhigh, img2nhigh, img3nhigh, img4nhigh, img5nhigh, img1urlhigh,
                            img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh, orikys,ret,bkbr,protypesave,returnables,retdate,makeupitemstr)






                    if (isInserted == true) {
                    } else {
                    }
                    /*   Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)*/
                    /*val kk=documentReference.id*/


                    Handler().postDelayed(Runnable {


                        if(suppcome.isNotEmpty()&&suppcome=="supplier"){//navigate to supplier's products activity

                            val data = Intent(applicationContext,SupplierSecondmain::class.java)

                            // Add the required data to be returned to the MainActivity
                            data.putExtra("proky", Arrays.toString(prosave_key))

                            // Set the resultCode to Activity.RESULT_OK to
                            // indicate a success and attach the Intent
                            // which contains our result data
                            setResult(Activity.RESULT_OK, data)

                            // With finish() we close the AnotherActivity to
                            // return to MainActivity
                            finish()

                            Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()


                            try{
                                pDialogs!!.dismiss()
                            }
                            catch (e:Exception)
                            {

                            }

                        }

                        else if(suppcome.isEmpty()){  //Normal back action
                            val o = Intent(this@MainActivityScroll, MainProductlistActivity::class.java)

                            o.putExtra("frm_main", "main")

                            o.putExtra("addpro", addpro)
                            o.putExtra("editpro", editepro)
                            o.putExtra("deletepro", deletepro)
                            o.putExtra("viewpro", viewpro)
                            o.putExtra("importpro", importpro)
                            o.putExtra("exportpro", exportpro)
                            o.putExtra("changestock", stockin_hand)
                            o.putExtra("skey", branchky)
                            startActivity(o)
                            finish()
                            Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()


                            try{
                                pDialogs!!.dismiss()
                            }
                            catch (e:Exception)
                            {

                            }
                        }
                    },2500)


                } else {
                    Toast.makeText(applicationContext, "No internet connection", Toast.LENGTH_SHORT).show()
                    try{
                        pDialogs!!.dismiss()
                    }
                    catch (e:Exception)
                    {

                    }

                }
            }
            .addOnFailureListener { e ->
                println("COME FAILURE LISTENER")
                Log.w(TAG, "Error adding document", e)
                Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                /* save_progress.visibility = android.view.View.GONE*/
            }



   }


    override fun onBackPressed()

    {

        commonlisteners = ""
        println("LISTENER SAVE"+commonlisteners)

        println("CESS VALIDATE"+cessvaluevalidate)

        println("name VALIDATE"+pnamevalidate)
        println("vol VALIDATE"+volvalidate)
        println("bcode VALIDATE"+bcodeidvalidate)
        println("hsc VALIDATE"+hscvalidate)
        println("hscvalide VALIDATE"+hscdesvalidate)
        println("maincatvalidate VALIDATE"+maincatvalidate)
        println("subcatvalidate VALIDATE"+subcatvalidate)
        println("listvalidate VALIDATE"+listvalidate)
        println("pricevalidate VALIDATE"+pricevalidate)
        println("taxcheckvalidate VALIDATE"+taxcheckvalidate)
        println("intgstvalidate VALIDATE"+intgstvalidate)
        println("cessvaluevalidate VALIDATE"+cessvaluevalidate)
        println("checkcommisionvalidate VALIDATE"+checkcommisionvalidate)
        println("checkbonusvalidate VALIDATE"+checkbonusvalidate)
        println("percentagevalvalidate VALIDATE"+percentagevalvalidate)
        println("maxstockvalidate VALIDATE"+maxstockvalidate)
        println("minstockvalidate VALIDATE"+minstockvalidate)
        println("des_boxvalidate VALIDATE"+des_boxvalidate)
        println("stockhandvalidate VALIDATE"+stockhandvalidate)


        println("F1 VAL"+f1)
        println("s1 VAL"+s1)
        println("t1 VAL"+t1)
        println("Fo1 VAL"+fo1)
        println("Fif1 VAL"+fif1)
        println("Fn1 VAL"+fn1)
        println("sn1 VAL"+sn1)
        println("tn1 VAL"+tn1)
        println("Fon1 VAL"+fon1)
        println("Fif1 VAL"+fifn1)


        println("F1ed VAL"+f1edit)
        println("s1ed VAL"+s1edit)
        println("t1ed AL"+t1edit)
        println("Fof1ed VAL"+fo1edit)
        println("Fif1ed VAL"+fif1edit)

        println("Fn1ed VAL"+fn1edit)
        println("sn1ed VAL"+sn1edit)
        println("tn1ed AL"+tn1edit)
        println("Fnof1ed VAL"+fon1edit)
        println("Finf1ed VAL"+fifn1edit)


        try{
            if((pnamevalidate!=pname.text.toString())||(volvalidate!=vol.text.toString())||(bcodeidvalidate!=bcodeid.text.toString()) ||
                (hscvalidate!=hsc.text.toString())||(hscdesvalidate!=hscdes.text.toString())||(maincatvalidate!=cate.selectedItem.toString())||
                (subcatvalidate!=manu.selectedItem.toString())|| (listvalidate!=unitspinner.selectedItem.toString())||(pricevalidate!=price.text.toString())
                ||(taxcheckvalidate!=taxcheck.isChecked.toString())||(intgstvalidate!=intgst.text.toString())||(cessvaluevalidate!=cess.text.toString())
                ||(checkcommisionvalidate!=checkcommision.isChecked.toString())||(retailvalidate!=retail.isChecked.toString())||(backbarvalidate!=backbox.isChecked.toString())||(returnablevalidate!="false")||(percentagevalvalidate!=percentageval.text.toString())||(maxstockvalidate!=maxstock.text.toString())
                ||(minstockvalidate!=minstock.text.toString())||(des_boxvalidate!=des_box.text.toString())||(stockhandvalidate!=stockhand.text.toString())){

            commonlisteners = "change"
            println("ONBACK URL1 NOT EQUAL"+f1)

        }



        else if(((f1 != f1edit) || (s1 != s1edit) || (t1 != t1edit) || (fo1 != fo1edit) || (fif1 != fif1edit))){
            println("ONBACK URL1 EDIT NOT EQUAl"+f1)
            commonlisteners = "change"
        }
        }
        catch (e:Exception){

        }


        //If any changes happened for this product then save alert popup creates.
        if (((f1.isNotEmpty()) || (s1.isNotEmpty()) || (t1.isNotEmpty()) || (fo1.isNotEmpty()) || (fif1.isNotEmpty())||(commonlisteners == "change"))&&(pid.text.toString()=="Auto-generated")) {
            println("ONBACK URL1 EDIT NOT SID"+f1)
            alert()
        }

        else if ((commonlisteners == "change")&&(id.text.toString().isNotEmpty())) {
            println("ONBACK URL1 EDIT LIST ID"+f1)
            alert()
        }

              else{

            if(suppcome.isNotEmpty()&&suppcome=="supplier"){//Navigate to supplier's product activity


                val data = Intent(applicationContext,SupplierSecondmain::class.java)
                setResult(Activity.RESULT_CANCELED, data)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()

            }

            else if(suppcome.isEmpty()){   //Normal back action
                val o=Intent(this@MainActivityScroll,MainProductlistActivity::class.java)

                o.putExtra("frm_main","main")


                o.putExtra("addpro",addpro)
                o.putExtra("editpro",editepro)
                o.putExtra("deletepro",deletepro)
                o.putExtra("viewpro",viewpro)
                o.putExtra("importpro",importpro)
                o.putExtra("exportpro",exportpro)
                o.putExtra("changestock", stockin_hand)
                o.putExtra("skey",branchky)

                startActivity(o)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }



        }

    }


    fun alert()

    {
        val builder = AlertDialog.Builder(this@MainActivityScroll)
        with(builder) {
            setTitle("Save?")
            setMessage("Do you want to save?")


            // Dialog

            setPositiveButton("Yes") { dialog, whichButton ->
                if(net_status()==true) {
                    save.isEnabled = false
                    dialog.dismiss()
                    savepopup()//Save all datas to db
                }
                else{
                    dialog.dismiss()
                }

            }
                    .setNegativeButton("No") { dialog, whichButton ->



                        if (idsmy.text.toString().isNotEmpty()) {  //If it is new product,iamges will be deleted and doesn't save the product

                            dialog.dismiss()

                            val progressDialog = ProgressDialog(this@MainActivityScroll);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);
                            println("true " + idsmy.text.toString())
                            val del = ArrayList<String>()
                            val storage = FirebaseStorage.getInstance()
                            val storageRef = storage.getReference()
                            if (fn1.isEmpty() && sn1.isEmpty() && tn1.isEmpty() && fon1.isEmpty() && fifn1.isEmpty()) {
                                progressDialog.dismiss()

                                try{
                                    pDialogs!!.dismiss()
                                }
                                catch (e:Exception)
                                {

                                }
                                if(suppcome.isEmpty()){//Normal save action

                                    val o = Intent(this@MainActivityScroll, MainProductlistActivity::class.java)

                                    o.putExtra("frm_main", "main")


                                    o.putExtra("addpro", addpro)
                                    o.putExtra("editpro", editepro)
                                    o.putExtra("deletepro", deletepro)
                                    o.putExtra("viewpro", viewpro)
                                    o.putExtra("importpro", importpro)
                                    o.putExtra("exportpro", exportpro)
                                    o.putExtra("changestock", stockin_hand)
                                    o.putExtra("skey", branchky)

                                    startActivity(o)
                                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                    finish()
                                }

                                else if(suppcome.isNotEmpty()&&suppcome=="supplier")  //Navigate to supplier's product activity
                                {
                                    val data = Intent(applicationContext,SupplierSecondmain::class.java)
                                    setResult(Activity.RESULT_CANCELED, data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()
                                }
                            }
                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                            val dir = File(path);

                            if (fn1.isNotEmpty()) {
                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }

                                del.add(fn1)
                                del.add(img1nhigh)
                            }
                            if (sn1.isNotEmpty()) {
                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(sn1)
                                del.add(img2nhigh)
                            }
                            if (tn1.isNotEmpty()) {
                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(tn1)
                                del.add(img3nhigh)
                            }
                            if (fon1.isNotEmpty()) {
                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(fon1)
                                del.add(img4nhigh)
                            }
                            if (fifn1.isNotEmpty()) {
                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                del.add(fifn1)
                                del.add(img5nhigh)
                            }
                            if ((del.size >= 0)&&(net_status()==true)) {
                                for (i in del) {
                                    val imagesRef = storageRef.child("product").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {
                                                if (i == del.get(del.size - 1)) {




                                                    if(suppcome.isEmpty()) {//Normal save action

                                                        progressDialog.dismiss()
                                                        val o = Intent(this@MainActivityScroll, MainProductlistActivity::class.java)

                                                        o.putExtra("frm_main", "main")


                                                        o.putExtra("addpro", addpro)
                                                        o.putExtra("editpro", editepro)
                                                        o.putExtra("deletepro", deletepro)
                                                        o.putExtra("viewpro", viewpro)
                                                        o.putExtra("importpro", importpro)
                                                        o.putExtra("exportpro", exportpro)
                                                        o.putExtra("changestock", stockin_hand)
                                                        o.putExtra("skey", branchky)

                                                        startActivity(o)
                                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                                        finish()
                                                    }


                                                    else if(suppcome.isNotEmpty()&&suppcome=="supplier"){//Navigate to supplier's product activity

                                                        val data = Intent(applicationContext,SupplierSecondmain::class.java)
                                                        setResult(Activity.RESULT_CANCELED, data)
                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                        finish()
                                                    }
                                                }
                                            }
                                            .addOnCompleteListener {
                                            }
                                }
                            }
                            else{
                                try{
                                    pDialogs!!.dismiss()
                                }
                                catch (e:Exception)
                                {

                                }
                                progressDialog.dismiss()
                                if(suppcome.isEmpty()) {  //Normal back action

                                val o=Intent(this@MainActivityScroll,MainProductlistActivity::class.java)

                                o.putExtra("frm_main","main")


                                o.putExtra("addpro",addpro)
                                o.putExtra("editpro",editepro)
                                o.putExtra("deletepro",deletepro)
                                o.putExtra("viewpro",viewpro)
                                o.putExtra("importpro",importpro)
                                o.putExtra("exportpro",exportpro)
                                o.putExtra("changestock", stockin_hand)
                                o.putExtra("skey",branchky)

                                startActivity(o)
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                finish()
                                }

                                else if(suppcome.isNotEmpty()&&suppcome=="supplier"){  //Navigate to supplier's product activity
                                    val data = Intent(applicationContext,SupplierSecondmain::class.java)
                                    setResult(Activity.RESULT_CANCELED, data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()
                                }
                            }
                        } else if ((id.text.isNotEmpty())&&(net_status()==true)) {  //If it is existing product,iamges will be deleted and doesn't update the product
                            val delname = ArrayList<String>()
                            val delnameedit = ArrayList<String>()
                            val delnamehigh = ArrayList<String>()
                            val delnameedithigh = ArrayList<String>()
                            val delurl = ArrayList<String>()
                            val delurledit = ArrayList<String>()
                            val delurledithigh = ArrayList<String>()
                            val deldbnm = ArrayList<String>()

                            val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                            val dir = File(path);

                            val progressDialog = ProgressDialog(this@MainActivityScroll);
                            progressDialog.setTitle("Please wait...");
                            progressDialog.setMessage("wait for a while...");
                            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progressDialog.show();
                            progressDialog.setCancelable(false);

                            if (fn1 != fn1edit) {
                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fn1)
                                delnamehigh.add(img1nhigh)
                            }
                            if (sn1 != sn1edit) {
                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(sn1)
                                delnamehigh.add(img2nhigh)
                            }
                            if (tn1 != tn1edit) {
                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(tn1)
                                delnamehigh.add(img3nhigh)
                            }
                            if (fon1 != fon1edit) {
                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fon1)
                                delnamehigh.add(img4nhigh)
                            }
                            if (fifn1 != fifn1edit) {
                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")

                                var y = recacnm + ".png"
                                val dir = File(path);
                                val file = File(dir, y)
                                if (file.exists()) {
                                    file.delete()
                                }
                                delname.add(fifn1)
                                delnamehigh.add(img5nhigh)
                            }


                            println("DELE NAME" + delname)
                            println("DELE NAME HIGH" + delnamehigh)


                            delurl.add(f1edit)
                            delnameedit.add(fn1edit)

                            delurledithigh.add(f1edithigh)
                            delnameedithigh.add(fn1edithigh)

                            dialog.dismiss()


                            deletedb()
                            if ((delname.size >= 0)&&(net_status()==true)) {
                                for (i in delname) {
                                    val storage = FirebaseStorage.getInstance()
                                    val storageRef = storage.getReference()

                                    val imagesRef = storageRef.child("product").child(i)
                                    imagesRef.delete()
                                            .addOnSuccessListener {

                                                if (i == delname.get(delname.size - 1)) {
                                                    for (i in delnamehigh) {
                                                        val imagesRef = storageRef.child("product").child(i)
                                                        imagesRef.delete()
                                                                .addOnSuccessListener {
                                                                    if (i == delnamehigh.get(delnamehigh.size - 1)) {

                                                                        progressDialog.dismiss()
                                                                        if(suppcome.isEmpty()){

                                                                        val o=Intent(this@MainActivityScroll,MainProductlistActivity::class.java)

                                                                        o.putExtra("frm_main","main")


                                                                        o.putExtra("addpro",addpro)
                                                                        o.putExtra("editpro",editepro)
                                                                        o.putExtra("deletepro",deletepro)
                                                                        o.putExtra("viewpro",viewpro)
                                                                        o.putExtra("importpro",importpro)
                                                                        o.putExtra("exportpro",exportpro)
                                                                        o.putExtra("changestock", stockin_hand)
                                                                        o.putExtra("skey",branchky)

                                                                        startActivity(o)
                                                                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                                        finish()
                                                                        }

                                                                        else if(suppcome.isNotEmpty()&&suppcome=="supplier"){    //Navigate to supplier's product activity
                                                                            val data = Intent(applicationContext,SupplierSecondmain::class.java)
                                                                            setResult(Activity.RESULT_CANCELED, data)
                                                                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                                                            finish()
                                                                        }

                                                                    }

                                                                }
                                                    }
                                                }

                                            }
                                }


                            }
                            else{
                                progressDialog.dismiss()
                                if(suppcome.isEmpty())
                                {


                                val o=Intent(this@MainActivityScroll,MainProductlistActivity::class.java)

                                o.putExtra("frm_main","main")


                                o.putExtra("addpro",addpro)
                                o.putExtra("editpro",editepro)
                                o.putExtra("deletepro",deletepro)
                                o.putExtra("viewpro",viewpro)
                                o.putExtra("importpro",importpro)
                                o.putExtra("exportpro",exportpro)
                                o.putExtra("changestock", stockin_hand)
                                o.putExtra("skey",branchky)

                                startActivity(o)
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                finish()
                                }

                                else if(suppcome.isNotEmpty()&&suppcome=="supplier"){
                                    val data = Intent(applicationContext,SupplierSecondmain::class.java)
                                    setResult(Activity.RESULT_CANCELED, data)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()
                                }
                            }
                        }
                        else{
                            if(suppcome.isEmpty()){


                            Toast.makeText(applicationContext,"No internet Connection",Toast.LENGTH_SHORT).show()
                            val o=Intent(this@MainActivityScroll,MainProductlistActivity::class.java)

                            o.putExtra("frm_main","main")


                            o.putExtra("addpro",addpro)
                            o.putExtra("editpro",editepro)
                            o.putExtra("deletepro",deletepro)
                            o.putExtra("viewpro",viewpro)
                            o.putExtra("importpro",importpro)
                            o.putExtra("exportpro",exportpro)
                            o.putExtra("changestock", stockin_hand)
                            o.putExtra("skey",branchky)

                            startActivity(o)
                            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                            finish()
                            }

                            else if(suppcome.isNotEmpty()&&suppcome=="supplier"){
                                val data = Intent(applicationContext,SupplierSecondmain::class.java)
                                setResult(Activity.RESULT_CANCELED, data)
                                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                finish()
                            }
                        }
                    }

            val dialog = builder.create()

            dialog.show()
        }
    }


    fun deletedb() { //Delete images from existing product
        if(((fn1 != fn1edit)||(sn1 != sn1edit)||(tn1 != tn1edit)|| (fon1 != fon1edit)||(fifn1 != fifn1edit))&&(net_status()==true)) {
            if ((id.text.isNotEmpty()) && (fn1 != fn1edit)) {
                db.collection("product").document(id.text.toString())
                        .update("img1url", f1edit)
                        .addOnSuccessListener {
                          db.collection("product").document(id.text.toString())
                                    .update("img1n", fn1edit)
                                    .addOnCompleteListener {
                                      db.collection("product").document(id.text.toString())
                                                .update("img1urlhigh", f1edithigh)
                                                .addOnSuccessListener {
                                                  db.collection("product").document(id.text.toString())
                                                            .update("img1nhigh", fn1edithigh)

                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (sn1 != sn1edit)) {

              db.collection("product").document(id.text.toString())
                        .update("img2url", s1edit)
                        .addOnSuccessListener {
                          db.collection("product").document(id.text.toString())
                                    .update("img2n", sn1edit)
                                    .addOnCompleteListener {
                                      db.collection("product").document(id.text.toString())
                                                .update("img2urlhigh", s1edithigh)
                                                .addOnSuccessListener {
                                                  db.collection("product").document(id.text.toString())
                                                            .update("img2nhigh", sn1edithigh)


                                                }
                                    }

                        }
            }
            if ((id.text.isNotEmpty()) && (tn1 != tn1edit)) {
              db.collection("product").document(id.text.toString())
                        .update("img3url", t1edit)
                        .addOnSuccessListener {
                          db.collection("product").document(id.text.toString())
                                    .update("img3n", tn1edit)
                                    .addOnCompleteListener {
                                      db.collection("product").document(id.text.toString())
                                                .update("img3urlhigh", t1edithigh)
                                                .addOnSuccessListener {
                                                  db.collection("product").document(id.text.toString())
                                                            .update("img3nhigh", tn1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (fon1 != fon1edit)) {
              db.collection("product").document(id.text.toString())
                        .update("img4url", fo1edit)
                        .addOnSuccessListener {
                          db.collection("product").document(id.text.toString())
                                    .update("img4n", fon1edit)
                                    .addOnCompleteListener {
                                      db.collection("product").document(id.text.toString())
                                                .update("img4urlhigh", fo1edithigh)
                                                .addOnSuccessListener {
                                                  db.collection("product").document(id.text.toString())
                                                            .update("img4nhigh", fon1edithigh)


                                                }
                                    }

                        }

            }
            if ((id.text.isNotEmpty()) && (fifn1 != fifn1edit)) {
              db.collection("product").document(id.text.toString())
                        .update("img5url", fif1edit)
                        .addOnSuccessListener {
                          db.collection("product").document(id.text.toString())
                                    .update("img5n", fifn1edit)
                                    .addOnCompleteListener {
                                      db.collection("product").document(id.text.toString())
                                                .update("img5urlhigh", fif1edithigh)
                                                .addOnSuccessListener {
                                                  db.collection("product").document(id.text.toString())
                                                            .update("img5nhigh", fifn1edithigh)

                                                }
                                    }

                        }
            }
        }
        else{
            if(suppcome.isEmpty()){

                val o=Intent(this@MainActivityScroll,MainProductlistActivity::class.java)

            o.putExtra("frm_main","main")


            o.putExtra("addpro",addpro)
            o.putExtra("editpro",editepro)
            o.putExtra("deletepro",deletepro)
            o.putExtra("viewpro",viewpro)
            o.putExtra("importpro",importpro)
            o.putExtra("exportpro",exportpro)
            o.putExtra("changestock", stockin_hand)
            o.putExtra("skey",branchky)

            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
            finish()
            }

            else if(suppcome.isNotEmpty()&&suppcome=="supplier"){
                val data = Intent(applicationContext,SupplierSecondmain::class.java)
                setResult(Activity.RESULT_CANCELED, data)
                overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                finish()
            }
        }
    }



    fun savepopup(){

        if (pname.length() == 0) {//If pname edittext field length=0 then  'Required field*' error displayed
            errorpronm.visibility = View.VISIBLE

            errorpronm.setText("Required field*")
        }
        if (price.length() == 0) {//If price edittext field length=0 then  'Required field*' error displayed
            errorproprice.visibility = View.VISIBLE

            errorproprice.setText("Required field*")
        }
        if (retail.isChecked==false&&backbox.isChecked==false) {//If retail checkbox,backbox checkbox is not checked then 'Required field*' error displayed
            reterr.visibility = View.VISIBLE

            bkbxerr.visibility=View.VISIBLE


            Toast.makeText(applicationContext, "Please Check retail or backbar", Toast.LENGTH_SHORT).show()
        }
        if ((id.text == "")&&(errorpronm.visibility==View.INVISIBLE)&&(errorproprice.visibility==View.INVISIBLE)&&((reterr.visibility==View.INVISIBLE&&bkbxerr.visibility==View.INVISIBLE))) {
            onStarClicked1()    //Insert to online db and sql db if all error views are invisible
        }
        var npid = id.text.toString()
        var pid = (pid.text).toString()
        var pname = (pname.text).toString()
        var bcode = (bcodeid.text).toString()
        var pdes = (hscdes.text).toString()
        var orikys=branchky
        var weight = (vol.text).toString()
        var psac = (hsc.text).toString()

        if(stockhand.text.toString().isNotEmpty()) {
            var stockonhand = (stockhand.text).toString()
            stkhand=stockonhand
        }
        else{

            stkhand="0"
        }

            protypesave=""


        var minstock = (minstock.text).toString()
        var maxstock = (maxstock.text).toString()
        var price = (price.text).toString()
        var taxable = taxcheck.isChecked.toString()
        var igst = (intgst.text).toString()
        var cgst = (centgst.text).toString()
        var sgst = (stategst.text).toString()
        var cess = (cess.text).toString()
        var taxtotal = (taxtot.text).toString()
        var cessval = (cessvalue.text).toString()
        var currency = currencyradio.isChecked.toString()
        var percentage = percenradio.isChecked.toString()
        var percentagevalue = (percentageval.text).toString()
        var product_dec = (des_box.text).toString()
        var mrP = (mrp.text).toString()
        var cate = cate.selectedItem.toString()
        var manufacture = manu.selectedItem.toString()
        var ut = unitspinner.selectedItem.toString()
        var consold = checkbonus.isChecked.toString()
        var comm = checkcommision.isChecked.toString()
        var status=(disable.text).toString()
        val img1n=fn1
        val img2n=sn1
        val img3n=tn1
        val img4n=fon1
        val img5n=fifn1


        var ret=retail.isChecked.toString()
        var bkbr=backbox.isChecked.toString()
        var returnables="false"
        var retdate=""



        if(f1.isEmpty()){

        }
        if(f1.isNotEmpty())
        {

            val img1url=f1
            imgurls=img1url
        }

        val img2url=s1
        val img3url=t1
        val img4url=fo1
        val img5url=fif1

        val data = s(p_id = pid, p_nm = pname, bc = bcode, desc = pdes, wg_vol = weight, hsn = psac, ctgy = cate,
                mfr = manufacture, ut = ut, min_stk = minstock, price = price, mx_stk = maxstock, cn_sold = consold,
                emp_com = comm, taxchk = taxable, igst = igst, cgst = cgst, sgst = sgst, cess = cess, taxtot = taxtotal,
                cesstot = cessval, mrp = mrP, curency = currency,status = status, percentage = percentage, retail = ret,
                backbar = bkbr, percentageval = percentagevalue, product_desc = product_dec,stock_hand = stkhand, img1n = img1n,
                img2n = img2n, img3n = img3n, img4n = img4n, img5n = img5n, img1url = imgurls, img2url = img2url, img3url = img3url,
                img4url = img4url, img5url = img5url,img1nhigh = img1nhigh, img2nhigh = img2nhigh, img3nhigh = img3nhigh,
                img4nhigh = img4nhigh, img5nhigh = img5nhigh,img1urlhigh = img1urlhigh, img2urlhigh = img2urlhigh,
                img3urlhigh = img3urlhigh, img4urlhigh = img4urlhigh, img5urlhigh = img5urlhigh,orikys =orikys,
                supp_key = suppky,supp_name = suppname,protype = protypesave,returnable = returnables,returnableday = retdate,makeupitem = makeupitemstr)

        if ((id.text != "")&&(errorpronm.visibility==View.INVISIBLE)&&(errorproprice.visibility==View.INVISIBLE)&&((reterr.visibility==View.INVISIBLE&&bkbxerr.visibility==View.INVISIBLE))) {

             pDialogs = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE)
            pDialogs!!.getProgressHelper().setBarColor(Color.parseColor("#263238"))
            pDialogs!!.setTitleText("Saving...")
            pDialogs!!.setCancelable(false)
            pDialogs!!.show();


            val db = FirebaseFirestore.getInstance()

            //Update to local sql table

            val isInserted = myDb.updatedata(npid,pid,pname,bcode,pdes,weight,psac,cate,manufacture,ut,minstock,price,maxstock,
                    consold,comm,taxable,igst,cgst,sgst,cess,taxtotal,cessval,mrP,currency,status,percentage,percentagevalue,product_dec,
                    stkhand,img1n,img2n,img3n,img4n,img5n,imgurls,img2url,img3url,img4url,img5url,img1nhigh, img2nhigh, img3nhigh, img4nhigh,
                    img5nhigh, img1urlhigh, img2urlhigh, img3urlhigh, img4urlhigh, img5urlhigh,orikys,ret,bkbr,protypesave,returnables,retdate,makeupitemstr)

            if (isInserted == true){
                Toast.makeText(this, "Saving...", Toast.LENGTH_SHORT).show()}
            else{
            }

            db.collection("product").document(id.text.toString())

                    .set(data)  ////Update to online db and sql db if all error views are invisible
                    .addOnSuccessListener {
                        val map = mutableMapOf<String, Any?>()
                        map.put("$branchky", stkhand)
                        db.collection("product").document(id.text.toString())
                                .update(map)
                                .addOnCompleteListener {


                                    val database = FirebaseDatabase.getInstance()

                                    if (stockhand.text.toString().isNotEmpty()) {
                                        val service_access = SessionManagement(this)
                                        val user = service_access.userDetails

                                        // name
                                        val name = user[SessionManagement.KEY_NAME]
                                        brkey = name.toString()
                                        for (i in 0 until brnchkeys.size) {  //Get stockonhand values and update to online db
                                            if (brnchkeys[i].toString() == brkey) {
                                                println("BRANCH KEY" + brkey)
                                                println("BRANCH KEY ARRAY" + brnchkeys[i])

                                                println("STOCK HAND" + stockhand.text.toString())
                                                println("ID" + id.text.toString())

                                                var ad = brnchkeys[i]

                                                val map = mutableMapOf<String, Any?>()
                                                map.put("$ad", stockhand.text.toString())
                                                db.collection("product").document(id.text.toString())
                                                        .set(map, SetOptions.merge())


                                            } else {

                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(id.text.toString() + "_" + brnchkeys[i])

                                                val messageListener = object : ValueEventListener {

                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        if (dataSnapshot.exists()) {

                                                            val message = dataSnapshot.value

                                                            var ads = brnchkeys[i]

                                                            val map = mutableMapOf<String, Any?>()

                                                            map.put("$ads", message)
                                                            db.collection("product").document(id.text.toString())
                                                                    .update(map)

                                                        }
                                                    }

                                                    override fun onCancelled(databaseError: DatabaseError) {
                                                        // Failed to read value
                                                    }
                                                }

                                                myRef!!.addValueEventListener(messageListener)


                                            }

                                        }
                                    } else {

                                        stkhand = "0"
                                    }

                                    if (idsmy.text.toString().isNotEmpty()) {
                                        val myRef = database.getReference(idsmy.text.toString() + "_" + branchky)

                                        myRef.setValue(stockhand.text.toString())
                                    } else {
                                        val myRef = database.getReference(id.text.toString() + "_" + branchky)

                                        myRef.setValue(stockhand.text.toString())
                                    }




                                    if(idsmy.text.toString().isNotEmpty()) {
                                        val myRef = database.getReference(idsmy.text.toString() + "_" + branchky)

                                        myRef.setValue(stockhand.text.toString())
                                    }
                                    else{
                                        val myRef = database.getReference(id.text.toString() + "_" + branchky)

                                        myRef.setValue(stockhand.text.toString())
                                    }

                                }
                                .addOnSuccessListener {




                                    Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()
                                    try{
                                        pDialogs!!.dismiss()
                                    }
                                    catch (e:Exception)
                                    {

                                    }
                                    if(suppcome.isEmpty()){

                                    val o=Intent(this@MainActivityScroll,MainProductlistActivity::class.java)

                                    o.putExtra("frm_main","main")


                                    o.putExtra("addpro",addpro)
                                    o.putExtra("editpro",editepro)
                                    o.putExtra("deletepro",deletepro)
                                    o.putExtra("viewpro",viewpro)
                                    o.putExtra("importpro",importpro)
                                    o.putExtra("exportpro",exportpro)
                                    o.putExtra("changestock", stockin_hand)
                                    o.putExtra("skey",branchky)

                                    startActivity(o)
                                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                                    finish()
                                    }

                                    else if(suppcome.isNotEmpty()&&suppcome=="supplier"){
                                        val data = Intent(applicationContext,SupplierSecondmain::class.java)

                                        // Add the required data to be returned to the MainActivity
                                        data.putExtra("proky", Arrays.toString(prosave_key))

                                        // Set the resultCode to Activity.RESULT_OK to
                                        // indicate a success and attach the Intent
                                        // which contains our result data
                                        setResult(Activity.RESULT_OK, data)

                                        // With finish() we close the AnotherActivity to
                                        // return to MainActivity
                                        finish()


                                        Toast.makeText(this, "data is updated", Toast.LENGTH_LONG).show()

                                    }

                                }




                    }

                    .addOnFailureListener {
                        Toast.makeText(this, "not updated", Toast.LENGTH_LONG).show()
                        try{
                            pDialogs!!.dismiss()
                        }
                        catch (e:Exception)
                        {

                        }
                    }



        }
        else{
            if(idsmy.text.isEmpty()) {
                Toast.makeText(applicationContext, "Please fill required fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun loadim() {  //Load images in slider
        scrollpro.visibility = View.GONE
        if (file_maps.isNotEmpty()) {


            for (r in 0 until file_maps.size) {
                try {
                    val textSliderView = TextSliderView(this)
                    // initialize a SliderLayout
                    Log.d("file_maps", "r  " + file_maps[r])
                    textSliderView
                            //.description(name)
                            .image(file_maps[r])
                            .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                            .setOnSliderClickListener {


                                if(net_status()==true) {
                                    //Navigate to multi images activity
                                    val b = Intent(applicationContext, AddImagesActivity_prod::class.java)
                                    b.putExtra("id", id.text.toString())
                                    b.putExtra("addpro", addpro)
                                    b.putExtra("editpro", editepro)
                                    b.putExtra("deletepro", deletepro)
                                    b.putExtra("viewpro", viewpro)
                                    b.putExtra("importpro", importpro)
                                    b.putExtra("exportpro", exportpro)
                                    b.putExtra("changestock", stockin_hand)
                                    b.putExtra("edtcli", editcli)

                                    b.putExtra("f1", f1)
                                    b.putExtra("fn1", fn1)
                                    b.putExtra("s1", s1)
                                    b.putExtra("sn1", sn1)
                                    b.putExtra("t1", t1)
                                    b.putExtra("tn1", tn1)
                                    b.putExtra("fo1", fo1)
                                    b.putExtra("fon1", fon1)
                                    b.putExtra("fif1", fif1)
                                    b.putExtra("fifn1", fifn1)
                                    b.putExtra("f1high", img1urlhigh)
                                    b.putExtra("listenersave", commonlisteners)
                                    b.putExtra("fn1high", img1nhigh)
                                    b.putExtra("s1high", img2urlhigh)
                                    b.putExtra("sn1high", img2nhigh)
                                    b.putExtra("t1high", img3urlhigh)
                                    b.putExtra("tn1high", img3nhigh)
                                    b.putExtra("fo1high", img4urlhigh)
                                    b.putExtra("fon1high", img4nhigh)
                                    b.putExtra("fif1high", img5urlhigh)
                                    b.putExtra("fifn1high", img5nhigh)
                                    b.putExtra("mresult", mresultsarr)
                                    b.putExtra("f1edithigh", f1edithigh)
                                    b.putExtra("fn1edithigh", fn1edithigh)
                                    b.putExtra("s1edithigh", s1edithigh)
                                    b.putExtra("sn1edithigh", sn1edithigh)
                                    b.putExtra("t1edithigh", t1edithigh)
                                    b.putExtra("tn1edithigh", tn1edithigh)
                                    b.putExtra("fo1edithigh", fo1edithigh)
                                    b.putExtra("fon1edithigh", fon1edithigh)
                                    b.putExtra("fif1edithigh", fif1edithigh)
                                    b.putExtra("fifn1edithigh", fifn1edithigh)

                                    b.putExtra("cacnm1", cacnm1)
                                    b.putExtra("f1edit", f1edit)
                                    b.putExtra("fn1edit", fn1edit)
                                    b.putExtra("s1edit", s1edit)
                                    b.putExtra("sn1edit", sn1edit)
                                    b.putExtra("t1edit", t1edit)
                                    b.putExtra("tn1edit", tn1edit)
                                    b.putExtra("fo1edit", fo1edit)
                                    b.putExtra("fon1edit", fon1edit)
                                    b.putExtra("fif1edit", fif1edit)
                                    b.putExtra("fifn1edit", fifn1edit)
                                    startActivityForResult(b, 0)
                                    scroll2_slider.isEnabled = true
                                }
                                else{
                                    Toast.makeText(applicationContext,"You're offline.",Toast.LENGTH_SHORT).show()
                                }
                            }
                    scroll2_slider2.addSlider(textSliderView)
                } catch (e: Exception) {

                }
            }
            scroll2_slider2.setPresetTransformer(SliderLayout.Transformer.Default)
            scroll2_slider2.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
            scroll2_slider2.setCustomAnimation(DescriptionAnimation())
            scroll2_slider2.setDuration(5000)

            //scroll2_preview_service_image2
            try {
                val newurl = URL(file_maps[0]).openStream()
                val img = BitmapFactory.decodeStream(newurl)

            } catch (e: Exception) {

            }
        }
    }



    //Receive image links from multi images activity and load into slider.

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            0 // Do your stuff here...
            -> {
                if (resultCode == Activity.RESULT_OK) {

                    scroll2_slider.removeAllSliders()
                    scroll2_slider2.removeAllSliders()


                    val ad=intent.getStringExtra("addspro")
                    val ed=intent.getStringExtra("editspro")
                    val viw=intent.getStringExtra("viewspro")
                    val impo=intent.getStringExtra("importspro")
                    val expo=intent.getStringExtra("exportspro")
                    val del=intent.getStringExtra("deletespro")
                    stockin_hand=intent.getStringExtra("changestock")

                    if (ad!=null)
                    {
                        addpro = ad
                    }
                    if(ed!=null){
                        editepro = ed
                    }
                    if (del!=null){
                        deletepro = del
                    }
                    if (viw!=null){
                        viewpro = viw
                    }
                    if (impo!=null){
                        importpro = impo
                    }
                    if (expo!=null){
                        exportpro = expo
                    }

                    scroll2_slider2.visibility = View.GONE
                    scroll2_slider.visibility = View.VISIBLE
                    val f = data!!.getStringExtra("f")
                    val fn = data!!.getStringExtra("fn")
                    val s = data!!.getStringExtra("s")
                    val sn = data!!.getStringExtra("sn")
                    val t = data!!.getStringExtra("t")
                    val tn = data!!.getStringExtra("tn")
                    val fo = data!!.getStringExtra("fo")
                    val fon = data!!.getStringExtra("fon")
                    val fif = data!!.getStringExtra("fif")
                    val fifn = data!!.getStringExtra("fifn")

                    imlistener=data!!.getStringExtra("fifn");


                    val fedit = data!!.getStringExtra("fedit")
                    val fnedit = data!!.getStringExtra("fnedit")
                    val sedit = data!!.getStringExtra("sedit")
                    val snedit = data!!.getStringExtra("snedit")
                    val tedit = data!!.getStringExtra("tedit")
                    val tnedit = data!!.getStringExtra("tnedit")
                    val foedit = data!!.getStringExtra("foedit")
                    val fonedit = data!!.getStringExtra("fonedit")
                    val fifedit = data!!.getStringExtra("fifedit")
                    val fifnedit = data!!.getStringExtra("fifnedit");


                    try {
                        mresultsarr = data!!.getStringArrayListExtra("mResult")
                    } catch (e: Exception) {

                    }



                    try {
                        cacnm1 = data!!.getStringExtra("cacnm1")
                    } catch (e: Exception) {

                    }
                    try {
                        commonlisteners = data!!.getStringExtra("listenersave")
                    } catch (e: Exception) {

                    }

                    try {
                        editcli = data!!.getStringExtra("edtcli")
                    } catch (e: Exception) {

                    }

                    val fhigh = data!!.getStringExtra("fhigh");
                    val fnhigh = data!!.getStringExtra("fnhigh");
                    val shigh = data!!.getStringExtra("shigh");
                    val snhigh = data!!.getStringExtra("snhigh");
                    val thigh = data!!.getStringExtra("thigh");
                    val tnhigh = data!!.getStringExtra("tnhigh");
                    val fohigh = data!!.getStringExtra("fohigh");
                    val fonhigh = data!!.getStringExtra("fonhigh");
                    val fifhigh = data!!.getStringExtra("fifhigh");
                    val fifnhigh = data!!.getStringExtra("fifnhigh");


                    println("fhigh" + fhigh)
                    println("shigh" + shigh)
                    println("thigh" + thigh)
                    println("fohigh" + fohigh)
                    println("fifhigh" + fifhigh)


                    println("fnhigh" + fnhigh)
                    println("snhigh" + snhigh)
                    println("tnhigh" + tnhigh)
                    println("fonhigh" + fonhigh)
                    println("fifnhigh" + fifnhigh)
                    if (fhigh.isNotEmpty()) {


                        img1urlhigh = fhigh
                        img1nhigh = fnhigh
                    } else {
                        img1urlhigh = ""
                        img1nhigh = ""
                    }
                    if (shigh.isNotEmpty()) {


                        img2urlhigh = shigh
                        img2nhigh = snhigh
                    } else {
                        img2urlhigh = ""
                        img2nhigh = ""
                    }
                    if (thigh.isNotEmpty()) {


                        img3urlhigh = thigh
                        img3nhigh = tnhigh
                    } else {
                        img3urlhigh = ""
                        img3nhigh = ""
                    }
                    if (fohigh.isNotEmpty()) {


                        img4urlhigh = fohigh
                        img4nhigh = fonhigh
                    } else {
                        img4urlhigh = ""
                        img4nhigh = ""
                    }
                    if (fifhigh.isNotEmpty()) {


                        img5urlhigh = fifhigh
                        img5nhigh = fifnhigh
                    } else {

                        img5urlhigh = ""
                        img5nhigh = ""
                    }


                    val fedithigh = data!!.getStringExtra("fedithigh")
                    val fnedithigh = data!!.getStringExtra("fnedithigh")
                    val sedithigh = data!!.getStringExtra("sedithigh")
                    val snedithigh = data!!.getStringExtra("snedithigh")
                    val tedithigh = data!!.getStringExtra("tedithigh")
                    val tnedithigh = data!!.getStringExtra("tnedithigh")
                    val foedithigh = data!!.getStringExtra("foedithigh")
                    val fonedithigh = data!!.getStringExtra("fonedithigh")
                    val fifedithigh = data!!.getStringExtra("fifedithigh")
                    val fifnedithigh = data!!.getStringExtra("fifnedithigh");

                    if (fedithigh.isNotEmpty()) {


                        f1edithigh = fedithigh
                        fn1edithigh = fnedithigh


                    } else {


                        f1edithigh = ""
                        fn1edithigh = ""
                    }
                    if (sedithigh.isNotEmpty()) {


                        s1edithigh = sedithigh
                        sn1edithigh = snedithigh

                    } else {


                        s1edithigh = ""
                        sn1edithigh = ""
                    }
                    if (tedithigh.isNotEmpty()) {

                        t1edithigh = tedithigh
                        tn1edithigh = tnedithigh

                    } else {

                        t1edithigh = ""
                        tn1edithigh = ""
                    }
                    if (foedithigh.isNotEmpty()) {
                        fo1edithigh = foedithigh
                        fon1edithigh = fonedithigh

                    } else {

                        fo1edithigh = ""
                        fon1edithigh = ""
                    }
                    if (fifedithigh.isNotEmpty()) {

                        fif1edithigh = fifedithigh
                        fifn1edithigh = fifnedithigh

                    } else {

                        fif1edithigh = ""
                        fifn1edithigh = ""
                    }

                    if (fedit.isNotEmpty()) {


                        f1edit = fedit
                        fn1edit = fnedit


                    } else {



                        f1edit = ""
                        fn1edit = ""
                    }
                    if (sedit.isNotEmpty()) {



                        s1edit = sedit
                        sn1edit = snedit

                    } else {





                        s1edit = ""
                        sn1edit = ""
                    }
                    if (tedit.isNotEmpty()) {

                        t1edit = tedit
                        tn1edit = tnedit

                    } else {

                        t1edit = ""
                        tn1edit = ""
                    }
                    if (foedit.isNotEmpty()) {
                        fo1edit = foedit
                        fon1edit = fonedit

                    } else {

                        fo1edit = ""
                        fon1edit = ""
                    }
                    if (fifedit.isNotEmpty()) {

                        fif1edit = fifedit
                        fifn1edit = fifnedit

                    } else {

                        fif1edit = ""
                        fifn1edit = ""
                    }




                    val bitmapArray = ArrayList<String>()
                    bitmapArray.clear()

                    scrollpro.visibility=View.VISIBLE

                    if (f.isNotEmpty()) {




                        d.add(f)
                        //println(bitmapArray[0])
                        f1 = f
                        fn1 = fn


                        if(img1nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img1nhigh
                                val recacnm = k.removeSuffix(".jpg")
                                cacnm1 = recacnm
                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(f1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(f1)
                            }
                        }
                        else{
                            d.add(f);bitmapArray.add(f)
                        }

                    } else {



                        f1 = ""
                        fn1 = ""
                    }
                    if (s.isNotEmpty()) {



                        d.add(s)




                        s1 = s
                        sn1 = sn



                        if(img2nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img2nhigh
                                val recacnm = k.removeSuffix(".jpg")
                                cacnm1 = recacnm
                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(s1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(s1)
                            }
                        }
                        else{
                            ;bitmapArray.add(s)
                        }

                    } else {





                        s1 = ""
                        sn1 = ""
                    }
                    if (t.isNotEmpty()) {




                        d.add(t);

                        t1 = t
                        tn1 = tn

                        if(img3nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img3nhigh
                                val recacnm = k.removeSuffix(".jpg")
                                cacnm1 = recacnm
                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(t1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(t1)
                            }
                        }
                        else{
                            bitmapArray.add(t)
                        }




                    } else {






                        t1 = ""
                        tn1 = ""
                    }
                    if (fo.isNotEmpty()) {



                        d.add(fo);


                        fo1 = fo
                        fon1 = fon

                        if(img4nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img4nhigh
                                val recacnm = k.removeSuffix(".jpg")
                                cacnm1 = recacnm
                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(fo1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(fo1)
                            }
                        }
                        else{

                            bitmapArray.add(fo)
                        }

                    } else {






                        fo1 = ""
                        fon1 = ""
                    }
                    if (fif.isNotEmpty()) {



                        d.add(fif);
                        fif1 = fif
                        fifn1 = fifn
                        if(img5nhigh.isNotEmpty()){
                            try {

                                val path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "Inventory_Product"

                                val dir = File(path);
                                if (!dir.exists())
                                    dir.mkdirs()

                                val k = img5nhigh
                                val recacnm = k.removeSuffix(".jpg")
                                cacnm1 = recacnm
                                var y = recacnm + ".png"

                                val file = File(dir, y)
                                println("CONTENT URI" + file)
                                if (file.exists()) {
                                    val contentUri = Uri.fromFile(File("$path/$y"))
                                    bitmapArray.add(contentUri.toString())
                                } else {
                                    bitmapArray.add(fif1)
                                }
                            }
                            catch (e:Exception){
                                bitmapArray.add(fif1)
                            }
                        }
                        else{

                            bitmapArray.add(fif)
                        }



                    } else {

                        fif1 = ""
                        fifn1 = ""
                    }


                    if(f1.isNotEmpty()||s1.isNotEmpty()||t1.isNotEmpty()||fo1.isNotEmpty()||fif1.isNotEmpty())
                    {
                        gallery.visibility=View.VISIBLE
                        imageView41.visibility=View.GONE
                        imageButton2.visibility=View.GONE
                    }





                    Handler().postDelayed(Runnable {  //Load images into slider



                        Log.d("tag", "  " + bitmapArray)
                        if (bitmapArray.isNotEmpty()) {
                            for (r in 0 until bitmapArray.size) {
                                scrollpro.visibility=View.GONE
                                val textSliderView = TextSliderView(this)
                                // initialize a SliderLayout
                                Log.d("khd", "r  " + bitmapArray[r])
                                textSliderView
                                        //.description(name)
                                        .image(bitmapArray[r])
                                        .setScaleType(BaseSliderView.ScaleType.CenterCrop)
                                        .setOnSliderClickListener {
                                            if(net_status()==true) {


                                                // Navigate to multi images select activity
                                            val b = Intent(applicationContext, AddImagesActivity_prod::class.java)
                                            b.putExtra("id", id.text.toString())
                                            b.putExtra("f1", f1)
                                            b.putExtra("fn1", fn1)
                                            b.putExtra("s1", s1)
                                            b.putExtra("sn1", sn1)
                                            b.putExtra("t1", t1)
                                            b.putExtra("tn1", tn1)
                                            b.putExtra("fo1", fo1)
                                            b.putExtra("fon1", fon1)
                                            b.putExtra("fif1", fif1)
                                            b.putExtra("fifn1", fifn1)
                                            b.putExtra("f1high", img1urlhigh)
                                            b.putExtra("listenersave", commonlisteners)
                                            b.putExtra("fn1high", img1nhigh)
                                            b.putExtra("s1high", img2urlhigh)
                                            b.putExtra("sn1high", img2nhigh)
                                            b.putExtra("t1high", img3urlhigh)
                                            b.putExtra("tn1high", img3nhigh)
                                            b.putExtra("fo1high", img4urlhigh)
                                            b.putExtra("fon1high", img4nhigh)
                                            b.putExtra("fif1high", img5urlhigh)
                                            b.putExtra("fifn1high", img5nhigh)
                                            b.putExtra("mresult", mresultsarr)
                                            b.putExtra("f1edithigh", f1edithigh)
                                            b.putExtra("fn1edithigh", fn1edithigh)
                                            b.putExtra("s1edithigh", s1edithigh)
                                            b.putExtra("sn1edithigh", sn1edithigh)
                                            b.putExtra("t1edithigh", t1edithigh)
                                            b.putExtra("tn1edithigh", tn1edithigh)
                                            b.putExtra("fo1edithigh", fo1edithigh)
                                            b.putExtra("fon1edithigh", fon1edithigh)
                                            b.putExtra("fif1edithigh", fif1edithigh)
                                            b.putExtra("fifn1edithigh", fifn1edithigh)

                                            b.putExtra("addpro", addpro)
                                            b.putExtra("editpro", editepro)
                                            b.putExtra("deletepro", deletepro)
                                            b.putExtra("viewpro", viewpro)
                                            b.putExtra("importpro", importpro)
                                            b.putExtra("exportpro", exportpro)
                                            b.putExtra("changestock", stockin_hand)

                                            b.putExtra("cacnm1", cacnm1)
                                            b.putExtra("f1edit", f1edit)
                                            b.putExtra("fn1edit", fn1edit)
                                            b.putExtra("s1edit", s1edit)
                                            b.putExtra("sn1edit", sn1edit)
                                            b.putExtra("t1edit", t1edit)
                                            b.putExtra("tn1edit", tn1edit)
                                            b.putExtra("fo1edit", fo1edit)
                                            b.putExtra("fon1edit", fon1edit)
                                            b.putExtra("fif1edit", fif1edit)
                                            b.putExtra("fifn1edit", fifn1edit)
                                            startActivityForResult(b, 0)
                                            scroll2_slider.isEnabled = true
                                            }
                                            else{
                                                Toast.makeText(applicationContext,"You're offline.",Toast.LENGTH_SHORT).show()
                                            }
                                        }

                                //add your extra information
                                /*textSliderView.bundle(Bundle())
                        textSliderView.bundle.clear()*/
                                //.putString("extra", bitmapArray[r])

                                scroll2_slider.addSlider(textSliderView)
                            }
                            scroll2_slider.setPresetTransformer(SliderLayout.Transformer.Default)
                            scroll2_slider.setPresetIndicator(SliderLayout.PresetIndicators.Right_Bottom)
                            scroll2_slider.setCustomAnimation(DescriptionAnimation())
                            scroll2_slider.setDuration(5000)

                            //scroll2_preview_service_image
                            val newurl = URL(bitmapArray[0]).openStream()
                            val img = BitmapFactory.decodeStream(newurl)

                        }
                    }, 1000)





                    //bitmapArray.addAll(data.get("bitmapArray"))
                    //println(bitmapArray)
                    Log.d(" ", "result " + f)
                    Log.d(" ", "result " + s)
                    Log.d(" ", "result " + t)
                    Log.d(" ", "result " + fo)
                    Log.d(" ", "result " + fif)
                    /* this.runOnUiThread(Runnable() {
                         file_maps.clear()
                         d.addAll(d)
                         Log.d("map","  "+d)
                     })*/
                }


            }
            1 // Do your other stuff here...
            -> {
                if (resultCode == Activity.RESULT_OK) {  //If result code is 1 scanned barcode value will be displayed
                    if (data != null) {
                        val barcode = data.getParcelableExtra<Barcode>("barcode")
                        bcodeid.post { bcodeid.setText(barcode.displayValue) }
                        Log.d("jkjvfdhjh", "barcode  " + barcode.displayValue)


                    }

                }
                if (resultCode == Activity.RESULT_CANCELED) {
                    return;
                }

            }
        /*etc -> {
        }*/
        }
    }
    fun popup(st:String){ //Access Denined alrt
        val pop= AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }



    companion object {
        //Listens inetrnet status whether net is on/off.

        val REQUEST_CODE = 100
        val PERMISSION_REQUEST = 200
        var onbkinside:String?=null
        var pDialogs: SweetAlertDialog? = null
        private var relativeslayoutdis: RelativeLayout? = null
        private var consermaindis: ConstraintLayout? = null
        private var constraintLayout3dis: ConstraintLayout? = null
        private var scroll2_sliderdis:SliderLayout?=null
        private var scroll2_slider2dis:SliderLayout?=null
        private var gallerydis:ImageButton?=null

        private var editdis:ImageButton?=null

        private val log_str: String? = null



        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                //And some views will be disabled when net is off

                relativeslayoutdis!!.visibility=View.VISIBLE
                constraintLayout3dis!!.visibility=View.VISIBLE

                scroll2_sliderdis!!.isEnabled=false
                scroll2_slider2dis!!.isEnabled=false
                gallerydis!!.isEnabled=false

                for (i  in 0 until consermaindis!!.getChildCount()) {
                    val child = consermaindis!!.getChildAt(i);
                    child.setEnabled(false);
                }




                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }
                onbkinside="came"

            }
            else
            {

                //And some views will be enabled when net is on
                onbkinside="not"
                relativeslayoutdis!!.visibility=View.GONE
                constraintLayout3dis!!.visibility=View.GONE

                scroll2_sliderdis!!.isEnabled=true
                scroll2_slider2dis!!.isEnabled=true
                gallerydis!!.isEnabled=true


                for (i  in 0 until consermaindis!!.getChildCount()) {
                    val child = consermaindis!!.getChildAt(i);
                    child.setEnabled(true);
                }
            }
        }
    }

    fun net_status():Boolean{ //Check net status
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}


