package com.example.vinitas.inventory_app

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import kotlinx.android.synthetic.main.activity_request_verify.*
import java.util.*
import android.R.string.cancel
import android.content.Context
import android.content.DialogInterface
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.os.Handler
import android.widget.TextView
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import kotlin.collections.ArrayList


class RequestVerifyActivity : AppCompatActivity() {


    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    var supplieridfr=String()


    var pono=String()



    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }

    private var addpurord: String=""
    private var editepurord:String=""
    private var deletepurord:String=""
    private var viewpurord:String=""
    private var transferpurord:String=""
    private var exportpurord:String=""
    private var sendpurpo= String()


    private var addsuppin: String=""
    private var editesuppin:String=""
    private var deletesuppin:String=""
    private var viewsuppin:String=""
    private var transfersuppin:String=""
    private var exportsuppin:String=""






    private var addpurreq: String=""
    private var editepurreq:String=""
    private var deletepurreq:String=""
    private var viewpurreq:String=""
    private var transferpurreq:String=""
    private var exportpurreq:String=""




    var stat= String()
    var brnky=String()
    var edclick= String()

    data class k(
            var status:String
    )
    data class s(

            var req_id: String,
            var branch_id: String,
            var ponumber:String,

            var supp_invoice:Any,
            var oreder_date:Any,
            var description:Any,
            var required_date:Any,
            var postatus:Any,
            var recstatus:Any,
            var req_date: Any,
            var req_name: Any,
            var req_mail: Any,
            var req_phone: Any,
            var prod_nms: Any,
            var req_estimated:Any,
            var supplier_name:Any,
            var supplier_address:Any,
            var supplier_addressLine1:Any,
            var supplier_addressLine2:Any,
            var supplier_GST:Any,
            var supplier_Phone:Any,
            var supplier_City:Any,
            var supplier_State:Any,
            var supplier_key:Any,

            var IGST_tot:Any,
            var CGST_tot:Any,
            var SGST_tot:Any,
            var Cess_tot:Any,







            var Gross_tot:Any


            /*    var stk_wg_vol: Any,
                var stk_name: String,
                var stk_mfr: String,

                var taxchk: Any*/
    )


    var namesnd= String()
    var statusssnd= String()
    var phonesnd= String()
    var datesnd= String()
    var datessnd= String()
    var Stockidssnd= String()
    var listidssnd= String()
    var bridssnd= String()
    var imgslnkssnd= String()



    data class li(

            var stk_name: Any,
            var stk_mfr: Any,
            var stk_hsn: Any,
            var stk_barcode: Any,
            var stk_received: Any,
            var stk_price: Any,
            var stk_total: Any,
            var stk_grosstotal: Any,
            var stk_cess: Any,
            var otherstk_igst: Any,
            var otherstk_cgst: Any,
            var otherstk_sgst: Any,
            var otherstk_igsttotal: Any,
            var otherstk_cesstotal: Any,
            var otherstk_tally: Any,
            var otherstk_received: Any,
            var received_price:Any,
            var received_total:Any,
            var otherstk_img:Any,

            var received_taxtotal:Any,
            var received_cesstotal:Any,
            var received_grosstotal:Any,
            var stk_key:Any,
            var stk_prokey:Any
    )
    var TAG="some"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_verify)



        net_status() //Check internet status.


        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@RequestVerifyActivity) > 0)
        {

        }
        else{
            Toast.makeText(applicationContext,"You are offline",Toast.LENGTH_SHORT).show()

        }


        //Define No connection view  when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        addLogText(NetworkUtil.getConnectivityStatusString(this@RequestVerifyActivity))

        var ids = arrayOf<String>()
        var prodnms = arrayOf<String>()


        userback.setOnClickListener {
            onBackPressed()
        }




        try {

            namesnd = intent.getStringExtra("spnm")
        }
        catch (e:Exception)

        {

        }
        try {
            statusssnd = intent.getStringExtra("status")

        }
        catch (e:Exception)

        {

        }
        try {
            phonesnd = intent.getStringExtra("spph")


        }
        catch (e:Exception)

        {

        }

        try {
            datesnd = intent.getStringExtra("date")

        }
        catch (e:Exception)

        {

        }
        try {
            datessnd = intent.getStringExtra("estidate")


        }
        catch (e:Exception)

        {

        }
        try {
            Stockidssnd = intent.getStringExtra("reqids")
        }
        catch (e:Exception)
        {

        }
        try {
            listidssnd = intent.getStringExtra("listids")
        }
        catch (e:Exception)
        {

        }


        try {
            val imlinks=intent.getStringExtra("imlink")
            imgslnkssnd=imlinks



        }
        catch (e:Exception){

        }

        try{

            edclick=intent.getStringExtra("edclick")

        }
        catch (e:Exception)
        {

        }


        try{
            supplieridfr=intent.getStringExtra("supplieridfr")
        }
        catch (e:Exception){

        }


        var idofl=String()
        var statustos=String()


        var pronameArray = arrayListOf<String>()
        var hsnArray = arrayListOf<String>()
        var manufacturerArray = arrayListOf<String>()
        var barcodeArray = arrayListOf<String>()
        var quantityArray = arrayListOf<String>()
        var priceArray = arrayListOf<String>()
        var totArray = arrayListOf<String>()
        var grosstotArray = arrayListOf<String>()

        var cessArray = arrayListOf<String>()
        var keyArray = arrayListOf<String>()
        var igstArray = arrayListOf<String>()
        var cgstArray = arrayListOf<String>()
        var sgstArray = arrayListOf<String>()
        var igsttotArray = arrayListOf<String>()
        var cesstotalArray = arrayListOf<String>()
        var tallyArray = arrayListOf<String>()
        var receivedArray = arrayListOf<String>()
        var receivedpriceArray    = arrayListOf<String>()
        var receivedtotalArray    = arrayListOf<String>()
        var receivedtaxtotalArray = arrayListOf<String>()
        var receivedcesstotArray  = arrayListOf<String>()
        var receivedgrosstotArray = arrayListOf<String>()

        var idproArray=arrayListOf<String>()



        var imageArray = arrayListOf<String>()
        val db = FirebaseFirestore.getInstance()
        val g = intent.getStringExtra("idd")
        listoids.setText(g)
        val gd = intent.getStringExtra("status")
        statustos=gd

        val gdky = intent.getStringExtra("brid")
        brnky=gdky









        //Purchase request

        val adpr = intent.getStringExtra("addpurreq")
        val edpr = intent.getStringExtra("editpurreq")
        val delpr = intent.getStringExtra("deletepurreq")
        val vipr=intent.getStringExtra("viewpurreq")
        val tranpr=intent.getStringExtra("transferpurreq")
        val expr=intent.getStringExtra("exportpurreq")

        if (adpr != null) {
            addpurreq = adpr
        }
        if (edpr != null) {
            editepurreq = edpr
        }
        if (delpr != null) {
            deletepurreq = delpr
        }
        if (vipr != null) {
            viewpurreq = vipr
        }
        if (tranpr != null) {
            transferpurreq = tranpr


            println("PURCHASE REQUEST TRANSFER NEXT"+transferpurreq)


        }
        if (expr != null) {
            exportpurreq = expr
        }


        //Purchase order

        val adord = intent.getStringExtra("addpurord")
        val edord = intent.getStringExtra("editpurord")
        val delord = intent.getStringExtra("deletepurord")
        val viord=intent.getStringExtra("viewpurord")
        val tranord=intent.getStringExtra("transferpurord")
        val exord=intent.getStringExtra("exportpurord")
        sendpurpo=intent.getStringExtra("sendpurord")
        if (adord != null) {
            addpurord = adord
        }
        if (edord != null) {
            editepurord = edord
        }
        if (delord != null) {
            deletepurord = delord
        }
        if (viord != null) {
            viewpurord = viord
        }
        if (tranord != null) {
            transferpurord = tranord
        }
        if (exord != null) {
            exportpurord = exord
        }


        //Supplier Invoice

        val adsuppin = intent.getStringExtra("addsuppin")
        val edsuppin = intent.getStringExtra("editsuppin")
        val delsuppin = intent.getStringExtra("deletesuppin")
        val visuppin=intent.getStringExtra("viewsuppin")
        val transuppin=intent.getStringExtra("transfersuppin")
        val exsuppin=intent.getStringExtra("exportsuppin")

        if (adsuppin != null) {
            addsuppin = adsuppin
        }
        if (edsuppin != null) {
            editesuppin = edsuppin
        }
        if (delsuppin != null) {
            deletesuppin = delsuppin
        }
        if (visuppin != null) {
            viewsuppin = visuppin
        }
        if (transuppin != null) {
            transfersuppin = transuppin
        }
        if (exsuppin != null) {
            exportsuppin = exsuppin
        }



        idofl=listoids.text.toString()



        //Get purchase request from db

        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();

        db.collection("${brnky}_Purchase Request").document(listoids.text.toString())
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        if(task.result.exists()){
                        if (task.result != null) {
                            Log.d("data", "is" + task.result.data)
                            req_id.setText(task.result.get("req_id").toString())
                            request_date.setText(task.result.get("req_date").toString())
                            reqest_date.setText(task.result.get("req_estimated").toString())
                            req_name.setText(task.result.get("req_name").toString())
                            req_mail.setText(task.result.get("req_mail").toString())

                            supp_name.setText(task.result.get("supplier_name").toString())
                            supp_phone.setText(task.result.get("supplier_Phone").toString())
                            supp_addre.setText(task.result.get("supplier_address").toString())
                            addre1.setText(task.result.get("supplier_addressLine1").toString())
                            addre2.setText(task.result.get("supplier_addressLine2").toString())
                            supp_gst.setText(task.result.get("supplier_GST").toString())
                            supp_city.setText(task.result.get("supplier_City").toString())
                            supp_state.setText(task.result.get("supplier_State").toString())

                            supplieridfr=task.result.get("supplier_Key").toString()
                        } else {
                            Log.d("data", "is not here")
                        }
                    }
                        else{
                        }

                    }
                        else {
                        Log.d("task is not success", "full" + task.exception)
                    }

                }
        db.collection("${brnky}_Purchase Request/${listoids.text}/Stock_products")
                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                    if (e != null) {
                        Log.w("", "Listen failed.", e)
                        return@EventListener
                    }
                    if(value.isEmpty==false) {
                        for (document in value) {

                            Log.d("d", "key --- " + document.id + " => " + document.data)
                            println(document.data)

                            var dt = document.data
                            var id = (document.id)
                            id = id
                            ids = ids.plusElement(id)
                            /*idsforup=ids*/
                            println("Heyyyyyyy" + Arrays.toString(ids))
                            println("HELLOOOOOOOOO" + id)
                            pronameArray.add(dt["stk_name"].toString())

                            manufacturerArray.add(dt["stk_mfr"].toString())
                            hsnArray.add(dt["stk_hsn"].toString())

                            quantityArray.add(dt["stk_received"].toString())

                            priceArray.add(dt["stk_price"].toString())
                            totArray.add(dt["stk_total"].toString())
                            grosstotArray.add(dt["stk_grosstotal"].toString())

                            barcodeArray.add(dt["stk_barcode"].toString())
                            cessArray.add(dt["stk_cess"].toString())
                            igstArray.add(dt["otherstk_igst"].toString())
                            cgstArray.add(dt["otherstk_cgst"].toString())
                            sgstArray.add(dt["otherstk_sgst"].toString())
                            igsttotArray.add(dt["otherstk_igsttotal"].toString())
                            cesstotalArray.add(dt["otherstk_cesstotal"].toString())
                            tallyArray.add(dt["otherstk_tally"].toString())
                            receivedArray.add(dt["otherstk_received"].toString())
                            receivedpriceArray.add("0")
                            receivedtotalArray.add("0")
                            receivedtaxtotalArray.add("0")
                            receivedcesstotArray.add("0")
                            receivedgrosstotArray.add("0")
                            try {
                                var im = (dt["otherstk_img"].toString())
                                if (im.isNotEmpty()) {

                                    imageArray.add(im)
                                } else {
                                    imageArray.add("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                }
                            } catch (e: Exception) {

                            }
                            keyArray.add(id)
                            idproArray.add(dt["stk_prokey"].toString())

                        }
                    }
                    else{
                        pDialog.dismiss()
                    }
                    pDialog.dismiss()
                    val whatever = purchseorder_list_adaps(this, pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray,grosstotArray,
                            cessArray, keyArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray,receivedpriceArray,receivedtaxtotalArray,
                            receivedcesstotArray,receivedgrosstotArray,receivedtotalArray,imageArray)
                    purreq_list.adapter = whatever
                    Helper.getListViewSize(purreq_list);
                    pur_save_prgrs.visibility = View.GONE
                    try {
                        var total = 0.0F
                        var igsttot = 0.0F
                        var cesstotals = 0.0F
                        var b = 2
                        for (i in 0 until priceArray.count()) {
                            var c = (priceArray[i])
                            var cy=(igsttotArray[i])
                            var cyz=(cesstotalArray[i])
                            var qyz=(quantityArray[i])

                            var cdec=c.toBigDecimal()
                            var qyzdec=qyz.toBigDecimal()
                            var totquanpri=(cdec*qyzdec)




                            total = total.plus(totquanpri.toInt())

                            igsttot = igsttot.plus(cy.toFloat())
                            cesstotals = cesstotals.plus(cyz.toFloat())

                            igst_tot.setText(String.format("%.2f",igsttot))
                            var l = igst_tot.text.toString()
                            var ss = l.toBigDecimal()
                            var tt = ss / b.toBigDecimal()
                            cgst_tot.setText(String.format("%.2f",tt))
                            sgst_tot.setText(String.format("%.2f",tt))

                            cess_tot.setText(String.format("%.2f",cesstotals))

                            var f=cesstotals
                            var g=igsttot

                            var op=total
                            var m=f.toFloat()
                            var n=g.toFloat()

                            var yy=m+n+op

                            try {
                                gross_tot.setText(String.format("%.2f",yy))
                            }
                            catch (e:Exception){
                                gross_tot.setText(String.format("%.2f",yy))
                            }
                            Log.v("fgarghhgioghigjrio", "TOTAL" + total)

                            var d = pronameArray[i]
                            var t = d.removeSuffix("- ml")
                            prodnms = prodnms.plusElement(t)
                            names.setText(Arrays.toString(prodnms))
                            var u = names.text
                            var s = u.removePrefix("[")
                            var y = s.removeSuffix("]")
                            names.setText(y)



                            println("TRIMED LIST NAMESSS" + Arrays.toString(prodnms))
                        }
                    } catch (e: Exception) {
                        Toast.makeText(applicationContext, "Price empty", Toast.LENGTH_SHORT).show()
                    }
                    listoids.setText("")


                })




        //----------------------------------Verify button click to make purchase order------------------------//

        acverify.setOnClickListener {

            if(net_status()==true) {
                println("CLICKED")
                if (transferpurreq == "true") {
                    val alert = AlertDialog.Builder(this@RequestVerifyActivity)
                    val inflater = this.layoutInflater
                    val dialog = alert.create()
                    dialog.setView(inflater.inflate(R.layout.loginpop, null))
                    dialog.show()
                    val ok = dialog.findViewById<Button>(R.id.ok) as Button


                    ok.setOnClickListener { views ->
                        if (statustos == "") {
                            var status = "Pending"
                            statustos = status
                            stat = status
                        } else {
                            var status = "Approved"
                            statustos = status
                            stat = status
                        }
                        val map = mutableMapOf<String, Any?>()
                        map.put("status", stat)

                        db.collection("${brnky}_Purchase Request").document(idofl)
                                .update(map)
                                .addOnSuccessListener {
                                    val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                                    pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
                                    pDialog.setTitleText("Processing...");
                                    pDialog.setCancelable(false);
                                    pDialog.show();
                                    if (statustos == "Pending") {

                                        val i = Intent(this@RequestVerifyActivity, PurchaseRequestActivity::class.java)
                                        i.putExtra("from_ver", "halfverify")
                                        i.putExtra("viewsuppin", viewsuppin)
                                        i.putExtra("addsuppin", addsuppin)
                                        i.putExtra("deletesuppin", deletesuppin)
                                        i.putExtra("editsuppin", editesuppin)
                                        i.putExtra("transfersuppin", transfersuppin)
                                        i.putExtra("exportsuppin", exportsuppin)


                                        i.putExtra("viewpurord", viewpurord)
                                        i.putExtra("addpurord", addpurord)
                                        i.putExtra("deletepurord", deletepurord)
                                        i.putExtra("editpurord", editepurord)
                                        i.putExtra("transferpurord", transferpurord)
                                        i.putExtra("exportpurord", exportpurord)
                                        i.putExtra("sendpurord", sendpurpo)




                                        i.putExtra("viewpurreq", viewpurreq)
                                        i.putExtra("addpurreq", addpurreq)
                                        i.putExtra("deletepurreq", deletepurreq)
                                        i.putExtra("editpurreq", editepurreq)
                                        i.putExtra("transferpurreq", transferpurreq)
                                        i.putExtra("exportpurreq", exportpurreq)


                                        i.putExtra("brky", brnky)
                                        startActivity(i)
                                        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_right)
                                        finish()
                                    }


                                }

                        println("STATUSSSSSS" + statustos)
                        if ((listoids.text == "") && (statustos == "Approved")) {
                            pur_save_prgrs.visibility = android.view.View.VISIBLE
                            onStarClicked1(pronameArray, manufacturerArray, hsnArray, barcodeArray, quantityArray, priceArray, totArray,grosstotArray, cessArray, igstArray, cgstArray, sgstArray, igsttotArray, cesstotalArray, tallyArray, receivedArray, receivedpriceArray, receivedtaxtotalArray, receivedcesstotArray, receivedgrosstotArray, receivedtotalArray, keyArray, imageArray,idproArray)

                        }

                        /*var pronms = (names.text).toString()
                    var pono="PO"+id1
                    var reqdate=""
                    var desc=""
                    var orderdate=""
                    var postatus=""
                    var requestid = (req_id.text).toString()
                    var requestdate = (request_date.text).toString()
                    var requ_name = (req_name.text).toString()
                    var requ_mail = (req_mail.text).toString()
                    var requ_esti = (reqest_date.text).toString()
                    var requ_phone = (req_phone.text).toString()
                    var supp_name = (supp_name.text).toString()
                    var supp_phone = (supp_phone.text).toString()
                    var supp_gst = (supp_gst.text).toString()
                    var supp_city = (supp_city.text).toString()
                    var supp_state = (supp_state.text).toString()
                    var supp_add1 = (supp_addre.text).toString()
                    var supp_add2 = (addre1.text).toString()
                    var supp_add3 = (addre2.text).toString()

                    var igsttot = (igst_tot.text).toString()
                    var cgsttot = (cgst_tot.text).toString()
                    var sgsttot = (sgst_tot.text).toString()
                    var cesstot = (cess_tot.text).toString()
                    var grosstot = (gross_tot.text).toString()


                    val data = s(req_id = requestid, req_date = requestdate, req_name = requ_name, req_mail = requ_mail, req_estimated = requ_esti, req_phone = requ_phone, supplier_name = supp_name, supplier_Phone = supp_phone, supplier_GST = supp_gst, supplier_City = supp_city, supplier_State = supp_state, supplier_address = supp_add1, supplier_addressLine1 = supp_add2, supplier_addressLine2 = supp_add3, IGST_tot = igsttot, CGST_tot = cgsttot, SGST_tot = sgsttot, Cess_tot = cesstot, Gross_tot = grosstot, prod_nms = pronms)
                    var db = FirebaseFirestore.getInstance()
                    println(Arrays.toString(ids))
                    db.collection("Purchase Request").document(listoids.text.toString())
                            .set(data)
                            .addOnSuccessListener {
                                var refid = listoids.text.toString()
                                println("WHAT A IDSSSSSSSS" + listoids.text.toString())
                                var path = "Purchase Request/$refid/Stock_products"

                                for (i in 0 until priceArray.size) {
                                    var stk_name = pronameArray[i]
                                    var stk_mfr = manufacturerArray[i]
                                    var stk_hsn = hsnArray[i]
                                    var stk_bcode = barcodeArray[i]
                                    var stk_quan = quantityArray[i]
                                    var stk_pri = priceArray[i]
                                    var stk_tot = totArray[i]
                                    var stk_cess = cessArray[i]
                                    var stk_igst = igstArray[i]
                                    var stk_cgst = cgstArray[i]
                                    var stk_sgst = sgstArray[i]
                                    var stk_igsttot = igsttotArray[i]
                                    var stk_cesstot = cesstotalArray[i]
                                    var stk_tally = tallyArray[i]
                                    var stk_received = receivedArray[i]
                                    var stk_key = keyArray[i]


                                    var d = li(stk_name = stk_name, stk_mfr = stk_mfr, stk_hsn = stk_hsn, stk_barcode = stk_bcode, stk_received = stk_quan, stk_price = stk_pri, stk_total = stk_tot, stk_cess = stk_cess, otherstk_igst = stk_igst, otherstk_cgst = stk_cgst, otherstk_sgst = stk_sgst, otherstk_igsttotal = stk_igsttot, otherstk_cesstotal = stk_cesstot, stk_key = stk_key, otherstk_tally = stk_tally, otherstk_received = stk_received)
                                    if (keyArray[i].equals("")) {
                                        db.collection(path)
                                                .add(d)
                                                .addOnSuccessListener { documentReference ->
                                                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                                                    var refid = documentReference.id

                                                }
                                    }

                                    *//*  else if(getiddel.isNotEmpty()){
                                      val deleteSize =  getiddel.size
                                      val i = 0
                                      for (i in getiddel) {
                                          db.collection(path).document(i.toString())
                                                  .delete()
                                                  .addOnSuccessListener {
                                                      getiddel.clear()
                                                      onBackPressed()


                                                  }
                                      }
                                  }*//*
                                    else {
                                        db.collection(path).document(keyArray[i])
                                                .set(d)
                                                .addOnCompleteListener {
                                                    Toast.makeText(this, "Your Data is Saved", Toast.LENGTH_LONG).show()
                                                    pur_save_prgrs.visibility = android.view.View.GONE
                                                    onBackPressed()
                                                }
                                    }
                                }

                            }

                }


            }
        }*/
                    }
                } else if (transferpurreq == "false") {
                    popup("Purchase order")
                }
            }
            else{
                Toast.makeText(applicationContext,"Please turn on your connection",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun onStarClicked1(pronameArray:ArrayList<String>, manufacturerArray:ArrayList<String>, hsnArray:ArrayList<String>,
                               barcodeArray:ArrayList<String>, quantityArray:ArrayList<String>, priceArray:ArrayList<String>,
                               totArray:ArrayList<String>,grosstotArray:ArrayList<String>, cessArray:ArrayList<String>, igstArray:ArrayList<String>, cgstArray:ArrayList<String>,
                               sgstArray:ArrayList<String>, igsttotArray:ArrayList<String>, cesstotalArray:ArrayList<String>,
                               tallyArray: ArrayList<String>,receivedArray: ArrayList<String>,receivedpriceArray:ArrayList<String>,
                               receivedtaxtotalArray:ArrayList<String>,receivedcesstotArray:ArrayList<String>,receivedgrosstotArray:ArrayList<String>,
                               receivedtotalArray:ArrayList<String>, keyArray:ArrayList<String>,imageArray:ArrayList<String>,idproArray:ArrayList<String>) {
        data class Count(var number: Int)

        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("Purchase_order")
        myRef.runTransaction(object : com.google.firebase.database.Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): com.google.firebase.database.Transaction.Result? {
                var p = mutableData.value


                if (p == null) {
                    p = 1
                }

                if (p == 0) {
                    // Unstar the post and remove self from stars
                    p = 1

                } else {
                    // Star the post and add self to stars
                    p = Integer.parseInt(p.toString()) + 1
                }

                // Set value and report transaction success
                mutableData.value = p
                //mutableData.setValue(p.number)
                return com.google.firebase.database.Transaction.success(mutableData)
            }

            override fun onComplete(
                    databaseError: DatabaseError?,
                    b: Boolean,
                    dataSnapshot: DataSnapshot
            ) {

                println(dataSnapshot)
                println(dataSnapshot.value)
                val id = dataSnapshot.value

                prod_insert(id.toString(),pronameArray,manufacturerArray,hsnArray,barcodeArray,quantityArray,priceArray,totArray,grosstotArray,cessArray,
                        igstArray,cgstArray,sgstArray,igsttotArray,cesstotalArray,tallyArray,
                        receivedArray,receivedpriceArray,receivedtaxtotalArray,receivedcesstotArray,receivedgrosstotArray,
                        receivedtotalArray,keyArray,imageArray,idproArray)


                // Transaction completed
                // Log.d("", "postTransaction:onComplete:" + databaseError)
            }
        })
    }

    fun prod_insert(id1: String, pronameArray: ArrayList<String>, manufacturerArray: ArrayList<String>, hsnArray: ArrayList<String>,
                    barcodeArray: ArrayList<String>, quantityArray: ArrayList<String>, priceArray: ArrayList<String>, totArray: ArrayList<String>, grosstotArray: ArrayList<String>,
                    cessArray: ArrayList<String>, igstArray:ArrayList<String>, cgstArray:ArrayList<String>, sgstArray:ArrayList<String>,
                    igsttotArray:ArrayList<String>, cesstotalArray:ArrayList<String>, tallyArray:ArrayList<String>, receivedArray:ArrayList<String>,
                    receivedpriceArray:ArrayList<String>, receivedtaxtotalArray:ArrayList<String>, receivedcesstotArray:ArrayList<String>,
                    receivedgrosstotArray:ArrayList<String>, receivedtotalArray:ArrayList<String>, keyArray: ArrayList<String>,
                    imageArray: ArrayList<String>, idproArray: ArrayList<String>) {


        if((id1=="1")||(id1=="2")||(id1=="3")||(id1=="4")||(id1=="5")
                ||(id1=="6")||(id1=="7")||(id1=="8")||(id1=="9")){
             pono="PO0"+id1
        }
        else{
            pono="PO"+id1
        }
        var brid =brnky
        var requestid = req_id.text.toString()

        var reqdate=""
        var desc=""
        var orderdate=""
        var postatus="InComplete"
        var recstatus=""

        var pronms=(names.text).toString()
        var requestdate = (request_date.text).toString()
        var requ_name = (req_name.text).toString()
        var requ_mail = (req_mail.text).toString()
        var requ_esti = (reqest_date.text).toString()
        var requ_phone = (req_phone.text).toString()
        var supp_name = (supp_name.text).toString()
        var supp_phone = (supp_phone.text).toString()
        var supp_gst = (supp_gst.text).toString()
        var supp_city = (supp_city.text).toString()
        var supp_state = (supp_state.text).toString()
        var supp_add1 = (supp_addre.text).toString()
        var supp_add2 = (addre1.text).toString()
        var supp_add3 = (addre2.text).toString()
        var igst = (igst_ed.text).toString()
        var cgstii = (cgst_ed.text).toString()
        var sgstii = (sgst_ed.text).toString()
        var igsttot = (igst_tot.text).toString()
        var cgsttot = (cgst_tot.text).toString()
        var sgsttot = (sgst_tot.text).toString()
        var cesstot = (cess_tot.text).toString()
        var grosstot = (gross_tot.text).toString()

        var suppinv=""

        val data = s(branch_id = brid,req_id = requestid, req_date = requestdate, req_name = requ_name,
                req_mail = requ_mail,req_estimated = requ_esti,req_phone = requ_phone,supplier_name = supp_name,
                supplier_Phone = supp_phone,supplier_GST = supp_gst,supplier_City = supp_city,supplier_State = supp_state,
                supplier_address = supp_add1,supplier_addressLine1 = supp_add2,supplier_addressLine2 = supp_add3,
                IGST_tot = igsttot,CGST_tot = cgsttot,SGST_tot = sgsttot,Cess_tot = cesstot,Gross_tot = grosstot,
                prod_nms = pronms,ponumber = pono,required_date = reqdate,postatus = postatus,recstatus = recstatus,
                oreder_date = orderdate,description = desc,supplier_key = supplieridfr,supp_invoice = suppinv)
        var db = FirebaseFirestore.getInstance()
        db.collection("${brnky}_Purchase Orders")
                .add(data)
                .addOnSuccessListener { documentReference ->

                    Log.d(TAG, "DocumentSnapshot written with ID: " + documentReference.id)
                    var refid=documentReference.id


                    var path="${brnky}_Purchase Orders/$refid/purchase_products"
                    for(i in 0 until priceArray.size) {

                        var stk_name=pronameArray[i]
                        var stk_mfr=manufacturerArray[i]
                        var stk_hsn=hsnArray[i]
                        var stk_bcode=barcodeArray[i]
                        var stk_quan=quantityArray[i]
                        var stk_pri=  priceArray[i]
                        var stk_tot=totArray[i]
                        var stk_grosstot=grosstotArray[i]

                        var stk_cess=cessArray[i]
                        var stk_igst = igstArray[i]
                        var stk_cgst = cgstArray[i]
                        var stk_sgst = sgstArray[i]
                        var stk_igsttot = igsttotArray[i]
                        var stk_cesstot = cesstotalArray[i]
                        var stk_tally = tallyArray[i]
                        var stk_received = receivedArray[i]
                        var im_arr=imageArray[i]
                        var stk_receivedprice = receivedpriceArray[i]
                        var stk_receivedtotal = receivedtotalArray[i]
                        var stk_receivedtaxtotal = receivedtaxtotalArray[i]
                        var stk_receivedcesstotal = receivedcesstotArray[i]
                        var stk_receivedgrosstotal = receivedgrosstotArray[i]
                        var idproarr=idproArray[i]


                        var stk_key= keyArray[i]
                        var d=li(stk_name=stk_name,stk_mfr = stk_mfr,stk_hsn=stk_hsn,stk_barcode = stk_bcode,stk_received = stk_quan,
                                stk_price = stk_pri,stk_total = stk_tot, stk_grosstotal = stk_grosstot,stk_cess = stk_cess,otherstk_igst=stk_igst,
                                otherstk_cgst=stk_cgst,otherstk_sgst=stk_sgst,otherstk_igsttotal = stk_igsttot,otherstk_cesstotal = stk_cesstot,stk_key = stk_key,
                                otherstk_tally = stk_tally,otherstk_received = stk_received,received_price = stk_receivedprice,received_cesstotal = stk_receivedcesstotal,
                                received_grosstotal = stk_receivedgrosstotal,received_taxtotal = stk_receivedtaxtotal,received_total = stk_receivedtotal,otherstk_img = im_arr,stk_prokey = idproarr)
                        db.collection(path)
                                .add(d)

                                .addOnSuccessListener { documentReference ->

                                }

                    }
                    var resid=documentReference.id
                    val pDialog= SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
                    pDialog.dismiss()



                    val pDialog1 = SweetAlertDialog(this,SweetAlertDialog.SUCCESS_TYPE)


                    pDialog1.progressHelper.barColor = resources.getColor(R.color.toolbar)

                    pDialog1.titleText = "Accepted!"
                    pDialog1.contentText = "Your request accepted!!!"
                    pDialog1.changeAlertType(SweetAlertDialog.SUCCESS_TYPE)
                    pDialog1.show()

                    val a= Intent(this@RequestVerifyActivity,PurchaseRequestActivity::class.java)
                    a.putExtra("status",stat)
                    a.putExtra("from_ver","verify")
                    a.putExtra("viewsuppin", viewsuppin)
                    a.putExtra("addsuppin", addsuppin)
                    a.putExtra("deletesuppin", deletesuppin)
                    a.putExtra("editsuppin", editesuppin)
                    a.putExtra("transfersuppin", transfersuppin)
                    a.putExtra("exportsuppin", exportsuppin)


                    a.putExtra("viewpurord", viewpurord)
                    a.putExtra("addpurord", addpurord)
                    a.putExtra("deletepurord", deletepurord)
                    a.putExtra("editpurord", editepurord)
                    a.putExtra("transferpurord", transferpurord)
                    a.putExtra("exportpurord", exportpurord)
                    a.putExtra("sendpurord", sendpurpo)




                    a.putExtra("viewpurreq", viewpurreq)
                    a.putExtra("addpurreq", addpurreq)
                    a.putExtra("deletepurreq", deletepurreq)
                    a.putExtra("editpurreq", editepurreq)
                    a.putExtra("transferpurreq", transferpurreq)
                    a.putExtra("exportpurreq", exportpurreq)


                    a.putExtra("brky",brnky)
                    Handler().postDelayed({
                        pDialog1.hide()
                        startActivity(a)
                        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                        finish()
                    }, 2000)


                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Error adding document", e)
                    Toast.makeText(this, "data is Not Save", Toast.LENGTH_LONG).show()
                    /* save_progress.visibility = android.view.View.GONE*/
                }

    }

    fun popup(st:String){  //Access denied popup
        val pop= android.support.v7.app.AlertDialog.Builder(this)
        pop.create()
        val title= TextView(this)
        title.setTextColor(resources.getColor(android.R.color.holo_red_dark))
        title.setPadding(50,20,20,20)
        title.textSize= 20F
        title.setText("Access Denied!")
        pop.setCustomTitle(title)
        pop.setMessage("You dont have Access to $st")
        pop.setPositiveButton("ok", DialogInterface.OnClickListener { dialogInterface, i ->
            dialogInterface.cancel()
        })
        pop.show()
    }

    override fun onBackPressed() {

        var frmver="verify"

        val b = Intent(applicationContext, RequestAddActivity::class.java)

        b.putExtra("from_req", "startlist_req")
        b.putExtra("spnm", namesnd)
        b.putExtra("spph", phonesnd)
        b.putExtra("date", datesnd)
        b.putExtra("estidate", datessnd)
        b.putExtra("reqids",Stockidssnd )
        b.putExtra("listids", listidssnd)
        b.putExtra("status", statusssnd)
        b.putExtra("frmver",frmver)
        try{
            b.putExtra("edclick",edclick)
        }
        catch (e:Exception){

        }



        try {
            b.putExtra("imlink",imgslnkssnd )
        }
        catch (e:Exception){

        }

        b.putExtra("viewsuppin", viewsuppin)
        b.putExtra("addsuppin", addsuppin)
        b.putExtra("deletesuppin", deletesuppin)
        b.putExtra("editsuppin", editesuppin)
        b.putExtra("transfersuppin", transfersuppin)
        b.putExtra("exportsuppin", exportsuppin)


        b.putExtra("viewpurord", viewpurord)
        b.putExtra("addpurord", addpurord)
        b.putExtra("deletepurord", deletepurord)
        b.putExtra("editpurord", editepurord)
        b.putExtra("transferpurord", transferpurord)
        b.putExtra("exportpurord", exportpurord)
        b.putExtra("sendpurord", sendpurpo)




        b.putExtra("viewpurreq", viewpurreq)
        b.putExtra("addpurreq", addpurreq)
        b.putExtra("deletepurreq", deletepurreq)
        b.putExtra("editpurreq", editepurreq)
        b.putExtra("transferpurreq", transferpurreq)
        b.putExtra("exportpurreq", exportpurreq)


        b.putExtra("brids",brnky)
        startActivity(b)
        overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
        finish()



    }
    companion object {
        //Listens internet status whether net is on/off.

        val REQUEST_CODE = 100
        val PERMISSION_REQUEST = 200
        var onbkinside:String?=null
        var pDialogs: SweetAlertDialog? = null
        private var log_network: View? = null
        private var log_networktext: View? = null
        private val log_str: String? = null



        fun addLogText(log: String?) {
            if(log=="NOT_CONNECT"){
                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                try {
                    pDialogs!!.dismiss()
                }
                catch (e:Exception){

                }
                onbkinside="came"

            }
            else
            {
                onbkinside="not"
                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
            }
        }
    }
    fun net_status():Boolean{   ////Check internet status.
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }

}
