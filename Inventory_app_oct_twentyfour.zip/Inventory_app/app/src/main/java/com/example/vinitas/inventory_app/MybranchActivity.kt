package com.example.vinitas.inventory_app


import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkInfo
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.constraint.ConstraintLayout
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.view.animation.AnimationUtils
import android.view.inputmethod.InputMethodManager
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.RelativeLayout
import android.widget.Toast
import cn.pedant.SweetAlert.SweetAlertDialog
import com.example.vinitas.netlistener.services.NetworkChangeReceiver
import com.example.vinitas.netlistener.utils.NetworkUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.EventListener

import kotlinx.android.synthetic.main.activity_mybranch.*
import java.util.*
import kotlin.collections.ArrayList

class MybranchActivity : AppCompatActivity() {

    data class k(
            var stock_hand:String
    )

    var db = FirebaseFirestore.getInstance()
    val TAG = "some"
    var idss= String()
    var lststr= String()
    var qntArray= arrayOf<String>()
    var ffstr= String()
    var idstr= String()
    var countss= 0
    var bcd= String()

    var esc= String()
    var upstr= String()
    var numberstr= String()
    var regtr= String()
    var nmstr= String()
    var kyval= String()

    var avoidpop= String()

    var idstrarr=arrayOf<String>()
    var stockonhand= String()

        var datach= String()
        var qn=String()

    internal  var intentFilter: IntentFilter? =null
    internal var receiver: NetworkChangeReceiver? = null

    override fun onResume() {
        super.onResume()
        registerReceiver(receiver, intentFilter)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(receiver)
    }


    private  var viewstklvls=String()
    var brids=String()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mybranch)

        net_status() ////Check internet status.

        var sd= String()

        var x= String()

        var reg= String()

        viewstklvls = intent.getStringExtra("viewstklvl")

        val j = intent.getStringExtra("bkey")

        brids = j
        /*       val window = this.getWindow()

// clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)

// add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)

// finally change the color
        window.setStatusBarColor(ContextCompat.getColor(this, android.R.color.black))*/





        //Listens internet changing movements

        intentFilter = IntentFilter()
        intentFilter!!.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        receiver = NetworkChangeReceiver()

        if (NetworkUtil.getConnectivityStatus(this@MybranchActivity) > 0)
        {

        }
        else{

        }


        //Define No connection view when inetrnet connection is off.

        log_network = findViewById(R.id.view7)
        log_networktext = findViewById(R.id.textView36)
        relatively=findViewById(R.id.relativeslayout)
        cont=findViewById<ConstraintLayout>(R.id.containmybr)

        addLogText(NetworkUtil.getConnectivityStatusString(this@MybranchActivity))



        //Search view open when clicking the search icon

        search.setOnClickListener {
            println("clicked")
            cardsearch.visibility=View.VISIBLE
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@MybranchActivity,R.anim.slide_to_right))
            searchedit.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(searchedit, InputMethodManager.SHOW_IMPLICIT)
        }

        //Search view close when clicking the close icon

        searback1.setOnClickListener {
            cardsearch.visibility=View.GONE
            searchedit.text.clear()
            cardsearch.startAnimation(AnimationUtils.loadAnimation(this@MybranchActivity,R.anim.slide_to_left))
            ggg()
            mylist.visibility=View.VISIBLE
            nores.visibility= View.GONE
        }


        imageButton2.setOnClickListener({


            //Vert menu with 'Logout'option


            val popup = PopupMenu(this@MybranchActivity, imageButton2)

            popup.menuInflater.inflate(R.menu.logout, popup.menu)

            popup.setOnMenuItemClickListener { item ->


                //Navigate to pin activity
                if (item.title == "Logout") {
                    Toast.makeText(this@MybranchActivity, "You are logged out", Toast.LENGTH_SHORT).show()
                    val f = Intent(this@MybranchActivity, PinActivity::class.java)
                    startActivity(f)
                    overridePendingTransition(R.anim.slide_in_right,R.anim.slide_out_right)
                    finish()
                }
                true
            }

            popup.show()
        })



        //---------------------------Search action -------------------------------//
        searchedit.addTextChangedListener(object : TextWatcher {
            override fun onTextChanged(des: CharSequence, start: Int, before: Int, count: Int) {
                avoidpop="camein"

                progressBar3.visibility= View.VISIBLE
                mylist.visibility=View.GONE

                println("KEYS OF SEARCHHH" + kyval)
                sd = des.toString()
                x = sd
                val regexStr = "^[0-9]*$"
                val emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

                //--------------------Barcode search------------------------------//

                fun bcodeget() {

                    nores.visibility = View.GONE

                    if ((des.length >= 3) && (bcd == "bcode")) {

                        var idsArray = arrayOf<String>()
                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()
                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status


                        db.collection("product").orderBy("bc").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0
                                                idstr = id

                                                idstrarr = idstrarr.plusElement(idstr)



                                                lststr = "in"
                                                var ddstr = id + "_" + brids
                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + brids)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$brids", qn)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)
                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{ task, e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        stockonhand = doc.get("$brids").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                        val img5url = doc.get("img5url").toString();//37
                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33


                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)

                                                                                        icohighArray = icohighArray.plusElement(img1urlhigh)
                                                                                        icohighnmArray = icohighnmArray.plusElement(img1nhigh)








                                                                                        println(Arrays.toString(disArray))

                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                        if (ur.isNotEmpty()) {
                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                        } else {
                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                        }

                                                                                        progressBar3.visibility = View.GONE
                                                                                        mylist.visibility = View.VISIBLE

                                                                                    }


                                                                                    val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                    val slist = findViewById<View>(R.id.mylist) as ListView
                                                                                    slist.adapter = whatever


                                                                                })

                                                                    }


                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        } else {

                                        //--------------------Stock level search------------------//

                                            db.collection("product").orderBy("$brids").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0
                                                                    idstr = id

                                                                    idstrarr = idstrarr.plusElement(idstr)



                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + brids
                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + brids)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$brids", qn)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)
                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            stockonhand = doc.get("$brids").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            try {
                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                val img4url = doc.get("img4url").toString();//36

                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28
                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33
                                                                                                                icohighArray = icohighArray.plusElement(img1urlhigh)
                                                                                                                icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                                val img5url = doc.get("img5url").toString();//37
                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                } else {
                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                }
                                                                                                            } catch (e: Exception) {


                                                                                                            }


                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))



                                                                                                            progressBar3.visibility = View.GONE
                                                                                                            mylist.visibility = View.VISIBLE
                                                                                                        }


                                                                                                        val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray,
                                                                                                                icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.mylist) as ListView
                                                                                                        slist.adapter = whatever


                                                                                                    })

                                                                                        }


                                                                            }


                                                                        }


                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)

                                                                }
                                                            } else {

                                                            //--------------------------//Mrp search -----------------------//

                                                                db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                                            if (e != null) {
                                                                            }
                                                                            if (value.isEmpty == false) {
                                                                                for (document in value) {
                                                                                        Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                                        val dd = document.data

                                                                                        val id = document.id;//0
                                                                                        idstr = id

                                                                                        idstrarr = idstrarr.plusElement(idstr)



                                                                                        lststr = "in"
                                                                                        var ddstr = id + "_" + brids
                                                                                        val database = FirebaseDatabase.getInstance()
                                                                                        val myRef = database.getReference(ddstr)
                                                                                        myRef.root

                                                                                        val messageListener = object : ValueEventListener {
                                                                                            override fun onCancelled(p0: DatabaseError?) {
                                                                                                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                                            }


                                                                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                                                datach = "changed"

                                                                                                if (dataSnapshot.exists()) {


                                                                                                    val docid = dataSnapshot.key

                                                                                                    var ff = docid.removeSuffix("-" + brids)

                                                                                                    println("DOC ID" + docid)
                                                                                                    println("TRIMMED DOC ID" + ff)
                                                                                                    ffstr = ff
                                                                                                    val message = dataSnapshot.value
                                                                                                    val qnty = message.toString()
                                                                                                    var tt = qnty
                                                                                                    qn = tt

                                                                                                    val map = mutableMapOf<String, Any?>()
                                                                                                    map.put("$brids", qn)
                                                                                                    db.collection("product").document(id)
                                                                                                            .update(map)
                                                                                                            .addOnSuccessListener {

                                                                                                                db.collection("product").document(id)
                                                                                                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                                            println("e : "+e)
                                                                                                                            if (e==null) {
                                                                                                                                var doc = task.data

                                                                                                                                val ids = task.id;//0
                                                                                                                                idss = ids
                                                                                                                                stockonhand = doc.get("$brids").toString();//7
                                                                                                                                val pid = doc.get("p_id").toString();//1
                                                                                                                                val pname = doc.get("p_nm").toString();//2
                                                                                                                                val bcode = doc.get("bc").toString();//3
                                                                                                                                val pdes = doc.get("desc").toString();//4
                                                                                                                                val weight = doc.get("wg_vol").toString();//5
                                                                                                                                val psac = doc.get("hsn").toString();//6
                                                                                                                                val minstock = doc.get("min_stk").toString();//8
                                                                                                                                val maxstock = doc.get("mx_stk").toString();//9
                                                                                                                                val price = doc.get("price").toString();//10
                                                                                                                                val taxable = doc.get("taxchk").toString();//11
                                                                                                                                val igst = doc.get("igst").toString();//12
                                                                                                                                val cgst = doc.get("cgst").toString();//13
                                                                                                                                val sgst = doc.get("sgst").toString();//14
                                                                                                                                val cess = doc.get("taxchk").toString();//15
                                                                                                                                val taxtotal = doc.get("taxtot").toString();//16
                                                                                                                                val cessval = doc.get("cesstot").toString();//17
                                                                                                                                val currency = doc.get("curency").toString();//18
                                                                                                                                val percentage = doc.get("percentage").toString();//19
                                                                                                                                val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                                                val product_dec = doc.get("product_desc").toString();//21
                                                                                                                                val mrP = doc.get("mrp").toString();//22
                                                                                                                                val cate = doc.get("ctgy").toString();//23
                                                                                                                                val manufacture = doc.get("mfr").toString();//24
                                                                                                                                val ut = doc.get("ut").toString();//25
                                                                                                                                val consold = doc.get("cn_sold").toString();//26
                                                                                                                                val comm = doc.get("emp_com").toString();//27
                                                                                                                                val status = doc.get("status").toString();//27
                                                                                                                                try {
                                                                                                                                    val img1n = doc.get("img1n").toString();//28
                                                                                                                                    val img2n = doc.get("img2n").toString();//29
                                                                                                                                    val img3n = doc.get("img3n").toString();//30
                                                                                                                                    val img4n = doc.get("img4n").toString();//31
                                                                                                                                    val img5n = doc.get("img5n").toString();//32
                                                                                                                                    val img1url = doc.get("img1url").toString();//33
                                                                                                                                    val img2url = doc.get("img2url").toString();//34
                                                                                                                                    val img3url = doc.get("img3url").toString();//35
                                                                                                                                    val img4url = doc.get("img4url").toString();//36
                                                                                                                                    val img5url = doc.get("img5url").toString();//37


                                                                                                                                    val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                                    val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                                    icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                                    icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                                    if (ur.isNotEmpty()) {
                                                                                                                                        primgArray = primgArray.plusElement(ur)
                                                                                                                                    } else {
                                                                                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")

                                                                                                                                    }
                                                                                                                                } catch (e: Exception) {

                                                                                                                                }


                                                                                                                                idsArray = idsArray.plusElement(ids)
                                                                                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                                                } else {
                                                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                                                }




                                                                                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                                                } else {
                                                                                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                                                }
                                                                                                                                if (bcode.isNotEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                                                } else if (bcode.isEmpty()) {
                                                                                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                                                                                }

                                                                                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                                                mhArray = mhArray.plusElement(maxstock)
                                                                                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                                                                                disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                                                println(Arrays.toString(disArray))



                                                                                                                                progressBar3.visibility = View.GONE
                                                                                                                                mylist.visibility = View.VISIBLE
                                                                                                                            }


                                                                                                                            val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                                            val slist = findViewById<View>(R.id.mylist) as ListView
                                                                                                                            slist.adapter = whatever
                                                                                                                        })
                                                                                                            }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                        myRef!!.addValueEventListener(messageListener)
                                                                                    }
                                                                                } else {

                                                                                    nores.visibility=View.VISIBLE
                                                                                    mylist.visibility=View.GONE
                                                                                }



                                                                        })

                                                            }



                                                    })


                                        }





                                })
                    }
                }





                fun priget() {
                    nores.visibility = View.GONE



                    if ((des.length >= 1)) {

                        var idsArray = arrayOf<String>()

                        var nameArray = arrayOf<String>()

                        var sunbnmArray = arrayOf<String>() //mfr

                        var bcArray = arrayOf<String>()//bc

                        var sohArray = arrayOf<String>()//stock_hand


                        var mlArray = arrayOf<String>()//wg_vol

                        var mhArray = arrayOf<String>()//mx_stk

                        var priceArray = arrayOf<String>()//price
                        var primgArray = arrayOf<String>()

                        var disArray = arrayOf<String>()//status

                        var icohighArray = arrayOf<String>()
                        var icohighnmArray = arrayOf<String>()




                        db.collection("product").orderBy("$brids").startAt(numberstr).endAt(esc)
                                .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                    if (e != null) {
                                    }
                                    if (value.isEmpty == false) {
                                        for (document in value) {
                                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                val dd = document.data

                                                val id = document.id;//0
                                                idstr = id

                                                idstrarr = idstrarr.plusElement(idstr)



                                                lststr = "in"
                                                var ddstr = id + "_" + brids
                                                val database = FirebaseDatabase.getInstance()
                                                val myRef = database.getReference(ddstr)
                                                myRef.root

                                                val messageListener = object : ValueEventListener {
                                                    override fun onCancelled(p0: DatabaseError?) {
                                                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                    }


                                                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                        datach = "changed"

                                                        if (dataSnapshot.exists()) {


                                                            val docid = dataSnapshot.key

                                                            var ff = docid.removeSuffix("-" + brids)

                                                            println("DOC ID" + docid)
                                                            println("TRIMMED DOC ID" + ff)
                                                            ffstr = ff
                                                            val message = dataSnapshot.value
                                                            val qnty = message.toString()
                                                            var tt = qnty
                                                            qn = tt

                                                            val map = mutableMapOf<String, Any?>()
                                                            map.put("$brids", qn)
                                                            db.collection("product").document(id)
                                                                    .update(map)
                                                                    .addOnSuccessListener {

                                                                        db.collection("product").document(id)
                                                                                .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                    println("e : "+e)
                                                                                    if (e==null) {
                                                                                        var doc = task.data

                                                                                        val ids = task.id;//0
                                                                                        idss = ids
                                                                                        stockonhand = doc.get("$brids").toString();//7
                                                                                        val pid = doc.get("p_id").toString();//1
                                                                                        val pname = doc.get("p_nm").toString();//2
                                                                                        val bcode = doc.get("bc").toString();//3
                                                                                        val pdes = doc.get("desc").toString();//4
                                                                                        val weight = doc.get("wg_vol").toString();//5
                                                                                        val psac = doc.get("hsn").toString();//6
                                                                                        val minstock = doc.get("min_stk").toString();//8
                                                                                        val maxstock = doc.get("mx_stk").toString();//9
                                                                                        val price = doc.get("price").toString();//10
                                                                                        val taxable = doc.get("taxchk").toString();//11
                                                                                        val igst = doc.get("igst").toString();//12
                                                                                        val cgst = doc.get("cgst").toString();//13
                                                                                        val sgst = doc.get("sgst").toString();//14
                                                                                        val cess = doc.get("taxchk").toString();//15
                                                                                        val taxtotal = doc.get("taxtot").toString();//16
                                                                                        val cessval = doc.get("cesstot").toString();//17
                                                                                        val currency = doc.get("curency").toString();//18
                                                                                        val percentage = doc.get("percentage").toString();//19
                                                                                        val percentagevalue = doc.get("percentageval").toString();//20
                                                                                        val product_dec = doc.get("product_desc").toString();//21
                                                                                        val mrP = doc.get("mrp").toString();//22
                                                                                        val cate = doc.get("ctgy").toString();//23
                                                                                        val manufacture = doc.get("mfr").toString();//24
                                                                                        val ut = doc.get("ut").toString();//25
                                                                                        val consold = doc.get("cn_sold").toString();//26
                                                                                        val comm = doc.get("emp_com").toString();//27
                                                                                        val status = doc.get("status").toString();//27
                                                                                        try {
                                                                                            val img1n = doc.get("img1n").toString();//28
                                                                                            val img2n = doc.get("img2n").toString();//29
                                                                                            val img3n = doc.get("img3n").toString();//30
                                                                                            val img4n = doc.get("img4n").toString();//31
                                                                                            val img5n = doc.get("img5n").toString();//32
                                                                                            val img1url = doc.get("img1url").toString();//33
                                                                                            val img2url = doc.get("img2url").toString();//34
                                                                                            val img3url = doc.get("img3url").toString();//35
                                                                                            val img4url = doc.get("img4url").toString();//36
                                                                                            val img5url = doc.get("img5url").toString();//37


                                                                                            val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                            val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                            icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                            icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                            val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                            if (ur.isNotEmpty()) {
                                                                                                primgArray = primgArray.plusElement(ur)
                                                                                            } else {
                                                                                                primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")

                                                                                            }
                                                                                        } catch (e: Exception) {

                                                                                        }


                                                                                        idsArray = idsArray.plusElement(ids)
                                                                                        if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                            nameArray = nameArray.plusElement(pname)

                                                                                        } else {
                                                                                            nameArray = nameArray.plusElement(pname)
                                                                                        }




                                                                                        if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                            sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                        } else {
                                                                                            sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                        }
                                                                                        if (bcode.isNotEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC " + bcode)
                                                                                        } else if (bcode.isEmpty()) {
                                                                                            bcArray = bcArray.plusElement("BC Not Available")

                                                                                        }

                                                                                        mlArray = mlArray.plusElement(weight + "ml")
                                                                                        priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                        mhArray = mhArray.plusElement(maxstock)
                                                                                        sohArray = sohArray.plusElement(stockonhand)
                                                                                        disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                        println(Arrays.toString(disArray))



                                                                                        progressBar3.visibility = View.GONE
                                                                                        mylist.visibility = View.VISIBLE
                                                                                    }


                                                                                    val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                    val slist = findViewById<View>(R.id.mylist) as ListView
                                                                                    slist.adapter = whatever


                                                                                })

                                                                    }


                                                        }


                                                    }


                                                }
                                                myRef!!.addValueEventListener(messageListener)

                                            }
                                        } else {
                                            db.collection("product").orderBy("mrp").startAt(numberstr).endAt(esc)
                                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                        if (e != null) {
                                                        }
                                                        if (value.isEmpty == false) {
                                                            for (document in value) {
                                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                    val dd = document.data

                                                                    val id = document.id;//0
                                                                    idstr = id

                                                                    idstrarr = idstrarr.plusElement(idstr)



                                                                    lststr = "in"
                                                                    var ddstr = id + "_" + brids
                                                                    val database = FirebaseDatabase.getInstance()
                                                                    val myRef = database.getReference(ddstr)
                                                                    myRef.root

                                                                    val messageListener = object : ValueEventListener {
                                                                        override fun onCancelled(p0: DatabaseError?) {
                                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                        }


                                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                            datach = "changed"

                                                                            if (dataSnapshot.exists()) {


                                                                                val docid = dataSnapshot.key

                                                                                var ff = docid.removeSuffix("-" + brids)

                                                                                println("DOC ID" + docid)
                                                                                println("TRIMMED DOC ID" + ff)
                                                                                ffstr = ff
                                                                                val message = dataSnapshot.value
                                                                                val qnty = message.toString()
                                                                                var tt = qnty
                                                                                qn = tt

                                                                                val map = mutableMapOf<String, Any?>()
                                                                                map.put("$brids", qn)
                                                                                db.collection("product").document(id)
                                                                                        .update(map)
                                                                                        .addOnSuccessListener {

                                                                                            db.collection("product").document(id)
                                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                        println("e : "+e)
                                                                                                        if (e==null) {
                                                                                                            var doc = task.data

                                                                                                            val ids = task.id;//0
                                                                                                            idss = ids
                                                                                                            stockonhand = doc.get("$brids").toString();//7
                                                                                                            val pid = doc.get("p_id").toString();//1
                                                                                                            val pname = doc.get("p_nm").toString();//2
                                                                                                            val bcode = doc.get("bc").toString();//3
                                                                                                            val pdes = doc.get("desc").toString();//4
                                                                                                            val weight = doc.get("wg_vol").toString();//5
                                                                                                            val psac = doc.get("hsn").toString();//6
                                                                                                            val minstock = doc.get("min_stk").toString();//8
                                                                                                            val maxstock = doc.get("mx_stk").toString();//9
                                                                                                            val price = doc.get("price").toString();//10
                                                                                                            val taxable = doc.get("taxchk").toString();//11
                                                                                                            val igst = doc.get("igst").toString();//12
                                                                                                            val cgst = doc.get("cgst").toString();//13
                                                                                                            val sgst = doc.get("sgst").toString();//14
                                                                                                            val cess = doc.get("taxchk").toString();//15
                                                                                                            val taxtotal = doc.get("taxtot").toString();//16
                                                                                                            val cessval = doc.get("cesstot").toString();//17
                                                                                                            val currency = doc.get("curency").toString();//18
                                                                                                            val percentage = doc.get("percentage").toString();//19
                                                                                                            val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                            val product_dec = doc.get("product_desc").toString();//21
                                                                                                            val mrP = doc.get("mrp").toString();//22
                                                                                                            val cate = doc.get("ctgy").toString();//23
                                                                                                            val manufacture = doc.get("mfr").toString();//24
                                                                                                            val ut = doc.get("ut").toString();//25
                                                                                                            val consold = doc.get("cn_sold").toString();//26
                                                                                                            val comm = doc.get("emp_com").toString();//27
                                                                                                            val status = doc.get("status").toString();//27
                                                                                                            try {
                                                                                                                val img1n = doc.get("img1n").toString();//28
                                                                                                                val img2n = doc.get("img2n").toString();//29
                                                                                                                val img3n = doc.get("img3n").toString();//30
                                                                                                                val img4n = doc.get("img4n").toString();//31
                                                                                                                val img5n = doc.get("img5n").toString();//32
                                                                                                                val img1url = doc.get("img1url").toString();//33
                                                                                                                val img2url = doc.get("img2url").toString();//34
                                                                                                                val img3url = doc.get("img3url").toString();//35
                                                                                                                val img4url = doc.get("img4url").toString();//36
                                                                                                                val img5url = doc.get("img5url").toString();//37


                                                                                                                val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                if (ur.isNotEmpty()) {
                                                                                                                    primgArray = primgArray.plusElement(ur)
                                                                                                                } else {
                                                                                                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")

                                                                                                                }
                                                                                                            } catch (e: Exception) {

                                                                                                            }


                                                                                                            idsArray = idsArray.plusElement(ids)
                                                                                                            if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                nameArray = nameArray.plusElement(pname)

                                                                                                            } else {
                                                                                                                nameArray = nameArray.plusElement(pname)
                                                                                                            }




                                                                                                            if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                            } else {
                                                                                                                sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                            }
                                                                                                            if (bcode.isNotEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                            } else if (bcode.isEmpty()) {
                                                                                                                bcArray = bcArray.plusElement("BC Not Available")

                                                                                                            }

                                                                                                            mlArray = mlArray.plusElement(weight + "ml")
                                                                                                            priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                            mhArray = mhArray.plusElement(maxstock)
                                                                                                            sohArray = sohArray.plusElement(stockonhand)
                                                                                                            disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                            println(Arrays.toString(disArray))



                                                                                                            progressBar3.visibility = View.GONE
                                                                                                            mylist.visibility = View.VISIBLE
                                                                                                        }


                                                                                                        val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                        val slist = findViewById<View>(R.id.mylist) as ListView
                                                                                                        slist.adapter = whatever
                                                                                                    })
                                                                                        }
                                                                            }
                                                                        }
                                                                    }
                                                                    myRef!!.addValueEventListener(messageListener)
                                                                }
                                                            } else {
                                                                bcodeget()
                                                            }




                                                    })


                                        }


                                })
                    }
                }




                        if (x.trim().matches(regexStr.toRegex())) {
                            upstr = x
                            println("CAME INTO NUMBER" + upstr)
                            var escp = x + '\uf8ff'
                            esc = escp
                            reg = upstr
                            numberstr = upstr
                            bcd = "bcode"
                            bcodeget()
                            //write code here for success
                        }

                        if ((des.length == 1) && (x !== reg)) {
                            val upperString = x.substring(0, 1).toUpperCase() + x.substring(1)
                            upstr = upperString
                            nmstr = upstr
                            var escp = upperString + '\uf8ff'
                            esc = escp

                            println("CAPPPSSSS" + upperString)
                        }

                        if ((des.length >= 1) && (x == reg)) {

                            upstr = x
                            println("CAME INTO NUMBER" + upstr)
                            var escp = x + '\uf8ff'
                            esc = escp
                            reg = upstr
                            numberstr = upstr
                            regtr = "num"
                            priget()
                        }


                        //----------------------Product name search--------------------------------//

                        else if ((des.length >= 3) && (x !== reg)) {
                            var idsArray = arrayOf<String>()
                            var nameArray = arrayOf<String>()

                            var sunbnmArray = arrayOf<String>() //mfr

                            var bcArray = arrayOf<String>()//bc

                            var sohArray = arrayOf<String>()//stock_hand


                            var mlArray = arrayOf<String>()//wg_vol

                            var mhArray = arrayOf<String>()//mx_stk

                            var priceArray = arrayOf<String>()//price
                            var primgArray = arrayOf<String>()

                            var disArray = arrayOf<String>()//status


                            var icohighArray = arrayOf<String>()
                            var icohighnmArray = arrayOf<String>()


                            db.collection("product").orderBy("p_nm").startAt(upstr).endAt(esc)
                                    .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                        if (e != null) {
                                        }
                                        if (value.isEmpty == false) {
                                            for (document in value) {
                                                    Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                    val dd = document.data

                                                    val id = document.id;//0
                                                    idstr = id

                                                    idstrarr = idstrarr.plusElement(idstr)



                                                    lststr = "in"
                                                    var ddstr = id + "_" + brids
                                                    val database = FirebaseDatabase.getInstance()
                                                    val myRef = database.getReference(ddstr)
                                                    myRef.root

                                                    val messageListener = object : ValueEventListener {
                                                        override fun onCancelled(p0: DatabaseError?) {
                                                            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                        }


                                                        override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                            datach = "changed"

                                                            if (dataSnapshot.exists()) {


                                                                val docid = dataSnapshot.key

                                                                var ff = docid.removeSuffix("-" + brids)

                                                                println("DOC ID" + docid)
                                                                println("TRIMMED DOC ID" + ff)
                                                                ffstr = ff
                                                                val message = dataSnapshot.value
                                                                val qnty = message.toString()
                                                                var tt = qnty
                                                                qn = tt

                                                                val map = mutableMapOf<String, Any?>()
                                                                map.put("$brids", qn)
                                                                db.collection("product").document(id)
                                                                        .update(map)
                                                                        .addOnSuccessListener {

                                                                            db.collection("product").document(id)
                                                                                    .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                        println("e : "+e)
                                                                                        if (e==null) {

                                                                                            if (task.exists() == true) {
                                                                                                var doc = task.data

                                                                                                val ids = task.id;//0
                                                                                                idss = ids
                                                                                                stockonhand = doc.get("$brids").toString();//7
                                                                                                val pid = doc.get("p_id").toString();//1
                                                                                                val pname = doc.get("p_nm").toString();//2
                                                                                                val bcode = doc.get("bc").toString();//3
                                                                                                val pdes = doc.get("desc").toString();//4
                                                                                                val weight = doc.get("wg_vol").toString();//5
                                                                                                val psac = doc.get("hsn").toString();//6
                                                                                                val minstock = doc.get("min_stk").toString();//8
                                                                                                val maxstock = doc.get("mx_stk").toString();//9
                                                                                                val price = doc.get("price").toString();//10
                                                                                                val taxable = doc.get("taxchk").toString();//11
                                                                                                val igst = doc.get("igst").toString();//12
                                                                                                val cgst = doc.get("cgst").toString();//13
                                                                                                val sgst = doc.get("sgst").toString();//14
                                                                                                val cess = doc.get("taxchk").toString();//15
                                                                                                val taxtotal = doc.get("taxtot").toString();//16
                                                                                                val cessval = doc.get("cesstot").toString();//17
                                                                                                val currency = doc.get("curency").toString();//18
                                                                                                val percentage = doc.get("percentage").toString();//19
                                                                                                val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                val product_dec = doc.get("product_desc").toString();//21
                                                                                                val mrP = doc.get("mrp").toString();//22
                                                                                                val cate = doc.get("ctgy").toString();//23
                                                                                                val manufacture = doc.get("mfr").toString();//24
                                                                                                val ut = doc.get("ut").toString();//25
                                                                                                val consold = doc.get("cn_sold").toString();//26
                                                                                                val comm = doc.get("emp_com").toString();//27
                                                                                                val status = doc.get("status").toString();//27
                                                                                                try {
                                                                                                    val img1n = doc.get("img1n").toString();//28
                                                                                                    val img2n = doc.get("img2n").toString();//29
                                                                                                    val img3n = doc.get("img3n").toString();//30
                                                                                                    val img4n = doc.get("img4n").toString();//31
                                                                                                    val img5n = doc.get("img5n").toString();//32
                                                                                                    val img1url = doc.get("img1url").toString();//33
                                                                                                    val img2url = doc.get("img2url").toString();//34
                                                                                                    val img3url = doc.get("img3url").toString();//35
                                                                                                    val img4url = doc.get("img4url").toString();//36
                                                                                                    val img5url = doc.get("img5url").toString();//37

                                                                                                    val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                    val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                    icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                    icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                    if (ur.isNotEmpty()) {
                                                                                                        primgArray = primgArray.plusElement(ur)
                                                                                                    } else {
                                                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                    }
                                                                                                } catch (e: Exception) {

                                                                                                }


                                                                                                idsArray = idsArray.plusElement(ids)
                                                                                                if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                    nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                    nameArray = nameArray.plusElement(pname)

                                                                                                } else {
                                                                                                    nameArray = nameArray.plusElement(pname)
                                                                                                }




                                                                                                if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                } else {
                                                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                }
                                                                                                if (bcode.isNotEmpty()) {
                                                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                } else if (bcode.isEmpty()) {
                                                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                                                }

                                                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                mhArray = mhArray.plusElement(maxstock)
                                                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                                                disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                println(Arrays.toString(disArray))



                                                                                                progressBar3.visibility = View.GONE
                                                                                                mylist.visibility = View.VISIBLE
                                                                                                val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                val slist = findViewById<View>(R.id.mylist) as ListView
                                                                                                slist.adapter = whatever
                                                                                            } else {

                                                                                            }
                                                                                        }


                                                                                    })

                                                                        }


                                                            }


                                                        }


                                                    }
                                                    myRef!!.addValueEventListener(messageListener)

                                                }
                                            } else {


                                            //---------------------Manufacturer search---------------------//

                                                db.collection("product").orderBy("mfr").startAt(upstr).endAt(esc)
                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->
                                                            if (e != null) {
                                                            }
                                                            if (value.isEmpty == false) {
                                                                for (document in value) {
                                                                        Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                                                        val dd = document.data

                                                                        val id = document.id;//0
                                                                        idstr = id

                                                                        idstrarr = idstrarr.plusElement(idstr)



                                                                        lststr = "in"
                                                                        var ddstr = id + "_" + brids
                                                                        val database = FirebaseDatabase.getInstance()
                                                                        val myRef = database.getReference(ddstr)
                                                                        myRef.root

                                                                        val messageListener = object : ValueEventListener {
                                                                            override fun onCancelled(p0: DatabaseError?) {
                                                                                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                                                                            }


                                                                            override fun onDataChange(dataSnapshot: DataSnapshot) {
                                                                                datach = "changed"

                                                                                if (dataSnapshot.exists()) {


                                                                                    val docid = dataSnapshot.key

                                                                                    var ff = docid.removeSuffix("-" + brids)

                                                                                    println("DOC ID" + docid)
                                                                                    println("TRIMMED DOC ID" + ff)
                                                                                    ffstr = ff
                                                                                    val message = dataSnapshot.value
                                                                                    val qnty = message.toString()
                                                                                    var tt = qnty
                                                                                    qn = tt

                                                                                    val map = mutableMapOf<String, Any?>()
                                                                                    map.put("$brids", qn)
                                                                                    db.collection("product").document(id)
                                                                                            .update(map)
                                                                                            .addOnSuccessListener {

                                                                                                db.collection("product").document(id)
                                                                                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                                                                                            println("e : "+e)
                                                                                                            if (e==null) {

                                                                                                                if (task.exists() == true) {
                                                                                                                    var doc = task.data

                                                                                                                    val ids = task.id;//0
                                                                                                                    idss = ids
                                                                                                                    stockonhand = doc.get("$brids").toString();//7
                                                                                                                    val pid = doc.get("p_id").toString();//1
                                                                                                                    val pname = doc.get("p_nm").toString();//2
                                                                                                                    val bcode = doc.get("bc").toString();//3
                                                                                                                    val pdes = doc.get("desc").toString();//4
                                                                                                                    val weight = doc.get("wg_vol").toString();//5
                                                                                                                    val psac = doc.get("hsn").toString();//6
                                                                                                                    val minstock = doc.get("min_stk").toString();//8
                                                                                                                    val maxstock = doc.get("mx_stk").toString();//9
                                                                                                                    val price = doc.get("price").toString();//10
                                                                                                                    val taxable = doc.get("taxchk").toString();//11
                                                                                                                    val igst = doc.get("igst").toString();//12
                                                                                                                    val cgst = doc.get("cgst").toString();//13
                                                                                                                    val sgst = doc.get("sgst").toString();//14
                                                                                                                    val cess = doc.get("taxchk").toString();//15
                                                                                                                    val taxtotal = doc.get("taxtot").toString();//16
                                                                                                                    val cessval = doc.get("cesstot").toString();//17
                                                                                                                    val currency = doc.get("curency").toString();//18
                                                                                                                    val percentage = doc.get("percentage").toString();//19
                                                                                                                    val percentagevalue = doc.get("percentageval").toString();//20
                                                                                                                    val product_dec = doc.get("product_desc").toString();//21
                                                                                                                    val mrP = doc.get("mrp").toString();//22
                                                                                                                    val cate = doc.get("ctgy").toString();//23
                                                                                                                    val manufacture = doc.get("mfr").toString();//24
                                                                                                                    val ut = doc.get("ut").toString();//25
                                                                                                                    val consold = doc.get("cn_sold").toString();//26
                                                                                                                    val comm = doc.get("emp_com").toString();//27
                                                                                                                    val status = doc.get("status").toString();//27
                                                                                                                    try {
                                                                                                                        val img1n = doc.get("img1n").toString();//28
                                                                                                                        val img2n = doc.get("img2n").toString();//29
                                                                                                                        val img3n = doc.get("img3n").toString();//30
                                                                                                                        val img4n = doc.get("img4n").toString();//31
                                                                                                                        val img5n = doc.get("img5n").toString();//32
                                                                                                                        val img1url = doc.get("img1url").toString();//33
                                                                                                                        val img2url = doc.get("img2url").toString();//34
                                                                                                                        val img3url = doc.get("img3url").toString();//35
                                                                                                                        val img4url = doc.get("img4url").toString();//36
                                                                                                                        val img5url = doc.get("img5url").toString();//37

                                                                                                                        val img1nhigh = doc.get("img1nhigh").toString();//28

                                                                                                                        val img1urlhigh = doc.get("img1urlhigh").toString();//33

                                                                                                                        icohighArray = icohighArray.plusElement(img1urlhigh)

                                                                                                                        icohighnmArray = icohighnmArray.plusElement(img1nhigh)


                                                                                                                        val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                                                                        if (ur.isNotEmpty()) {
                                                                                                                            primgArray = primgArray.plusElement(ur)
                                                                                                                        } else {
                                                                                                                            primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                                                                        }
                                                                                                                    } catch (e: Exception) {

                                                                                                                    }


                                                                                                                    idsArray = idsArray.plusElement(ids)
                                                                                                                    if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname + " - " + weight + " " + ut)
                                                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut != "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                                                    } else if ((weight.isNotEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                                                    } else if ((weight.isEmpty()) && (ut.isNotEmpty() && ut == "Select")) {
                                                                                                                        nameArray = nameArray.plusElement(pname)

                                                                                                                    } else {
                                                                                                                        nameArray = nameArray.plusElement(pname)
                                                                                                                    }




                                                                                                                    if (manufacture.isNotEmpty() && manufacture != "Select") {
                                                                                                                        sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                                                                    } else {
                                                                                                                        sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                                                                    }
                                                                                                                    if (bcode.isNotEmpty()) {
                                                                                                                        bcArray = bcArray.plusElement("BC " + bcode)
                                                                                                                    } else if (bcode.isEmpty()) {
                                                                                                                        bcArray = bcArray.plusElement("BC Not Available")

                                                                                                                    }

                                                                                                                    mlArray = mlArray.plusElement(weight + "ml")
                                                                                                                    priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                                                                    mhArray = mhArray.plusElement(maxstock)
                                                                                                                    sohArray = sohArray.plusElement(stockonhand)
                                                                                                                    disArray = disArray.plusElement("Qty - " + stockonhand)





                                                                                                                    println(Arrays.toString(disArray))



                                                                                                                    progressBar3.visibility = View.GONE
                                                                                                                    mylist.visibility = View.VISIBLE
                                                                                                                    val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray, icohighnmArray, icohighArray)
                                                                                                                    val slist = findViewById<View>(R.id.mylist) as ListView
                                                                                                                    slist.adapter = whatever
                                                                                                                } else {

                                                                                                                }
                                                                                                            }


                                                                                                        })

                                                                                            }


                                                                                }


                                                                            }


                                                                        }
                                                                        myRef!!.addValueEventListener(messageListener)

                                                                    }
                                                                } else {
                                                                    mylist.visibility = View.GONE
                                                                    nores.visibility = View.VISIBLE

                                                                }

                                                        })


                                            }

                                    })
                        }









                return
            }
            override fun beforeTextChanged(arg0: CharSequence, arg1: Int, arg2: Int,
                                           arg3: Int) {
                // TODO Auto-generated method stub


            }
            override fun afterTextChanged(arg0: Editable) {
                // TODO Auto-generated method stub
                if(searchedit.text.toString().isEmpty())
                {
                    ggg()
                    progressBar3.visibility=View.GONE
                }
            }
        })



        ggg()

        /*swipeContainer.setOnRefreshListener {
            // Your code to refresh the list here.
            // Make sure you call swipeContainer.setRefreshing(false)
            // once the network request has completed successfully.
            ggg()
        }
        // Configure the refreshing colors
        swipeContainer.setColorSchemeResources(R.color.toolbar,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light)*/






        back1.setOnClickListener {
            onBackPressed()
        }





    }


    //--------------Get current stock level of that product and update it to db-----------------------//

    fun getsoh(id:String,bid:String) {


     progressBar3.visibility=View.VISIBLE

        lststr="in"
        var ddstr = id + "_" + bid
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference(ddstr)
        myRef.root

        val messageListener = object : ValueEventListener {


            override fun onDataChange(dataSnapshot: DataSnapshot) {
                datach="changed"

                if (dataSnapshot.exists()) {


                    val docid = dataSnapshot.key

                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value
                    val qnty = message.toString()
                    var tt = qnty
                    qn = tt

                    val map = mutableMapOf<String, Any?>()
                    map.put("$brids",qn)
                    db.collection("product").document(id)
                            .update(map)
                            .addOnSuccessListener {

                                db.collection("product").document(id)
                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                            println("e : "+e)
                                            if (e==null) {
                                                var doc = task.data

                                                val ids = task.id;//0
                                                Log.d(TAG, "cleared")
                                                db.collection("product")
                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                            var idsArray = arrayOf<String>()
                                                            var nameArray = arrayOf<String>()

                                                            var sunbnmArray = arrayOf<String>() //mfr

                                                            var bcArray = arrayOf<String>()//bc

                                                            var sohArray = arrayOf<String>()//stock_hand


                                                            var mlArray = arrayOf<String>()//wg_vol

                                                            var mhArray = arrayOf<String>()//mx_stk

                                                            var priceArray = arrayOf<String>()//price
                                                            var primgArray = arrayOf<String>()

                                                            var icohighArray=arrayOf<String>()
                                                            var icohighnmArray=arrayOf<String>()

                                                            var disArray = arrayOf<String>()//status




                                                            if (e != null) {
                                                                Log.w("", "Listen failed.", e)
                                                                return@EventListener
                                                            }

                                                            for (document in value) {

                                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                println(document.data)




                                                                val ids = document.id;//0
                                                                idss=ids
                                                                try {
                                                                     stockonhand = document.get("$bid").toString();//7
                                                                }catch (e:Exception)
                                                                {

                                                                }
                                                                val pid = document.get("p_id").toString();//1
                                                                val pname = document.get("p_nm").toString();//2
                                                                val bcode = document.get("bc").toString();//3
                                                                val pdes = document.get("desc").toString();//4
                                                                val weight = document.get("wg_vol").toString();//5
                                                                val psac = document.get("hsn").toString();//6
                                                                val minstock = document.get("min_stk").toString();//8
                                                                val maxstock = document.get("mx_stk").toString();//9
                                                                val price = document.get("price").toString();//10
                                                                val taxable = document.get("taxchk").toString();//11
                                                                val igst = document.get("igst").toString();//12
                                                                val cgst = document.get("cgst").toString();//13
                                                                val sgst = document.get("sgst").toString();//14
                                                                val cess = document.get("taxchk").toString();//15
                                                                val taxtotal = document.get("taxtot").toString();//16
                                                                val cessval = document.get("cesstot").toString();//17
                                                                val currency = document.get("curency").toString();//18
                                                                val percentage = document.get("percentage").toString();//19
                                                                val percentagevalue = document.get("percentageval").toString();//20
                                                                val product_dec = document.get("product_desc").toString();//21
                                                                val mrP = document.get("mrp").toString();//22
                                                                val cate = document.get("ctgy").toString();//23
                                                                val manufacture = document.get("mfr").toString();//24
                                                                val ut = document.get("ut").toString();//25
                                                                val consold = document.get("cn_sold").toString();//26
                                                                val comm = document.get("emp_com").toString();//27
                                                                val status = document.get("status").toString();//27
                                                                try {
                                                                    val img1n = document.get("img1n").toString();//28
                                                                    val img2n = document.get("img2n").toString();//29
                                                                    val img3n = document.get("img3n").toString();//30
                                                                    val img4n = document.get("img4n").toString();//31
                                                                    val img5n = document.get("img5n").toString();//32
                                                                    val img1url = document.get("img1url").toString();//33
                                                                    val img2url = document.get("img2url").toString();//34
                                                                    val img3url = document.get("img3url").toString();//35
                                                                    val img4url = document.get("img4url").toString();//36
                                                                    val img5url = document.get("img5url").toString();//37

                                                                    val img1nhigh = document.get("img1nhigh").toString();//28

                                                                    val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)


                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                    if (ur.isNotEmpty()) {
                                                                        primgArray = primgArray.plusElement(ur)
                                                                    } else {
                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                    }
                                                                }
                                                                catch (e:Exception){

                                                                }


                                                                idsArray = idsArray.plusElement(ids)


                                                                if((weight.isNotEmpty())&&(ut.isNotEmpty()&&ut!="Select")){
                                                                    nameArray = nameArray.plusElement(pname+" - "+weight+" "+ut)
                                                                }

                                                                else if((weight.isEmpty())&&(ut.isNotEmpty()&&ut!="Select")){
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }
                                                                else if((weight.isNotEmpty())&&(ut.isNotEmpty()&&ut=="Select")){
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else if((weight.isEmpty())&&(ut.isNotEmpty()&&ut=="Select")){
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else{
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }




                                                                if(manufacture.isNotEmpty()&&manufacture!="Select") {
                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                }
                                                                else{
                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                }
                                                                if(bcode.isNotEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                }
                                                                else if(bcode.isEmpty()){
                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                }

                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                mhArray = mhArray.plusElement(maxstock)
                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                disArray = disArray.plusElement("Qty - " + stockonhand)

                                                              /*  swipeContainer.setRefreshing(false);*/

                                                                progressBar3.visibility=View.GONE


                                                                println(Arrays.toString(disArray))





                                                            }


mylist.visibility=View.VISIBLE
                                                            val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray,
                                                                    priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                            val slist = findViewById<View>(R.id.mylist) as ListView
                                                            slist.adapter = whatever


                                                        })





                                            }
                                        })
                            }


                }





                else {



                    /*val docid = dataSnapshot.key
                    keylist.add(docid)
                    var ff = docid.removeSuffix("-" + bid)

                    println("DOC ID" + docid)
                    println("TRIMMED DOC ID" + ff)
                    ffstr = ff
                    val message = dataSnapshot.value
                    val qnty = message.toString()*/

                    qn = "0"

                    val map = mutableMapOf<String, Any?>()
                    map.put("$brids",qn)
                    db.collection("product").document(id)
                            .update(map)
                            .addOnSuccessListener {

                                db.collection("product").document(id)
                                        .addSnapshotListener(EventListener<DocumentSnapshot>{task,e->
                                            println("e : "+e)
                                            if (e==null) {
                                                var doc = task.data

                                                val ids = task.id;//0
                                                Log.d(TAG, "cleared")
                                                db.collection("product")
                                                        .addSnapshotListener(EventListener<QuerySnapshot> { value, e ->

                                                            var idsArray = arrayOf<String>()
                                                            var nameArray = arrayOf<String>()

                                                            var sunbnmArray = arrayOf<String>() //mfr

                                                            var bcArray = arrayOf<String>()//bc

                                                            var sohArray = arrayOf<String>()//stock_hand


                                                            var mlArray = arrayOf<String>()//wg_vol

                                                            var mhArray = arrayOf<String>()//mx_stk

                                                            var priceArray = arrayOf<String>()//price
                                                            var primgArray = arrayOf<String>()

                                                            var disArray = arrayOf<String>()//status

                                                            var icohighArray=arrayOf<String>()
                                                            var icohighnmArray=arrayOf<String>()




                                                            if (e != null) {
                                                                Log.w("", "Listen failed.", e)
                                                                return@EventListener
                                                            }

                                                            for (document in value) {

                                                                Log.d("d", "key --- " + document.id + " => " + document.data)
                                                                println(document.data)




                                                                val ids = document.id;//0
                                                                idss=ids
                                                                 stockonhand = document.get("$brids").toString();//7
                                                                val pid = document.get("p_id").toString();//1
                                                                val pname = document.get("p_nm").toString();//2
                                                                val bcode = document.get("bc").toString();//3
                                                                val pdes = document.get("desc").toString();//4
                                                                val weight = document.get("wg_vol").toString();//5
                                                                val psac = document.get("hsn").toString();//6
                                                                val minstock = document.get("min_stk").toString();//8
                                                                val maxstock = document.get("mx_stk").toString();//9
                                                                val price = document.get("price").toString();//10
                                                                val taxable = document.get("taxchk").toString();//11
                                                                val igst = document.get("igst").toString();//12
                                                                val cgst = document.get("cgst").toString();//13
                                                                val sgst = document.get("sgst").toString();//14
                                                                val cess = document.get("taxchk").toString();//15
                                                                val taxtotal = document.get("taxtot").toString();//16
                                                                val cessval = document.get("cesstot").toString();//17
                                                                val currency = document.get("curency").toString();//18
                                                                val percentage = document.get("percentage").toString();//19
                                                                val percentagevalue = document.get("percentageval").toString();//20
                                                                val product_dec = document.get("product_desc").toString();//21
                                                                val mrP = document.get("mrp").toString();//22
                                                                val cate = document.get("ctgy").toString();//23
                                                                val manufacture = document.get("mfr").toString();//24
                                                                val ut = document.get("ut").toString();//25
                                                                val consold = document.get("cn_sold").toString();//26
                                                                val comm = document.get("emp_com").toString();//27
                                                                val status = document.get("status").toString();//27

                                                                try {
                                                                    val img1n = document.get("img1n").toString();//28
                                                                    val img2n = document.get("img2n").toString();//29
                                                                    val img3n = document.get("img3n").toString();//30
                                                                    val img4n = document.get("img4n").toString();//31
                                                                    val img5n = document.get("img5n").toString();//32
                                                                    val img1url = document.get("img1url").toString();//33
                                                                    val img2url = document.get("img2url").toString();//34
                                                                    val img3url = document.get("img3url").toString();//35
                                                                    val img4url = document.get("img4url").toString();//36
                                                                    val img5url = document.get("img5url").toString();//37


                                                                    val img1nhigh = document.get("img1nhigh").toString();//28

                                                                    val img1urlhigh = document.get("img1urlhigh").toString();//33

                                                                    icohighArray=icohighArray.plusElement(img1urlhigh)

                                                                    icohighnmArray=icohighnmArray.plusElement(img1nhigh)


                                                                    val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                                                    if (ur.isNotEmpty()) {
                                                                        primgArray = primgArray.plusElement(ur)
                                                                    } else {
                                                                        primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/inventory-product.appspot.com/o/noimage1.png?alt=media&token=503a8680-42aa-413b-99b4-7ca317e3e254")
                                                                    }
                                                                }

                                                                catch (e:Exception){

                                                                }


                                                                idsArray = idsArray.plusElement(ids)
                                                                if((weight.isNotEmpty())&&(ut.isNotEmpty()&&ut!="Select")){
                                                                    nameArray = nameArray.plusElement(pname+" - "+weight+" "+ut)
                                                                }

                                                                else if((weight.isEmpty())&&(ut.isNotEmpty()&&ut!="Select")){
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }
                                                                else if((weight.isNotEmpty())&&(ut.isNotEmpty()&&ut=="Select")){
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else if((weight.isEmpty())&&(ut.isNotEmpty()&&ut=="Select")){
                                                                    nameArray = nameArray.plusElement(pname)

                                                                }
                                                                else{
                                                                    nameArray = nameArray.plusElement(pname)
                                                                }




                                                                if(manufacture.isNotEmpty()&&manufacture!="Select") {
                                                                    sunbnmArray = sunbnmArray.plusElement(manufacture)
                                                                }
                                                                else{
                                                                    sunbnmArray = sunbnmArray.plusElement("MFR - Not Available")
                                                                }
                                                                if(bcode.isNotEmpty()) {
                                                                    bcArray = bcArray.plusElement("BC " + bcode)
                                                                }
                                                                else if(bcode.isEmpty()){
                                                                    bcArray = bcArray.plusElement("BC Not Available")

                                                                }

                                                                mlArray = mlArray.plusElement(weight + "ml")
                                                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                                                mhArray = mhArray.plusElement(maxstock)
                                                                sohArray = sohArray.plusElement(stockonhand)
                                                                disArray = disArray.plusElement("Qty - " + stockonhand)


                                                                progressBar3.visibility=View.GONE



                                                                println(Arrays.toString(disArray))





                                                            }


mylist.visibility=View.VISIBLE
                                                            val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray,icohighnmArray,icohighArray)
                                                            val slist = findViewById<View>(R.id.mylist) as ListView
                                                            slist.adapter = whatever



                                                        })





                                            }
                                        })
                            }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Failed to read value


            }
        }

        myRef!!.addValueEventListener(messageListener)





    }

    /*fun get() {
        db.collection("products").whereEqualTo("orikys", brids)
                .get()
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Log.d(TAG, "cleared")
                        if (task.result.isEmpty == false) {
                            for (document in task.result) {
                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data

                                val ids = document.id;//0
                                val stockonhand = dd["stock_hand"].toString();//7
                                val pid = dd["p_id"].toString();//1
                                val pname = dd["p_nm"].toString();//2
                                val bcode = dd["bc"].toString();//3
                                val pdes = dd["desc"].toString();//4
                                val weight = dd["wg_vol"].toString();//5
                                val psac = dd["hsn"].toString();//6
                                val minstock = dd["min_stk"].toString();//8
                                val maxstock = dd["mx_stk"].toString();//9
                                val price = dd["price"].toString();//10
                                val taxable = dd["taxchk"].toString();//11
                                val igst = dd["igst"].toString();//12
                                val cgst = dd["cgst"].toString();//13
                                val sgst = dd["sgst"].toString();//14
                                val cess = dd["taxchk"].toString();//15
                                val taxtotal = dd["taxtot"].toString();//16
                                val cessval = dd["cesstot"].toString();//17
                                val currency = dd["curency"].toString();//18
                                val percentage = dd["percentage"].toString();//19
                                val percentagevalue = dd["percentageval"].toString();//20
                                val product_dec = dd["product_desc"].toString();//21
                                val mrP = dd["mrp"].toString();//22
                                val cate = dd["ctgy"].toString();//23
                                val manufacture = dd["mfr"].toString();//24
                                val ut = dd["ut"].toString();//25
                                val consold = dd["cn_sold "].toString();//26
                                val comm = dd["emp_com"].toString();//27
                                val status = dd["status"].toString();//27
                                val img1n = dd["img1n"].toString();//28
                                val img2n = dd["img2n"].toString();//29
                                val img3n = dd["img3n"].toString();//30
                                val img4n = dd["img4n"].toString();//31
                                val img5n = dd["img5n"].toString();//32
                                val img1url = dd["img1url"].toString();//33
                                val img2url = dd["img2url"].toString();//34
                                val img3url = dd["img3url"].toString();//35
                                val img4url = dd["img4url"].toString();//36
                                val img5url = dd["img5url"].toString();//37


                                idsArray = idsArray.plusElement(ids)
                                nameArray = nameArray.plusElement(pname)
                                sunbnmArray = sunbnmArray.plusElement(manufacture)
                                bcArray = bcArray.plusElement("BC - " + bcode)

                                mlArray = mlArray.plusElement(weight + "ml")
                                priceArray = priceArray.plusElement("MRP - " + mrP)
                                mhArray = mhArray.plusElement(maxstock)
                                sohArray = sohArray.plusElement(stockonhand)
                                disArray = disArray.plusElement("Qty - " + stockonhand)





                                println(Arrays.toString(disArray))

                                val ur = img1url //"https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fourimages-77.jpg?alt=media&token=43c72e90-76fb-48f4-8221-db6e3b63ad25"
                                if (ur.isNotEmpty()) {
                                    primgArray = primgArray.plusElement(ur)
                                } else {
                                    primgArray = primgArray.plusElement("https://firebasestorage.googleapis.com/v0/b/new-service-9f6f2.appspot.com/o/service%2Fprofile.png?alt=media&token=389c7936-030e-4898-b716-4fb3448a3c71")
                                }


                            }
                            val whatever = mybranchAdapter(this@MybranchActivity, idsArray, nameArray, mlArray, sunbnmArray, bcArray, priceArray, disArray, primgArray)
                            val slist = findViewById<View>(R.id.mylist) as ListView
                            slist.adapter = whatever
                            whatever.notifyDataSetChanged()
                        }
                    }
                }

    }*/


    //-------------------Get all products from db----------------------//

    fun ggg() {
        val pDialog = SweetAlertDialog(this, SweetAlertDialog.PROGRESS_TYPE);
        pDialog.getProgressHelper().setBarColor(Color.parseColor("#263238"));
        pDialog.setTitleText("Loading...")
        pDialog.setCancelable(false)
        pDialog.show();
        db.collection("product")
                .get()
                .addOnCompleteListener { task ->

                    if (task.isSuccessful) {
                        Log.d(TAG, "cleared")
                        if (task.result.isEmpty == false) {
                            for (document in task.result) {
                                Log.d(TAG, "dapet" + document.id + " => " + document.data)
                                val dd = document.data

                                val id = document.id;//0
                                idstr = id

                                idstrarr = idstrarr.plusElement(idstr)
                                getsoh(id, brids)


                            }
                            pDialog.dismiss()


                        }

                    }
                }

    }

    override fun onBackPressed() {
        if(cardsearch.visibility==View.VISIBLE){   //If search view is visble,
            cardsearch.visibility = View.GONE     //Close the search view

            mylist.visibility = View.VISIBLE  //Visible the listview
            nores.visibility  = View.GONE//Gone the 'no results found' view
            ggg() //And load the products to list

        }
        else{
            //---------------Finish the activity-------------------------//

            val o= Intent(this@MybranchActivity,stocklevelsActivity::class.java)
            o.putExtra("from_stock","mystock")
            o.putExtra("viewstklvl",viewstklvls)
            o.putExtra("bkey",brids)
            startActivity(o)
            overridePendingTransition(R.anim.slide_in_right,R.anim.slide_in_right)
            finish()
        }

    }
    companion object {


        //Listens internet status whether net is on/off.

        private var log_network: View? = null
        private var log_networktext: View? = null
        var pDialogs: SweetAlertDialog? = null
        private var relatively: RelativeLayout?=null
        private var cont: ConstraintLayout?=null
        private val log_str: String? = null

        fun addLogText(log: String?) {

            if(log=="NOT_CONNECT"){

                /// if connection is off then all views becomes disable

                log_network!!.visibility=View.VISIBLE
                log_networktext!!.visibility=View.VISIBLE
                relatively!!.visibility=View.VISIBLE
                cont!!.setBackgroundColor(Color.parseColor("#43161616"))


                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(false);
                }

                try {

                }
                catch (e:Exception){

                }

            }
            else
            {
                /// if connection is off then all views becomes enabled

                log_network!!.visibility=View.GONE
                log_networktext!!.visibility=View.GONE
                relatively!!.visibility=View.GONE
                cont!!.setBackgroundColor(Color.parseColor("#ffffff"))
                for (i  in 0 until cont!!.getChildCount()) {
                    val child = cont!!.getChildAt(i);
                    child.setEnabled(true);
                }

            }
        }
    }

    fun net_status():Boolean{  //Check internet status.

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var connected=false
        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).state == NetworkInfo.State.CONNECTED || connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).state == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true
        } else {
            Toast.makeText(this,"No internet connection",Toast.LENGTH_LONG).show()
            connected = false
        }
        return connected
    }




}

