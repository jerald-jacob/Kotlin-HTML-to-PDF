package com.example.vinitas.gallery.sampledata

import android.R.attr.scheme
import android.R.attr.path
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.support.v4.content.PermissionChecker.checkCallingOrSelfPermission
import android.util.Log.getStackTraceString
import com.facebook.common.file.FileUtils.mkdirs
import java.nio.file.Files.exists

import android.os.Environment.getExternalStorageDirectory
import android.system.Os.mkdir

import android.os.Environment.MEDIA_MOUNTED
import android.os.Environment.DIRECTORY_DCIM
import android.os.Environment.getExternalStoragePublicDirectory
import android.text.TextUtils
import java.io.File
import java.io.IOException


object FileUtils {

    private val JPEG_FILE_PREFIX = "IMG"
    private val JPEG_FILE_SUFFIX = ".jpg"
    private val TAG = "FileUtils"


    private val EXTERNAL_STORAGE_PERMISSION = "android.permission.WRITE_EXTERNAL_STORAGE"

    @Throws(IOException::class)
    fun createTmpFile(context: Context): File {
        var dir: File
        if (TextUtils.equals(Environment.getExternalStorageState(), Environment.MEDIA_MOUNTED)) {
            dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
            if (!dir.exists()) {
                dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM + "/Camera")
                if (!dir.exists()) {
                    dir = getCacheDirectory(context, true)
                }
            }
        } else {
            dir = getCacheDirectory(context, true)
        }
        return File.createTempFile(JPEG_FILE_PREFIX, JPEG_FILE_SUFFIX, dir)
    }

    /**
     * Returns application cache directory. Cache directory will be created on SD card
     * *("/Android/data/[app_package_name]/cache")* (if card is mounted and app has appropriate permission) or
     * on device's file system depending incoming parameters.
     *
     * @param context        Application context
     * @param preferExternal Whether prefer external location for cache
     * @return Cache [directory][File].<br></br>
     * **NOTE:** Can be null in some unpredictable cases (if SD card is unmounted and
     * [Context.getCacheDir()][android.content.Context.getCacheDir] returns null).
     */
    @JvmOverloads
    fun getCacheDirectory(context: Context, preferExternal: Boolean = true): File {
        var appCacheDir: File? = null
        var externalStorageState: String
        try {
            externalStorageState = Environment.getExternalStorageState()
        } catch (e: NullPointerException) { // (sh)it happens (Issue #660)
            externalStorageState = ""
        } catch (e: IncompatibleClassChangeError) { // (sh)it happens too (Issue #989)
            externalStorageState = ""
        }

        if (preferExternal && MEDIA_MOUNTED == externalStorageState && hasExternalStoragePermission(context)) {
            appCacheDir = getExternalCacheDir(context)
        }
        if (appCacheDir == null) {
            appCacheDir = context.getCacheDir()
        }
        if (appCacheDir == null) {
            val cacheDirPath = context.getFilesDir().getPath() + context.getPackageName() + "/cache/"
            appCacheDir = File(cacheDirPath)
        }
        return appCacheDir
    }

    /**
     * Returns individual application cache directory (for only image caching from ImageLoader). Cache directory will be
     * created on SD card *("/Android/data/[app_package_name]/cache/uil-images")* if card is mounted and app has
     * appropriate permission. Else - Android defines cache directory on device's file system.
     *
     * @param context Application context
     * @param cacheDir Cache directory path (e.g.: "AppCacheDir", "AppDir/cache/images")
     * @return Cache [directory][File]
     */
    fun getIndividualCacheDirectory(context: Context, cacheDir: String): File {
        val appCacheDir = getCacheDirectory(context)
        var individualCacheDir = File(appCacheDir, cacheDir)
        if (!individualCacheDir.exists()) {
            if (!individualCacheDir.mkdir()) {
                individualCacheDir = appCacheDir
            }
        }
        return individualCacheDir
    }

    private fun getExternalCacheDir(context: Context): File? {
        val dataDir = File(File(Environment.getExternalStorageDirectory(), "Android"), "data")
        val appCacheDir = File(File(dataDir, context.getPackageName()), "cache")
        if (!appCacheDir.exists()) {
            if (!appCacheDir.mkdirs()) {
                return null
            }
            try {
                File(appCacheDir, ".nomedia").createNewFile()
            } catch (e: IOException) {

            }

        }
        return appCacheDir
    }

    private fun hasExternalStoragePermission(context: Context): Boolean {
        val perm = context.checkCallingOrSelfPermission(EXTERNAL_STORAGE_PERMISSION)
        return perm == PackageManager.PERMISSION_GRANTED
    }

    fun getUriByResId(resId: Int): Uri {

        return Uri.Builder().scheme("res").path(resId.toString()).build()
    }


}
/**
 * Returns application cache directory. Cache directory will be created on SD card
 * *("/Android/data/[app_package_name]/cache")* if card is mounted and app has appropriate permission. Else -
 * Android defines cache directory on device's file system.
 *
 * @param context Application context
 * @return Cache [directory][File].<br></br>
 * **NOTE:** Can be null in some unpredictable cases (if SD card is unmounted and
 * [Context.getCacheDir()][android.content.Context.getCacheDir] returns null).
 */